#!/usr/bin/env python3
import argparse,concurrent.futures,hashlib,json,pathlib,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('destination',type=pathlib.Path);p.add_argument('--side',choices=['client','server'],default='server');a=p.parse_args();a.destination.mkdir(parents=True,exist_ok=True)
 def fetch(m):
  if m['env'][a.side]=='unsupported':return 'SKIP '+m['slug']
  f=m['file'];out=a.destination/pathlib.Path(f['path']).name
  if not out.exists() or hashlib.sha512(out.read_bytes()).hexdigest()!=f['hashes']['sha512']:
   with urllib.request.urlopen(urllib.request.Request(f['downloads'][0],headers={'User-Agent':'BunkerRelay/0.1'}),timeout=120) as r:data=r.read()
   if hashlib.sha512(data).hexdigest()!=f['hashes']['sha512']:raise RuntimeError('Hash mismatch '+m['slug'])
   temp=out.with_suffix('.jar.part');temp.write_bytes(data);temp.replace(out)
  return 'OK '+m['slug']
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
  for s in pool.map(fetch,json.loads((ROOT/'pack.lock.json').read_text())['mods']):print(s,flush=True)
if __name__=='__main__':main()
