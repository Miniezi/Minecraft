#!/usr/bin/env python3
import io,json,pathlib,sys,tomllib,zipfile,re
ROOT=pathlib.Path(__file__).resolve().parents[1];folder=pathlib.Path(sys.argv[1]);mods={};required=[];incompatible=[];duplicates=[]
def scan(data,origin):
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  for name in ['META-INF/neoforge.mods.toml','META-INF/mods.toml']:
   if name not in z.namelist():continue
   t=tomllib.loads(z.read(name).decode())
   for m in t.get('mods',[]):
    if m['modId'] in mods and mods[m['modId']][0]!=m.get('version'):duplicates.append(m['modId'])
    mods[m['modId']]=[m.get('version'),origin]
   for owner,ds in t.get('dependencies',{}).items():
    for d in ds:
     if d.get('type','').lower()=='required' or d.get('mandatory')==True:required.append([owner,d])
     if d.get('type','').lower()=='incompatible':incompatible.append([owner,d])
   break
  if 'META-INF/jarjar/metadata.json' in z.namelist():
   for j in json.loads(z.read('META-INF/jarjar/metadata.json'))['jars']:
    if j['path'] in z.namelist():scan(z.read(j['path']),origin+'!'+j['path'])
for m in json.loads((ROOT/'pack.lock.json').read_text())['mods']:
 p=folder/pathlib.Path(m['file']['path']).name
 if not p.exists() and '--server' in sys.argv and m['env']['server']=='unsupported':continue
 scan(p.read_bytes(),p.name)
relay=ROOT/'mod/build/libs/bunkerrelay-0.7.0.jar'
if relay.is_file():scan(relay.read_bytes(),relay.name)
mods.update(minecraft=['1.21.1','runtime'],neoforge=['21.1.265','runtime'])
def cmp(a,b):
 def v(s):
  m=re.match(r'^\d+(?:\.\d+)*',s)
  if not m:raise ValueError(s)
  return tuple(map(int,m[0].split('.')))
 a,b=v(a),v(b);n=max(len(a),len(b));a+=tuple([0]*(n-len(a)));b+=tuple([0]*(n-len(b)));return (a>b)-(a<b)
def fits(v,r):
 if r=='*':return True
 if ',' not in r:return cmp(v,r.strip('[]'))==0
 lo,hi=[s.strip() for s in r[1:-1].split(',')]
 return (not lo or cmp(v,lo)>0 or cmp(v,lo)==0 and r[0]=='[') and (not hi or cmp(v,hi)<0 or cmp(v,hi)==0 and r[-1]==']')
fail=[];unknown=[];checked=0
for owner,d in required:
 if '--server' in sys.argv and d.get('side','BOTH').upper()=='CLIENT':continue
 actual=mods.get(d['modId'])
 if not actual:fail.append([owner,d,'missing']);continue
 try:
  checked+=1
  if not fits(actual[0],d.get('versionRange','[0,)')):fail.append([owner,d,actual[0]])
 except (TypeError,ValueError):unknown.append([owner,d])
for owner,d in incompatible:
 actual=mods.get(d['modId'])
 if actual:
  try:
   if fits(actual[0],d.get('versionRange','[0,)')):fail.append([owner,d,actual[0]])
  except (TypeError,ValueError):unknown.append([owner,d])
result={'mod_ids':mods,'checked_required_ranges':checked,'failures':fail,'unparsed':unknown,'duplicate_versions':duplicates}
(ROOT/'docs/dependency-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:v for k,v in result.items() if k!='mod_ids'})
if fail or unknown or duplicates:raise SystemExit(1)
