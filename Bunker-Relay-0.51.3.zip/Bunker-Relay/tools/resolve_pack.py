#!/usr/bin/env python3
"""Rebuild the Modrinth index from the exact dependency lock."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    mods = json.loads((ROOT / 'pack.lock.json').read_text())['mods']
    projects = {mod['project_id']: mod for mod in mods}
    if len(projects) != len(mods) or len({mod['file']['path'] for mod in mods}) != len(mods):
        raise ValueError('Duplicate project or destination in dependency lock')
    for mod in mods:
        for dep in mod['dependencies']:
            if dep['dependency_type'] != 'required':
                continue
            target = projects.get(dep['project_id'])
            if not target or (dep['version_id'] and target['version_id'] != dep['version_id']):
                raise ValueError(f"{mod['slug']}: unsatisfied dependency {dep}")
    path = ROOT / 'modrinth.index.json'
    index = json.loads(path.read_text())
    index['files'] = [mod['file'] for mod in mods]
    path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')

if __name__ == '__main__':
    main()
