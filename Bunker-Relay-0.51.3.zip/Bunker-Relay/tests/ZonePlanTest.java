import dev.bunkerrelay.ZonePlan;
public class ZonePlanTest {
 public static void main(String[] args){
  for(long seed=0;seed<1000;seed++)for(int d=1;d<=5;d++){
   var sites=ZonePlan.sites(seed,d);
   if(!sites.equals(ZonePlan.sites(seed,d))||sites.size()!=5+2*d)throw new AssertionError("determinism/count");
   for(var a:sites){
    if(Math.abs(a.x())+5>=94||Math.abs(a.z())+5>=94)throw new AssertionError("bounds");
    if(Math.abs(a.x())<10&&Math.abs(a.z())<10)throw new AssertionError("extraction");
    for(var b:sites)if(a!=b&&Math.abs(a.x()-b.x())<=10&&Math.abs(a.z()-b.z())<=10)throw new AssertionError("overlap");
   }
  }
  for(int t=2;t<=5;t++)if(ZonePlan.lootCount(t)<=ZonePlan.lootCount(t-1))throw new AssertionError("loot");
  for(int d:new int[]{-1,0,6})try{ZonePlan.sites(1,d);throw new AssertionError("invalid tier");}catch(IllegalArgumentException ok){}
  System.out.println("PASS: 5000 deterministic layouts, bounds, overlap, extraction, loot, invalid tiers");
 }
}
