import dev.bunkerrelay.SectorPlan;
public class SectorPlanTest {
 public static void main(String[] args){
  if(SectorPlan.DEFAULT_SIZE!=4096||!SectorPlan.center(0).equals(new SectorPlan.Center(0,0)))throw new AssertionError("Default/origin");
  java.util.Set<Integer> xs=new java.util.HashSet<>();
  for(int i=0;i<SectorPlan.GRID;i++){var c=SectorPlan.center(i);if(!xs.add(c.x())||Math.abs(c.x())+4096>=29999984)throw new AssertionError("Duplicate/outside world");}
  for(int n:new int[]{0,1,3499,3500,SectorPlan.MAX_SECTORS-1})for(int size:new int[]{2048,4096,8192}){
   var c=SectorPlan.center(n);if(!SectorPlan.contains(c.x(),c.z(),size,c.x(),c.z()))throw new AssertionError("Center excluded");
   if(SectorPlan.contains(c.x(),c.z(),size,c.x()+size/2.0,c.z())||SectorPlan.contains(c.x(),c.z(),size,c.x(),c.z()-size/2.0))throw new AssertionError("Boundary included");
   if(size>=SectorPlan.STRIDE)throw new AssertionError("Overlap");
  }
  if(SectorPlan.validSize(192)||SectorPlan.validSize(9000))throw new AssertionError("Invalid size");
  try{SectorPlan.center(SectorPlan.MAX_SECTORS);throw new AssertionError("Overflow");}catch(IllegalArgumentException expected){}
  System.out.println("SectorPlan PASS: default, boundaries, non-overlap, world limits");
 }
}
