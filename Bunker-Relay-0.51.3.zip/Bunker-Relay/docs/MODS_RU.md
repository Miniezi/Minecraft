# Моды 0.7.0

26 внешних файлов + собственный Bunker Relay. Версии закреплены в pack.lock.json.

| Мод | Версия | Источник |
|---|---|---|
| AmbientSounds | 6.3.11 | [ambientsounds](https://modrinth.com/mod/ambientsounds) |
| AppleSkin | 3.0.9+mc1.21 | [appleskin](https://modrinth.com/mod/appleskin) |
| Athena | 4.0.6 | [athena-ctm](https://modrinth.com/mod/athena-ctm) |
| Chipped | 4.0.2 | [chipped](https://modrinth.com/mod/chipped) |
| Create | 6.0.10+mc1.21.1 | [create](https://modrinth.com/mod/create) |
| CreativeCore | 2.13.53 | [creativecore](https://modrinth.com/mod/creativecore) |
| Dynamic FPS | 3.11.4 | [dynamic-fps](https://modrinth.com/mod/dynamic-fps) |
| EMI | 1.1.24+1.21.1+neoforge | [emi](https://modrinth.com/mod/emi) |
| Entity Culling | 1.11.3 | [entityculling](https://modrinth.com/mod/entityculling) |
| Farmer's Delight | 1.21.1-1.3.4 | [farmers-delight](https://modrinth.com/mod/farmers-delight) |
| FerriteCore | 7.0.3-neoforge | [ferrite-core](https://modrinth.com/mod/ferrite-core) |
| ImmediatelyFast | 1.6.15+1.21.1-neoforge | [immediatelyfast](https://modrinth.com/mod/immediatelyfast) |
| Jade 🔍 | 15.10.6+neoforge | [jade](https://modrinth.com/mod/jade) |
| ModernFix | 5.27.27+mc1.21.1 | [modernfix](https://modrinth.com/mod/modernfix) |
| Moonlight Lib | 1.21.1-3.8.2 | [moonlight](https://modrinth.com/mod/moonlight) |
| Mouse Tweaks | 1.21-2.26.1-neoforge | [mouse-tweaks](https://modrinth.com/mod/mouse-tweaks) |
| Resourceful Lib | 3.0.12 | [resourceful-lib](https://modrinth.com/mod/resourceful-lib) |
| Simple Voice Chat | neoforge-1.21.1-2.6.22 | [simple-voice-chat](https://modrinth.com/mod/simple-voice-chat) |
| Sodium | mc1.21.1-0.8.13-neoforge | [sodium](https://modrinth.com/mod/sodium) |
| Sophisticated Backpacks | 1.21.1-3.26.20.2244 | [sophisticated-backpacks](https://modrinth.com/mod/sophisticated-backpacks) |
| Sophisticated Core | 1.21.1-1.5.31.2460 | [sophisticated-core](https://modrinth.com/mod/sophisticated-core) |
| Sophisticated Storage | 1.21.1-1.6.16.2222 | [sophisticated-storage](https://modrinth.com/mod/sophisticated-storage) |
| spark | 1.10.124-neoforge-1.21.1 | [spark](https://modrinth.com/mod/spark) |
| Supplementaries | 1.21.1-4.0.2 | [supplementaries](https://modrinth.com/mod/supplementaries) |
| The Lost Cities | 1.21-8.4.6 | [the-lost-cities](https://modrinth.com/mod/the-lost-cities) |
| [TaCZ] Timeless and Classics Zero | 1.2.0 | [timeless-and-classics-zero](https://modrinth.com/mod/timeless-and-classics-zero) |

Aeronautics, Sable, Corpse и Lootr исключены. Create, Lost Cities, TaCZ и Sophisticated остаются.

0.4 добавляет серверные варианты мобов и события внутри Bunker Relay; дополнительных модов не требуется.
