package dev.bunkerrelay;

import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;

final class AirdropIntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        verifyScanner(level,state);
        var director=RaidDirector.get(server);
        var site=new BlockPos(state.centerX+44,level.getMaxBuildHeight()-20,state.centerZ+44);
        level.setBlock(site.below(),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        level.setBlock(site,Blocks.AIR.defaultBlockState(),3);
        level.setBlock(site.above(),Blocks.AIR.defaultBlockState(),3);
        director.dropDue=director.elapsed;
        director.dropPosition=site.asLong();
        director.dropPending=true;
        director.dropLanded=false;
        int originalTier=state.activeLoot;
        state.activeLoot=4;
        Airdrop.tick(level,state,director,List.of());

        check(director.dropLanded&&!director.dropPending,"landing");
        check(RaidVisuals.descentHeight(25)==50&&RaidVisuals.descentHeight(10)==25
            &&RaidVisuals.descentHeight(.2)==.5&&RaidVisuals.descentHeight(-1)==0,"bounded animation");
        RaidVisuals.dropFrame(level,site,4.8);
        RaidVisuals.beacon(level,site,level.getGameTime());
        RaidVisuals.breachFrame(level,site,.5);
        RaidVisuals.extraction(level,site,40);
        var box=level.getBlockEntity(site);
        check(box instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity,"personal crate");
        check(PersonalLoot.templateItem(level,site,0).is(Items.EMERALD)&&PersonalLoot.templateItem(level,site,2).is(Items.DIAMOND),"premium cargo");
        Airdrop.tick(level,state,director,List.of());
        check(level.getBlockEntity(site)==box,"no refill");
        var saved=RaidDirector.load(director.save(new CompoundTag(),server.registryAccess()),server.registryAccess());
        check(saved.dropLanded&&saved.dropPosition==site.asLong(),"persistent delivery state");
        verifyBreach(level,state,director,site);
        state.activeLoot=originalTier;
        verifyDeath(server,state,level,site.offset(12,0,0));
        director.setDirty();
        server.saveEverything(false,true,true);
        System.out.println("RELAY_AIRDROP_PASS landing=true personal=true valuables=true one_shot=true breach=true");
        server.halt(false);
    }

    private static void verifyScanner(ServerLevel level,RelayState state){
        var origin=new BlockPos(state.centerX,level.getMaxBuildHeight()-20,state.centerZ);
        var site=origin.offset(39,0,7);
        var actor=new net.neoforged.neoforge.common.util.FakePlayer(level,
            new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(),"ScannerTester"));
        actor.moveTo(origin.getX()+.5,origin.getY(),origin.getZ()+.5,0,0);
        level.setBlock(site.below(),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        level.setBlock(site,Blocks.AIR.defaultBlockState(),3);
        level.setBlock(site.above(),Blocks.AIR.defaultBlockState(),3);
        int originalResearch=state.research;
        int scanner=1<<TrophyResearch.Part.SCANNER.ordinal();
        try{
            state.research=originalResearch&~scanner;
            var baseline=new RaidDirector();
            baseline.elapsed=130;
            Airdrop.tick(level,state,baseline,List.of(actor));
            check(!baseline.dropPending,"ordinary bearings miss the alternate platform");

            state.research=originalResearch|scanner;
            var upgraded=new RaidDirector();
            upgraded.elapsed=130;
            Airdrop.tick(level,state,upgraded,List.of(actor));
            check(upgraded.dropPending&&upgraded.dropPosition==site.asLong()&&upgraded.dropDue==150,
                "installed scanner finds the alternate platform at the normal drop time");
            System.out.println("RELAY_AIRDROP_SCANNER_PASS");
        }finally{
            state.research=originalResearch;
            level.removeBlock(site.below(),false);
        }
    }

    private static void verifyBreach(ServerLevel level,RelayState state,RaidDirector director,BlockPos site){
        var actor=new net.neoforged.neoforge.common.util.FakePlayer(level,
            new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(),"CrateTester"));
        actor.moveTo(site.getX()+.5,site.getY(),site.getZ()+.5);
        var ground=site.north(2);
        level.setBlock(ground.below(),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        level.setBlock(ground,Blocks.AIR.defaultBlockState(),3);
        level.setBlock(ground.above(),Blocks.AIR.defaultBlockState(),3);
        check(Airdrop.status(director).contains("маяк активен"),"beacon online");
        check(!Airdrop.startBreach(actor,director,site),"normal opening leaves beacon active");
        actor.setShiftKeyDown(true);
        check(Airdrop.startBreach(actor,director,site)&&director.dropSecurity.getBoolean("muted"),"beacon silenced");
        director.elapsed+=11;
        Airdrop.tick(level,state,director,List.of(actor));
        check(!director.dropSecurity.contains("secured"),"timed breach");
        actor.moveTo(site.getX()+10,site.getY(),site.getZ());
        Airdrop.tick(level,state,director,List.of(actor));
        check(!director.dropSecurity.hasUUID("breacher"),"walking away cancels");
        actor.moveTo(site.getX()+.5,site.getY(),site.getZ()+.5);
        check(Airdrop.startBreach(actor,director,site),"breach can be retried");
        director.elapsed+=12;
        Airdrop.tick(level,state,director,List.of(actor));
        check(director.dropSecurity.contains("secured"),"compartment unlocked");
        var secured=BlockPos.of(director.dropSecurity.getLong("secured"));
        var chest=level.getBlockEntity(secured);
        check(PersonalLoot.templateItem(level,secured,0).is(Items.GOLDEN_APPLE)
            &&!PersonalLoot.templateItem(level,secured,3).isEmpty(),"secure reward");
        Airdrop.startBreach(actor,director,site);
        Airdrop.tick(level,state,director,List.of(actor));
        check(level.getBlockEntity(secured)==chest,"secure reward opens once");
        var registry=level.registryAccess();
        var loaded=RaidDirector.load(director.save(new CompoundTag(),registry),registry);
        check(loaded.dropSecurity.equals(director.dropSecurity),"security survives reload");
    }

    private static void verifyDeath(MinecraftServer server,RelayState state,ServerLevel level,BlockPos at){
        var id=java.util.UUID.randomUUID();
        var raider=new ServerPlayer(server,level,new com.mojang.authlib.GameProfile(id,"AirdropDeath"),net.minecraft.server.level.ClientInformation.createDefault()) { @Override public void closeContainer(){doCloseContainer();} };
        raider.setPos(at.getX()+.5,at.getY(),at.getZ()+.5);
        raider.getInventory().setItem(0,new net.minecraft.world.item.ItemStack(Items.IRON_SWORD));
        check(RaidRules.begin(raider,state)==null,"raid started");
        raider.getInventory().setItem(1,new net.minecraft.world.item.ItemStack(Items.EMERALD,7));
        var source=level.damageSources().genericKill();
        level.getChunkAt(at);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.entity.living.LivingDeathEvent(raider,source));
        check(RaidRules.record(raider).getString("status").equals("DEAD")
            &&raider.getInventory().getItem(1).getCount()==7,"death leaves equipment to vanilla");
        var drops=new java.util.ArrayList<net.minecraft.world.entity.item.ItemEntity>();
        raider.captureDrops(drops);
        raider.getInventory().dropAll();
        raider.captureDrops(null);
        check(drops.stream().anyMatch(item->item.getItem().is(Items.EMERALD)&&item.getItem().getCount()==7),
            "vanilla produces drop entities");
        var event=new net.neoforged.neoforge.event.entity.living.LivingDropsEvent(raider,source,drops,false);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(event);
        check(!event.isCanceled()&&!drops.isEmpty(),"drop event remains enabled");
        var respawned=new net.neoforged.neoforge.common.util.FakePlayer(server.getLevel(state.hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER),
            new com.mojang.authlib.GameProfile(id,"AirdropDeath"));
        // FakePlayer has no network channel for cross-dimension travel; settle from the respawn level.
        RaidRules.settle(respawned,false);
        check(respawned.getInventory().isEmpty()&&!RaidRules.active(respawned),"no starter equipment restored");
        System.out.println("RELAY_DEATH_DROPS_PASS");
    }

    private static void check(boolean value,String message){if(!value)throw new IllegalStateException("AIRDROP "+message);}
    private AirdropIntegrationTest(){}
}
