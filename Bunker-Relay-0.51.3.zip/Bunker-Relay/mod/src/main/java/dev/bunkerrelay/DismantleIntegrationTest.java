package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import com.tacz.guns.api.item.IAmmo;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.api.item.builder.AttachmentItemBuilder;
import com.tacz.guns.api.item.builder.GunItemBuilder;
import java.util.UUID;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

final class DismantleIntegrationTest {
    static void verify(MinecraftServer server) {
        var level=server.getLevel(BunkerRelay.HUB);
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"RelayDismantle")){
            @Override public java.util.OptionalInt openMenu(MenuProvider menu){
                containerMenu=menu.createMenu(78,getInventory(),this);
                return java.util.OptionalInt.of(78);
            }
        };
        var terminal=HubBuilder.TERMINAL;
        player.moveTo(terminal.getX(),terminal.getY(),terminal.getZ()+1);
        var pistol=GunItemBuilder.create().setId(ResourceLocation.parse("tacz:glock_17"))
            .setAmmoCount(5).build(player.registryAccess());
        var gun=(IGun)pistol.getItem();
        gun.setBulletInBarrel(pistol,true);
        var magazine=AttachmentItemBuilder.create().setId(ResourceLocation.parse("tacz:light_extended_mag_1")).build();
        gun.installAttachment(player.registryAccess(),pistol,magazine);
        var inventory=player.getInventory();
        inventory.selected=0;
        inventory.setItem(0,pistol);
        require(IGun.mainHandHoldGun(player),"gun held in main hand");
        var hit=new BlockHitResult(Vec3.atCenterOf(terminal),Direction.SOUTH,terminal,false);
        var click=NeoForge.EVENT_BUS.post(new PlayerInteractEvent.RightClickBlock(player,InteractionHand.MAIN_HAND,terminal,hit));
        require(click.isCanceled()&&player.containerMenu instanceof TerminalMenu,"normal terminal interaction with gun");
        player.containerMenu.clicked(5,0,ClickType.PICKUP,player);
        player.containerMenu.clicked(17,0,ClickType.PICKUP,player);
        require(player.containerMenu instanceof DismantleMenu,"catalog opens from base tab");
        var menu=player.containerMenu;
        var lore=menu.getSlot(9).getItem().get(DataComponents.LORE);
        require(lore!=null&&lore.lines().size()>=4&&menu.getSlot(52).getItem().isEmpty(),"preview before confirmation");
        var plan=GunDismantle.plan(player,pistol);
        require(plan.allowed()&&plan.outputs().stream().anyMatch(stack->stack.getItem() instanceof IAmmo&&stack.getCount()==6),"magazine and chamber preview");
        require(gun.getAttachmentTag(pistol,AttachmentType.EXTENDED_MAG)!=null
            &&plan.outputs().stream().anyMatch(stack->ItemStack.isSameItemSameComponents(stack,magazine)),"installed module preview");

        menu.clicked(9,0,ClickType.PICKUP,player);
        require(inventory.getItem(0)==pistol&&!menu.getSlot(52).getItem().isEmpty(),"selection is non-destructive");
        for(int i=1;i<36;i++)inventory.setItem(i,new ItemStack(Items.DIRT,64));
        menu.clicked(52,0,ClickType.PICKUP,player);
        require(inventory.getItem(0)==pistol,"full inventory cancels transaction");
        for(int i=1;i<36;i++)inventory.setItem(i,ItemStack.EMPTY);
        menu.clicked(9,0,ClickType.PICKUP,player);
        inventory.setItem(0,new ItemStack(Items.STICK));
        menu.clicked(52,0,ClickType.PICKUP,player);
        require(inventory.getItem(0).is(Items.STICK),"stale selection preserves replacement");
        inventory.setItem(0,pistol);
        DismantleMenu.open(player,false);
        menu=player.containerMenu;
        menu.clicked(9,0,ClickType.PICKUP,player);
        menu.clicked(52,0,ClickType.PICKUP,player);
        menu.clicked(52,0,ClickType.PICKUP,player);
        require(inventory.items.stream().noneMatch(stack->stack.getItem() instanceof IGun),"gun consumed once");
        for(var output:plan.outputs()){
            int count=inventory.items.stream().filter(stack->ItemStack.isSameItemSameComponents(stack,output))
                .mapToInt(ItemStack::getCount).sum();
            require(count==output.getCount(),"exact preview payout");
        }
        System.out.println("RELAY_DISMANTLE_PASS");
    }

    private static void require(boolean condition,String message){
        if(!condition)throw new IllegalStateException("Gun dismantle: "+message);
    }
}
