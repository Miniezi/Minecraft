package dev.bunkerrelay;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;

final class BunkerRequests {
    private static final String TAG = "relay_bunker_request";
    private static final int REQUIRED = 2;

    enum Request {
        MEDIC("Запасы медпункта", "Медицинские партии · карантинная больница", "Медикаменты дешевле на 15%"),
        ENGINEER("Ремонтный стенд", "Блоки питания · шахта, мастерская, станция биомассы", "Ремонт снаряжения дешевле на 25%");

        final String title, source, reward;
        Request(String title, String source, String reward) {
            this.title = title;
            this.source = source;
            this.reward = reward;
        }

        ItemStack item() {
            var stack = new ItemStack(this == MEDIC ? Items.PAPER : Items.REDSTONE_BLOCK);
            var data = new CompoundTag();
            data.putString(TAG, name());
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(data));
            stack.set(DataComponents.CUSTOM_NAME, Component.literal(this == MEDIC ? "Медицинская партия" : "Промышленный блок питания"));
            return stack;
        }

        String status(RelayState state) {
            return complete(state) ? "Готово · " + reward : progress(state) + " / " + REQUIRED + " · " + source;
        }

        int progress(RelayState state) { return state.bunkerRequests.getInt(name()); }
        boolean complete(RelayState state) { return progress(state) >= REQUIRED; }
    }

    static Request forSite(String template) {
        return switch (template) {
            case "hospital" -> Request.MEDIC;
            case "mines", "mega_biomass_tower", "kaisyn:outpost/camps/savanna_plateau/side/workshop" -> Request.ENGINEER;
            default -> null;
        };
    }

    static int salvagePrice(ItemStack stack) {
        var data = stack.get(DataComponents.CUSTOM_DATA);
        if (data == null) return 0;
        return switch (data.copyTag().getString(TAG)) {
            case "MEDIC" -> stack.is(Items.PAPER) ? 75 : 0;
            case "ENGINEER" -> stack.is(Items.REDSTONE_BLOCK) ? 100 : 0;
            default -> 0;
        };
    }

    static void contribute(ServerPlayer player, Request request) {
        if (!RelayEconomy.safe(player) || !BunkerRelay.nearTerminal(player)) return;
        var state = RelayState.get(player.server);
        int remaining = REQUIRED - request.progress(state);
        if (remaining <= 0) {
            RaidRules.tell(player, request.reward);
            return;
        }
        var wanted = request.item();
        int initial = remaining;
        for (var stack : player.getInventory().items) if (remaining > 0 && Warehouse.matches(stack, wanted)) {
            int used = Math.min(remaining, stack.getCount());
            stack.shrink(used);
            remaining -= used;
        }
        var warehouse = new Warehouse(player);
        int stored = Math.min(remaining, warehouse.count(wanted));
        if (stored > 0) warehouse.remove(wanted, stored);
        remaining -= stored;
        if (remaining == initial) {
            RaidRules.tell(player, request.source);
            return;
        }
        state.bunkerRequests.putInt(request.name(), REQUIRED - remaining);
        state.setDirty();
        if (stored > 0) warehouse.save();
        else RelayEconomy.save(player);
        player.server.saveEverything(false, true, true);
        RaidRules.tell(player, request.status(state));
    }

    private BunkerRequests() {}
}
