package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;

import java.util.List;

final class SupplySites {
    enum Kind {
        ARMORY("Оружейная",Blocks.RED_CONCRETE,Blocks.DEEPSLATE_BRICKS,3),
        CANTEEN("Полевая столовая",Blocks.LIME_CONCRETE,Blocks.BRICKS,1),
        WAREHOUSE("Грузовой склад",Blocks.ORANGE_CONCRETE,Blocks.GRAY_CONCRETE,2),
        FACTORY("Заводской цех",Blocks.YELLOW_CONCRETE,Blocks.DEEPSLATE_TILES,4);

        final String title;
        final Block stripe,wall;
        final int guards;
        Kind(String title,Block stripe,Block wall,int guards){
            this.title=title;this.stripe=stripe;this.wall=wall;this.guards=guards;
        }
    }

    private static final String SITE="relay_supply_site",CYCLE="relay_supply_cycle",ALARM="relay_supply_alarm";
    private static final int[][] INDOOR_AND_OUTDOOR_POSTS={{-3,-2},{3,-2},{-4,2},{4,2},
        {-7,8},{7,8},{-7,-8},{7,-8},{-8,0},{8,0}};
    private static final int[][] POSTS={{-7,8},{7,8},{-7,-8},{7,-8},{-8,0},{8,0}};

    static Kind select(RelayState state,int sectorX,int sectorZ){
        long roll=RaidDirector.roll(state.seed^0x7355bf93L,sectorX,sectorZ);
        int result=Math.floorMod(roll,9);
        return result<4?Kind.values()[result]:null;
    }

    static void build(ServerLevel level,RelayState state,BlockPos origin,Kind kind){
        int width=kind==Kind.WAREHOUSE?7:6;
        int height=kind==Kind.FACTORY?6:4;
        for(int x=-9;x<=9;x++)for(int z=-9;z<=9;z++){
            boolean inside=Math.abs(x)<=width&&Math.abs(z)<=6;
            for(int y=0;y<=6;y++)put(level,origin,x,y,z,Blocks.AIR);
            for(int y=-3;y<0;y++)if(y==-1||level.isEmptyBlock(origin.offset(x,y,z)))
                put(level,origin,x,y,z,y==-1&&x==0&&z>=1?kind.stripe:Blocks.POLISHED_ANDESITE);
            if(!inside)continue;
            put(level,origin,x,height,z,kind.wall);
            boolean entrance=z==6&&Math.abs(x)<=(kind==Kind.WAREHOUSE?2:1);
            if((Math.abs(x)==width||Math.abs(z)==6)&&!entrance)
                for(int y=0;y<height;y++)
                    put(level,origin,x,y,z,y==1&&Math.abs(x)==width&&Math.abs(z)<4?Blocks.IRON_BARS:kind.wall);
            if(entrance)put(level,origin,x,3,z,kind.stripe);
        }
        for(int side:new int[]{-1,1}){
            put(level,origin,side*2,2,6,Blocks.SEA_LANTERN);
            for(int z=-4;z<=3;z+=2){
                int x=side*4;
                switch(kind){
                    case ARMORY -> {
                        put(level,origin,x,0,z,Blocks.IRON_BLOCK);
                        put(level,origin,x,1,z,Blocks.IRON_BARS);
                    }
                    case CANTEEN -> {
                        put(level,origin,x,0,z,Blocks.SMOOTH_QUARTZ_SLAB);
                        put(level,origin,x+side,0,z,Blocks.SPRUCE_STAIRS);
                    }
                    case WAREHOUSE -> {
                        put(level,origin,x,0,z,Blocks.STRIPPED_SPRUCE_WOOD);
                        put(level,origin,x,1,z,Blocks.SPRUCE_PLANKS);
                        put(level,origin,x,2,z,Blocks.SPRUCE_TRAPDOOR);
                    }
                    case FACTORY -> {
                        for(int y=0;y<4;y++)put(level,origin,x,y,z,Blocks.CUT_COPPER);
                        put(level,origin,x,4,z,Blocks.IRON_BARS);
                    }
                }
            }
        }
        put(level,origin,0,3,-2,Blocks.SEA_LANTERN);
        cache(level,state,origin,kind);
    }

    static void cache(ServerLevel level,RelayState state,BlockPos origin,Kind kind){
        level.setBlock(origin,Blocks.CHEST.defaultBlockState(),2);
        if(!(level.getBlockEntity(origin) instanceof ChestBlockEntity chest))return;
        var note=new ItemStack(Items.PAPER);
        note.set(DataComponents.CUSTOM_NAME,Component.literal(kind.title));
        note.set(DataComponents.LORE,new ItemLore(List.of(Component.literal("Угроза · "+kind.guards+" / 4"))));
        chest.setItem(2,note);
        RaidLoot.specialist(chest,level,state,origin,kind);
        PersonalLoot.convert(level,origin,chest);
        MiniBosses.arm(level,state,origin,MiniBosses.Kind.valueOf(kind.name()));
        var personal=level.getBlockEntity(origin);
        if(personal!=null){
            personal.getPersistentData().putString(SITE,kind.name());
            personal.getPersistentData().putInt(CYCLE,state.generation+(state.generating?1:0));
            personal.setChanged();
        }
    }

    static int alert(ServerPlayer player,RelayState state,BlockPos origin){
        if(player.distanceToSqr(origin.getX()+.5,origin.getY()+.5,origin.getZ()+.5)>18*18)return 0;
        var level=player.serverLevel();
        if(!level.hasChunkAt(origin))return 0;
        var chest=level.getBlockEntity(origin);
        if(chest==null)return 0;
        var data=chest.getPersistentData();
        if(!data.contains(SITE)||data.getInt(CYCLE)!=state.generation)return 0;
        Kind kind;
        try{kind=Kind.valueOf(data.getString(SITE));}
        catch(IllegalArgumentException ignored){return 0;}
        int count=0;
        var guards=new java.util.ArrayList<java.util.UUID>();
        var condition=LandmarkCondition.read(data.getString("relay_landmark_condition"));
        var pressure=EncounterPressure.of(state);
        boolean valuable=kind==Kind.ARMORY||kind==Kind.FACTORY;
        int limit=pressure.guards(kind.guards,valuable);
        limit=switch(condition){
            case ABANDONED -> FieldSecurity.locked(level,state,origin)?1:0;
            case PATROL -> Math.min(POSTS.length,limit+2);
            case INFESTED -> Math.min(POSTS.length,limit+1);
            default -> limit;
        };
        String role=switch(condition){
            case PATROL -> "patrol_site";
            case INFESTED -> "infested_site";
            default -> valuable?"site_heavy":"site_guard";
        };
        if(limit>0&&!data.getBoolean(ALARM)){
            boolean ambush=state.nightRaid||pressure==EncounterPressure.INFECTED||condition==LandmarkCondition.INFESTED;
            int[][] positions=ambush?INDOOR_AND_OUTDOOR_POSTS:POSTS;
            for(int[] post:positions){
                var at=origin.offset(post[0],0,post[1]);
                if(player.distanceToSqr(at.getX()+.5,at.getY()+.5,at.getZ()+.5)<16
                    ||!level.getBlockState(at.below()).isSolidRender(level,at.below()))continue;
                var guard=RaidDirector.spawn(level,state,at,role,player);
                if(guard!=null){guards.add(guard.getUUID());if(++count>=limit)break;}
            }
        }
        MiniBosses.arm(level,state,origin,MiniBosses.Kind.valueOf(kind.name()));
        MiniBosses.encounter(player,state,origin);
        if(count>0){
            data.putBoolean(ALARM,true);
            FieldSecurity.arm(player,state,origin,guards);
            chest.setChanged();
            RaidHud.alert(player,kind.title+" · охрана обнаружила движение");
        }
        return count;
    }

    private static void put(ServerLevel level,BlockPos origin,int x,int y,int z,Block block){
        level.setBlock(origin.offset(x,y,z),block.defaultBlockState(),2);
    }

    private SupplySites(){}
}
