package dev.bunkerrelay;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.neoforged.neoforge.registries.DeferredRegister;

final class RaidHorror {
    static final DeferredRegister<SoundEvent> SOUNDS=DeferredRegister.create(Registries.SOUND_EVENT,"bunkerrelay");
    static final java.util.function.Supplier<SoundEvent> DRONE=SOUNDS.register("field_drone",
        ()->SoundEvent.createVariableRangeEvent(ResourceLocation.parse("bunkerrelay:field_drone")));

    static boolean enabled(ServerPlayer player){
        return !player.getPersistentData().getBoolean("relay_quiet");
    }

    static void atmosphere(ServerPlayer player){
        if(enabled(player))player.playNotifySound(DRONE.get(),SoundSource.AMBIENT,.48f,1f);
    }

    static void footsteps(ServerPlayer player, long roll) {
        double angle = Math.floorMod(roll, 360) * Math.PI / 180;
        double x = player.getX() + Math.cos(angle) * 7;
        double z = player.getZ() + Math.sin(angle) * 7;
        player.connection.send(new ClientboundSoundPacket(Holder.direct(SoundEvents.STONE_STEP),
            SoundSource.AMBIENT, x, player.getY(), z, .65f, .82f, roll));
    }

    static void facelessClue(ServerPlayer player) {
        if (!enabled(player)) return;
        double angle = Math.toRadians(player.getYRot());
        double x = player.getX() + Math.cos(angle) * 9;
        double z = player.getZ() + Math.sin(angle) * 9;
        player.connection.send(new ClientboundSoundPacket(Holder.direct(SoundEvents.STONE_STEP),
            SoundSource.AMBIENT, x, player.getY(), z, .8f, .58f, player.serverLevel().getGameTime()));
        player.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.AMBIENT, .4f, .65f);
        RaidVisuals.clue(player,x,z);
    }

    private RaidHorror(){}
}
