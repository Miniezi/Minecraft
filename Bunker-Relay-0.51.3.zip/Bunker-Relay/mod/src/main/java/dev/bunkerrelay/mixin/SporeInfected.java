package dev.bunkerrelay.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "com.Harbinger.Spore.Sentities.BaseEntities.Infected", remap = false)
abstract class SporeInfected {
    @Inject(method = "canStarve", at = @At("HEAD"), cancellable = true)
    private void bunkerrelay$noStarvation(CallbackInfoReturnable<Boolean> result) {
        result.setReturnValue(false);
    }

    @Inject(method = "setEvoPoints", at = @At("HEAD"), cancellable = true)
    private void bunkerrelay$noEvolutionProgress(Integer points, CallbackInfo result) {
        result.cancel();
    }

    @Inject(method = "getEvoPoints", at = @At("HEAD"), cancellable = true)
    private void bunkerrelay$ignoreSavedEvolution(CallbackInfoReturnable<Integer> result) {
        result.setReturnValue(0);
    }
}
