package dev.bunkerrelay;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

final class PdaProtection {
    private static final String RETURN="relay_return_pda";

    static void register(){
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST,PdaProtection::drops);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,PdaProtection::toss);
    }

    static boolean isPda(ItemStack stack){return stack.is(PocketDevice.ITEM.get());}

    private static void toss(ItemTossEvent event){
        if(!(event.getPlayer() instanceof ServerPlayer player)||!isPda(event.getEntity().getItem()))return;
        event.setCanceled(true);
        retain(player,event.getEntity().getItem());
    }

    private static void drops(LivingDropsEvent event){
        if(event.getEntity() instanceof ServerPlayer player&&event.getDrops().removeIf(item->isPda(item.getItem())))
            player.getPersistentData().putBoolean(RETURN,true);
    }

    static void retain(ServerPlayer player,ItemStack stack){
        if(!isPda(stack))return;
        SafeInventory.insert(player.getInventory(),stack);
        if(!stack.isEmpty()){
            player.getPersistentData().putBoolean(RETURN,true);
            stack.setCount(0);
        }
        player.inventoryMenu.broadcastChanges();
    }

    static void clonePlayer(ServerPlayer old,ServerPlayer replacement){
        if(old.getPersistentData().getBoolean(RETURN))
            replacement.getPersistentData().putBoolean(RETURN,true);
    }

    static void restore(ServerPlayer player){
        var data=player.getPersistentData();
        if(!player.isAlive()||!data.getBoolean(RETURN))return;
        if(player.getInventory().contains(new ItemStack(PocketDevice.ITEM.get()))){
            data.remove(RETURN);
            return;
        }
        var device=new ItemStack(PocketDevice.ITEM.get());
        if(SafeInventory.capacity(player.getInventory(),device)==0)return;
        SafeInventory.insert(player.getInventory(),device);
        data.remove(RETURN);
        player.inventoryMenu.broadcastChanges();
    }

    private PdaProtection(){}
}
