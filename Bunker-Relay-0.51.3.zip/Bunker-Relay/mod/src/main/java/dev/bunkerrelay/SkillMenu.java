package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

public final class SkillMenu extends ChestMenu {
    enum Skill {
        SCOUT("Разведчик","Эвакуация теперь мгновенная · очки возвращены",Items.COMPASS,10,1,null),
        VETERAN("Полевой ветеран","Эвакуация теперь мгновенная · очки возвращены",Items.ENDER_PEARL,19,2,SCOUT),
        DEALER("Переговорщик","+60 кр. за первую эвакуацию из новой зоны",Items.EMERALD,13,1,null),
        BROKER("Снабженец","+250 кр. к бюджету скупщика при обновлении",Items.GOLD_INGOT,22,2,DEALER),
        ORDERLY("Санитар","Перевязка напарника за 1 секунду",Items.PAPER,10,1,null),
        PARAMEDIC("Фельдшер","Поднятый напарник получает 12 здоровья",Items.GOLDEN_APPLE,19,2,ORDERLY);
        final String title,effect;
        final Item icon;
        final int slot,cost;
        final Skill prerequisite;
        Skill(String title,String effect,Item icon,int slot,int cost,Skill prerequisite){
            this.title=title;this.effect=effect;this.icon=icon;this.slot=slot;this.cost=cost;this.prerequisite=prerequisite;
        }
    }

    private final ServerPlayer owner;
    private final SimpleContainer panel;
    SkillMenu(int id,Inventory inventory){this(id,inventory,null,new SimpleContainer(27));}
    private SkillMenu(int id,Inventory inventory,ServerPlayer owner,SimpleContainer panel){
        super(RelayMenus.SKILLS.get(),id,inventory,panel,3);
        this.panel=panel;
        this.owner=owner;
        if(owner!=null)refresh();
    }

    static boolean has(ServerPlayer player,Skill skill){
        return (RelayEconomy.account(player).getInt("skillMask") & 1<<skill.ordinal())!=0;
    }

    static int points(ServerPlayer player){
        var account=RelayEconomy.account(player);
        int mask=account.getInt("skillMask");
        int scout=1<<Skill.SCOUT.ordinal(),veteran=1<<Skill.VETERAN.ordinal();
        int retired=scout|veteran;
        if((mask&retired)!=0){
            int refund=((mask&scout)!=0?Skill.SCOUT.cost:0)+((mask&veteran)!=0?Skill.VETERAN.cost:0);
            account.putInt("skillMask",mask&~retired);
            account.putInt("skillSpent",Math.max(0,account.getInt("skillSpent")-refund));
            RelayEconomy.save(player);
        }
        return Math.max(0,account.getCompound("paidZones").size()-account.getInt("skillSpent"));
    }

    static int open(ServerPlayer player){
        if(!RelayEconomy.safe(player))return 0;
        player.openMenu(new SimpleMenuProvider((id,inv,ignored)->new SkillMenu(id,inv,player,new SimpleContainer(27)),
            Component.literal("Навыки")));
        return 1;
    }

    static int learn(ServerPlayer player,Skill skill){
        if(skill==Skill.SCOUT||skill==Skill.VETERAN)return 0;
        if(!RelayEconomy.safe(player)||has(player,skill)||points(player)<skill.cost
            ||skill.prerequisite!=null&&!has(player,skill.prerequisite))return 0;
        var account=RelayEconomy.account(player);
        account.putInt("skillMask",account.getInt("skillMask")|1<<skill.ordinal());
        account.putInt("skillSpent",account.getInt("skillSpent")+skill.cost);
        RelayEconomy.save(player);
        RaidRules.tell(player,"Изучен навык «"+skill.title+"»");
        return 1;
    }

    private void refresh(){
        icon(0,Items.COMPASS,"КПК · База","Назад");
        icon(4,Items.EXPERIENCE_BOTTLE,"Очки: "+points(owner),"Одно за первую эвакуацию из каждой зоны");
        for(var skill:Skill.values()){
            if(skill==Skill.SCOUT||skill==Skill.VETERAN){

                continue;
            }
            boolean learned=has(owner,skill);
            String requirement=learned?"Изучено":skill.cost+" оч. "+(skill.prerequisite==null?"":"· нужен "+skill.prerequisite.title);
            icon(skill.slot,skill.icon,skill.title,skill.effect+" · "+requirement);
        }
    }
    private void icon(int slot,Item item,String name,String hint){
        var stack=new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME,Component.literal(name));
        stack.set(DataComponents.LORE,new ItemLore(List.of(Component.literal(hint))));
        panel.setItem(slot,stack);
    }
    @Override public void clicked(int slot,int button,ClickType type,Player player){
        if(player!=owner||type!=ClickType.PICKUP||button!=0||!stillValid(player))return;
        if(slot==0){PocketDevice.open(owner,PocketDevice.Page.BASE);return;}
        for(var skill:Skill.values())if(slot==skill.slot){
            if(learn(owner,skill)==0)RaidRules.tell(owner,"Проверьте очки и предыдущий навык.");
            refresh();sendAllDataToRemote();return;
        }
    }
    @Override public ItemStack quickMoveStack(Player player,int slot){return ItemStack.EMPTY;}
    @Override public boolean stillValid(Player player){return owner!=null&&player==owner&&RelayEconomy.safe(owner);}
}
