package dev.bunkerrelay;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;

final class CargoContract {
    private static final ResourceLocation WEIGHT=ResourceLocation.parse("bunkerrelay:cargo_weight");

    static void prepare(ServerLevel level,RelayState state) {
        var signal=RaidDirector.get(level.getServer()).rooms.stream()
            .filter(room->room.getString("type").equals("signal")).findFirst().orElseThrow();
        var station=new BlockPos(signal.getInt("x")+5,signal.getInt("y"),signal.getInt("z")-2);
        level.setBlock(station,Blocks.LODESTONE.defaultBlockState(),3);
        state.cargoStation=station.asLong();
        state.cargoAt=station.asLong();
        state.cargoAvailable=true;
        state.cargoDelivered=false;
        state.cargoCarrier=null;
        state.setDirty();
    }

    static boolean station(RelayState state,BlockPos position) {
        return state.cargoAvailable&&position.asLong()==state.cargoStation;
    }

    private static boolean active(ServerPlayer player,RelayState state) {
        var record=RaidRules.record(player);
        return state.ready&&record!=null&&record.getString("status").equals("ACTIVE")
            &&record.getInt("generation")==state.generation
            &&player.level().dimension().equals(BunkerRelay.key(state.activeDimension))
            &&player.isAlive()&&!player.isSpectator();
    }

    static String status(RelayState state) {
        if(!state.cargoAvailable)return "Контракт появится в новой зоне";
        if(state.cargoDelivered)return "Груз доставлен";
        if(state.cargoCarrier!=null)return "Груз у участника группы";
        return "Ящик запчастей · "+BlockPos.of(state.cargoAt).toShortString();
    }

    static int report(ServerPlayer player) {
        var state=RelayState.get(player.server);
        RaidRules.chat(player,status(state));
        if(state.cargoAvailable&&!state.cargoDelivered&&state.cargoCarrier==null&&active(player,state))Navigation.route(player,"cargo");
        RaidRules.tell(player,"КПК · «Поднять груз» или «Оставить груз»");
        return 1;
    }

    static int take(ServerPlayer player) {
        var state=RelayState.get(player.server);
        if(!active(player,state)||!state.cargoAvailable||state.cargoDelivered||state.cargoCarrier!=null
            ||!player.getOffhandItem().isEmpty()||player.blockPosition().distSqr(BlockPos.of(state.cargoAt))>25){
            RaidRules.tell(player,"Для подъёма подойдите к грузу на вылазке и освободите вторую руку.");
            return 0;
        }
        if(RaidJournal.get(player.server).raids.values().stream().anyMatch(raid->
            raid.getInt("generation")==state.generation&&raid.getString("status").equals("COMMIT")&&raid.contains("cargoTeam")))return 0;
        state.cargoCarrier=player.getUUID();
        Navigation.route(player,"auto");
        state.setDirty();
        tick(player,state);
        RaidRules.tell(player,"Груз взят. Эвакуируйтесь с ним или передайте группе.");
        return 1;
    }

    static int drop(ServerPlayer player,RelayState state) {
        if(!player.getUUID().equals(state.cargoCarrier))return 0;
        var pos=player.blockPosition();
        if(player.level().dimension().equals(BunkerRelay.key(state.activeDimension))
            &&SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,pos.getX(),pos.getZ())
            &&pos.getY()>=player.level().getMinBuildHeight())state.cargoAt=pos.asLong();
        state.cargoCarrier=null;
        state.setDirty();
        clearWeight(player);
        RaidRules.tell(player,"Груз оставлен · "+BlockPos.of(state.cargoAt).toShortString());
        return 1;
    }

    static void signal(ServerPlayer player,RelayState state) {
        if(!state.cargoAvailable||state.cargoDelivered||state.cargoCarrier!=null||!active(player,state))return;
        var pos=BlockPos.of(state.cargoAt);
        if(player.blockPosition().distSqr(pos)<24*24)
            player.serverLevel().sendParticles(player,net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK,false,
                pos.getX()+.5,pos.getY()+1,pos.getZ()+.5,8,.35,.35,.35,.04);
    }

    static void tick(ServerPlayer player,RelayState state) {
        if(!player.getUUID().equals(state.cargoCarrier)){clearWeight(player);return;}
        if(!active(player,state)||!player.getOffhandItem().isEmpty()){drop(player,state);return;}
        var speed=player.getAttribute(Attributes.MOVEMENT_SPEED);
        if(speed!=null&&!speed.hasModifier(WEIGHT))speed.addTransientModifier(new AttributeModifier(WEIGHT,
            TrophyResearch.has(state,TrophyResearch.Part.HARNESS)?-.10:-.25,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    private static void clearWeight(ServerPlayer player) {
        var speed=player.getAttribute(Attributes.MOVEMENT_SPEED);
        if(speed!=null)speed.removeModifier(WEIGHT);
    }

    static void capture(ServerPlayer carrier,RelayState state,CompoundTag raid) {
        var exit=new BlockPos(state.centerX,state.spawnY,state.centerZ);
        if(!state.cargoAvailable||state.cargoDelivered||!state.relayPowered||!active(carrier,state)
            ||!carrier.getUUID().equals(state.cargoCarrier)||!carrier.getOffhandItem().isEmpty()
            ||carrier.blockPosition().distSqr(exit)>144)return;
        var team=new ListTag();
        team.add(NbtUtils.createUUID(carrier.getUUID()));
        for(var teammate:carrier.server.getPlayerList().getPlayers())
            if(teammate!=carrier&&active(teammate,state)&&teammate.blockPosition().distSqr(exit)<=32*32)
                team.add(NbtUtils.createUUID(teammate.getUUID()));
        raid.put("cargoTeam",team);
    }

    static void settle(ServerPlayer carrier,CompoundTag raid) {
        var team=raid.getList("cargoTeam",Tag.TAG_INT_ARRAY);
        if(!raid.getString("status").equals("COMMIT")||team.isEmpty())return;
        var state=RelayState.get(carrier.server);
        if(raid.getInt("generation")==state.generation){
            state.cargoDelivered=true;
            state.cargoCarrier=null;
            state.setDirty();
        }
        clearWeight(carrier);
        for(var recipient:team){
            UUID id=NbtUtils.loadUUID(recipient);
            RaidContracts.add(carrier,id,raid,"cargo_parts",new ItemStack(Items.COPPER_BLOCK,4));
            RaidContracts.add(carrier,id,raid,"cargo_iron",new ItemStack(Items.IRON_BLOCK,2));
        }
        RaidJournal.get(carrier.server).flush(carrier.server);
    }

    private CargoContract() {}
}
