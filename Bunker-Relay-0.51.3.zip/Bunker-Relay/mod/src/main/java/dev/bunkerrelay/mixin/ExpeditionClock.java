package dev.bunkerrelay.mixin;

import dev.bunkerrelay.ExpeditionLight;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Level.class)
abstract class ExpeditionClock {
    @Inject(method="getDayTime",at=@At("HEAD"),cancellable=true)
    private void bunkerrelay$fixedSky(CallbackInfoReturnable<Long> callback){
        if((Object)this instanceof ServerLevel level&&ExpeditionLight.fixed(level))
            callback.setReturnValue(ExpeditionLight.time(level));
    }
}
