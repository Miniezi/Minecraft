package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import noobanidus.mods.lootr.common.api.registry.LootrRegistry;
import noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity;

final class PersonalLoot {
    static void convert(ServerLevel level, BlockPos pos, ChestBlockEntity chest) {
        var contents = NonNullList.withSize(chest.getContainerSize(), ItemStack.EMPTY);
        for (int i = 0; i < contents.size(); i++) contents.set(i, chest.getItem(i).copy());
        var original = chest.getBlockState();
        chest.clearContent();
        level.setBlock(pos, LootrRegistry.getInventoryBlock().defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof LootrChestBlockEntity personal) {
            personal.setInfoReferenceInventory(contents);
            personal.setChanged();
        } else {
            level.setBlock(pos, original, 3);
            if (!(level.getBlockEntity(pos) instanceof ChestBlockEntity restored))
                throw new IllegalStateException("Could not restore raid cache at " + pos);
            for (int i = 0; i < contents.size(); i++) restored.setItem(i, contents.get(i));
            restored.setChanged();
        }
    }

    static ItemStack templateItem(ServerLevel level, BlockPos pos, int slot) {
        var entity = level.getBlockEntity(pos);
        if (entity instanceof LootrChestBlockEntity personal) return personal.getInfoReferenceInventory().get(slot);
        if (entity instanceof ChestBlockEntity chest) return chest.getItem(slot);
        return ItemStack.EMPTY;
    }

    private PersonalLoot() {}
}
