package dev.bunkerrelay.mixin;

import dev.bunkerrelay.CityParcels;
import mcjty.lostcities.config.LostCityProfile;
import mcjty.lostcities.varia.ChunkCoord;
import mcjty.lostcities.worldgen.IDimensionInfo;
import mcjty.lostcities.worldgen.lost.BuildingInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value=BuildingInfo.class,remap=false)
abstract class LostCityParcels {
    @Inject(method="isCityRaw",at=@At("HEAD"),cancellable=true)
    private static void bunkerrelay$reserveParcels(ChunkCoord chunk,IDimensionInfo dimension,LostCityProfile profile,
        CallbackInfoReturnable<Boolean> result){
        if(CityParcels.reserved(chunk.dimension(),chunk.chunkX(),chunk.chunkZ()))
            result.setReturnValue(false);
    }
}
