package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
/** Incremental bounded rebuild of the private expedition dimension. */
public final class ZoneBuilder {
 private final ServerLevel level;private final RelayState state;private int column;
 public static final int RADIUS=96,WIDTH=192;
 public ZoneBuilder(ServerLevel level,RelayState state){this.level=level;this.state=state;forceArea(level,true);}
 public static void forceArea(ServerLevel level,boolean forced){for(int x=-6;x<6;x++)for(int z=-6;z<6;z++)level.setChunkForced(x,z,forced);}
 public int percent(){return (int)(column*100L/(WIDTH*WIDTH));}
 public boolean tick(){
  BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
  int budget=Boolean.getBoolean("bunkerrelay.smokeTest")?96:24;
  for(int n=0;n<budget&&column<WIDTH*WIDTH;n++,column++){
   int x=column%WIDTH-RADIUS,z=column/WIDTH-RADIUS;
   if(x%16==0&&z%16==0){
    level.getChunk(x>>4,z>>4);
    level.getServer().getCommands().performPrefixedCommand(level.getServer().createCommandSourceStack().withLevel(level).withSuppressedOutput(),"fillbiome "+x+" 0 "+z+" "+(x+15)+" 127 "+(z+15)+" bunkerrelay:"+state.theme);
   }
   BlockState surface=(state.theme.equals("ash")?Blocks.BLACKSTONE:state.theme.equals("infected")?Blocks.MOSS_BLOCK:Blocks.COARSE_DIRT).defaultBlockState();
   for(int y=1;y<128;y++){
    BlockState wanted=y<29?Blocks.STONE.defaultBlockState():y==29?surface:Blocks.AIR.defaultBlockState();
    if(y==29&&(Math.abs(x)<3||Math.abs(z)<3))wanted=Blocks.GRAY_CONCRETE.defaultBlockState();
    pos.set(x,y,z);if(!level.getBlockState(pos).equals(wanted))level.setBlock(pos,wanted,2);
   }
  }
  if(column<WIDTH*WIDTH)return false;
  decorate();forceArea(level,false);return true;
 }
 private void decorate(){
  List<Entity> old=new ArrayList<>();level.getEntities().getAll().forEach(old::add);
  for(Entity e:old)if(!(e instanceof ServerPlayer))e.discard();
  Random rng=new Random(state.seed);
  for(ZonePlan.Site site:ZonePlan.sites(state.seed,state.difficulty)){
   int x=site.x(),z=site.z();Block wall=state.theme.equals("infected")?Blocks.MOSSY_STONE_BRICKS:state.theme.equals("ash")?Blocks.CRACKED_DEEPSLATE_BRICKS:Blocks.CRACKED_STONE_BRICKS;
   int height=site.kind()==2?10:5;
   for(int dx=-5;dx<=5;dx++)for(int dz=-5;dz<=5;dz++)for(int y=30;y<30+height;y++){
    boolean edge=Math.abs(dx)==5||Math.abs(dz)==5;
    if(y==30||(edge&&rng.nextDouble()>0.14)||(site.kind()==0&&y==34))level.setBlock(new BlockPos(x+dx,y,z+dz),wall.defaultBlockState(),2);
   }
   level.setBlock(new BlockPos(x,31,z-5),Blocks.AIR.defaultBlockState(),2);level.setBlock(new BlockPos(x,32,z-5),Blocks.AIR.defaultBlockState(),2);
   BlockPos cp=new BlockPos(x+2,31,z+2);level.setBlock(cp,Blocks.CHEST.defaultBlockState(),3);
   if(level.getBlockEntity(cp) instanceof ChestBlockEntity chest){
    Item[] common={Items.IRON_INGOT,Items.COPPER_INGOT,Items.REDSTONE,Items.COAL,Items.BREAD,Items.ARROW};
    for(int i=0;i<ZonePlan.lootCount(state.loot);i++)chest.setItem(i,new ItemStack(common[rng.nextInt(common.length)],1+rng.nextInt(state.loot*2)));
    if(state.loot>=3)chest.setItem(20,new ItemStack(Items.GOLD_INGOT,state.loot-1));if(state.loot==5)chest.setItem(21,new ItemStack(Items.DIAMOND));chest.setChanged();
   }
   for(int i=0;i<state.difficulty;i++){
    Mob mob=SporeEncounters.create(level,state,i);if(mob==null)continue;
    mob.moveTo(x-3+i,31,z-2,0,0);mob.setPersistenceRequired();mob.getAttribute(Attributes.MAX_HEALTH).setBaseValue(16+state.difficulty*6);mob.setHealth(mob.getMaxHealth());
    if(mob.getAttribute(Attributes.ATTACK_DAMAGE)!=null)mob.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(2+state.difficulty);
    level.addFreshEntity(mob);
   }
  }
  for(int x=-5;x<=5;x++)for(int z=-5;z<=5;z++)level.setBlock(new BlockPos(x,29,z),Blocks.SMOOTH_STONE.defaultBlockState(),2);
  level.setBlock(new BlockPos(0,30,0),Blocks.LODESTONE.defaultBlockState(),3);level.setWeatherParameters(0,24000,state.difficulty>=3,state.difficulty>=5);
 }
 public static void buildBase(ServerLevel level,boolean garage){
  int r=garage?40:48;
  for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){
   level.setBlock(new BlockPos(x,29,z),Blocks.SMOOTH_STONE.defaultBlockState(),2);
   if(Math.abs(x)==r||Math.abs(z)==r)for(int y=30;y<=36;y++)level.setBlock(new BlockPos(x,y,z),Blocks.DEEPSLATE_BRICKS.defaultBlockState(),2);
   if(x%12==0&&z%12==0)level.setBlock(new BlockPos(x,29,z),Blocks.SEA_LANTERN.defaultBlockState(),2);
  }
  level.setBlock(new BlockPos(0,30,0),Blocks.LODESTONE.defaultBlockState(),3);
  for(int x=-8;x<=8;x++)for(int z=10;z<=22;z++){
   level.setBlock(new BlockPos(x,36,z),Blocks.GRAY_CONCRETE.defaultBlockState(),2);
   if(Math.abs(x)==8||z==22)for(int y=30;y<36;y++)level.setBlock(new BlockPos(x,y,z),Blocks.STONE_BRICKS.defaultBlockState(),2);
  }
  level.setBlock(new BlockPos(-4,30,20),Blocks.CRAFTING_TABLE.defaultBlockState(),3);level.setBlock(new BlockPos(-2,30,20),Blocks.FURNACE.defaultBlockState(),3);level.setBlock(new BlockPos(2,30,20),Blocks.CHEST.defaultBlockState(),3);
 }
}
