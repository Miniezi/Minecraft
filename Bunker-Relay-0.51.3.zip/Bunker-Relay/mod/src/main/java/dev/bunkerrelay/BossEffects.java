package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

final class BossEffects {
    static void phase(ServerLevel level,BlockPos position,String theme){
        level.sendParticles(impact(theme),position.getX()+.5,position.getY()+1.2,position.getZ()+.5,
            45,.9,.6,.9,.08);
        level.playSound(null,position,SoundEvents.BEACON_ACTIVATE,SoundSource.HOSTILE,1,.64f);
    }

    static void warning(ServerLevel level,BlockPos position,String theme,int radius,boolean first){
        ring(level,position,ParticleTypes.END_ROD,radius,.13,32,0);
        ring(level,position,impact(theme),radius-.27,.34,16,Math.PI/16);
        if(first)level.playSound(null,position,SoundEvents.NOTE_BLOCK_BASEDRUM.value(),SoundSource.HOSTILE,1.4f,.62f);
    }

    static void strike(ServerLevel level,BlockPos position,String theme,int radius){
        var particle=impact(theme);
        for(int band=1;band<=3;band++)
            ring(level,position,particle,radius*band/3.0,.2+band*.15,band*8,band*.17);
        level.sendParticles(particle,position.getX()+.5,position.getY()+.4,position.getZ()+.5,35,.55,.4,.55,.10);
        var sound=switch(theme){
            case "infected" -> SoundEvents.SLIME_SQUISH;
            case "forest" -> SoundEvents.PLAYER_ATTACK_SWEEP;
            case "ash" -> SoundEvents.BLAZE_SHOOT;
            default -> SoundEvents.IRON_GOLEM_ATTACK;
        };
        level.playSound(null,position,sound,SoundSource.HOSTILE,1.5f,.75f);
    }

    private static ParticleOptions impact(String theme){
        return switch(theme){
            case "infected" -> ParticleTypes.SPORE_BLOSSOM_AIR;
            case "forest" -> ParticleTypes.CRIT;
            case "ash" -> ParticleTypes.FLAME;
            default -> ParticleTypes.ELECTRIC_SPARK;
        };
    }

    private static void ring(ServerLevel level,BlockPos position,ParticleOptions particle,double radius,double height,int points,double rotation){
        for(int i=0;i<points;i++){
            double angle=rotation+2*Math.PI*i/points;
            level.sendParticles(particle,position.getX()+.5+radius*Math.cos(angle),position.getY()+height,
                position.getZ()+.5+radius*Math.sin(angle),1,0,0,0,0);
        }
    }

    private BossEffects(){}
}
