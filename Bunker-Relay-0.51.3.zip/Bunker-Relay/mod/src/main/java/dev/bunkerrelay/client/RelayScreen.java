package dev.bunkerrelay.client;

import dev.bunkerrelay.LockerMenu;
import dev.bunkerrelay.DismantleMenu;
import dev.bunkerrelay.PocketDevice;
import dev.bunkerrelay.RelayEconomy;
import dev.bunkerrelay.TerminalMenu;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;

/** Renders server-supplied buttons without exposing the underlying inventory slots. */
public final class RelayScreen<T extends ChestMenu> extends AbstractContainerScreen<T> {
    private static final int TEXT = 0xffecf0f6;
    private static final int MUTED = 0xffb3ceca;
    private static final int SURFACE = 0xff192e31;
    private static final int HEADER = 32;
    private static final int CARD = 30;
    private static final ResourceLocation EXPEDITION_ART=ResourceLocation.parse("bunkerrelay:textures/gui/expedition_locations.png");
    private record Button(int slot, int x, int y, int width, int height, boolean compact) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + width && my >= y && my < y + height;
        }
    }

    private final List<Button> buttons = new ArrayList<>();
    private final boolean terminal;
    private final boolean pocket;
    private final boolean market;
    private final boolean warehouse;
    private final boolean dismantle;
    private int scroll;
    private int maxScroll;
    private int bodyTop;
    private int bodyLeft;
    private int previewWidth;

    public RelayScreen(T menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        terminal = menu instanceof TerminalMenu;
        pocket = menu instanceof PocketDevice.Menu;
        market = menu instanceof RelayEconomy.MarketMenu;
        warehouse = menu instanceof LockerMenu;
        dismantle = menu instanceof DismantleMenu;
    }

    @Override protected void init() {
        imageWidth = Math.min(pocket ? 358 : 462, width - 8);
        imageHeight = Math.min(pocket ? 238 : 284, height - 8);
        super.init();
    }

    private boolean present(int slot) { return !menu.getSlot(slot).getItem().isEmpty(); }

    private List<Integer> actions() {
        var result = new ArrayList<Integer>();
        if (terminal && present(24)) {
            int[] order = present(10) ? new int[]{10,11,12,13,14,18,19,20,21}
                : new int[]{22,24,6,27,52,18,47,46,4};
            for (int slot : order) if (present(slot)) result.add(slot);
        } else {
            int start = market || warehouse || pocket || dismantle ? 9 : 0;
            int end = market || warehouse || dismantle ? 45 : menu.getRowCount() * 9;
            for (int slot = start; slot < end; slot++) {
                if (terminal && (slot == 1 || slot == 3 || slot == 5)) continue;
                if (present(slot)) result.add(slot);
            }
        }
        return result;
    }

    private void line(int[] slots, int left, int y, int available, int height) {
        var active = new ArrayList<Integer>();
        for (int slot : slots) if (present(slot)) active.add(slot);
        if (active.isEmpty()) return;
        int cell = available / active.size();
        for (int i = 0; i < active.size(); i++)
            buttons.add(new Button(active.get(i), left + i * cell, y, cell - 4, height, true));
    }

    private void layout() {
        buttons.clear();
        bodyTop = topPos + HEADER + 7;
        bodyLeft = leftPos + 8;
        int contentWidth = imageWidth - 16;
        if (terminal || pocket || warehouse) {
            line(terminal ? new int[]{1,3,5} : new int[]{0,1,2}, bodyLeft, bodyTop, contentWidth, 22);
            bodyTop += 26;
        }
        if (warehouse) {
            line(new int[]{7,8}, bodyLeft, bodyTop, contentWidth, 17);
            bodyTop += 21;
        }
        if (market) {
            int sideWidth = Math.min(126, contentWidth / 3);
            int y = bodyTop;
            for (int slot : new int[]{8,0,1,2,3,4,5,6,7,48,50,51,52}) if (present(slot)) {
                int row = Math.min(18, (imageHeight - HEADER - 14) / 13);
                buttons.add(new Button(slot, bodyLeft, y, sideWidth - 5, row - 2, true));
                y += row;
            }
            bodyLeft += sideWidth;
            contentWidth -= sideWidth;
        }
        int footer = topPos + imageHeight - 24;
        previewWidth = terminal && present(23) && contentWidth>=275 ? Math.min(182,contentWidth/2) : 0;
        if(terminal && present(23)){
            line(new int[]{24,26},bodyLeft,footer,contentWidth,18);
            if(previewWidth>0)contentWidth-=previewWidth+8;
        }
        if (market) line(new int[]{45,46,49}, bodyLeft, footer, contentWidth, 18);
        if (warehouse) line(new int[]{45,46,49,52}, bodyLeft, footer, contentWidth, 18);
        if (dismantle) line(new int[]{52,53}, bodyLeft, footer, contentWidth, 18);
        var actions = actions();
        int columns = contentWidth >= 270 && !market ? 2 : 1;
        int capacity = Math.max(1, (footer - bodyTop - 3) / CARD) * columns;
        maxScroll = Math.max(0, (actions.size() - capacity + columns - 1) / columns) * columns;
        scroll = Math.clamp(scroll - scroll % columns, 0, maxScroll);
        int cardWidth = contentWidth / columns;
        for (int i = 0; i < capacity && scroll + i < actions.size(); i++)
            buttons.add(new Button(actions.get(scroll + i), bodyLeft + i % columns * cardWidth,
                bodyTop + i / columns * CARD, cardWidth - 4, CARD - 4, false));
    }

    @Override protected void renderBg(GuiGraphics g, float partial, int mx, int my) {}

    @Override public void render(GuiGraphics g, int mx, int my, float partial) {
        int accent = terminal ? 0xffffb86b : pocket ? 0xff6cdbc8 : 0xff9cbdff;
        g.fill(0, 0, width, height, 0xb400070d);
        g.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xff111822);
        g.fill(leftPos, topPos, leftPos + imageWidth, topPos + HEADER, SURFACE);
        g.fill(leftPos + 8, topPos + 8, leftPos + 10, topPos + HEADER - 8, accent);
        String heading = terminal && present(10) ? "Новая вылазка" : title.getString();
        g.drawString(font, heading, leftPos + 17, topPos + 12, TEXT, false);
        String shortcut = terminal&&present(23)?"":market || warehouse ? "ЛКМ · 1     ПКМ · максимум" : "Esc · закрыть";
        int shortcutWidth = font.width(shortcut);
        if (shortcutWidth + font.width(heading) + 32 <= imageWidth)
            g.drawString(font, shortcut, leftPos + imageWidth - shortcutWidth - 10, topPos + 12, MUTED, false);

        layout();
        renderExpeditionArt(g);
        Button hovered = null;
        for (var button : buttons) {
            var item = menu.getSlot(button.slot()).getItem();
            String name = item.getHoverName().getString();
            boolean selected = name.startsWith("• ") || name.startsWith("▶ ");
            if (selected) name = name.substring(2);
            boolean primary = terminal && (button.slot() == 22 || button.slot() == 24);
            boolean hot = button.contains(mx, my);
            int x = button.x(), y = button.y();
            g.fill(x, y, x + button.width(), y + button.height(),
                hot ? 0xff384a62 : selected || primary ? 0xff2b3b55 : SURFACE);
            if (selected || primary) g.fill(x, y, x + 2, y + button.height(), accent);
            int textX = x + 7;
            if (!button.compact()) {
                g.renderItem(item, x + 6, y + 5);
                textX = x + 28;
            }
            int textWidth = Math.max(0, button.width() - (textX - x) - 4);
            g.drawString(font, font.plainSubstrByWidth(name, textWidth), textX,
                y + (button.compact() ? (button.height() - 8) / 2 : 4), TEXT, false);
            var lore = item.get(DataComponents.LORE);
            if (!button.compact() && lore != null && !lore.lines().isEmpty())
                g.drawString(font, font.plainSubstrByWidth(lore.lines().getFirst().getString(), textWidth),
                    textX, y + 15, MUTED, false);
            if (hot) hovered = button;
        }
        if ((market || warehouse || dismantle) && actions().isEmpty())
            g.drawString(font, dismantle ? "В инвентаре нет оружия TaCZ" : "Здесь пока пусто", bodyLeft + 6, bodyTop + 10, MUTED, false);
        if (maxScroll > 0) {
            int top = bodyTop;
            int end = topPos + imageHeight - 26;
            int x = leftPos + imageWidth - 5;
            g.fill(x, top, x + 2, end, SURFACE);
            int thumb = top + (end - top - 9) * scroll / maxScroll;
            g.fill(x, thumb, x + 2, thumb + 9, accent);
        }
        if (hovered != null) g.renderTooltip(font, menu.getSlot(hovered.slot()).getItem(), mx, my);
    }

    private void renderExpeditionArt(GuiGraphics g) {
        if(!terminal||!present(23))return;
        var caption=menu.getSlot(23).getItem().getHoverName();
        if(previewWidth==0){
            String title=caption.getString();
            g.drawString(font,title,leftPos+imageWidth-font.width(title)-9,topPos+12,TEXT,false);
            return;
        }
        int region=0;
        for(int i=0;i<4;i++)if(menu.getSlot(10+i).getItem().getHoverName().getString().startsWith("• ")){region=i;break;}
        boolean night=menu.getSlot(23).getItem().is(Items.CLOCK);
        int x=leftPos+imageWidth-8-previewWidth;
        int h=Math.min(previewWidth*2/3,imageHeight-HEADER-88);
        if(h<16)return;
        g.blit(EXPEDITION_ART,x,bodyTop,previewWidth,h,night?543:0,362*region,543,362,1086,1448);
        g.fill(x,bodyTop+h,x+previewWidth,bodyTop+h+20,SURFACE);
        g.drawString(font,caption,x+6,bodyTop+h+6,TEXT,false);
    }

    @Override public boolean mouseClicked(double x, double y, int button) {
        if (button != 0 && button != 1) return false;
        layout();
        for (var action : buttons) if (action.contains(x, y)) {
            if (button == 1 && (!market && !warehouse || action.compact())) return true;
            minecraft.gameMode.handleInventoryMouseClick(menu.containerId, action.slot(), button,
                ClickType.PICKUP, minecraft.player);
            if (action.compact() || terminal && (action.slot() == 22 || action.slot() == 47)
                || pocket && (action.slot() == 12 || action.slot() == 13)) scroll = 0;
            return true;
        }
        return true;
    }

    @Override public boolean mouseScrolled(double x, double y, double dx, double dy) {
        int step = imageWidth - 16 - (previewWidth>0?previewWidth+8:0) >= 270 && !market ? 2 : 1;
        scroll = Math.clamp(scroll + (dy < 0 ? step : -step), 0, maxScroll);
        return true;
    }
}
