package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.HashSet;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class RegionalIntegrationTest {
    static void verify(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        int originalX=state.centerX,originalZ=state.centerZ;
        String originalTheme=state.activeTheme;
        var templates=new HashSet<String>();
        for(var profile:ZoneProfile.values()){
            for(long seed=-10;seed<=10;seed++)
                check(profile.difficulty(seed)>=profile.min&&profile.difficulty(seed)<=profile.max,"zone tier");
            for(var plan:ZoneLandmarks.plans(profile.id))
                check(templates.add(plan.template())&&level.getStructureManager()
                    .get(SporeStorySites.templateId(plan.template())).isPresent(),"distinct available template");
            state.activeTheme=profile.id;
            state.centerX=4000+profile.ordinal()*1500;
            state.centerZ=4000;
            state.activeLoot=profile.max;
            for(int index:new int[]{0,3,4}){
                var plan=ZoneLandmarks.plans(profile.id).get(index);
                ZoneLandmarks.build(level,state,index);
                var room=RaidDirector.get(server).rooms.getLast();
                var cache=new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z"));
                check(room.getString("title").equals(plan.title()),"landmark "+plan.title());
                check(room.getString("template").equals(plan.template()),"correct source "+plan.title());
                check(level.getBlockState(cache.north(2)).is(Blocks.AIR)&&!PersonalLoot.templateItem(level,cache,4).isEmpty(),"open access and loot");
                var condition=LandmarkCondition.read(room.getString("condition"));
                check(condition==LandmarkCondition.choose(state.seed,BlockPos.of(room.getLong("origin"))),"seeded condition");
                var block=level.getBlockEntity(cache);
                check(block!=null&&block.getPersistentData().getString("relay_landmark_condition").equals(condition.name()),"condition persisted at cache");
                check(condition==LandmarkCondition.REGULAR||!PersonalLoot.templateItem(level,cache,10).isEmpty(),"alternate loot");
                var request=BunkerRequests.forSite(plan.template());
                if(request!=null)check(Warehouse.matches(PersonalLoot.templateItem(level,cache,11),request.item()),"request field supply");
                if(plan.medical()&&profile.max>=3)
                    check(PersonalLoot.templateItem(level,cache,4).is(Medicine.BANDAGE.get())
                        &&PersonalLoot.templateItem(level,cache,5).is(Medicine.MEDKIT.get()),"hospital medicine");
            }

        }
        state.centerX=originalX;state.centerZ=originalZ;state.activeTheme=originalTheme;
        check(templates.size()==20,"twenty distinct large sites");
        state.ready=true;
        var doctor=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"RelayMedic"));
        doctor.setHealth(8);
        doctor.getFoodData().setFoodLevel(20);
        doctor.getFoodData().setSaturation(6);
        for(int tick=0;tick<10;tick++)doctor.getFoodData().tick(doctor);
        check(Math.abs(doctor.getHealth()-8.25f)<.01f,"food heals at one quarter rate");
        doctor.setHealth(8);
        doctor.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Medicine.BANDAGE.get(),2));
        Medicine.BANDAGE.get().use(level,doctor,InteractionHand.MAIN_HAND);
        check(doctor.getHealth()==13&&doctor.getMainHandItem().getCount()==1,"instant bandage");
        doctor.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Medicine.MEDKIT.get()));
        Medicine.MEDKIT.get().use(level,doctor,InteractionHand.MAIN_HAND);
        check(doctor.getHealth()==13&&doctor.getMainHandItem().getCount()==1,"shared cooldown");
        check(RelayEconomy.CATALOG.stream().filter(offer->RelayEconomy.merchant(offer)==RelayEconomy.Merchant.MEDIC).count()==2,"medic offers");
        var pda=new PocketDevice.Menu(9,doctor.getInventory(),doctor,PocketDevice.Page.RAID);
        check(pda.getSlot(10).getItem().getHoverName().getString().equals("Ориентиры"),"PDA map removed");
        System.out.println("RELAY_REGIONAL_PASS profiles=true templates=20 medicine=true food=true medic=true");
    }

    private static void check(boolean condition,String message){
        if(!condition)throw new IllegalStateException("Regional test: "+message);
    }

    private RegionalIntegrationTest(){}
}
