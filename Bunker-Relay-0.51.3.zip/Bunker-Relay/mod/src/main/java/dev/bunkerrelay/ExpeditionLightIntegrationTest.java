package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class ExpeditionLightIntegrationTest {
    static void verify(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var original=state.routeEvent;
        boolean fixed=state.fixedRaidLight,night=state.nightRaid;
        try{
            state.routeEvent=new CompoundTag();
            state.fixedRaidLight=true;state.nightRaid=true;
            long global=server.overworld().getDayTime();
            require(level.getDayTime()==18000,"expedition night");
            require(server.overworld().getDayTime()==global,"overworld clock unaffected");
            state.nightRaid=false;
            require(level.getDayTime()==6000,"expedition day");
            var pos=new BlockPos(state.centerX+64,state.spawnY+19,state.centerZ+64);
            level.setBlock(pos.below(),Blocks.STONE.defaultBlockState(),2);
            level.setBlock(pos,Blocks.AIR.defaultBlockState(),2);
            level.setBlock(pos.above(),Blocks.AIR.defaultBlockState(),2);
            require(RouteEvents.place(level,state,pos,180),"route chest");
            require(!PersonalLoot.templateItem(level,pos,4).isEmpty(),"supplies available");
            require(state.save(new CompoundTag(),server.registryAccess()).getCompound("routeEvent").contains("position"),"route persisted");
            RouteEvents.tick(level,state,320,List.of());
            require(level.isEmptyBlock(pos)&&!state.routeEvent.contains("position"),"expired route cleared");
            require(net.minecraft.core.registries.BuiltInRegistries.ITEM.containsKey(
                net.minecraft.resources.ResourceLocation.parse("relaylights:flashlight")),"standalone flashlight registered");
        }finally{
            state.fixedRaidLight=fixed;state.nightRaid=night;state.routeEvent=original;
        }
        System.out.println("RELAY_RAID_LIGHT_AND_SIGNALS_PASS");
    }

    private static void require(boolean condition,String message){
        if(!condition)throw new IllegalStateException("Raid light: "+message);
    }
}
