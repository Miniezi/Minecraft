package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update14IntegrationTest {
    static void run(MinecraftServer server){
        var state=RelayState.get(server);
        check(!state.initialized,"fresh fixture");
        var player=new FakePlayer(server.overworld(),new GameProfile(UUID.randomUUID(),"Relay14Start")){
            @Override public boolean teleportTo(ServerLevel target,double x,double y,double z,
                Set<RelativeMovement> flags,float yaw,float pitch){
                setServerLevel(target);
                moveTo(x,y,z,yaw,pitch);
                return true;
            }

            @Override public java.util.OptionalInt openMenu(MenuProvider menu){
                containerMenu=menu.createMenu(42,getInventory(),this);
                return java.util.OptionalInt.of(42);
            }
        };
        var commands=server.getCommands();
        commands.performPrefixedCommand(player.createCommandSourceStack().withPermission(0),"relay");
        check(!state.initialized,"operator required for first startup");
        commands.performPrefixedCommand(player.createCommandSourceStack().withPermission(2),"relay");
        var hub=server.getLevel(BunkerRelay.HUB);
        check(state.initialized&&state.hubV2&&player.serverLevel()==hub,"single command builds and selects bunker");
        check(hub.getBlockState(HubBuilder.TERMINAL).is(RelayTerminalBlock.TERMINAL.get()),"terminal built");
        check(player.containerMenu instanceof PocketDevice.Menu&&countDevice(player)==1,"starter PDA and menu");

        var marker=new BlockPos(9,73,25);
        hub.setBlock(marker,Blocks.EMERALD_BLOCK.defaultBlockState(),3);
        commands.performPrefixedCommand(player.createCommandSourceStack().withPermission(2),"relay");
        check(hub.getBlockState(marker).is(Blocks.EMERALD_BLOCK)&&countDevice(player)==1,"start is idempotent");
        check(server.getRecipeManager().byKey(ResourceLocation.parse("bunkerrelay:pocket_device")).isPresent(),"replacement recipe");
        var relay=commands.getDispatcher().getRoot().getChild("relay");
        for(String removed:java.util.List.of("init","upgrade","size","difficulty","theme","regenerate","power","research","shop"))
            check(relay.getChild(removed)==null,"removed command "+removed);

        var terminal=HubBuilder.TERMINAL;
        player.moveTo(terminal.getX()+.5,terminal.getY(),terminal.getZ()+.5);
        check(BunkerRelay.openTerminal(player)==1&&player.containerMenu instanceof TerminalMenu,"terminal menu");
        int previous=state.difficulty;
        var menu=(TerminalMenu)player.containerMenu;
        menu.clicked(10,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        check(state.difficulty==previous%5+1,"difficulty button");
        player.moveTo(terminal.getX()+10.5,terminal.getY(),terminal.getZ()+.5);
        menu.clicked(10,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        check(state.difficulty==previous%5+1&&BunkerRelay.openTerminal(player)==0,"remote actions rejected");
        System.out.println("RELAY_014_PASS bootstrap=true pocket=true terminal_only=true recipe=true");
        server.halt(false);
    }

    private static long countDevice(FakePlayer player){
        return player.getInventory().items.stream().filter(stack->stack.is(PocketDevice.ITEM.get())).count();
    }

    private static void check(boolean condition,String description){
        if(!condition)throw new IllegalStateException("RELAY_014 "+description);
    }

    private Update14IntegrationTest(){}
}
