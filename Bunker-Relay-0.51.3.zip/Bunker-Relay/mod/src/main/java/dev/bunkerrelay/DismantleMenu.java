package dev.bunkerrelay;

import com.tacz.guns.api.item.IGun;
import java.util.ArrayList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

public final class DismantleMenu extends ChestMenu {
    private final ServerPlayer owner;
    private final boolean workshop;
    private final SimpleContainer panel;
    private final ItemStack[] shown=new ItemStack[36];
    private int selected=-1;
    private ItemStack snapshot=ItemStack.EMPTY;

    DismantleMenu(int id,Inventory inventory) { this(id,inventory,null,false); }

    private DismantleMenu(int id,Inventory inventory,ServerPlayer owner,boolean workshop) {
        super(RelayMenus.DISMANTLE.get(),id,inventory,new SimpleContainer(54),6);
        this.owner=owner;
        this.workshop=workshop;
        panel=(SimpleContainer)getContainer();
        if(owner!=null)refresh();
    }

    static void open(ServerPlayer player,boolean workshop) {
        if(!accessible(player,workshop))return;
        player.openMenu(new SimpleMenuProvider((id,inv,ignored)->new DismantleMenu(id,inv,player,workshop),
            Component.literal("Разборка оружия")));
    }

    private static boolean accessible(ServerPlayer player,boolean workshop) {
        return RelayEconomy.safe(player)&&(workshop?CourtyardWorkshop.nearby(player,RelayState.get(player.server))
            :BunkerRelay.nearTerminal(player));
    }

    private void refresh() {
        panel.clearContent();
        var items=owner.getInventory().items;
        for(int i=0;i<items.size();i++){
            var stack=items.get(i);
            shown[i]=stack.copy();
            if(!(stack.getItem() instanceof IGun))continue;
            var recipe=GunDismantle.plan(owner,stack);
            var title=Component.literal(i==selected?"• ":"").append(stack.getHoverName());
            icon(9+i,stack,title,recipe);
        }
        if(selected>=0&&ItemStack.matches(items.get(selected),snapshot)){
            var recipe=GunDismantle.plan(owner,snapshot);
            if(recipe.allowed())icon(52,new ItemStack(Items.SHEARS),Component.literal("Разобрать"),recipe);
        }else clearSelection();
        var back=new ItemStack(Items.ARROW);
        back.set(DataComponents.CUSTOM_NAME,Component.literal(workshop?"Мастерская":"Терминал"));
        panel.setItem(53,back);
    }

    private void icon(int slot,ItemStack item,Component title,GunDismantle.Plan recipe) {
        var display=item.copyWithCount(1);
        display.set(DataComponents.CUSTOM_NAME,title);
        var lines=new ArrayList<Component>();
        lines.add(recipe.summary());
        if(recipe.allowed())for(var output:recipe.outputs())
            lines.add(Component.literal("• ").append(output.getHoverName()).append(" ×"+output.getCount()));
        display.set(DataComponents.LORE,new ItemLore(lines));
        panel.setItem(slot,display);
    }

    private void clearSelection(){
        selected=-1;
        snapshot=ItemStack.EMPTY;
    }

    @Override public boolean stillValid(Player player) {
        return player.level().isClientSide()||owner!=null&&player==owner&&accessible(owner,workshop);
    }

    @Override public void clicked(int slot,int button,ClickType type,Player player) {
        if(owner==null||player!=owner||!stillValid(player)||type!=ClickType.PICKUP||button!=0
            ||slot<0||slot>=panel.getContainerSize()||panel.getItem(slot).isEmpty())return;
        if(slot==53){
            if(workshop)CourtyardWorkshop.useOrLocate(owner);else BunkerRelay.openTerminal(owner);
            return;
        }
        if(slot==52&&selected>=0){
            GunDismantle.dismantle(owner,selected,snapshot);
            clearSelection();
        }else if(slot>=9&&slot<45){
            int index=slot-9;
            var current=owner.getInventory().getItem(index);
            clearSelection();
            if(ItemStack.matches(current,shown[index])&&GunDismantle.plan(owner,current).allowed()){
                selected=index;
                snapshot=current.copy();
            }
        }
        refresh();
        sendAllDataToRemote();
    }

    @Override public ItemStack quickMoveStack(Player player,int slot) { return ItemStack.EMPTY; }
}
