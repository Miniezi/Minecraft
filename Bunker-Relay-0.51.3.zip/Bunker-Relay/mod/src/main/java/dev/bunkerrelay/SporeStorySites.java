package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockIgnoreProcessor;

final class SporeStorySites {
    record Site(BlockPos origin,String template,BlockPos approach){}

    static Site build(ServerLevel level,RelayState state,int x,int z,String type,int variant){
        String id=switch(type){
            case "echo" -> "lab";
            case "signal" -> "celltower";
            case "clinic" -> "hospital";
            case "archive" -> "church";
            default -> null;
        };
        return buildTemplate(level,state,x,z,type,variant,id,"spore_story");
    }

    static ResourceLocation templateId(String id){
        return id.contains(":")?ResourceLocation.parse(id):ResourceLocation.fromNamespaceAndPath("spore",id);
    }

    static Site buildTemplate(ServerLevel level,RelayState state,int x,int z,String type,int variant,String id,String footprint){
        if(id==null)return null;
        var template=level.getStructureManager().get(templateId(id)).orElse(null);
        if(template==null)return null;
        var size=template.getSize();
        int halfX=Math.max(8,size.getX()/2),halfZ=Math.max(6,size.getZ()/2);
        int floor=StructureLevels.floor(level,state,footprint,x,z,halfX,halfZ,size.getY()+2);
        var origin=new BlockPos(x,floor,z);
        // Depths from the matching Spore start pools, measured from their surface anchor.
        int basement=switch(id){
            case "biomass_tower", "biomass_tower_tall", "biomass_tower_small", "mega_biomass_tower" -> 1;
            case "cathedral" -> 20;
            case "cell" -> 3;
            case "celltower" -> 5;
            case "church", "church1", "church2" -> 3;
            case "hospital", "asylum" -> 9;
            case "iceberg_mines" -> 5;
            case "lab" -> 17;
            case "lodge" -> 8;
            case "massgrave1", "massgrave3", "massgrave4" -> 5;
            case "military_camp" -> 11;
            case "mines" -> 9;
            case "prison" -> 28;
            default -> 0;
        };
        var corner=origin.offset(-size.getX()/2,-Math.min(basement,floor-level.getMinBuildHeight()),-size.getZ()/2);
        var settings=new StructurePlaceSettings().setIgnoreEntities(true);
        if(!templateId(id).getNamespace().equals("spore")){
            settings.addProcessor(new BlockIgnoreProcessor(java.util.List.of(Blocks.STRUCTURE_BLOCK,Blocks.JIGSAW,
                Blocks.SPAWNER,Blocks.CHEST,Blocks.TRAPPED_CHEST,Blocks.BARREL,Blocks.DISPENSER,Blocks.DROPPER)));
        }
        if(!template.placeInWorld(level,corner,corner,settings,level.random,2))
            return null;

        Block accent=switch(type){
            case "echo" -> Blocks.CYAN_CONCRETE;
            case "signal" -> Blocks.YELLOW_CONCRETE;
            case "clinic" -> Blocks.WHITE_CONCRETE;
            default -> Blocks.ORANGE_CONCRETE;
        };
        boolean landmark=footprint.equals("landmark");
        Direction entrance=landmark?new Direction[]{Direction.NORTH,Direction.EAST,Direction.WEST}[variant]:Direction.NORTH;
        int approachDepth=entrance.getAxis()==Direction.Axis.X?halfX:halfZ;
        // The template supplies the shell; Relay supplies an accessible route and its objective room.
        for(int dz=-approachDepth-1;dz<=5;dz++){
            int width=dz>=-4?6:1;
            for(int dx=-width;dx<=width;dx++){
                var at=route(origin,entrance,dx,dz);
                level.setBlock(at.below(),(dx==0?accent:Blocks.POLISHED_ANDESITE).defaultBlockState(),2);
                for(int h=0;h<3;h++)level.setBlock(at.above(h),Blocks.AIR.defaultBlockState(),2);
            }
            if(dz%5==0)level.setBlock(route(origin,entrance,-1,dz).below(),Blocks.SEA_LANTERN.defaultBlockState(),2);
        }
        for(int side:new int[]{-1,1}){
            var post=route(origin,entrance,side*2,-approachDepth-1);
            for(int h=0;h<3;h++)level.setBlock(post.above(h),accent.defaultBlockState(),2);
            level.setBlock(post.above(3),Blocks.SEA_LANTERN.defaultBlockState(),2);
        }
        var approach=origin.relative(entrance,approachDepth+2);
        SurfacePlacement.approach(level,approach,entrance);
        int divider=new int[]{-4,-2,2}[variant];
        for(int h=0;h<2;h++)level.setBlock(origin.offset(divider,h,-1),Blocks.IRON_BARS.defaultBlockState(),2);
        level.setBlock(origin.south(4),Blocks.CHEST.defaultBlockState(),3);
        if(landmark&&type.equals("clinic")&&variant==1){
            for(int dx=-5;dx<=-3;dx++)for(int dz=1;dz<=3;dz++)
                level.setBlock(origin.offset(dx,0,dz),Blocks.WATER.defaultBlockState(),2);
        }
        return new Site(origin,id,approach);
    }

    private static BlockPos route(BlockPos origin,Direction entrance,int across,int north){
        return origin.relative(entrance,-north).relative(entrance.getClockWise(),across);
    }

    private SporeStorySites(){}
}
