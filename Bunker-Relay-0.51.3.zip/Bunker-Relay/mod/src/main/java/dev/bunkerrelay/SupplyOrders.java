package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemLore;
/** A board stays pinned until all three orders are filled, then a new successful sector refreshes it. */
public final class SupplyOrders {
 private static final List<String> POOL=List.of("iron","copper","redstone","coal","quartz","leather","andesite","zinc","alloy","gold","slime","brass");
 public record Order(String id,RelayEconomy.Offer goods){
  public int amount(){return goods.quantity()*2;}
  public int reward(){return goods.buy()*6/5;}
  public ItemStack target(ServerPlayer p){return goods.stack(p).copyWithCount(amount());}
 }
 private static CompoundTag board(ServerPlayer p){var a=RelayEconomy.account(p);if(!a.contains("orders",Tag.TAG_COMPOUND)){var b=new CompoundTag();b.putInt("cycle",a.getInt("rotation"));a.put("orders",b);}return a.getCompound("orders");}
 public static int cycle(ServerPlayer p){return board(p).getInt("cycle");}
 public static List<Order> list(ServerPlayer p){int offset=Math.floorMod(p.getUUID().hashCode()+cycle(p)*3,POOL.size());var result=new ArrayList<Order>();for(int i=0;i<3;i++){String id=POOL.get((offset+i)%POOL.size());result.add(new Order(id,RelayEconomy.CATALOG.stream().filter(o->o.id().equals(id)).findFirst().orElseThrow()));}return result;}
 public static boolean done(ServerPlayer p,Order o){return board(p).getCompound("done").getBoolean(o.id());}
 public static int count(ServerPlayer p,Order o){var target=o.target(p);return p.getInventory().items.stream().filter(s->ItemStack.isSameItemSameComponents(s,target)).mapToInt(ItemStack::getCount).sum();}
 public static int reputation(ServerPlayer p){return Math.max(0,RelayEconomy.account(p).getInt("reputation"));}
 public static int rank(ServerPlayer p){int n=reputation(p);return n>=60?3:n>=30?2:n>=10?1:0;}
 public static int discount(ServerPlayer p){return switch(rank(p)){case 1->3;case 2->6;case 3->10;default->0;};}
 public static String title(ServerPlayer p){return switch(rank(p)){case 1->"Поставщик";case 2->"Надёжный партнёр";case 3->"Ветеран снабжения";default->"Новичок";};}
 public static void onExtract(ServerPlayer p){if(list(p).stream().allMatch(o->done(p,o))){var b=new CompoundTag();b.putInt("cycle",cycle(p)+1);RelayEconomy.account(p).put("orders",b);}}
 public static String deliver(ServerPlayer p,Order order,int expectedCycle){
  if(!RelayEconomy.safe(p))return "Заказы сдаются только в бункере или гараже после вылазки.";
  if(cycle(p)!=expectedCycle||!list(p).contains(order))return "Список заказов изменился. Выберите заказ заново.";
  if(done(p,order))return "Этот заказ уже оплачен.";
  if(count(p,order)<order.amount())return "Недостаточно обычных предметов в основном инвентаре. Нужно: "+order.amount()+". Из рюкзака переложите вручную.";
  if(RelayEconomy.balance(p)>RelayEconomy.MAX_BALANCE-order.reward())return "Лимит счёта: предметы не списаны.";
  var target=order.target(p);int left=order.amount();for(var stack:p.getInventory().items){if(left==0)break;if(ItemStack.isSameItemSameComponents(stack,target)){int n=Math.min(left,stack.getCount());stack.shrink(n);left-=n;}}
  var a=RelayEconomy.account(p);a.putLong("balance",RelayEconomy.balance(p)+order.reward());a.putInt("reputation",Math.min(1_000_000,reputation(p)+5));var b=board(p);var paid=b.getCompound("done");paid.putBoolean(order.id(),true);b.put("done",paid);RelayEconomy.save(p);
  return "Заказ сдан: +"+order.reward()+" кр., +5 репутации. "+title(p)+" · скидка "+discount(p)+"%.";
 }
 public static int open(ServerPlayer p){p.openMenu(new SimpleMenuProvider((id,inv,player)->new OrdersMenu(id,inv,p),Component.literal("Заказы снабжения")));return 1;}
 static int openPocket(ServerPlayer p){
  if(!RelayEconomy.safe(p))return 0;
  p.openMenu(new SimpleMenuProvider((id,inv,player)->new OrdersMenu(id,inv,p,new SimpleContainer(27),true),Component.literal("Заказы снабжения")));
  return 1;
 }
 public static final class OrdersMenu extends ChestMenu {
  private final ServerPlayer owner;private final SimpleContainer panel;private final boolean pocket;private Order selected;private int displayedCycle;
  public OrdersMenu(int id,Inventory inv){super(RelayMenus.ORDERS.get(),id,inv,new SimpleContainer(27),3);owner=null;panel=(SimpleContainer)getContainer();pocket=false;}
 public OrdersMenu(int id,Inventory inv,ServerPlayer p){this(id,inv,p,new SimpleContainer(27),false);}
  private OrdersMenu(int id,Inventory inv,ServerPlayer p,SimpleContainer c,boolean pocket){super(RelayMenus.ORDERS.get(),id,inv,c,3);owner=p;panel=c;this.pocket=pocket;displayedCycle=cycle(p);refresh();}
  private void icon(int slot,ItemStack stack,String name,String... lore){stack.set(DataComponents.CUSTOM_NAME,Component.literal(name));stack.set(DataComponents.LORE,new ItemLore(Arrays.stream(lore).map(Component::literal).map(c->(Component)c).toList()));panel.setItem(slot,stack);}
  private void refresh(){panel.clearContent();var orders=list(owner);for(int i=0;i<3;i++){var o=orders.get(i);var stack=o.goods().stack(owner).copyWithCount(1);icon(10+i*2,stack,(done(owner,o)?"СДАНО · ":"")+o.goods().name().replaceFirst(" ×.*$","")+" ×"+o.amount(),"В инвентаре: "+count(owner,o)+" / "+o.amount(),"Оплата: "+o.reward()+" кр. и 5 репутации","Выбор заказа; сдача — отдельной кнопкой.");}
   if(pocket)icon(0,new ItemStack(Items.COMPASS),"КПК · Магазин","Вернуться к торговцам");
   icon(4,new ItemStack(Items.EMERALD),title(owner)+" · "+reputation(owner)+" реп.","Скидка: "+discount(owner)+"%. Пороги: 10 / 30 / 60.");
   icon(22,new ItemStack(selected==null?Items.GRAY_DYE:Items.LIME_DYE),selected==null?"Выберите заказ":"СДАТЬ "+selected.amount()+" шт. за "+selected.reward()+" кр.","Подтвердите левой кнопкой. Только дома, вне вылазки.");
   icon(26,new ItemStack(Items.PAPER),"Доска №"+displayedCycle,"Новые заказы: сдайте все три и эвакуируйтесь из новой зоны.","Несданные заказы сохраняются. Рюкзаки не вскрываются.");
  }
  @Override public void clicked(int slot,int button,ClickType type,Player p){if(p!=owner||type!=ClickType.PICKUP||button!=0)return;if(slot==0&&pocket){PocketDevice.open(owner,PocketDevice.Page.SHOP);return;}if(displayedCycle!=cycle(owner)){selected=null;displayedCycle=cycle(owner);refresh();sendAllDataToRemote();return;}if(slot==10||slot==12||slot==14){var o=list(owner).get((slot-10)/2);selected=done(owner,o)?null:o;}else if(slot==22&&selected!=null){RaidRules.tell(owner,deliver(owner,selected,displayedCycle));selected=null;}refresh();sendAllDataToRemote();}
  @Override public ItemStack quickMoveStack(Player p,int slot){return ItemStack.EMPTY;}
  @Override public boolean stillValid(Player p){return p==owner&&p.isAlive();}
 }
 private SupplyOrders(){}
}
