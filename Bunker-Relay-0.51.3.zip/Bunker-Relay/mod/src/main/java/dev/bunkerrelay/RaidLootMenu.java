package dev.bunkerrelay;
import java.util.function.BooleanSupplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.IItemHandler;

/** Live paged loot view. Preview stacks can never be moved or cloned by vanilla clicks. */
public final class RaidLootMenu extends ChestMenu {
 public interface Source {int size();ItemStack item(int slot);ItemStack extract(int slot,int count,boolean simulate);boolean valid();}
 private final ServerPlayer owner;private final Source source;private final SimpleContainer view;private int page;
 public static Source container(Container c,BooleanSupplier valid){return new Source(){
  public int size(){return c.getContainerSize();}public ItemStack item(int s){return c.getItem(s);}
  public ItemStack extract(int s,int n,boolean simulate){if(simulate)return c.getItem(s).copyWithCount(Math.min(n,c.getItem(s).getCount()));var result=c.removeItem(s,n);c.setChanged();return result;}
  public boolean valid(){return valid.getAsBoolean();}
 };}
 public static Source handler(IItemHandler h,BooleanSupplier valid){return new Source(){
  public int size(){return h.getSlots();}public ItemStack item(int s){return h.getStackInSlot(s);}public ItemStack extract(int s,int n,boolean simulate){return h.extractItem(s,n,simulate);}public boolean valid(){return valid.getAsBoolean();}
 };}
 public static boolean open(ServerPlayer p,BlockPos pos){
  var level=p.serverLevel();var be=level.getBlockEntity(pos);if(be==null)return false;var state=level.getBlockState(pos);
  BooleanSupplier present=()->p.level()==level&&level.getBlockEntity(pos)==be&&p.distanceToSqr(pos.getX()+0.5,pos.getY()+0.5,pos.getZ()+0.5)<=64;
  Container c=state.getBlock() instanceof ChestBlock chest?ChestBlock.getContainer(chest,state,level,pos,true):be instanceof Container container?container:null;
  Source source;
  if(c!=null){if(be instanceof RandomizableContainerBlockEntity loot)loot.unpackLootTable(p);Container storage=c;source=container(storage,()->present.getAsBoolean()&&storage.stillValid(p));}
  else {var handler=level.getCapability(Capabilities.ItemHandler.BLOCK,pos,null);if(handler==null)return false;source=handler(handler,present);}
  if(source.size()==0)return false;
  p.openMenu(new SimpleMenuProvider((id,inv,player)->new RaidLootMenu(id,inv,p,source),Component.literal("Добыча: ЛКМ — стак, ПКМ — 1")));return true;
 }
 public RaidLootMenu(int id,Inventory inv,ServerPlayer p,Source source){this(id,inv,p,source,new SimpleContainer(54));}
 private RaidLootMenu(int id,Inventory inv,ServerPlayer p,Source source,SimpleContainer view){
  super(MenuType.GENERIC_9x6,id,inv,view,6);this.owner=p;this.source=source;this.view=view;
  for(int i=0;i<54;i++){var old=slots.get(i);var slot=new Slot(view,i,old.x,old.y){@Override public boolean mayPlace(ItemStack s){return false;}@Override public boolean mayPickup(Player p){return false;}};slot.index=i;slots.set(i,slot);}refresh();
 }
 private void refresh(){
  int pages=Math.max(1,(source.size()+44)/45);page=Math.min(page,pages-1);
  for(int i=0;i<54;i++){int n=page*45+i;view.setItem(i,i<45&&n<source.size()?source.item(n).copy():ItemStack.EMPTY);}
  button(45,Items.ARROW,"Предыдущая страница");button(49,Items.PAPER,"Страница "+(page+1)+" / "+pages);button(53,Items.ARROW,"Следующая страница");
 }
 private void button(int i,Item item,String text){var s=new ItemStack(item);s.set(DataComponents.CUSTOM_NAME,Component.literal(text));view.setItem(i,s);}
 public int take(int localSlot,int amount){
  if(!stillValid(owner)||localSlot<0||localSlot>=45)return 0;int i=page*45+localSlot;if(i>=source.size())return 0;
  ItemStack stack=source.item(i);if(stack.isEmpty())return 0;String reject=RaidSnapshot.reject(stack,owner);if(reject!=null){RaidRules.tell(owner,reject);return 0;}
  int count=Math.min(amount,Math.min(stack.getCount(),SafeInventory.capacity(owner.getInventory(),stack)));if(count<=0){RaidRules.tell(owner,"Нет места. Предметы остаются в хранилище.");return 0;}
  var probe=source.extract(i,count,true);if(probe.isEmpty())return 0;count=Math.min(count,Math.min(probe.getCount(),SafeInventory.capacity(owner.getInventory(),probe)));if(count<=0)return 0;
  var got=source.extract(i,count,false);int extracted=got.getCount();SafeInventory.returnCarried(owner,got);refresh();broadcastChanges();return extracted;
 }
 @Override public void clicked(int slot,int button,ClickType type,Player player){
  if(player!=owner||!stillValid(player))return;
  if(slot>=0&&slot<54){
   if((type==ClickType.PICKUP||type==ClickType.QUICK_MOVE)&&getCarried().isEmpty()){
    if(slot==45)page=Math.max(0,page-1);else if(slot==53)page=Math.min(Math.max(0,(source.size()-1)/45),page+1);
    else if(slot<45)take(slot,type==ClickType.PICKUP&&button==1?1:Integer.MAX_VALUE);
   }
   refresh();sendAllDataToRemote();return;
  }
  if(type==ClickType.CLONE)return;super.clicked(slot,button,type,player);refresh();sendAllDataToRemote();
 }
 @Override public ItemStack quickMoveStack(Player p,int index){
  if(p!=owner||!stillValid(p)||index<0||index>=slots.size())return ItemStack.EMPTY;
  if(index<45){take(index,Integer.MAX_VALUE);return ItemStack.EMPTY;}
  if(index<54)return ItemStack.EMPTY;var slot=slots.get(index);var stack=slot.getItem();if(stack.isEmpty())return ItemStack.EMPTY;var original=stack.copy();
  if(index<81){if(!moveItemStackTo(stack,81,90,false))return ItemStack.EMPTY;}else if(!moveItemStackTo(stack,54,81,false))return ItemStack.EMPTY;
  if(stack.isEmpty())slot.setByPlayer(ItemStack.EMPTY);else slot.setChanged();return original;
 }
 @Override public boolean canTakeItemForPickAll(ItemStack s,Slot slot){return slot.index>=54&&super.canTakeItemForPickAll(s,slot);}
 @Override public boolean stillValid(Player p){return p==owner&&RaidRules.active(owner)&&source.valid();}
 @Override public void broadcastChanges(){if(source!=null&&source.valid())refresh();super.broadcastChanges();}
 @Override public void removed(Player p){if(p instanceof ServerPlayer server){var cursor=getCarried();setCarried(ItemStack.EMPTY);SafeInventory.returnCarried(server,cursor);}super.removed(p);}
}
