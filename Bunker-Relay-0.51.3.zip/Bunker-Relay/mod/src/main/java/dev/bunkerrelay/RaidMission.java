package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;

final class RaidMission {
    static void prepare(ServerLevel level, RelayState state) {
        state.mission = ExpeditionContracts.selected(state)==ExpeditionContracts.Type.BEACONS?5:1+Math.floorMod(state.seed,8);
        state.missionProgress = 0;
        state.missionStarted = false;
        state.missionSeconds = 0;
        state.missionNodes = RaidDirector.get(level.getServer()).rooms.stream()
            .filter(room -> switch (state.mission) {
                case 1 -> room.getString("type").equals("echo") || room.getString("type").equals("signal");
                case 2 -> room.getString("type").equals("clinic");
                case 3 -> room.getString("type").equals("archive");
                case 5 -> room.getString("type").equals("archive")||room.getString("type").equals("signal");
                case 6 -> room.getString("type").equals("clinic")||room.getString("type").equals("echo");
                case 7 -> switch (room.getString("type")) {
                    case "echo", "signal", "archive" -> true;
                    default -> false;
                };
                case 8 -> room.getString("type").equals("signal");
                default -> false;
            })
            .mapToLong(room -> new BlockPos(room.getInt("x") + 3, room.getInt("y"), room.getInt("z") + 4).asLong())
            .toArray();
        for (long node : state.missionNodes) level.setBlock(BlockPos.of(node), Blocks.LODESTONE.defaultBlockState(), 3);
    }

    static BlockPos radio(RelayState state) {
        return new BlockPos(state.relayX, state.relayY, state.relayZ);
    }

    static BlockPos target(RelayState state) {
        for (int i = 0; i < state.missionNodes.length; i++)
            if ((state.missionProgress & (1 << i)) == 0) return BlockPos.of(state.missionNodes[i]);
        return radio(state);
    }

    static boolean node(RelayState state, BlockPos pos) {
        for (long node : state.missionNodes) if (node == pos.asLong()) return true;
        return false;
    }

    static String label(RelayState state) {
        if (state.relayPowered) return "Эвакуация открыта";
        boolean atRadio = target(state).equals(radio(state));
        return switch (state.mission) {
            case 1 -> atRadio ? "Подайте питание на радиостанцию" : "Восстановите питание узлов";
            case 2 -> atRadio ? "Введите код на радиостанции" : "Найдите код доступа в лазарете";
            case 3 -> atRadio ? "Передайте данные по радио" : "Скопируйте данные в архиве";
            case 5 -> atRadio ? "Загрузите данные маяков в радиостанцию" : "Откалибруйте маяки по порядку";
            case 6 -> atRadio ? (state.missionStarted?"Передача образцов · "+(duration(state)-state.missionSeconds)+" с":"Начните передачу образцов") : "Возьмите образцы в двух объектах";
            case 7 -> atRadio ? "Передайте карту помех по радио" : "Проверьте три поста по маршруту";
            case 8 -> atRadio ? (state.missionStarted ? "Аварийный вызов · " + (duration(state) - state.missionSeconds) + " с" : "Отправьте аварийный вызов") : "Запустите резервный передатчик на блокпосту";
            case 4 -> state.missionStarted ? "Удерживайте радио · " + (duration(state) - state.missionSeconds) + " с" : "Начните передачу";
            default -> "Активируйте радиостанцию";
        };
    }

    static void use(ServerPlayer player, RelayState state, BlockPos pos) {
        if (state.relayPowered) { RaidRules.tell(player, "Эвакуация уже открыта."); return; }
        if (pos.equals(radio(state))) {
            if (!target(state).equals(pos)) { report(player); return; }
            if (!requiresDefense(state)) { complete(player.server, state); return; }
            state.missionStarted = true;
            state.setDirty();
            RaidRules.tell(player, label(state));
            return;
        }
        for (int i = 0; i < state.missionNodes.length; i++) {
            if (state.missionNodes[i] != pos.asLong() || (state.missionProgress & (1 << i)) != 0) continue;
            if((state.mission == 5 || state.mission == 7) && !target(state).equals(pos)){report(player);return;}
            state.missionProgress |= 1 << i;
            state.setDirty();
            for (var teammate : player.server.getPlayerList().getPlayers())
                if (RaidRules.active(teammate)) report(teammate);
            return;
        }
        RaidRules.tell(player, "Узел уже обработан.");
    }

    static int report(ServerPlayer player) {
        var state = RelayState.get(player.server);
        if (!state.ready) { RaidRules.tell(player, "Зона ещё не готова."); return 0; }
        var pos = state.relayPowered ? new BlockPos(state.centerX, state.spawnY, state.centerZ) : target(state);
        RaidRules.chat(player, label(state) + " · " + pos.toShortString());
        return 1;
    }

    private static boolean requiresDefense(RelayState state) {
        return state.mission == 4 || state.mission == 6 || state.mission == 8;
    }

    private static int duration(RelayState state) {
        return (state.mission == 8 ? 30 : 45) + 15 * state.activeDifficulty;
    }

    static void second(MinecraftServer server, RelayState state) {
        if (!state.ready || state.generating || state.relayPowered || !requiresDefense(state) || !state.missionStarted) return;
        var radio = radio(state);
        var defender = server.getPlayerList().getPlayers().stream()
            .filter(p -> p.isAlive() && !p.isSpectator() && RaidRules.active(p)
                && p.level().dimension().equals(BunkerRelay.key(state.activeDimension))
                && p.blockPosition().distSqr(radio) <= 144)
            .findFirst().orElse(null);
        if (defender == null) return;
        state.missionSeconds++;
        state.setDirty();
        if (state.missionSeconds >= duration(state)) complete(server, state);
        else if (state.mission == 8 && state.missionSeconds % 15 == 0)
            RaidDirector.spawnNear(defender, state, "faceless", 40);
        else if (state.mission != 8 && state.missionSeconds % 20 == 0)
            RaidDirector.spawnNear(defender, state, "stalker", 16);
    }

    private static void complete(MinecraftServer server, RelayState state) {
        state.relayPowered = true;
        state.setDirty();
        Navigation.signal(server, state);
        for (var player : server.getPlayerList().getPlayers()) {
            if (RaidRules.active(player)) Navigation.route(player, "exit");
            RaidRules.chat(player, "Задание выполнено. Выход · " + new BlockPos(state.centerX, state.spawnY, state.centerZ).toShortString());
        }
    }

    private RaidMission() {}
}
