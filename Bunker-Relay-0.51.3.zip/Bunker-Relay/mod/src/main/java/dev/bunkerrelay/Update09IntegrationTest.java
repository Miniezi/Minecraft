package dev.bunkerrelay;
import java.util.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.*;
import net.minecraft.world.level.storage.loot.parameters.*;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
public final class Update09IntegrationTest {
 private static void check(boolean b,String msg){if(!b)throw new IllegalStateException("UPDATE09: "+msg);}
 public static void run(MinecraftServer server){
  var s=RelayState.get(server);var level=server.getLevel(BunkerRelay.key(s.activeDimension));
  for(int d=1;d<=5;d++)for(int delta=-1;delta<=1;delta++){int t=RaidBalance.lootTier(d,delta);check(t>=1&&t<=5&&Math.abs(t-d)<=1,"loot bounds");}
  var params=new LootParams.Builder(level).withParameter(LootContextParams.ORIGIN,new Vec3(s.centerX,s.spawnY,s.centerZ)).create(LootContextParamSets.CHEST);
  var context=new LootContext.Builder(params).withQueriedLootTableId(ResourceLocation.parse("minecraft:chests/simple_dungeon")).create(Optional.empty());
  var modified=new StructureLoot(new net.minecraft.world.level.storage.loot.predicates.LootItemCondition[0]).apply(new it.unimi.dsi.fastutil.objects.ObjectArrayList<ItemStack>(),context);
  check(!modified.isEmpty()&&modified.stream().anyMatch(i->i.getItem() instanceof com.tacz.guns.api.item.IAmmo),"vanilla structure gets expedition supplies");
  var payload=new ExitSignal(level.dimension().location(),new BlockPos(s.centerX,s.spawnY,s.centerZ),true);
  var buf=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),level.registryAccess());try{ExitSignal.CODEC.encode(buf,payload);check(payload.equals(ExitSignal.CODEC.decode(buf)),"beam packet roundtrip");}finally{buf.release();}
  check(server.getCommands().getDispatcher().getRoot().getChild("relay").getChild("loot")==null,"no independent loot command");
  check(server.getCommands().getDispatcher().getRoot().getChild("relay").getChild("confirm")==null,"legacy remote confirmation removed");
  check(RelayMenus.TERMINAL.get()!=null&&RelayMenus.MARKET.get()!=null,"custom menu types registered");
  var names=new HashSet<String>();String original=s.activeTheme;for(String theme:new String[]{"industrial","infected","ash","forest"}){s.activeTheme=theme;names.add(RaidBosses.name(s));}s.activeTheme=original;check(names.size()==4,"four distinct bosses");
  System.out.println("RELAY_UPDATE09_PASS: loot bounds, structure supplies, beam packet, commands, custom menus, boss identities");
 }
 private Update09IntegrationTest(){}
}
