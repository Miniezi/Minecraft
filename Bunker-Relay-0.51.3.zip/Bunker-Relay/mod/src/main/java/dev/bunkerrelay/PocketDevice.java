package dev.bunkerrelay;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;

public final class PocketDevice extends Item {
    static final java.util.function.Supplier<Item> ITEM=BossTrophies.ITEMS.register("pocket_device",
        ()->new PocketDevice(new Item.Properties().stacksTo(1)));

    private PocketDevice(Properties properties){super(properties);}
    static void register(){PdaProtection.register();}

    @Override public boolean onDroppedByPlayer(ItemStack stack,Player player){return false;}

    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        if(player instanceof ServerPlayer serverPlayer)open(serverPlayer);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand),level.isClientSide());
    }

    enum Page { RAID, SHOP, BASE, ROUTES, CARGO }

    static int open(ServerPlayer player){
        return open(player,Page.RAID);
    }

    static int open(ServerPlayer player,Page page){
        player.openMenu(new SimpleMenuProvider((id,inventory,ignored)->new Menu(id,inventory,player,page),
            Component.translatable("item.bunkerrelay.pocket_device")));
        return 1;
    }

    static void grant(ServerPlayer player){
        var data=player.getPersistentData();
        if(data.getBoolean("relay_pda_issued"))return;
        var stack=new ItemStack(ITEM.get());
        if(SafeInventory.capacity(player.getInventory(),stack)<1){
            RaidRules.tell(player,"КПК · освободите слот и введите /relay ещё раз.");
            return;
        }
        SafeInventory.insert(player.getInventory(),stack);
        data.putBoolean("relay_pda_issued",true);
        RelayEconomy.save(player);
    }

    public static final class Menu extends ChestMenu {
        private final ServerPlayer owner;
        private final SimpleContainer panel;
        private Page page;

        Menu(int id,Inventory inventory){this(id,inventory,null,Page.RAID);}
        Menu(int id,Inventory inventory,ServerPlayer owner,Page page){this(id,inventory,owner,page,new SimpleContainer(27));}
        private Menu(int id,Inventory inventory,ServerPlayer owner,Page page,SimpleContainer panel){
            super(RelayMenus.POCKET.get(),id,inventory,panel,3);
            this.owner=owner;
            this.panel=panel;
            this.page=page;
            if(owner!=null)refresh();
        }

        private void button(int slot,Item item,String label,String hint){
            var stack=new ItemStack(item);
            stack.set(DataComponents.CUSTOM_NAME,Component.literal(label));
            stack.set(DataComponents.LORE,new ItemLore(java.util.List.of(Component.literal(hint))));
            panel.setItem(slot,stack);
        }

        void updateMeeting(){
            if(page==Page.ROUTES){refresh();broadcastChanges();}
        }

        private void refresh(){
            panel.clearContent();
            var state=RelayState.get(owner.server);
            button(0,Items.COMPASS,(page==Page.RAID||page==Page.ROUTES||page==Page.CARGO?"• ":"")+"Вылазка","");
            button(1,Items.EMERALD,(page==Page.SHOP?"• ":"")+"Магазин","");
            button(2,Items.IRON_BLOCK,(page==Page.BASE?"• ":"")+"База","");
            switch(page){
                case RAID -> {
                    button(9,Items.COMPASS,"Цель",state.ready?ExpeditionContracts.status(owner,state):"Зона ещё не готова");
                    button(10,Items.SPYGLASS,"Ориентиры","Выберите объект для компаса");
                    button(11,Items.WRITABLE_BOOK,"Журнал","Контракты и почта");
                    button(12,Items.BARREL,"Груз",CargoContract.status(state));
                    button(13,Items.SPECTRAL_ARROW,"Навигация","Маршруты и метка группы");
                    button(14,Items.IRON_DOOR,"Возвращение","На вылазке — с площадки эвакуации");
                    button(15,Items.FIREWORK_ROCKET,"Воздушный сброс",Airdrop.status(RaidDirector.get(owner.server)));
                    button(16,Items.LEATHER_CHESTPLATE,"Стартовый комплект",StarterKit.status(owner,state));
                    button(17,Items.SPYGLASS,"Следы у построек",ZoneLandmarks.lastClue(RaidDirector.get(owner.server)));
                    button(18,Items.REDSTONE_TORCH,"Сигнал по пути",RouteEvents.status(state));
                    button(19,Items.BARREL,"Тайник команды",TeamStash.status(owner,state));
                }
                case SHOP -> {
                    if(!RelayEconomy.safe(owner)){
                        button(9,Items.BARRIER,"Торговля на базе","Доступна в бункере и гараже");
                        break;
                    }
                    for(var merchant:RelayEconomy.Merchant.values())
                        button(9+merchant.ordinal(),merchant.icon,merchant.title,"Открыть ассортимент");
                    button(16,Items.HOPPER,"Скупщик","Оценить и продать предметы");
                    button(17,Items.WRITABLE_BOOK,"Заказы снабжения","Текущие поставки");
                }
                case BASE -> {
                    if(RelayEconomy.safe(owner)&&BaseUpgrades.has(owner,BaseUpgrades.Upgrade.STORAGE))
                        button(9,Items.BARREL,"Личный склад","Выдача, приём и продажа");
                    button(10,Items.SMITHING_TABLE,"Мастерская",CourtyardWorkshop.hint(owner,state));
                    button(11,Items.REDSTONE_TORCH,"Подсказки","Показать или скрыть навигацию");
                    button(12,Items.NOTE_BLOCK,"Скримеры","Переключить эффекты");
                    button(13,Items.HOPPER,"Корзина","Удаление после закрытия");
                    if(RelayEconomy.safe(owner))button(14,Items.EXPERIENCE_BOTTLE,"Навыки","Очки: "+SkillMenu.points(owner));
                }
                case ROUTES -> {
                    button(9,Items.SPECTRAL_ARROW,"Отметить точку","По направлению взгляда");
                    button(10,Items.FILLED_MAP,"Метка группы","Следовать активной метке");
                    button(11,Items.MAP,"Маршрут к выходу","Показать направление");
                    button(12,Items.RECOVERY_COMPASS,"Маршрут к задаче","Автоматически обновляется");
                    button(16,Items.SPYGLASS,"Выбрать ориентир","Объекты, находки и выходы");
                    button(13,Items.PAPER,"Проверочный код",MeetingSignals.ownCode(owner,state));
                    button(14,Items.ENDER_PEARL,"Позвать на встречу","Передать группе свою позицию и код");
                    var meeting=MeetingSignals.current(owner,state);
                    button(15,Items.COMPASS,"Точка встречи",meeting==null?"Нет активного сигнала":meeting.caption());
                }
                case CARGO -> {
                    button(9,Items.MAP,"Найти груз",CargoContract.status(state));
                    if(RaidRules.active(owner)){
                        button(10,Items.CHEST_MINECART,"Поднять груз","Подойдите к точке со свободной второй рукой");
                        button(11,Items.LEAD,"Оставить груз","Для передачи напарнику");
                    }
                }
            }
        }

        @Override public void clicked(int slot,int button,ClickType type,Player player){
            if(player!=owner||type!=ClickType.PICKUP||button!=0||!stillValid(player)
                ||slot<0||slot>=panel.getContainerSize()||panel.getItem(slot).isEmpty())return;
            if(slot<=2)page=Page.values()[slot];
            else switch(page){
                case RAID -> {
                    switch(slot){
                        case 9 -> {RaidRules.chat(owner,ExpeditionContracts.status(owner,RelayState.get(owner.server)));RaidMission.report(owner);}
                        case 10 -> ReconChart.targets(owner);
                        case 11 -> RaidContracts.open(owner);
                        case 12 -> page=Page.CARGO;
                        case 13 -> page=Page.ROUTES;
                        case 14 -> BunkerRelay.pocketTravel(owner);
                        case 15 -> Airdrop.track(owner);
                        case 16 -> StarterKit.claim(owner,RelayState.get(owner.server));
                        case 17 -> ReconChart.targets(owner);
                        case 18 -> RouteEvents.track(owner,RelayState.get(owner.server));
                        case 19 -> TeamStash.use(owner,RelayState.get(owner.server));
                        default -> {}
                    }
                }
                case SHOP -> {
                    if(RelayEconomy.safe(owner)){
                        if(slot>=9&&slot<9+RelayEconomy.Merchant.values().length)RelayEconomy.openPocket(owner,false,RelayEconomy.Merchant.values()[slot-9]);
                        if(slot==16)RelayEconomy.openPocket(owner,true,RelayEconomy.Merchant.RESOURCES);
                        if(slot==17)SupplyOrders.openPocket(owner);
                    }
                }
                case BASE -> {
                    switch(slot){
                        case 9 -> BaseUpgrades.locker(owner,true,false,RelayEconomy.Merchant.RESOURCES);
                        case 10 -> CourtyardWorkshop.useOrLocate(owner);
                        case 11 -> RaidHud.toggle(owner);
                        case 12 -> RaidDirector.toggleScares(owner);
                        case 13 -> RaidRules.discard(owner);
                        case 14 -> SkillMenu.open(owner);
                        default -> {}
                    }
                }
                case ROUTES -> {
                    switch(slot){
                        case 9 -> Navigation.ping(owner);
                        case 10 -> Navigation.route(owner,"ping");
                        case 11 -> Navigation.route(owner,"exit");
                        case 12 -> Navigation.route(owner,"auto");
                        case 13 -> RaidRules.tell(owner,"Ваш код · "+MeetingSignals.ownCode(owner,RelayState.get(owner.server)));
                        case 14 -> MeetingSignals.share(owner);
                        case 15 -> MeetingSignals.follow(owner);
                        case 16 -> ReconChart.targets(owner);
                        default -> {}
                    }
                }
                case CARGO -> {
                    switch(slot){
                        case 9 -> CargoContract.report(owner);
                        case 10 -> CargoContract.take(owner);
                        case 11 -> CargoContract.drop(owner,RelayState.get(owner.server));
                        default -> {}
                    }
                }
            }
            if(owner.containerMenu==this){refresh();broadcastChanges();}
        }
        @Override public ItemStack quickMoveStack(Player player,int slot){return ItemStack.EMPTY;}
        @Override public boolean stillValid(Player player){return player==owner&&owner.isAlive();}
    }
}
