package dev.bunkerrelay;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
/** Saved alongside inventory in the same vanilla player file; recovers the last saved open menu. */
public final class TrashRecovery {
 private static final String OPEN="relay_open_trash",PENDING="relay_trash_recovery";
 public static void checkpoint(ServerPlayer p,Container trash,ItemStack cursor){var list=new ListTag();for(int i=0;i<trash.getContainerSize();i++)if(!trash.getItem(i).isEmpty())list.add(trash.getItem(i).save(p.registryAccess()));if(!cursor.isEmpty())list.add(cursor.save(p.registryAccess()));p.getPersistentData().put(OPEN,list);}
 public static void closed(ServerPlayer p){p.getPersistentData().remove(OPEN);}
 public static void login(ServerPlayer p){var data=p.getPersistentData();var pending=data.getList(PENDING,Tag.TAG_COMPOUND);for(var tag:data.getList(OPEN,Tag.TAG_COMPOUND))pending.add(tag.copy());data.remove(OPEN);data.put(PENDING,pending);drain(p);}
 static void retain(ServerPlayer p,ListTag items){var data=p.getPersistentData();var pending=data.getList(PENDING,Tag.TAG_COMPOUND);for(var tag:items)pending.add(tag.copy());data.put(PENDING,pending);}
 public static boolean pending(ServerPlayer p){return !p.getPersistentData().getList(PENDING,Tag.TAG_COMPOUND).isEmpty();}
 public static void drain(ServerPlayer p){if(!p.isAlive()||!pending(p))return;if(RaidRules.active(p)&&!RaidRules.record(p).getString("status").equals("ACTIVE"))return;var remaining=new ListTag();int recovered=0;for(var tag:p.getPersistentData().getList(PENDING,Tag.TAG_COMPOUND)){var item=ItemStack.parseOptional(p.registryAccess(),(CompoundTag)tag);int before=item.getCount();SafeInventory.insert(p.getInventory(),item);recovered+=before-item.getCount();if(!item.isEmpty())remaining.add(item.save(p.registryAccess()));}p.getPersistentData().put(PENDING,remaining);if(recovered>0){p.inventoryMenu.broadcastChanges();RaidRules.tell(p,"Восстановлено из незакрытой корзины: "+recovered+" предметов.");}}
 public static void discardOnSettlement(ServerPlayer p){p.getPersistentData().remove(OPEN);p.getPersistentData().remove(PENDING);}
 private TrashRecovery(){}
}
