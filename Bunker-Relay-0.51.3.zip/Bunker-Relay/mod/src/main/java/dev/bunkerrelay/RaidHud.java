package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
/** Vanilla action bar; updated once a second, no client mod or custom packets. */
public final class RaidHud {
 private static final Map<UUID,ArrayDeque<String>> messages=new HashMap<>();
 private static final Map<UUID,Long> until=new HashMap<>();
 public static void alert(ServerPlayer p,String text){clear(p);notice(p,text);}
 public static void notice(ServerPlayer p,String text){
  if(text==null||text.isBlank())return;
  var q=messages.computeIfAbsent(p.getUUID(),id->new ArrayDeque<>());
  if(q.contains(text))return;
  String rest=text;while(!rest.isBlank()){int cut=Math.min(90,rest.length());if(cut<rest.length()){int space=rest.lastIndexOf(' ',cut);if(space>30)cut=space;}if(q.size()>=6)q.removeLast();q.addLast(rest.substring(0,cut).trim());rest=rest.substring(cut).trim();}
  if(!until.containsKey(p.getUUID()))until.put(p.getUUID(),p.server.overworld().getGameTime()+80);
  p.displayClientMessage(Component.literal(q.getFirst()),true);
 }
 public static boolean hasNotice(ServerPlayer p){var q=messages.get(p.getUUID());return q!=null&&!q.isEmpty();}
 public static void pulse(ServerPlayer p){var q=messages.get(p.getUUID());if(q==null)return;long now=p.server.overworld().getGameTime();if(now>=until.getOrDefault(p.getUUID(),0L)){q.pollFirst();if(q.isEmpty()){clear(p);return;}until.put(p.getUUID(),now+80);}p.displayClientMessage(Component.literal(q.getFirst()),true);}
 public static void clear(ServerPlayer p){messages.remove(p.getUUID());until.remove(p.getUUID());}
 public static void reset(){messages.clear();until.clear();}
 public static String direction(BlockPos from,BlockPos to){int x=to.getX()-from.getX(),z=to.getZ()-from.getZ();if(Math.abs(x)<=3&&Math.abs(z)<=3)return Math.abs(to.getY()-from.getY())>5?(to.getY()>from.getY()?"выше":"ниже"):"рядом";String ns=Math.abs(z)>3?(z<0?"С":"Ю"):"",ew=Math.abs(x)>3?(x<0?"З":"В"):"";return ns+ew;}
 public static void tick(ServerPlayer p,RelayState s){if(!hasNotice(p)&&!p.getPersistentData().getBoolean("relay_hud_off"))p.displayClientMessage(Component.literal(Navigation.text(p,s)),true);}
 public static int toggle(ServerPlayer p){boolean off=!p.getPersistentData().getBoolean("relay_hud_off");p.getPersistentData().putBoolean("relay_hud_off",off);p.displayClientMessage(Component.empty(),true);RaidRules.tell(p,"Подсказки вылазки: "+(off?"выключены":"включены"));return 1;}
 private RaidHud(){}
}
