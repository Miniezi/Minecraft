package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.common.util.FakePlayer;

final class WarehouseIntegrationTest {
    static void verify(MinecraftServer server) {
        var player = new FakePlayer(server.getLevel(BunkerRelay.HUB), new GameProfile(UUID.randomUUID(), "RelayWarehouse")) {
            @Override public java.util.OptionalInt openMenu(net.minecraft.world.MenuProvider provider) {
                containerMenu = provider.createMenu(62, getInventory(), this);
                return java.util.OptionalInt.of(62);
            }
        };
        var terminal = HubBuilder.TERMINAL;
        player.moveTo(terminal.getX(), terminal.getY(), terminal.getZ());
        var state = RelayState.get(server);
        int previous = state.baseUpgrades;
        try {
            state.baseUpgrades |= 1 << BaseUpgrades.Upgrade.STORAGE.ordinal();
            verify(player);
        } finally {
            state.baseUpgrades = previous;
        }
    }

    static void verify(ServerPlayer player) {
        var data = player.getPersistentData();
        var legacy = NonNullList.withSize(54, ItemStack.EMPTY);
        legacy.set(10, new ItemStack(Items.COPPER_INGOT, 5));
        legacy.set(53, new ItemStack(Items.COPPER_INGOT, 7));
        data.put(Warehouse.KEY, ContainerHelper.saveAllItems(new CompoundTag(), legacy, player.registryAccess()));
        player.getInventory().clearContent();
        player.getInventory().setItem(9, new ItemStack(Items.COPPER_INGOT, 3));
        var copper = new ItemStack(Items.COPPER_INGOT);
        BunkerRelay.openTerminal(player);
        player.containerMenu.clicked(3, 0, ClickType.PICKUP, player);
        player.containerMenu.clicked(28, 0, ClickType.PICKUP, player);
        require(player.containerMenu instanceof LockerMenu, "base opens warehouse");
        var menu = (LockerMenu) player.containerMenu;
        require(new Warehouse(player).entries().size() == 1 && new Warehouse(player).count(copper) == 12,
            "legacy stacks grouped");
        menu.clicked(1, 0, ClickType.PICKUP, player);
        menu.clicked(9, 1, ClickType.PICKUP, player);
        require(player.getInventory().getItem(9).isEmpty() && new Warehouse(player).count(copper) == 15, "deposit");
        menu.clicked(0, 0, ClickType.PICKUP, player);
        menu.clicked(9, 0, ClickType.PICKUP, player);
        require(new Warehouse(player).count(copper) == 14, "withdraw one");
        for (int i = 0; i < 36; i++) player.getInventory().setItem(i, new ItemStack(Items.DIRT, 64));
        menu.clicked(9, 1, ClickType.PICKUP, player);
        require(new Warehouse(player).count(copper) == 14, "full inventory preserves stock");
        player.getInventory().setItem(9, copper.copy());
        RelayEconomy.open(player, true);
        var lore = player.containerMenu.getSlot(9).getItem().get(DataComponents.LORE);
        require(lore != null && lore.lines().getFirst().getString().contains("склад 14"),
            "market displays warehouse quantity");
        player.containerMenu.clicked(51, 0, ClickType.PICKUP, player);
        require(player.containerMenu instanceof LockerMenu, "market opens warehouse");
        long balance = RelayEconomy.balance(player);
        int price = SalvageValue.price(copper);
        var account = RelayEconomy.account(player);
        account.putInt("budget", price * 2);
        player.containerMenu.clicked(9, 1, ClickType.PICKUP, player);
        require(new Warehouse(player).count(copper) == 12 && RelayEconomy.balance(player) == balance + price * 2
            && account.getInt("budget") == 0, "direct sale uses shared budget");
        player.containerMenu.clicked(9, 1, ClickType.PICKUP, player);
        require(new Warehouse(player).count(copper) == 12, "exhausted sale leaves stock intact");
        System.out.println("RELAY_WAREHOUSE_PASS");
    }

    private static void require(boolean condition, String operation) {
        if (!condition) throw new IllegalStateException("Warehouse: " + operation);
    }
}
