package dev.bunkerrelay;

import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.levelgen.Heightmap;

final class FieldSecurity {
    private static final String LOCK="relay_field_lock";
    private static final String CODE="relay_field_code";
    private static final String KEY="fieldSafeKey";
    private static final String KNOWN="fieldSafeCode";

    static void mark(ServerLevel level,BlockPos pos,String template){
        var chest=level.getBlockEntity(pos);
        if(chest==null)return;
        String type=switch(template){
            case "prison","military_camp" -> LOCK;
            case "kaisyn:outpost/camps/savanna_plateau/side/workshop","kaisyn:outpost/forts/desert/base_plate" -> CODE;
            default -> null;
        };
        if(type!=null){chest.getPersistentData().putBoolean(type,true);chest.setChanged();}
    }

    static boolean locked(ServerLevel level,RelayState state,BlockPos pos){
        if(!state.ready||!level.dimension().equals(BunkerRelay.key(state.activeDimension)))return false;
        var chest=level.getBlockEntity(pos);
        if(chest==null)return false;
        var data=chest.getPersistentData();
        return data.getInt("relay_supply_cycle")==state.generation&&data.getBoolean(LOCK)
            &&!state.fieldRoutes.getBoolean(KEY)&&!state.fieldRoutes.getBoolean(KNOWN);
    }

    static void read(ServerPlayer player,RelayState state,BlockPos pos){
        var chest=player.serverLevel().getBlockEntity(pos);
        if(chest==null)return;
        var data=chest.getPersistentData();
        if(data.getInt("relay_supply_cycle")!=state.generation||!data.getBoolean(CODE)||state.fieldRoutes.getBoolean(KNOWN))return;
        state.fieldRoutes.putBoolean(KNOWN,true);
        state.setDirty();
        RaidRules.chat(player,"Код сейфа найден. Им может воспользоваться вся группа.");
    }

    static void key(ServerLevel level,RelayState state,BlockPos site){
        if(!locked(level,state,site))return;
        state.fieldRoutes.putBoolean(KEY,true);
        state.setDirty();
        for(var player:level.players())if(RaidRules.active(player))
            RaidRules.chat(player,"У командира найден ключ от сейфа. Сейф доступен группе.");
    }

    static void arm(ServerPlayer player,RelayState state,BlockPos site,List<UUID> guards){
        if(guards.isEmpty()||state.fieldRoutes.contains("fieldPatrol")||state.fieldRoutes.getBoolean("fieldPatrolDone"))return;
        var alarm=new CompoundTag();
        alarm.putLong("site",site.asLong());
        alarm.putLong("due",player.serverLevel().getGameTime()+240);
        var ids=new net.minecraft.nbt.ListTag();
        for(var id:guards)ids.add(net.minecraft.nbt.NbtUtils.createUUID(id));
        alarm.put("guards",ids);
        state.fieldRoutes.put("fieldPatrol",alarm);
        state.setDirty();
        RaidRules.chat(player,"Охрана передаёт сигнал. Остановите отряд за 12 секунд или перехватите сигнал на подстанции.");
    }

    static void cancel(ServerPlayer player,RelayState state){
        if(!state.fieldRoutes.contains("fieldPatrol"))return;
        state.fieldRoutes.remove("fieldPatrol");
        state.setDirty();
        RaidRules.chat(player,"Подстанция перехватила сигнал. Патруль отменён.");
    }

    static void tick(ServerLevel level,RelayState state,List<ServerPlayer> players){
        if(!state.fieldRoutes.contains("fieldPatrol"))return;
        var alarm=state.fieldRoutes.getCompound("fieldPatrol");
        if(!alarm.getBoolean("sent")){
            if(level.getGameTime()<alarm.getLong("due"))return;
            var site=BlockPos.of(alarm.getLong("site"));
            if(level.hasChunkAt(site)&&alarm.getList("guards",net.minecraft.nbt.Tag.TAG_INT_ARRAY).stream()
                .map(net.minecraft.nbt.NbtUtils::loadUUID).noneMatch(id->{var entity=level.getEntity(id);return entity!=null&&entity.isAlive();})){
                state.fieldRoutes.remove("fieldPatrol");
                state.setDirty();
                return;
            }
            alarm.putBoolean("sent",true);
            state.setDirty();
            for(var player:players)RaidRules.chat(player,"Сигнал принят. Патруль выдвигается к основному выходу. Подстанция может перехватить приказ.");
        }
        for(var player:players){
            if(Math.hypot(player.getX()-state.centerX,player.getZ()-state.centerZ)>105)continue;
            int count=0;
            for(int[] offset:new int[][]{{0,55},{55,0},{0,-55},{-55,0},{42,42},{-42,-42}}){
                var column=new BlockPos(state.centerX+offset[0],0,state.centerZ+offset[1]);
                if(!level.hasChunkAt(column))continue;
                var point=column.atY(level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,column.getX(),column.getZ()));
                if(player.distanceToSqr(point.getX()+.5,point.getY(),point.getZ()+.5)<20*20
                    ||!level.getFluidState(point.below()).isEmpty()||!level.getBlockState(point.below()).isSolidRender(level,point.below()))continue;
                if(RaidDirector.spawn(level,state,point,"stalker",player)!=null&&++count>=2)break;
            }
            if(count>0){
                state.fieldRoutes.remove("fieldPatrol");
                state.fieldRoutes.putBoolean("fieldPatrolDone",true);
                state.setDirty();
                return;
            }
        }
    }

    private FieldSecurity(){}
}
