package dev.bunkerrelay;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

public final class ReconChart extends ChestMenu {
    private record Point(String title,BlockPos position){}
    private final ServerPlayer owner;
    private final SimpleContainer panel;
    private List<Point> points = List.of();
    private final int generation;
    private boolean sectorView;
    private int page;
    private int sectorX, sectorZ;
    private long lastRefresh;

    private static String key(int x,int z){return x+"/"+z;}

    static void visit(ServerPlayer player,RelayState state){
        if(!RaidRules.active(player)||!state.ready)return;
        int x=ExpeditionGrid.cell(state,player.getBlockX()-state.centerX);
        int z=ExpeditionGrid.cell(state,player.getBlockZ()-state.centerZ);
        if(!state.scoutMap.contains(key(x,z))){
            state.scoutMap.put(key(x,z),new net.minecraft.nbt.CompoundTag());
            state.setDirty();
        }
    }

    static BlockPos site(RelayState state,int x,int z){
        var entry=state.scoutMap.getCompound(key(x,z));
        return entry.contains("position")?BlockPos.of(entry.getLong("position")):null;
    }

    static void discovered(RelayState state,int x,int z,BlockPos pos,String label){
        var entry=new net.minecraft.nbt.CompoundTag();
        entry.putLong("position",pos.asLong());
        entry.putString("title",label);
        state.scoutMap.put(key(x,z),entry);
        state.setDirty();
    }

    ReconChart(int id,Inventory inv){this(id,inv,null,new SimpleContainer(27));}

    private ReconChart(int id,Inventory inv,ServerPlayer owner,SimpleContainer panel){
        this(id,inv,owner,panel,true);
    }

    private ReconChart(int id,Inventory inv,ServerPlayer owner,SimpleContainer panel,boolean sectors){
        super(RelayMenus.RECON.get(),id,inv,panel,3);
        this.sectorView=sectors;
        this.owner=owner;
        this.panel=panel;
        if(owner==null){generation=-1;return;}
        var state=RelayState.get(owner.server);
        generation=state.generation;
        center(state);
        render(state);
    }

    private List<Point> objectives(RelayState state){
        var entries=new ArrayList<Point>();
        entries.add(new Point("Площадка эвакуации",new BlockPos(state.centerX,state.spawnY,state.centerZ)));
        entries.add(new Point("Полевое радио",RaidMission.radio(state)));
        if(state.bossGeneration==state.generation)entries.add(new Point(RaidBosses.name(state),RaidBosses.arena(state)));
        var director=RaidDirector.get(owner.server);
        if(director.sectorX==state.centerX&&director.sectorZ==state.centerZ)
            director.rooms.stream().limit(4).forEach(room->entries.add(new Point(RaidDirector.roomName(room.getString("type")),
                new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z")))));
        for(int type=FieldRoutes.SUBSTATION;type<=FieldRoutes.EXIT;type++)
            if(FieldRoutes.known(state,type))entries.add(new Point(FieldRoutes.name(type),FieldRoutes.point(state,type)));
        for(var room:director.rooms)if(room.getString("type").equals("landmark")&&room.getBoolean("discovered"))
            entries.add(new Point(room.getString("title"),new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z"))));
        for(String key:state.scoutMap.getAllKeys()){
            var site=state.scoutMap.getCompound(key);
            if(site.contains("position"))entries.add(new Point(site.getString("title"),BlockPos.of(site.getLong("position"))));
        }
        entries.sort(java.util.Comparator.comparingDouble((Point point)->point.position().distSqr(owner.blockPosition())).thenComparing(Point::title));
        return entries;
    }

    private void center(RelayState state){
        sectorX=RaidRules.active(owner)?ExpeditionGrid.cell(state,owner.getBlockX()-state.centerX):0;
        sectorZ=RaidRules.active(owner)?ExpeditionGrid.cell(state,owner.getBlockZ()-state.centerZ):0;
    }

    private void render(RelayState state){
        panel.clearContent();
        lastRefresh=owner.serverLevel().getGameTime();
        if(!sectorView){
            points=objectives(state);
            for(int i=0;i<21 && page*21+i<points.size();i++){
                var point=points.get(page*21+i);
                icon(i,Items.MAP,point.title(),(int)Math.sqrt(point.position().distSqr(owner.blockPosition()))+" м · отслеживать");
            }
            if(page>0)icon(21,Items.ARROW,"Назад","Предыдущие точки");
            if((page+1)*21<points.size())icon(22,Items.ARROW,"Дальше","Следующие точки");
            icon(26,Items.COMPASS,"КПК","Маршруты группы");
            return;
        }
        var crew=RaidRules.active(owner)?owner.server.getPlayerList().getPlayers().stream()
            .filter(p->RaidRules.active(p)&&p.level().dimension().equals(BunkerRelay.key(state.activeDimension)))
            .toList():List.<ServerPlayer>of();
        for(int row=0;row<3;row++)for(int col=0;col<7;col++){
            int x=sectorX+col-3,z=sectorZ+row-1;
            var entry=state.scoutMap.getCompound(key(x,z));
            boolean visited=state.scoutMap.contains(key(x,z));
            var site=entry.getString("title");
            var members=new ArrayList<String>();
            for(var p:crew){
                if(ExpeditionGrid.cell(state,p.getBlockX()-state.centerX)==x
                    && ExpeditionGrid.cell(state,p.getBlockZ()-state.centerZ)==z)members.add(p.getScoreboardName());
            }
            String hint=site.isEmpty()?(visited?"Посещён":"Не разведан"):site+" · поставить указатель";
            if(!members.isEmpty())hint+=" · "+String.join(", ",members);
            icon(row*9+col,!members.isEmpty()?Items.COMPASS:!site.isEmpty()?Items.EMERALD:visited?Items.GREEN_STAINED_GLASS_PANE:Items.GRAY_STAINED_GLASS_PANE,
                "Сектор "+x+", "+z,hint);
        }
        icon(7,Items.ARROW,"Север","Сместить карту");
        icon(8,Items.ARROW,"Юг","Сместить карту");
        icon(16,Items.ARROW,"Запад","Сместить карту");
        icon(17,Items.ARROW,"Восток","Сместить карту");
        icon(25,Items.COMPASS,"Мой сектор","Вернуться к центру обзора");
        icon(26,Items.MAP,"Объекты и выходы","Полевое радио, задачи и эвакуация");
    }

    private void icon(int slot,net.minecraft.world.item.Item item,String title,String hint){
        var icon=new ItemStack(item);
        icon.set(DataComponents.CUSTOM_NAME,Component.literal(title));
        icon.set(DataComponents.LORE,new ItemLore(List.of(Component.literal(hint))));
        panel.setItem(slot,icon);
    }

    static int open(ServerPlayer player){
        return openView(player,true);
    }

    static int targets(ServerPlayer player){return openView(player,false);}

    private static int openView(ServerPlayer player,boolean sectors){
        if(!RelayState.get(player.server).ready){RaidRules.tell(player,"Зона ещё не готова.");return 0;}
        player.openMenu(new SimpleMenuProvider((id,inv,ignored)->new ReconChart(id,inv,player,new SimpleContainer(27),sectors),
            Component.literal(sectors?"Сектора":"КПК · Выбор ориентира")));
        return 1;
    }

    @Override public void clicked(int slot,int button,ClickType type,Player player){
        if(player!=owner||button!=0||type!=ClickType.PICKUP||slot<0||slot>=27||!stillValid(player))return;
        var state=RelayState.get(owner.server);
        if(slot==26){
            if(!sectorView){PocketDevice.open(owner,PocketDevice.Page.ROUTES);return;}
            sectorView=false;
            render(state);
            return;
        }
        Point point;
        if(sectorView){
            int min=ExpeditionGrid.cell(state,-state.activeSize/2);
            int max=ExpeditionGrid.cell(state,state.activeSize/2-1);
            switch(slot){
                case 7 -> sectorZ=Math.max(min,sectorZ-1);
                case 8 -> sectorZ=Math.min(max,sectorZ+1);
                case 16 -> sectorX=Math.max(min,sectorX-1);
                case 17 -> sectorX=Math.min(max,sectorX+1);
                case 25 -> center(state);
                default -> {
                    var entry=state.scoutMap.getCompound(key(sectorX+slot%9-3,sectorZ+slot/9-1));
                    if(entry.contains("position"))navigate(new Point(entry.getString("title"),BlockPos.of(entry.getLong("position"))));
                }
            }
            render(state);
            return;
        }
        if(slot==21&&page>0){page--;render(state);return;}
        if(slot==22&&(page+1)*21<points.size()){page++;render(state);return;}
        if(slot>=21||page*21+slot>=points.size())return;
        point=points.get(page*21+slot);
        navigate(point);
    }

    private void navigate(Point point){
        Navigation.waypoint(owner,generation,point.position(),point.title());
        owner.closeContainer();
        RaidRules.tell(owner,"Компас · "+point.title());
    }
    @Override public void broadcastChanges(){
        if(sectorView&&owner!=null&&stillValid(owner)&&owner.serverLevel().getGameTime()-lastRefresh>=20)render(RelayState.get(owner.server));
        super.broadcastChanges();
    }

    @Override public ItemStack quickMoveStack(Player p,int slot){return ItemStack.EMPTY;}
    @Override public boolean stillValid(Player p){
        if(p!=owner||owner==null||!owner.isAlive())return false;
        var state=RelayState.get(owner.server);
        return state.ready&&state.generation==generation;
    }
}
