package dev.bunkerrelay;

import java.util.function.Supplier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

final class TrophyResearch {
    enum Part {
        REGULATOR("regulator","Стабилизатор · 120 FE/с и доступ к изолированному медицинскому отсеку",BossTrophies.QUARANTINE),
        SCANNER("scanner","Модуль анализа · ранний пеленг аирдропа и +200 кр. к бюджету скупщика после вылазки",BossTrophies.ECHO),
        HARNESS("harness","Подвес груза · замедление 10% вместо 25%",BossTrophies.RANGER),
        TOOLING("tooling","Оснастка · ремонт вдвое дешевле",BossTrophies.FORGE);

        final Supplier<Item> module;
        final Supplier<Item> trophy;
        final String effect;
        Part(String id,String effect,Supplier<Item> trophy){
            module=BossTrophies.ITEMS.register(id,()->new Item(new Item.Properties().rarity(Rarity.RARE)));
            this.trophy=trophy;
            this.effect=effect;
        }
    }

    static void register(){Part.values();}
    static boolean has(RelayState state,Part part){return (state.research & 1<<part.ordinal())!=0;}

    static int dismantle(ServerPlayer player){
        if(!workshop(player))return 0;
        var held=player.getMainHandItem();
        for(var part:Part.values())if(held.is(part.trophy.get())){
            var module=new ItemStack(part.module.get());
            if(held.getCount()==1)player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,module);
            else{
                if(SafeInventory.capacity(player.getInventory(),module)<1){
                    RaidRules.tell(player,"Освободите один слот под деталь.");
                    return 0;
                }
                held.shrink(1);
                SafeInventory.insert(player.getInventory(),module);
            }
            RelayEconomy.save(player);
            RaidRules.tell(player,part.effect+" · установите деталь через терминал");
            return 1;
        }
        RaidRules.tell(player,"Возьмите трофей босса в основную руку.");
        return 0;
    }

    static int install(ServerPlayer player){
        if(!workshop(player))return 0;
        var state=RelayState.get(player.server);
        var held=player.getMainHandItem();
        for(var part:Part.values())if(held.is(part.module.get())){
            if(has(state,part)){
                RaidRules.tell(player,"Эта деталь уже установлена для всей команды.");
                return 0;
            }
            held.shrink(1);
            state.research|=1<<part.ordinal();
            state.setDirty();
            player.server.saveEverything(false,true,true);
            RaidRules.tell(player,part.effect);
            return 1;
        }
        RaidRules.tell(player,"Возьмите деталь в основную руку.");
        return 0;
    }

    static int report(ServerPlayer player){
        var state=RelayState.get(player.server);
        for(var part:Part.values())RaidRules.chat(player,(has(state,part)?"Установлено · ":"Доступно · ")+part.effect);
        RaidRules.tell(player,"Кнопки разбора и установки находятся на терминале.");
        return 1;
    }

    static boolean medicalLocked(net.minecraft.server.level.ServerLevel level,RelayState state,net.minecraft.core.BlockPos pos){
        if(has(state,Part.REGULATOR)||!level.hasChunkAt(pos))return false;
        var chest=level.getBlockEntity(pos);
        return chest!=null&&chest.getPersistentData().getBoolean("relay_filter_cache");
    }

    private static boolean workshop(ServerPlayer player){
        if(!RelayEconomy.safe(player)||!BaseUpgrades.has(player,BaseUpgrades.Upgrade.WORKSHOP)){
            RaidRules.tell(player,"Нужна открытая мастерская на базе.");
            return false;
        }
        return BasePower.available(player);
    }

    private TrophyResearch(){}
}
