package dev.bunkerrelay;

import java.util.List;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update17IntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        var base=server.getLevel(BunkerRelay.HUB);
        var player=new FakePlayer(base,new GameProfile(UUID.randomUUID(),"Relay17Menu")){
            @Override public java.util.OptionalInt openMenu(MenuProvider menu){
                containerMenu=menu.createMenu(61,getInventory(),this);
                return java.util.OptionalInt.of(61);
            }
        };
        var at=HubBuilder.TERMINAL;
        player.moveTo(at.getX(),at.getY(),at.getZ());
        check(BunkerRelay.openTerminal(player)==1,"terminal opens");
        check(!player.containerMenu.getSlot(22).getItem().isEmpty()&&player.containerMenu.getSlot(36).getItem().isEmpty(),"raid tab");
        player.containerMenu.clicked(3,0,ClickType.PICKUP,player);
        check(player.containerMenu.getSlot(22).getItem().isEmpty()&&!player.containerMenu.getSlot(36).getItem().isEmpty(),"shop tab");
        player.containerMenu.clicked(5,0,ClickType.PICKUP,player);
        check(!player.containerMenu.getSlot(52).getItem().isEmpty(),"base tab");
        var paid=new net.minecraft.nbt.CompoundTag();paid.putBoolean("test1",true);paid.putBoolean("test2",true);paid.putBoolean("test3",true);
        RelayEconomy.account(player).put("paidZones",paid);
        check(SkillMenu.learn(player,SkillMenu.Skill.BROKER)==0,"prerequisite");
        var account=RelayEconomy.account(player);
        account.putInt("skillMask",3);account.putInt("skillSpent",3);
        check(SkillMenu.points(player)==3&&SkillMenu.points(player)==3,"retired skills refunded once");
        check(SkillMenu.learn(player,SkillMenu.Skill.DEALER)==1&&SkillMenu.learn(player,SkillMenu.Skill.BROKER)==1
            &&SkillMenu.points(player)==0,"skill progression");
        state.baseUpgrades|=1<<BaseUpgrades.Upgrade.STORAGE.ordinal();
        WarehouseIntegrationTest.verify(player);

        var zone=server.getLevel(BunkerRelay.key(state.activeDimension));
        var raider=new FakePlayer(zone,new GameProfile(UUID.randomUUID(),"Relay17Raider"));
        var friend=new FakePlayer(zone,new GameProfile(UUID.randomUUID(),"Relay17Friend"));
        raider.moveTo(state.centerX+100,230,state.centerZ,0,0);
        friend.moveTo(state.centerX+250,230,state.centerZ,0,0);
        check(RaidDoubles.isolated(raider,List.of(raider,friend))&&!RaidDoubles.isolated(raider,List.of(raider)),"coop isolation");
        var spawn=new BlockPos(state.centerX+136,230,state.centerZ);
        zone.setBlock(spawn.below(),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        check(RaidDoubles.spawn(zone,state,raider,friend),"double spawns at distance");
        check(zone.getEntitiesOfClass(Mob.class,new AABB(spawn).inflate(4)).stream().anyMatch(mob->
            mob.getCustomName()!=null&&mob.getCustomName().getString().equals(friend.getScoreboardName())
            &&mob.getItemBySlot(EquipmentSlot.HEAD).has(DataComponents.PROFILE)&&mob.getTarget()==raider),"double identity and target");

        var probe=new RelayState();
        probe.variableStories=true;probe.generation=10;
        var site=ExpeditionLayout.story(probe,0);
        probe.generation++;
        check(!site.equals(ExpeditionLayout.story(probe,0)),"successive story sites differ");
        probe.activeLoot=1;int basic=RaidLoot.generate(zone,probe,RandomSource.create(17)).size();
        probe.activeLoot=4;int quality=RaidLoot.generate(zone,probe,RandomSource.create(17)).size();
        check(basic==3&&quality>basic,"nonempty and improved tiers");
        var tracked=RaidDirector.get(server).rooms.getFirst();
        var chest=new BlockPos(tracked.getInt("x"),tracked.getInt("y"),tracked.getInt("z")+4);
        check(!PersonalLoot.templateItem(zone,chest,4).isEmpty(),"stocked story chest before trap");
        System.out.println("RELAY_017_PASS tabs=true skills=true locker=true double=true layout=true loot=true");
    }

    private static void check(boolean condition,String message){if(!condition)throw new IllegalStateException("RELAY_017 "+message);}
    private Update17IntegrationTest(){}
}
