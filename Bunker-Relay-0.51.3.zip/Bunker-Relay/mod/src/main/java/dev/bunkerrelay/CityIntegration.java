package dev.bunkerrelay;
import net.minecraft.server.MinecraftServer;
import net.neoforged.fml.ModList;
public final class CityIntegration {
 public static void profiles(){if(!ModList.get().isLoaded("lostcities"))return;profile("relay_city","default",.42f);profile("relay_infected","ancient",.36f);profile("relay_ash","wasteland",.30f);}
 @SuppressWarnings("unchecked")
 public static void register(MinecraftServer server){if(!ModList.get().isLoaded("lostcities"))return;profiles();
  var value=(net.neoforged.neoforge.common.ModConfigSpec.ConfigValue<java.util.List<? extends String>>)mcjty.lostcities.setup.Config.COMMON_CONFIG.getValues().get(java.util.List.of("profiles","dimensionsWithProfiles"));
  var entries=new java.util.ArrayList<String>(value.get());entries.removeIf(v->v.startsWith("bunkerrelay:city=")||v.startsWith("bunkerrelay:infected_city=")||v.startsWith("bunkerrelay:ashlands="));entries.add("bunkerrelay:city=relay_city");entries.add("bunkerrelay:infected_city=relay_infected");entries.add("bunkerrelay:ashlands=relay_ash");value.set(entries);value.save();mcjty.lostcities.setup.Config.resetProfileCache();mcjty.lostcities.worldgen.LostCityFeature.globalDimensionInfoDirtyCounter++;
 }
 private static void profile(String name,String base,float density){var profiles=mcjty.lostcities.config.ProfileSetup.STANDARD_PROFILES;var original=profiles.get(base);if(original==null)throw new IllegalStateException("Missing Lost Cities profile: "+base);var p=new mcjty.lostcities.config.LostCityProfile(name,false);p.copyFrom(original);p.CITY_CHANCE=.035;p.CITY_MINHEIGHT=-64;p.CITY_MAXHEIGHT=320;p.CITY_MINRADIUS=96;p.CITY_MAXRADIUS=176;p.CITY_THRESHOLD=.15f;p.CITY_SPAWN_MULTIPLIER1=1;p.CITY_SPAWN_MULTIPLIER2=1;p.BUILDING_CHANCE=density;p.GENERATE_SPAWNERS=false;
  p.BUILDING_MAXFLOORS=5;p.BUILDING_MAXCELLARS=0;p.BUILDING_MINCELLARS=0;
  p.RAILWAYS_ENABLED=false;p.RAILWAY_STATIONS_ENABLED=false;p.RAILWAY_SURFACE_STATIONS_ENABLED=false;
  p.HIGHWAY_GENERATION_MODE=mcjty.lostcities.config.HighwayGenerationMode.LEGACY;p.HIGHWAY_DISTANCE_MASK=0;
  p.SCATTERED_CHANCE_MULTIPLIER=0;
  profiles.put(name,p);}
 public static void smoke(net.minecraft.server.level.ServerLevel level,RelayState s){
  var info=new mcjty.lostcities.LostCitiesImp().getLostInfo(level);if(info==null)throw new IllegalStateException("City dimension profile missing");
  int buildings=0,cities=0,bx=0,bz=0;
  for(int x=(s.centerX>>4)-16;x<=(s.centerX>>4)+16;x++)for(int z=(s.centerZ>>4)-16;z<=(s.centerZ>>4)+16;z++){var chunk=info.getChunkInfo(x,z);if(CityParcels.reserved(level.dimension(),x,z)&&(chunk.isCity()||chunk.getBuildingType()!=null))
   throw new IllegalStateException("Lost Cities in protected corridor: "+x+", "+z);
   if(chunk.isCity())cities++;if(chunk.getBuildingType()!=null){buildings++;bx=x;bz=z;}}
  if(cities<100||buildings==0||buildings>cities*.65)throw new IllegalStateException("Unexpected city coverage: cities="+cities+" buildings="+buildings);level.getChunk(bx,bz);int blocks=0;
  for(int x=bx*16;x<bx*16+16;x++)for(int z=bz*16;z<bz*16+16;z++)for(int y=64;y<180;y++){
   var id=net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(level.getBlockState(new net.minecraft.core.BlockPos(x,y,z)).getBlock()).getPath();if(id.contains("bricks")||id.contains("glass")||id.contains("concrete"))blocks++;
  }
  if(blocks==0)throw new IllegalStateException("City building blocks missing");System.out.println("RELAY_CITY_PASS cities="+cities+" buildings="+buildings+" blocks="+blocks);
 }
 private CityIntegration(){}
}
