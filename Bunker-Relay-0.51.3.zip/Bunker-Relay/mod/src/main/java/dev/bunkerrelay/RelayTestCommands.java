package dev.bunkerrelay;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.List;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;

final class RelayTestCommands {
    static final String TEST_MOB="relay_admin_test";

    static LiteralArgumentBuilder<CommandSourceStack> branch(){
        var root=literal("test").requires(source->source.hasPermission(2)).executes(c->help(c.getSource()));
        root.then(literal("status").executes(c->status(c.getSource())));
        root.then(literal("points").executes(c->points(c.getSource())));
        var offer=literal("offer");
        var generation=literal("new");
        for(var zone:ZoneProfile.values()){
            offer.then(literal(zone.id).then(literal("day").executes(c->offer(c.getSource(),zone,false)))
                .then(literal("night").executes(c->offer(c.getSource(),zone,true))));
            generation.then(literal(zone.id).executes(c->generate(c.getSource(),zone)));
        }
        root.then(offer).then(generation);
        root.then(literal("time").then(literal("day").executes(c->clock(c.getSource(),false)))
            .then(literal("night").executes(c->clock(c.getSource(),true))));
        root.then(literal("airdrop").executes(c->airdrop(c.getSource())));
        root.then(literal("signal").executes(c->signal(c.getSource())));
        root.then(literal("boss").executes(c->boss(c.getSource())));
        var mini=literal("miniboss");
        for(var kind:MiniBosses.Kind.values())mini.then(literal(kind.name().toLowerCase(Locale.ROOT))
            .executes(c->mini(c.getSource(),kind)));
        root.then(mini);
        var mob=literal("mob");
        for(String role:List.of("stalker","screamer","warden","faceless","patrol_site"))
            mob.then(literal(role).executes(c->mob(c.getSource(),role,1)));
        root.then(mob);
        root.then(literal("wave").then(argument("count",IntegerArgumentType.integer(1,8))
            .executes(c->mob(c.getSource(),"stalker",IntegerArgumentType.getInteger(c,"count")))));
        root.then(literal("clear").executes(c->clear(c.getSource())));
        root.then(literal("loot").executes(c->loot(c.getSource())));
        root.then(literal("kit").executes(c->kit(c.getSource())));
        root.then(literal("mission").executes(c->RaidMission.report(c.getSource().getPlayerOrException())));
        root.then(literal("cargo").executes(c->CargoContract.report(c.getSource().getPlayerOrException())));
        root.then(literal("market").executes(c->RelayEconomy.open(c.getSource().getPlayerOrException(),false)));
        root.then(literal("sell").executes(c->RelayEconomy.open(c.getSource().getPlayerOrException(),true)));
        root.then(literal("orders").executes(c->SupplyOrders.open(c.getSource().getPlayerOrException())));
        root.then(literal("journal").executes(c->RaidContracts.open(c.getSource().getPlayerOrException())));
        root.then(literal("warehouse").executes(c->BaseUpgrades.locker(c.getSource().getPlayerOrException())));
        root.then(literal("workshop").executes(c->CourtyardWorkshop.useOrLocate(c.getSource().getPlayerOrException())));
        root.then(literal("dismantle").executes(c->{
            var player=c.getSource().getPlayerOrException();
            if(!BunkerRelay.nearTerminal(player))return fail(c.getSource(),"Подойдите к терминалу.");
            DismantleMenu.open(player,false);return 1;
        }));
        root.then(literal("pda").executes(c->PocketDevice.open(c.getSource().getPlayerOrException())));
        root.then(literal("fund").then(argument("credits",IntegerArgumentType.integer(1,10000))
            .executes(c->fund(c.getSource(),IntegerArgumentType.getInteger(c,"credits")))));
        root.then(literal("gear").then(literal("flashlight").executes(c->give(c.getSource(), "relaylights:flashlight")))
            .then(literal("medkit").executes(c->give(c.getSource(),"bunkerrelay:medkit"))));
        return root;
    }

    private static int help(CommandSourceStack source){
        say(source,"/relay test · Доступные ветки дополняются по Tab.");
        say(source,"Зона: status, points, offer, new, time, signal, airdrop, mission, cargo.");
        say(source,"Бой: boss, miniboss, mob, wave, clear. Добыча и база: loot, kit, gear, market, sell, fund, orders, journal, pda, warehouse, workshop, dismantle.");
        return 1;
    }

    private static int status(CommandSourceStack source){
        var state=RelayState.get(source.getServer());
        var director=RaidDirector.get(source.getServer());
        say(source,"Зона "+state.activeDimension+" · цикл "+state.generation+" · сид "+state.seed
            +" · "+state.activeSize+"×"+state.activeSize+" · угроза "+state.activeDifficulty+" · добыча "+state.activeLoot);
        say(source,(state.generating?"Генерация":state.ready?"Зона открыта":"Зона закрыта")
            +" · "+(state.nightRaid?"ночь":"день")+" · "+BasePower.label(state)+" · "+director.elapsed+" с активной вылазки");
        say(source,Airdrop.status(director)+" · "+RouteEvents.status(state)+" · "+CargoContract.status(state));
        return 1;
    }

    private static int points(CommandSourceStack source){
        var state=RelayState.get(source.getServer());
        if(!state.ready||state.generating)return fail(source,"Зона ещё не готова.");
        say(source,"Вход и выход · "+new BlockPos(state.centerX,state.spawnY,state.centerZ).toShortString()
            +" · радио "+new BlockPos(state.relayX,state.relayY,state.relayZ).toShortString()
            +" · арена "+RaidBosses.arena(state).toShortString());
        for(var room:RaidDirector.get(source.getServer()).rooms){
            say(source,(room.contains("title")?room.getString("title"):RaidDirector.roomName(room.getString("type")))
                +" · "+new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z")).toShortString());
        }
        return 1;
    }

    private static int offer(CommandSourceStack source,ZoneProfile zone,boolean night){
        var state=RelayState.get(source.getServer());
        state.lightOffers.putBoolean(zone.id,night);
        state.setDirty();
        return say(source,zone.title+" · следующее предложение "+(night?"ночью":"днём"));
    }

    private static int generate(CommandSourceStack source,ZoneProfile zone)throws CommandSyntaxException{
        var player=source.getPlayerOrException();
        if(!BunkerRelay.nearTerminal(player))return fail(source,"Подойдите к терминалу. Команда создаёт новый цикл вылазки.");
        var state=RelayState.get(source.getServer());
        return BunkerRelay.launchSelection(player,zone,state.size,ExpeditionContracts.Type.STANDARD)?1:0;
    }

    private static int clock(CommandSourceStack source,boolean night)throws CommandSyntaxException{
        var player=raider(source);
        var state=RelayState.get(player.server);
        state.fixedRaidLight=true;
        state.nightRaid=night;
        state.setDirty();
        return say(source,night?"Активная зона зафиксирована на ночи.":"Активная зона зафиксирована на дне.");
    }

    private static int airdrop(CommandSourceStack source)throws CommandSyntaxException{
        var player=raider(source);
        var director=RaidDirector.get(player.server);
        if(director.dropLanded||director.dropPending)return fail(source,"В этом цикле уже есть аирдроп.");
        director.dropDue=director.elapsed+20;
        director.setDirty();
        return say(source,"Аирдроп запрошен. После выбора площадки начнётся обычный сброс.");
    }

    private static int signal(CommandSourceStack source)throws CommandSyntaxException{
        var player=raider(source);
        var state=RelayState.get(player.server);
        if(state.routeEvent.contains("position"))return fail(source,"Дождитесь окончания текущего сигнала.");
        return RouteEvents.find(player.serverLevel(),state,RaidDirector.get(player.server).elapsed,List.of(player))
            ?say(source,"Полевой сигнал создан. Откройте КПК.")
            :fail(source,"Отойдите от входа и найдите открытую местность.");
    }

    private static int boss(CommandSourceStack source)throws CommandSyntaxException{
        var player=raider(source);
        var state=RelayState.get(player.server);
        if(state.bossDefeated)return fail(source,"Босс уже повержен в этом цикле.");
        if(player.blockPosition().distSqr(RaidBosses.arena(state))>48*48)
            return fail(source,"Подойдите к арене · "+RaidBosses.arena(state).toShortString());
        RaidBosses.encounter(player.server,state,player.serverLevel(),List.of(player));
        return state.bossId!=null?say(source,"Бой с боссом активен."):fail(source,"Арена пока недоступна.");
    }

    private static int mini(CommandSourceStack source,MiniBosses.Kind kind)throws CommandSyntaxException{
        var player=raider(source);
        if(!player.serverLevel().getEntities(player,player.getBoundingBox().inflate(48),
            entity->entity.getTags().contains(TEST_MOB)&&entity.getPersistentData().contains("relay_miniboss")).isEmpty())
            return fail(source,"Рядом уже есть тестовый мини-босс.");
        return MiniBosses.deploy(player,RelayState.get(player.server),player.blockPosition(),kind,true)
            ?say(source,"Вызван мини-босс «"+kind.name+"»."):fail(source,"Поблизости нет подходящей площадки.");
    }

    private static int mob(CommandSourceStack source,String role,int wanted)throws CommandSyntaxException{
        var player=raider(source);
        var state=RelayState.get(player.server);
        var level=player.serverLevel();
        int count=0;
        for(int i=0;i<16&&count<wanted;i++){
            double angle=i*Math.PI/8;
            var at=player.blockPosition().offset((int)Math.round(Math.cos(angle)*14),0,(int)Math.round(Math.sin(angle)*14));
            if(!level.hasChunkAt(at)||Math.hypot(at.getX()-state.centerX,at.getZ()-state.centerZ)<24)continue;
            at=at.atY(level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,at.getX(),at.getZ()));
            if(Math.abs(at.getY()-player.getY())>12||!level.getBlockState(at.below()).isSolidRender(level,at.below()))continue;
            var enemy=RaidDirector.spawn(level,state,at,count%2==1&&wanted>1?"screamer":role,player);
            if(enemy!=null){enemy.addTag(TEST_MOB);count++;}
        }
        return count>0?say(source,"Вызвано заражённых: "+count+" из "+wanted):fail(source,"Лимит заражённых достигнут или нет безопасной площадки.");
    }

    private static int clear(CommandSourceStack source)throws CommandSyntaxException{
        var player=raider(source);
        var entities=player.serverLevel().getEntities(player,player.getBoundingBox().inflate(96),e->e.getTags().contains(TEST_MOB));
        entities.forEach(net.minecraft.world.entity.Entity::discard);
        return say(source,"Убрано тестовых мобов поблизости: "+entities.size());
    }

    private static int loot(CommandSourceStack source){
        var state=RelayState.get(source.getServer());
        var stacks=RaidLoot.generate(source.getLevel(),state,RandomSource.create(state.seed^BlockPos.containing(source.getPosition()).asLong()));
        var text=Component.literal("Пример тайника · ");
        for(var stack:stacks)text.append(stack.getHoverName()).append(" ×"+stack.getCount()+"  ");
        source.sendSuccess(()->text,false);
        return 1;
    }

    private static int kit(CommandSourceStack source)throws CommandSyntaxException{
        var p=raider(source);
        return StarterKit.claim(p,RelayState.get(p.server))?1:0;
    }

    private static int fund(CommandSourceStack source,int amount)throws CommandSyntaxException{
        var player=source.getPlayerOrException();
        if(!RelayEconomy.safe(player))return fail(source,"Начисление доступно на базе.");
        long balance=RelayEconomy.balance(player);
        int credited=(int)Math.min(amount,RelayEconomy.MAX_BALANCE-balance);
        if(credited==0)return fail(source,"Достигнут лимит счёта.");
        RelayEconomy.account(player).putLong("balance",balance+credited);
        RelayEconomy.save(player);
        return say(source,"Личный счёт пополнен на "+credited+" кр.");
    }

    private static int give(CommandSourceStack source,String id)throws CommandSyntaxException{
        var player=source.getPlayerOrException();
        if(!RelayEconomy.safe(player))return fail(source,"Получите снаряжение на базе.");
        var item=BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(id)).orElseThrow();
        var stack=new ItemStack(item);
        if(SafeInventory.capacity(player.getInventory(),stack)<1)return fail(source,"Освободите место в инвентаре.");
        SafeInventory.insert(player.getInventory(),stack);
        RelayEconomy.save(player);
        return say(source,"Предмет выдан.");
    }

    private static ServerPlayer raider(CommandSourceStack source)throws CommandSyntaxException{
        var player=source.getPlayerOrException();
        var state=RelayState.get(player.server);
        if(state.ready&&!state.generating&&RaidRules.active(player)&&player.isAlive()
            &&player.level().dimension().equals(BunkerRelay.key(state.activeDimension)))return player;
        throw new com.mojang.brigadier.exceptions.SimpleCommandExceptionType(
            Component.literal("Команда доступна внутри активной вылазки.")).create();
    }

    private static int say(CommandSourceStack source,String message){
        source.sendSuccess(()->Component.literal(message),false);
        return 1;
    }

    private static int fail(CommandSourceStack source,String message){
        source.sendFailure(Component.literal(message));
        return 0;
    }

    private RelayTestCommands(){}
}
