package dev.bunkerrelay;
import java.util.*;
import com.mojang.authlib.GameProfile;
import com.tacz.guns.api.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.common.util.FakePlayer;
public final class EconomyIntegrationTest {
 private static final UUID ID=UUID.fromString("98317156-dd13-4721-a003-cd7c32244eab"),FIXTURE=UUID.fromString("2a25c7ab-3c3f-4daf-9ba8-b06cc492116e");
 private static void check(boolean value,String why){if(!value)throw new IllegalStateException("ECONOMY: "+why);}
 private static FakePlayer player(MinecraftServer server){return new FakePlayer(server.getLevel(BunkerRelay.HUB),new GameProfile(ID,"EconomyTest"));}
 private static RelayEconomy.Offer offer(String id){return RelayEconomy.CATALOG.stream().filter(o->o.id().equals(id)).findFirst().orElseThrow();}
 private static int count(FakePlayer p,ItemStack target){return p.getInventory().items.stream().filter(s->ItemStack.isSameItemSameComponents(s,target)).mapToInt(ItemStack::getCount).sum();}
 public static void run(MinecraftServer server){
  var p=player(server);var a=RelayEconomy.account(p);check(RelayEconomy.balance(p)==300,"starter credits once");a.putLong("balance",10000);var ammo=offer("9mm");var iron=offer("iron");
  for(var o:RelayEconomy.CATALOG){check(o.buy()>o.sell()&&o.sell()>0,"strict price spread "+o.id());check(!o.stack(p).isEmpty(),"item exists "+o.id());}
  var ammoStack=ammo.stack(p);check(ammoStack.getItem() instanceof IAmmo&&((IAmmo)ammoStack.getItem()).getAmmoId(ammoStack).equals(ResourceLocation.parse("tacz:9mm")),"correct ammo data");
  var gun=offer("glock").stack(p);check(gun.getItem() instanceof IGun&&((IGun)gun.getItem()).getGunId(gun).equals(ResourceLocation.parse("tacz:glock_17")),"correct gun data");
  RelayEconomy.buy(p,ammo);check(RelayEconomy.balance(p)==9904&&count(p,ammoStack)==32&&RelayEconomy.remaining(p,ammo)==7,"purchase and stock");
  RelayEconomy.sell(p,ammo);check(RelayEconomy.balance(p)==9936&&count(p,ammoStack)==0&&a.getInt("budget")==1168,"sale consumes exact batch, spread");
  long before=RelayEconomy.balance(p);for(int i=0;i<36;i++)p.getInventory().setItem(i,new ItemStack(Items.COBBLESTONE,64));int stock=RelayEconomy.remaining(p,iron);RelayEconomy.buy(p,iron);check(RelayEconomy.balance(p)==before&&RelayEconomy.remaining(p,iron)==stock,"full inventory no debit");
  p.getInventory().clearContent();a.putLong("balance",0);RelayEconomy.buy(p,iron);check(p.getInventory().isEmpty()&&RelayEconomy.remaining(p,iron)==stock,"insufficient funds");a.putLong("balance",10000);
  for(int i=0;i<10;i++)RelayEconomy.buy(p,iron);check(count(p,iron.stack(p))==32&&RelayEconomy.remaining(p,iron)==0&&RelayEconomy.balance(p)==9360,"stock exhaustion");
  p.getInventory().clearContent();var named=iron.stack(p);named.set(DataComponents.CUSTOM_NAME,Component.literal("Keep"));p.getInventory().setItem(0,named);RelayEconomy.sell(p,iron);check(named.getCount()==8&&RelayEconomy.balance(p)==9360,"modified item never sold");
  p.getInventory().setItem(0,new ItemStack(Items.IRON_INGOT,3));p.getInventory().setItem(1,new ItemStack(Items.IRON_INGOT,5));RelayEconomy.sell(p,iron);check(count(p,iron.stack(p))==0&&RelayEconomy.balance(p)==9408,"sale across slots");
  a.putInt("budget",0);p.getInventory().setItem(0,iron.stack(p));RelayEconomy.sell(p,iron);check(count(p,iron.stack(p))==8&&RelayEconomy.balance(p)==9408,"buyer budget exhaustion");
  a.putLong("balance",RelayEconomy.MAX_BALANCE);a.putInt("budget",600);RelayEconomy.sell(p,iron);check(count(p,iron.stack(p))==8,"balance overflow guarded");a.putLong("balance",9408);
  var previous=RelayEconomy.offers(p);var raid=new CompoundTag();raid.putString("contractCycle","economy-test-zone");raid.putInt("economyDifficulty",3);raid.putString("status","RESTORE");RelayEconomy.extracted(p,raid);check(a.getInt("rotation")==0&&RelayEconomy.balance(p)==9408,"death no reward or restock");raid.putString("status","COMMIT");RelayEconomy.extracted(p,raid);check(RelayEconomy.balance(p)==9733&&a.getInt("rotation")==1&&a.getInt("budget")==1200&&RelayEconomy.remaining(p,iron)==4&&!previous.equals(RelayEconomy.offers(p)),"extraction reward and rotation");RelayEconomy.extracted(p,raid);check(RelayEconomy.balance(p)==9733&&a.getInt("rotation")==1,"same zone replay idempotent");
  var journal=RaidJournal.get(server);journal.raids.put(ID,new CompoundTag());RelayEconomy.buy(p,ammo);RelayEconomy.sell(p,iron);check(RelayEconomy.balance(p)==9733&&count(p,iron.stack(p))==8,"active raid trade forbidden");journal.raids.remove(ID);
  p.getInventory().clearContent();var menu=new RelayEconomy.MarketMenu(7,p.getInventory(),p,false);menu.clicked(9,0,ClickType.QUICK_MOVE,p);menu.clicked(9,0,ClickType.SWAP,p);check(RelayEconomy.balance(p)==9733&&p.getInventory().isEmpty(),"icons protected");menu.clicked(9,0,ClickType.PICKUP,p);check(RelayEconomy.balance(p)==9730&&count(p,ammoStack)==1,"LMB immediate single purchase");
  var clone=new FakePlayer(server.getLevel(BunkerRelay.HUB),new GameProfile(ID,"EconomyTest"));
  net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(new net.neoforged.neoforge.event.entity.player.PlayerEvent.Clone(clone,p,true));
  check(RelayEconomy.balance(clone)==9730&&RelayEconomy.remaining(clone,ammo)==7,"death clone preserves account and stock");
  var state=RelayState.get(server);var q=new FakePlayer(server.getLevel(state.hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER),new GameProfile(UUID.fromString("74270661-095c-48fd-88a6-507b899cb7db"),"SettleEconomy"));
  journal.raids.remove(q.getUUID());RelayEconomy.account(q);check(RaidRules.begin(q,state)==null,"settlement entry");RaidRules.settle(q,false);check(RelayEconomy.balance(q)==300&&RelayEconomy.account(q).getInt("rotation")==0,"failed settlement preserves wallet");
  check(RaidRules.begin(q,state)==null,"second settlement entry");RaidRules.settle(q,true);long settledBalance=RelayEconomy.balance(q);check(settledBalance==300+RelayEconomy.extractionReward(state.activeDifficulty)&&!RaidRules.active(q),"real settlement credits before journal removal");
  check(RaidRules.begin(q,state)==null,"repeat sector entry");RaidRules.settle(q,true);check(RelayEconomy.balance(q)==settledBalance&&RelayEconomy.account(q).getInt("rotation")==1,"repeat settlement cannot farm sector");
  var fixture=new CompoundTag();fixture.put("data",p.getPersistentData().copy());fixture.put("inventory",p.getInventory().save(new ListTag()));journal.raids.put(FIXTURE,fixture);journal.flush(server);
  System.out.println("RELAY_ECONOMY_PASS: prices, ammo/guns, balance, stock, buy/sell, full inventory, insufficient funds, exact components, budget, overflow, successful extraction, replay, rotation, raid restriction, direct GUI purchase");
 }
 public static void reload(MinecraftServer server){var p=player(server);var f=RaidJournal.get(server).raids.get(FIXTURE);check(f!=null,"fixture survives restart");p.getPersistentData().merge(f.getCompound("data"));p.getInventory().load(f.getList("inventory",Tag.TAG_COMPOUND));check(RelayEconomy.balance(p)==9730&&RelayEconomy.account(p).getInt("rotation")==1&&RelayEconomy.remaining(p,offer("9mm"))==7&&count(p,offer("9mm").stack(p))==1,"persisted account, stock and inventory");var r=new CompoundTag();r.putString("status","COMMIT");r.putString("contractCycle","economy-test-zone");RelayEconomy.extracted(p,r);check(RelayEconomy.balance(p)==9730,"persisted receipt blocks repeated payout");System.out.println("RELAY_ECONOMY_RELOAD_PASS: saved account fixture, inventory, stock, receipt");}
 private EconomyIntegrationTest(){}
}
