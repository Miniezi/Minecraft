package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.inventory.ClickType;
import net.neoforged.neoforge.common.util.FakePlayer;

final class BunkerRequestsIntegrationTest {
    static void verify(MinecraftServer server, RelayState state) {
        var terminal = HubBuilder.TERMINAL;
        var player = new FakePlayer(server.getLevel(BunkerRelay.HUB), new GameProfile(UUID.randomUUID(), "RelayRequests")) {
            @Override public java.util.OptionalInt openMenu(MenuProvider provider) {
                containerMenu = provider.createMenu(63, getInventory(), this);
                return java.util.OptionalInt.of(63);
            }
        };
        player.moveTo(terminal.getX(), terminal.getY(), terminal.getZ());
        var original = state.bunkerRequests;
        state.bunkerRequests = new CompoundTag();
        try {
            var request = BunkerRequests.Request.MEDIC;
            var supply = request.item();
            require(SalvageValue.price(supply) == 75, "sellable delivery");
            var medicine = RelayEconomy.CATALOG.stream().filter(offer -> offer.id().equals("medkit")).findFirst().orElseThrow();
            int before = RelayEconomy.price(player, medicine);
            require(BunkerRelay.openTerminal(player) == 1, "terminal available");
            player.containerMenu.clicked(5, 0, ClickType.PICKUP, player);
            player.getInventory().setItem(0, supply.copy());
            player.containerMenu.clicked(15, 0, ClickType.PICKUP, player);
            require(request.progress(state) == 1 && player.getInventory().getItem(0).isEmpty(), "partial shared delivery");
            var warehouse = new Warehouse(player);
            require(warehouse.deposit(supply.copyWithCount(2), 2) == 2, "test stock");
            warehouse.save();
            player.containerMenu.clicked(15, 0, ClickType.PICKUP, player);
            player.containerMenu.clicked(15, 0, ClickType.PICKUP, player);
            require(request.complete(state) && new Warehouse(player).count(supply) == 1, "exact delivery from warehouse");
            var teammate = new FakePlayer(player.serverLevel(), new GameProfile(UUID.randomUUID(), "RelayRequestMate"));
            require(RelayEconomy.price(teammate, medicine) < before, "team discount");
            require(state.save(new CompoundTag(), server.registryAccess()).getCompound("bunkerRequests").getInt(request.name()) == 2,
                "progress saved");
        } finally {
            state.bunkerRequests = original;
            state.setDirty();
        }
        var seen = EnumSet.noneOf(LandmarkCondition.class);
        for (int seed = 0; seed < 120; seed++) seen.add(LandmarkCondition.choose(seed, new BlockPos(512, 64, -512)));
        require(seen.size() == LandmarkCondition.values().length, "condition variety");
        System.out.println("RELAY_REQUESTS_AND_CONDITIONS_PASS");
    }

    private static void require(boolean condition, String operation) {
        if (!condition) throw new IllegalStateException("Bunker requests: " + operation);
    }
}
