package dev.bunkerrelay;

import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update11IntegrationTest {
    private static final BlockPos OLD_MARKER = new BlockPos(28,300,28);
    private static final BlockPos BASE_MARKER = new BlockPos(10,73,25);

    static void request(MinecraftServer server) {
        var state=RelayState.get(server);
        var hub=server.getLevel(BunkerRelay.HUB);
        hub.setBlock(BASE_MARKER,Blocks.EMERALD_BLOCK.defaultBlockState(),3);
        var city=server.getLevel(BunkerRelay.key("city"));
        city.setBlock(OLD_MARKER,Blocks.DIAMOND_BLOCK.defaultBlockState(),3);
        state.theme="industrial";
        state.size=2048;
        state.setDirty();
        var player=new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay11Reset"));
        var terminal=HubBuilder.TERMINAL;
        player.moveTo(terminal.getX()+0.5,terminal.getY(),terminal.getZ()+0.5);
        BunkerRelay.launchSelection(player,ZoneProfile.of(state.theme),state.size,ExpeditionContracts.Type.STANDARD);
        check("industrial".equals(ExpeditionReset.pending(server)),"reset request persisted");
        System.out.println("RELAY_011_REQUEST_PASS");
    }

    static void verify(MinecraftServer server, RelayState state) {
        var level=server.getLevel(BunkerRelay.key("city"));
        check(state.centerX==0&&state.centerZ==0&&state.activeSize==2048,"fixed zone center and size");
        check(!level.getBlockState(OLD_MARKER).is(Blocks.DIAMOND_BLOCK),"old city chunk regenerated");
        check(server.getLevel(BunkerRelay.HUB).getBlockState(BASE_MARKER).is(Blocks.EMERALD_BLOCK),"base marker preserved");
        var director=RaidDirector.get(server);
        check(director.rooms.size()==4,"fresh story buildings");
        for(var room:director.rooms){
            int x=room.getInt("x"),y=room.getInt("y"),z=room.getInt("z");
            check(level.getBlockState(new BlockPos(x,y+6,z)).isAir(),"roof exposed");
            check(level.getBlockState(new BlockPos(x,y,z-6)).isAir(),"entrance exposed");
        }
        long weapons=RelayEconomy.CATALOG.stream().filter(o->o.item().startsWith("gun/")).count();
        long mods=RelayEconomy.CATALOG.stream().filter(o->o.item().startsWith("attachment/")).count();
        check(weapons>=26&&mods>=21,"expanded weapon and module catalog");
        for (var offer:RelayEconomy.CATALOG)
            if (offer.item().startsWith("immersiveengineering:")||offer.item().startsWith("mekanism:"))
                check(net.minecraft.core.registries.BuiltInRegistries.ITEM.containsKey(net.minecraft.resources.ResourceLocation.parse(offer.item())),"registered shop item "+offer.id());
        check(ExpeditionReset.pending(server)==null,"reset request cleared");
        System.out.println("RELAY_011_RESET_PASS catalog_guns="+weapons+" catalog_modules="+mods);
        server.halt(false);
    }

    private static void check(boolean condition,String message) {
        if(!condition)throw new IllegalStateException("RELAY_011 "+message);
    }

    private Update11IntegrationTest() {}
}
