package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class FieldSecurityIntegrationTest {
    static void verify(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"RelayFieldSecurity"));
        var safe=new BlockPos(312,72,312);
        var source=safe.east(30);
        SupplySites.cache(level,state,safe,SupplySites.Kind.ARMORY);
        SupplySites.cache(level,state,source,SupplySites.Kind.FACTORY);
        FieldSecurity.mark(level,safe,"prison");
        FieldSecurity.mark(level,source,"kaisyn:outpost/camps/savanna_plateau/side/workshop");
        check(FieldSecurity.locked(level,state,safe),"locked before access");
        FieldSecurity.read(player,state,source);
        check(!FieldSecurity.locked(level,state,safe),"code unlocks");
        state.fieldRoutes.remove("fieldSafeCode");
        FieldSecurity.key(level,state,safe.east(1));
        check(FieldSecurity.locked(level,state,safe),"wrong guard does not unlock");
        FieldSecurity.key(level,state,safe);
        check(!FieldSecurity.locked(level,state,safe),"matching guard unlocks");
        state.fieldRoutes.remove("fieldSafeKey");
        FieldSecurity.arm(player,state,safe,List.of(UUID.randomUUID()));
        check(state.fieldRoutes.contains("fieldPatrol"),"alarm armed");
        FieldSecurity.cancel(player,state);
        check(!state.fieldRoutes.contains("fieldPatrol"),"intercepted");
        FieldSecurity.arm(player,state,safe,List.of(UUID.randomUUID()));
        state.fieldRoutes.getCompound("fieldPatrol").putLong("due",0);
        FieldSecurity.tick(level,state,List.of(player));
        check(!state.fieldRoutes.contains("fieldPatrol"),"defeated guards cannot transmit");
        check(ZoneLandmarks.plans("industrial").stream().noneMatch(plan->plan.template().equals("military_camp"))
            &&ZoneLandmarks.plans("ash").stream().noneMatch(plan->plan.template().equals("prison")),"objectives in separate regions");
        var near=new BlockPos(0,72,55);
        level.setBlock(near.below(),Blocks.STONE.defaultBlockState(),3);
        var guard=RaidDirector.spawn(level,state,near,"stalker",player);
        check(guard!=null,"live sender fixture");
        player.moveTo(.5,72,.5);
        FieldSecurity.arm(player,state,near,List.of(guard.getUUID()));
        state.fieldRoutes.getCompound("fieldPatrol").putLong("due",0);
        FieldSecurity.tick(level,state,List.of(player));
        check(state.fieldRoutes.getBoolean("fieldPatrolDone"),"patrol deployed");
        guard.discard();
        state.fieldRoutes.remove("fieldPatrolDone");
        state.fieldRoutes.putString("expeditionContract","MEDICAL");
        SupplySites.cache(level,state,safe,SupplySites.Kind.CANTEEN);
        SupplySites.cache(level,state,source,SupplySites.Kind.CANTEEN);
        level.getBlockEntity(safe).getPersistentData().putString("relay_landmark","Карантинная больница");
        level.getBlockEntity(source).getPersistentData().putString("relay_landmark","Санитарный шлюз");
        check(RaidRules.begin(player,state)==null,"contract raid");
        ExpeditionContracts.discover(player,state,safe);
        var raid=RaidRules.record(player);
        check(!raid.getBoolean("medicalFound"),"hospital requires clue");
        ExpeditionContracts.discover(player,state,source);
        ExpeditionContracts.discover(player,state,safe);
        player.getInventory().setItem(0,ExpeditionContracts.reserve(state));
        ExpeditionContracts.capture(player,state,raid);
        check(raid.getString("expeditionReward").equals("medical"),"medical chain complete");
        ExpeditionContracts.award(player,raid);
        ExpeditionContracts.award(player,raid);
        check(RaidContracts.count(player)==1,"one contract reward");
        RaidJournal.get(server).raids.remove(player.getUUID());
        state.fieldRoutes.remove("expeditionContract");
        var cache=level.getBlockEntity(safe);
        cache.getPersistentData().putBoolean("relay_filter_cache",true);
        check(TrophyResearch.medicalLocked(level,state,safe),"filter required");
        int research=state.research;
        state.research|=1<<TrophyResearch.Part.REGULATOR.ordinal();
        check(!TrophyResearch.medicalLocked(level,state,safe),"research unlocks reserve");
        state.research=research;
        var path=new BlockPos(64,78,64);
        for(int x=-4;x<=4;x++)for(int z=0;z<=10;z++)
            level.setBlock(path.offset(x,-1,z),x==0&&z>=4&&z<=6?Blocks.WATER.defaultBlockState():Blocks.GRASS_BLOCK.defaultBlockState(),2);
        check(TrailSurvey.markDetour(level,state,path,path.south(10),path,Blocks.ANDESITE),"route around water");
        check(level.getFluidState(path.offset(0,-1,5)).is(net.minecraft.tags.FluidTags.WATER),"detour preserves water");
        System.out.println("RELAY_FIELD_SECURITY_PASS");
    }

    private static void check(boolean condition,String message){
        if(!condition)throw new IllegalStateException("Field Security: "+message);
    }

    private FieldSecurityIntegrationTest(){}
}
