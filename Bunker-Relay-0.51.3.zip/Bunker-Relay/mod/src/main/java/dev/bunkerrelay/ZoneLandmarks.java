package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.core.Direction;
import noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity;

final class ZoneLandmarks {
    record Plan(String title,String template,SupplySites.Kind loot,boolean medical){}
    private static final List<Plan> FOREST=List.of(
        new Plan("Дом лесничего","lodge",SupplySites.Kind.CANTEEN,false),
        new Plan("Лесной приют","church1",SupplySites.Kind.CANTEEN,true),
        new Plan("Забытое лесное захоронение","massgrave3",SupplySites.Kind.WAREHOUSE,false),
        new Plan("Рыбацкая станция","kaisyn:village/old_growth_taiga_polish/houses/old_growth_taiga_fisher_1",SupplySites.Kind.CANTEEN,false),
        new Plan("Таёжная дозорная башня","kaisyn:outpost/towers/taiga/base_plate",SupplySites.Kind.WAREHOUSE,false));
    private static final List<Plan> INDUSTRIAL=List.of(
        new Plan("Полицейский участок","prison",SupplySites.Kind.ARMORY,false),
        new Plan("Склад гражданской обороны","cell",SupplySites.Kind.WAREHOUSE,false),
        new Plan("Промышленная шахта","mines",SupplySites.Kind.FACTORY,false),
        new Plan("Ремонтная мастерская","kaisyn:outpost/camps/savanna_plateau/side/workshop",SupplySites.Kind.FACTORY,false),
        new Plan("Оружейная кузница","kaisyn:village/old_growth_taiga_polish/houses/old_growth_taiga_toolsmith_and_weaponsmith_1",SupplySites.Kind.ARMORY,false));
    private static final List<Plan> INFECTED=List.of(
        new Plan("Карантинная больница","hospital",SupplySites.Kind.CANTEEN,true),
        new Plan("Изолятор","asylum",SupplySites.Kind.WAREHOUSE,true),
        new Plan("Заражённый собор","cathedral",SupplySites.Kind.FACTORY,false),
        new Plan("Запечатанный медпункт","betterdungeons:zombie_dungeon/floor1/room/floor1_room_0",SupplySites.Kind.CANTEEN,true),
        new Plan("Санитарный шлюз","betterdungeons:zombie_dungeon/floor1/room/floor1_specialroom_0",SupplySites.Kind.WAREHOUSE,true));
    private static final List<Plan> ASH=List.of(
        new Plan("Заброшенный могильник","massgrave1",SupplySites.Kind.WAREHOUSE,false),
        new Plan("Станция сбора биомассы","mega_biomass_tower",SupplySites.Kind.FACTORY,false),
        new Plan("Военная база","military_camp",SupplySites.Kind.ARMORY,false),
        new Plan("Форт на пустоши","kaisyn:outpost/forts/desert/base_plate",SupplySites.Kind.ARMORY,false),
        new Plan("Засыпанное святилище","kaisyn:other/desert_temple_mimic/pyramid_main",SupplySites.Kind.WAREHOUSE,false));
    private static final int[][] OFFSETS={{-672,-672},{672,-672},{672,672},{-672,672},{0,672}};
    static final int COUNT=OFFSETS.length;
    private static final int[][] ALTERNATIVES={{0,0},{80,0},{0,80},{-80,0},{0,-80}};


    static List<Plan> plans(String theme){
        return switch(ZoneProfile.of(theme)){
            case FOREST -> FOREST;
            case INDUSTRIAL -> INDUSTRIAL;
            case INFECTED -> INFECTED;
            case ASH -> ASH;
        };
    }

    static void build(ServerLevel level,RelayState state,int index){
        var plan=plans(state.activeTheme).get(index);
        SporeStorySites.Site site=null;
        LandmarkCondition condition=LandmarkCondition.REGULAR;
        int entrance=0;
        for(var offset:ALTERNATIVES){
            if(state.layoutVersion==3&&(offset[0]!=0||offset[1]!=0))break;
            var point=state.layoutVersion==3?ExpeditionGrid.point(state,9+index)
                :ExpeditionLayout.position(state,OFFSETS[index][0]+offset[0],OFFSETS[index][1]+offset[1]);
            int x=point.getX(),z=point.getZ();
            if(!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,x-32,z-32)
                ||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,x+32,z+32))continue;
            boolean known=StructureLevels.known(level,state,"landmark",x,z);
            if(state.layoutVersion!=3&&!known&&(ExpeditionLayout.nearStoryPlots(state,point)||StructureLevels.overlapsHistorical(level,state,point,14)))continue;
            try{
                condition=LandmarkCondition.choose(state.seed,point);
                entrance=condition.entrance(Math.floorMod(RaidDirector.roll(state.seed,x,z),3));
                site=SporeStorySites.buildTemplate(level,state,x,z,
                    plan.medical?"clinic":plan.loot==SupplySites.Kind.ARMORY?"signal":"archive",
                    entrance,plan.template,"landmark");
            }catch(IllegalArgumentException noHeadroom){
                continue;
            }
            if(site!=null)break;
        }
        if(site==null)return;
        int compartment=Math.floorMod(RaidDirector.roll(state.seed,site.origin().getX(),site.origin().getZ()),3);
        if(plan.medical&&entrance==1&&compartment==2)compartment=0;
        if(condition!=LandmarkCondition.REGULAR){
            var direction=new Direction[]{Direction.NORTH,Direction.EAST,Direction.WEST}[entrance];
            var marker=site.approach().relative(direction.getOpposite()).relative(direction.getClockWise(),2).above(2);
            level.setBlock(marker,condition.marker.defaultBlockState(),2);
        }
        var original=site.origin().south(4);
        var cache=switch(compartment){case 1->site.origin().offset(4,0,3);case 2->site.origin().offset(-4,0,3);default->original;};
        if(!cache.equals(original)){
            level.setBlock(original,net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),2);
            level.setBlock(cache,net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),2);
        }
        SupplySites.cache(level,state,cache,plan.loot);
        if(condition==LandmarkCondition.INFESTED)SporeCorpses.scatter(level,state,site.origin(),cache);
        if(level.getBlockEntity(cache) instanceof LootrChestBlockEntity chest){
            chest.getPersistentData().putString("relay_landmark",plan.title);
            chest.getPersistentData().putString("relay_landmark_condition",condition.name());
            var inventory=chest.getInfoReferenceInventory();
            var label=inventory.get(2).copy();
            label.set(DataComponents.CUSTOM_NAME,Component.literal(plan.title));
            label.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(java.util.List.of(
                Component.literal("Отсек · "+(compartment==0?"в дальнем зале":compartment==1?"справа от центра":"слева от центра")))));
            inventory.set(2,label);
            var request=BunkerRequests.forSite(plan.template);
            if(request!=null)inventory.set(11,request.item());
            if(condition!=LandmarkCondition.REGULAR)inventory.set(10,condition.bonus(state.activeLoot));
            if(plan.template.equals("hospital")&&ExpeditionContracts.selected(state)==ExpeditionContracts.Type.MEDICAL)
                inventory.set(0,ExpeditionContracts.reserve(state));
            if(plan.medical){
                var medical=new java.util.ArrayList<ItemStack>();
                RaidLoot.medical(medical,state,net.minecraft.util.RandomSource.create(state.seed^cache.asLong()));
                for(int slot=0;slot<medical.size();slot++)inventory.set(4+slot,medical.get(slot));
            }
            chest.setChanged();
        }
        FieldSecurity.mark(level,cache,plan.template);
        if(plan.template.equals("hospital")&&state.activeTheme.equals("infected")){
            var reserve=site.origin().offset(5,0,-3);
            level.setBlock(reserve,net.minecraft.world.level.block.Blocks.CHEST.defaultBlockState(),3);
            if(level.getBlockEntity(reserve) instanceof net.minecraft.world.level.block.entity.ChestBlockEntity chest){
                chest.setItem(4,new ItemStack(Medicine.MEDKIT.get(),2));
                chest.setItem(5,new ItemStack(Medicine.BANDAGE.get(),5));
                PersonalLoot.convert(level,reserve,chest);
                var personal=level.getBlockEntity(reserve);
                if(personal!=null){
                    personal.getPersistentData().putBoolean("relay_filter_cache",true);
                    personal.setChanged();
                }
            }
        }
        var room=new CompoundTag();
        room.putString("type","landmark");
        room.putString("title",plan.title);
        room.putString("template",plan.template);
        room.putString("condition",condition.name());
        room.putLong("approach",site.approach().asLong());
        room.putLong("origin",site.origin().asLong());
        room.putInt("x",cache.getX());room.putInt("y",cache.getY());room.putInt("z",cache.getZ());
        var director=RaidDirector.get(level.getServer());
        director.rooms.add(room);
        director.setDirty();
        int sx=ExpeditionGrid.cell(state,cache.getX()-state.centerX);
        int sz=ExpeditionGrid.cell(state,cache.getZ()-state.centerZ);
        state.caches.add(ChunkPos.asLong(sx,sz));
        state.setDirty();
    }

    static void visit(ServerPlayer player,RelayState state){
        if(!RaidRules.active(player))return;
        var director=RaidDirector.get(player.server);
        for(var room:director.rooms){
            if(!room.getString("type").equals("landmark"))continue;
            var at=position(room);
            var approach=room.contains("approach")?BlockPos.of(room.getLong("approach")):at;
            if(player.distanceToSqr(approach.getX()+.5,approach.getY()+.5,approach.getZ()+.5)>48*48
                &&player.distanceToSqr(at.getX()+.5,at.getY()+.5,at.getZ()+.5)>48*48)continue;
            if(!room.getBoolean("discovered")){
                room.putBoolean("discovered",true);
                director.setDirty();
                var condition=LandmarkCondition.read(room.getString("condition"));
                RaidRules.chat(player,"КПК · "+room.getString("title")+" · "+approach.toShortString()
                    +(condition==LandmarkCondition.REGULAR?"":" · "+condition.clue));
            }
            SupplySites.alert(player,state,at);
        }
    }

    static void report(ServerPlayer player,RaidDirector director){
        for(var room:director.rooms)
            if(room.getString("type").equals("landmark")&&room.getBoolean("discovered"))
                RaidRules.chat(player,room.getString("title")+" · "+position(room).toShortString()
                    +conditionLabel(room));
    }

    static String lastClue(RaidDirector director){
        for(var room:director.rooms.reversed()){
            if(!room.getString("type").equals("landmark")||!room.getBoolean("discovered"))continue;
            var condition=LandmarkCondition.read(room.getString("condition"));
            if(condition!=LandmarkCondition.REGULAR)return room.getString("title")+" · "+condition.title;
        }
        return "Осмотрите подход к постройке";
    }

    private static String conditionLabel(CompoundTag room){
        var condition=LandmarkCondition.read(room.getString("condition"));
        return condition==LandmarkCondition.REGULAR?"":" · "+condition.title+" · "+condition.clue;
    }

    private static BlockPos position(CompoundTag room){return new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z"));}
    private ZoneLandmarks(){}
}
