package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;

enum MiniBossCombat {
    RANGED, AMBUSH, BRUISER;

    private static final String COOLDOWN = "relay_miniboss_next_move";
    private static final String IMPACT = "relay_miniboss_impact";
    private static final String IMPACT_POS = "relay_miniboss_impact_pos";
    private static final double STRIKE_RADIUS = 4;

    void configure(Mob mob) {
        var speed=mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if(speed!=null&&this==BRUISER)speed.setBaseValue(speed.getBaseValue()*.75);
    }

    void fight(ServerLevel level,Mob mob,ServerPlayer target,MiniBosses.Kind kind,RelayState state) {
        var data=mob.getPersistentData();
        long now=level.getGameTime();
        var site=BlockPos.of(data.getLong("relay_guard_site"));
        if(!data.contains("relay_guard_site")||mob.blockPosition().distSqr(site)>34*34){
            data.remove(IMPACT);
            if(data.contains("relay_guard_site")){
                mob.setTarget(null);
                mob.getNavigation().moveTo(site.getX()+.5,site.getY(),site.getZ()+.5,1.15);
            }
            return;
        }
        if(this==BRUISER&&data.contains(IMPACT)){
            long due=data.getLong(IMPACT);
            if(now>=due){
                var impact=BlockPos.of(data.getLong(IMPACT_POS));
                data.remove(IMPACT);
                if(now-due<=40&&mob.blockPosition().distSqr(impact)<=9)strike(level,mob,kind,state,impact);
            }
            return;
        }
        if(now<data.getLong(COOLDOWN)||!mob.hasLineOfSight(target))return;
        double distance=mob.distanceToSqr(target);
        switch(this){
            case RANGED -> {
                if(distance>=9*9||distance<.1)return;
                var retreat=mob.position().subtract(target.position()).multiply(1,0,1).normalize().scale(5);
                var point=BlockPos.containing(mob.position().add(retreat));
                if(point.distSqr(site)<=20*20&&mob.getNavigation().moveTo(point.getX()+.5,point.getY(),point.getZ()+.5,1.25))
                    data.putLong(COOLDOWN,now+35);
            }
            case AMBUSH -> {
                if(distance<3*3||distance>12*12)return;
                mob.setTarget(target);
                mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,45,1));
                mob.getNavigation().moveTo(target,1.3);
                level.sendParticles(ParticleTypes.SMOKE,mob.getX(),mob.getY()+.4,mob.getZ(),8,.4,.3,.4,.02);
                data.putLong(COOLDOWN,now+150);
            }
            case BRUISER -> {
                if(distance>6*6)return;
                var impact=mob.blockPosition();
                mob.getNavigation().stop();
                mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,43,5));
                data.putLong(IMPACT,now+40);
                data.putLong(IMPACT_POS,impact.asLong());
                data.putLong(COOLDOWN,now+(data.getBoolean("relay_miniboss_phase")?100:160));
                for(var player:level.players())if(RaidRules.active(player)&&player.distanceToSqr(mob)<=16*16)
                    RaidHud.alert(player,kind.name+" готовит удар · отойдите");
                level.playSound(null,impact,SoundEvents.IRON_GOLEM_STEP,SoundSource.HOSTILE,1.3f,.6f);
                for(int i=0;i<20;i++){
                    double angle=i*Math.PI/10;
                    level.sendParticles(ParticleTypes.SMOKE,impact.getX()+.5+STRIKE_RADIUS*Math.cos(angle),
                        impact.getY()+.15,impact.getZ()+.5+STRIKE_RADIUS*Math.sin(angle),2,0,.03,0,0);
                }
            }
        }
    }

    private static void strike(ServerLevel level,Mob mob,MiniBosses.Kind kind,RelayState state,BlockPos impact) {
        BossEffects.strike(level,impact,kind.theme,(int)STRIKE_RADIUS);
        for(var player:level.players()){
            if(!player.isAlive()||player.isSpectator()||!RaidRules.active(player)||!mob.hasLineOfSight(player)
                ||player.distanceToSqr(impact.getX()+.5,impact.getY(),impact.getZ()+.5)>STRIKE_RADIUS*STRIKE_RADIUS)continue;
            if(player.hurt(player.damageSources().mobAttack(mob),4+state.activeDifficulty))
                player.knockback(.55,mob.getX()-player.getX(),mob.getZ()-player.getZ());
        }
    }
}
