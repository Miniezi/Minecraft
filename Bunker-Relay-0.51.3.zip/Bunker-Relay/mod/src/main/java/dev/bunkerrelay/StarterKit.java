package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;

final class StarterKit {
    private static final String CLAIM="starterKitGeneration", MARK="relay_starter_kit";

    static String status(ServerPlayer player,RelayState state){
        var raid=RaidRules.record(player);
        if(!state.ready||state.generating||raid==null||!raid.getString("status").equals("ACTIVE")
            ||raid.getInt("generation")!=state.generation||!player.level().dimension().equals(BunkerRelay.key(state.activeDimension)))
            return "Доступен после входа в вылазку";
        var account=RelayEconomy.account(player);
        return account.contains(CLAIM)&&account.getInt(CLAIM)==state.generation
            ?"Уже выдан в этом цикле":"Учебный Glock, 12 патронов 9 мм и припасы";
    }

    static boolean claim(ServerPlayer player,RelayState state){
        var raid=RaidRules.record(player);
        if(!state.ready||state.generating||raid==null||!raid.getString("status").equals("ACTIVE")
            ||raid.getInt("generation")!=state.generation||!player.level().dimension().equals(BunkerRelay.key(state.activeDimension))){
            RaidRules.tell(player,status(player,state));
            return false;
        }
        var account=RelayEconomy.account(player);
        if(account.contains(CLAIM)&&account.getInt(CLAIM)==state.generation){
            RaidRules.tell(player,"Комплект уже выдан в этом цикле.");
            return false;
        }
        var pistol=com.tacz.guns.api.item.builder.GunItemBuilder.create().setId(net.minecraft.resources.ResourceLocation.parse("tacz:glock_17")).setAmmoCount(0).build(player.registryAccess());
        pistol.set(DataComponents.CUSTOM_NAME,Component.literal("Учебный Glock 17"));
        var ammo=com.tacz.guns.api.item.builder.AmmoItemBuilder.create().setId(net.minecraft.resources.ResourceLocation.parse("tacz:9mm")).setCount(12).build();
        var kit=List.of(mark(pistol),mark(ammo),mark(new ItemStack(Items.STONE_SWORD)),mark(new ItemStack(Items.STONE_PICKAXE)),
            mark(new ItemStack(Items.LEATHER_CHESTPLATE)),mark(new ItemStack(Items.BREAD,6)),mark(new ItemStack(Items.TORCH,8)));
        var inventory=player.getInventory();
        long free=inventory.items.stream().filter(ItemStack::isEmpty).count();
        long needed=kit.stream().filter(stack->SafeInventory.capacity(inventory,stack)-free*stack.getMaxStackSize()<stack.getCount()).count();
        if(free<needed){
            RaidRules.tell(player,"Освободите место в основном инвентаре для комплекта.");
            return false;
        }
        for(var stack:kit)SafeInventory.insert(inventory,stack);
        account.putInt(CLAIM,state.generation);
        RelayEconomy.save(player);
        RaidRules.tell(player,"Стартовый комплект получен.");
        return true;
    }

    private static ItemStack mark(ItemStack stack){
        var tag=stack.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY).copyTag();
        tag.putBoolean(MARK,true);
        stack.set(DataComponents.CUSTOM_DATA,CustomData.of(tag));
        stack.set(DataComponents.LORE,new ItemLore(List.of(Component.literal("Стартовый комплект Relay · скупка 1 кр./шт."))));
        return stack;
    }

    static boolean marked(ItemStack stack){
        var data=stack.get(DataComponents.CUSTOM_DATA);
        return data!=null&&data.copyTag().getBoolean(MARK);
    }

    private StarterKit(){}
}
