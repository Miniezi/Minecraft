package dev.bunkerrelay;
import java.util.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
public final class SupplyIntegrationTest {
 private static final UUID ID=UUID.fromString("eae15477-1e14-4933-a4e5-bab802b48bcd"),FIXTURE=UUID.fromString("6fb7c311-ffb3-4e2d-ad97-997f9404c1e7");
 private static FakePlayer player(MinecraftServer server){return new FakePlayer(server.getLevel(BunkerRelay.HUB),new GameProfile(ID,"SupplyTest"));}
 private static void check(boolean b,String why){if(!b)throw new IllegalStateException("SUPPLY: "+why);}
 private static void give(FakePlayer p,SupplyOrders.Order o){p.getInventory().clearContent();SafeInventory.insert(p.getInventory(),o.target(p));}
 private static CompoundTag raid(String cycle,String status){var r=new CompoundTag();r.putString("contractCycle",cycle);r.putString("status",status);r.putInt("economyDifficulty",1);return r;}
 public static void run(MinecraftServer server){
  var p=player(server);var a=RelayEconomy.account(p);var j=RaidJournal.get(server);j.raids.remove(ID);var orders=SupplyOrders.list(p);int cycle=SupplyOrders.cycle(p);check(orders.size()==3&&new HashSet<>(orders).size()==3,"three distinct orders");var first=orders.getFirst();
  for(int r:new int[]{0,10,30,60,1000}){a.putInt("reputation",r);for(var offer:RelayEconomy.CATALOG)check(RelayEconomy.price(p,offer)>offer.sell(),"no buy/sell arbitrage at rank "+r);for(var o:orders)check(o.reward()<2*RelayEconomy.price(p,o.goods()),"order cannot profit from shop purchases");}a.putInt("reputation",0);
  SupplyOrders.deliver(p,first,cycle);check(RelayEconomy.balance(p)==300&&!SupplyOrders.done(p,first),"missing goods no payment");give(p,first);var renamed=p.getInventory().getItem(0);renamed.set(DataComponents.CUSTOM_NAME,Component.literal("Keep"));SupplyOrders.deliver(p,first,cycle);check(!SupplyOrders.done(p,first)&&renamed.getCount()>0,"modified goods protected");
  give(p,first);a.putLong("balance",RelayEconomy.MAX_BALANCE);SupplyOrders.deliver(p,first,cycle);check(SupplyOrders.count(p,first)==first.amount()&&!SupplyOrders.done(p,first),"credit cap no item loss");a.putLong("balance",300);
  j.raids.put(ID,raid("active","ACTIVE"));SupplyOrders.deliver(p,first,cycle);check(!SupplyOrders.done(p,first)&&RelayEconomy.balance(p)==300,"no delivery in raid");j.raids.remove(ID);
  var menu=new SupplyOrders.OrdersMenu(11,p.getInventory(),p);menu.clicked(10,1,ClickType.PICKUP,p);menu.clicked(22,0,ClickType.PICKUP,p);check(!SupplyOrders.done(p,first),"right click no selection");menu.clicked(10,0,ClickType.PICKUP,p);check(!SupplyOrders.done(p,first),"selection not delivery");menu.clicked(22,0,ClickType.PICKUP,p);menu.clicked(22,0,ClickType.PICKUP,p);check(SupplyOrders.done(p,first)&&RelayEconomy.balance(p)==300+first.reward()&&SupplyOrders.count(p,first)==0&&SupplyOrders.reputation(p)==5,"one confirmed delivery");
  give(p,first);long before=RelayEconomy.balance(p);SupplyOrders.deliver(p,first,cycle);check(RelayEconomy.balance(p)==before&&SupplyOrders.count(p,first)==first.amount(),"duplicate protected");check(menu.quickMoveStack(p,10).isEmpty(),"icons cannot be extracted");
  RelayEconomy.extracted(p,raid("supply-one","COMMIT"));check(SupplyOrders.list(p).equals(orders)&&SupplyOrders.cycle(p)==cycle&&SupplyOrders.done(p,first),"unfinished board persists across extraction");
  for(int i=1;i<3;i++){give(p,orders.get(i));SupplyOrders.deliver(p,orders.get(i),cycle);}check(SupplyOrders.reputation(p)==15&&SupplyOrders.discount(p)==3,"rank threshold discount");
  var ammo=RelayEconomy.CATALOG.getFirst();p.getInventory().clearContent();before=RelayEconomy.balance(p);RelayEconomy.buy(p,ammo);check(RelayEconomy.balance(p)==before-96,"unit discount rounded up");
  RelayEconomy.extracted(p,raid("supply-two","RESTORE"));check(SupplyOrders.cycle(p)==cycle,"failure cannot refresh");RelayEconomy.extracted(p,raid("supply-one","COMMIT"));check(SupplyOrders.cycle(p)==cycle,"same sector cannot refresh");RelayEconomy.extracted(p,raid("supply-two","COMMIT"));check(SupplyOrders.cycle(p)==cycle+1&&!SupplyOrders.list(p).equals(orders)&&SupplyOrders.list(p).stream().noneMatch(o->SupplyOrders.done(p,o)),"completed board refreshes on new successful sector");
  before=RelayEconomy.balance(p);SupplyOrders.deliver(p,first,cycle);check(RelayEconomy.balance(p)==before,"old board rejected");
  RaidHud.toggle(p);var clone=player(server);NeoForge.EVENT_BUS.post(new PlayerEvent.Clone(clone,p,true));check(SupplyOrders.reputation(clone)==15&&SupplyOrders.cycle(clone)==cycle+1&&clone.getPersistentData().getBoolean("relay_hud_off"),"clone preserves board reputation HUD");
  check(RaidHud.direction(BlockPos.ZERO,new BlockPos(20,0,-20)).equals("СВ"),"compass northeast");check(RaidHud.direction(BlockPos.ZERO,new BlockPos(0,10,0)).equals("выше"),"vertical target");
  var fixture=new CompoundTag();fixture.put("data",p.getPersistentData().copy());fixture.putInt("cycle",SupplyOrders.cycle(p));fixture.putLong("balance",RelayEconomy.balance(p));j.raids.put(FIXTURE,fixture);j.flush(server);
  System.out.println("RELAY_SUPPLY_PASS: orders, confirmations, exact components, insufficient goods, cap, raid restriction, duplicate payout, pinned board, success-only refresh, discounts, no arbitrage, Clone, HUD directions");
 }
 public static void reload(MinecraftServer server){var f=RaidJournal.get(server).raids.get(FIXTURE);check(f!=null,"fixture saved");var p=player(server);p.getPersistentData().merge(f.getCompound("data"));check(SupplyOrders.reputation(p)==15&&SupplyOrders.discount(p)==3&&SupplyOrders.cycle(p)==f.getInt("cycle")&&RelayEconomy.balance(p)==f.getLong("balance")&&p.getPersistentData().getBoolean("relay_hud_off"),"persistent reputation orders balance HUD");var before=SupplyOrders.list(p);RelayEconomy.extracted(p,raid("supply-two","COMMIT"));check(SupplyOrders.list(p).equals(before)&&RelayEconomy.balance(p)==f.getLong("balance"),"saved receipt survives restart");System.out.println("RELAY_SUPPLY_RELOAD_PASS: reputation, board, balance, HUD preference, sector receipt");}
 private SupplyIntegrationTest(){}
}
