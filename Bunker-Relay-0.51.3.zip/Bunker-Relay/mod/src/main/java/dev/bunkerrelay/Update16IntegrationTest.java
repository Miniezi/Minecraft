package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update16IntegrationTest {
    static void verify(MinecraftServer server,RelayState state){
        var hub=server.getLevel(BunkerRelay.HUB);
        check(state.workshopBuilt,"workshop added");
        var blocked=new BlockPos(-18,96,-19);
        check(hub.getBlockState(blocked).is(Blocks.DIAMOND_BLOCK),"player block preserved");
        check(!BlockPos.of(state.workshopOrigin).above().equals(blocked),"alternate plot");
        var door=CourtyardWorkshop.entrance(state);
        check(Math.abs(door.getX())<30&&door.getZ()<8,"door is inside courtyard");
        for(int z=-2;z<=3;z++){
            var step=door.south(z);
            check(hub.isEmptyBlock(step)&&hub.isEmptyBlock(step.above())&&!hub.isEmptyBlock(step.below()),"walkable door path "+z);
        }
        var player=new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay16Tabs")){
            @Override public java.util.OptionalInt openMenu(MenuProvider menu){
                containerMenu=menu.createMenu(60,getInventory(),this);
                return java.util.OptionalInt.of(60);
            }
        };
        var bench=CourtyardWorkshop.bench(state);
        player.moveTo(bench.getX()+.5,bench.getY(),bench.getZ()+1.5);
        check(CourtyardWorkshop.useOrLocate(player)==1&&player.containerMenu instanceof WorkshopMenu,"walk-up workshop menu");
        click(player,0);
        check(player.containerMenu instanceof PocketDevice.Menu&&label(player,2).startsWith("•"),"return to base tab");
        click(player,1);
        check(label(player,1).startsWith("•")&&label(player,9).equals("Оружейник"),"shop shows merchants");
        click(player,9);
        check(player.containerMenu instanceof RelayEconomy.MarketMenu,"merchant opens");
        click(player,52);
        check(player.containerMenu instanceof PocketDevice.Menu&&label(player,1).startsWith("•"),"market returns to shop");
        var expedition=server.getLevel(BunkerRelay.key(state.activeDimension));
        player.setServerLevel(expedition);
        PocketDevice.open(player,PocketDevice.Page.SHOP);
        check(label(player,9).equals("Торговля на базе")&&player.containerMenu.getSlot(14).getItem().isEmpty(),"no remote trade");
        click(player,9);
        check(player.containerMenu instanceof PocketDevice.Menu,"no trade menu in a raid dimension");
        System.out.println("RELAY_016_PASS tabs=true shop_return=true trade_guard=true walkable=true migration=true");
        server.saveEverything(false,true,true);
        server.halt(false);
    }

    private static String label(FakePlayer player,int slot){return player.containerMenu.getSlot(slot).getItem().getHoverName().getString();}
    private static void click(FakePlayer player,int slot){player.containerMenu.clicked(slot,0,ClickType.PICKUP,player);}
    private static void check(boolean condition,String description){if(!condition)throw new IllegalStateException("RELAY_016 "+description);}
    private Update16IntegrationTest(){}
}
