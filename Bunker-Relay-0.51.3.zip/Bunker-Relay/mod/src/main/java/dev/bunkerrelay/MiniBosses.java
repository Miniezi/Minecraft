package dev.bunkerrelay;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

final class MiniBosses {
    private static final String KIND="relay_miniboss";
    private static final Map<UUID,ServerBossEvent> bars=new HashMap<>();

    enum Kind {
        ARMORY("Комендант оружейной","inf_pillager",Items.GOLD_INGOT,"industrial",MiniBossCombat.RANGED),
        CANTEEN("Заражённый завхоз","inf_hazmat",Items.GOLDEN_CARROT,"infected",MiniBossCombat.AMBUSH),
        WAREHOUSE("Кладовщик","inf_vindicator",Items.IRON_BLOCK,"forest",MiniBossCombat.BRUISER),
        FACTORY("Мастер цеха","protector",Items.COPPER_BLOCK,"ash",MiniBossCombat.BRUISER),
        ECHO("Лабораторный смотритель","slasher",Items.GOLD_INGOT,"infected",MiniBossCombat.AMBUSH),
        SIGNAL("Офицер блокпоста","spitter",Items.GOLD_INGOT,"industrial",MiniBossCombat.RANGED),
        CLINIC("Карантинный санитар","inf_hazmat",Items.GOLDEN_CARROT,"infected",MiniBossCombat.AMBUSH),
        ARCHIVE("Хранитель архива","knight",Items.IRON_BLOCK,"forest",MiniBossCombat.BRUISER),
        VAULT("Сторож резерва","brute",Items.IRON_BLOCK,"industrial",MiniBossCombat.BRUISER),
        AIRDROP("Охотник за грузом","stalker",Items.GOLD_INGOT,"ash",MiniBossCombat.AMBUSH);

        final String name,theme;
        final String type;
        final Item reward;
        final MiniBossCombat combat;
        Kind(String name,String type,Item reward,String theme,MiniBossCombat combat){
            this.name=name;this.type=type;this.reward=reward;this.theme=theme;this.combat=combat;
        }
    }

    static Kind story(String type){
        return switch(type){
            case "echo" -> Kind.ECHO;
            case "signal" -> Kind.SIGNAL;
            case "clinic" -> Kind.CLINIC;
            default -> Kind.ARCHIVE;
        };
    }

    static void arm(ServerLevel level,RelayState state,BlockPos site,Kind kind){
        int generation=state.generation+(state.generating?1:0);
        var chest=level.getBlockEntity(site);
        if(chest==null)return;
        var data=chest.getPersistentData();
        if(data.contains(KIND)&&data.getInt("relay_miniboss_cycle")==generation)return;
        data.putString(KIND,kind.name());
        data.putInt("relay_miniboss_cycle",generation);
        data.remove("relay_miniboss_deployed");
        chest.setChanged();
    }

    static void replaceLegacy(ServerLevel level,RelayState state,Mob mob){
        var data=mob.getPersistentData();
        if(!data.contains(KIND)||!data.contains("relay_guard_site")
            ||data.getInt("relay_structure_generation")!=state.generation)return;
        var site=BlockPos.of(data.getLong("relay_guard_site"));
        level.getServer().tell(new net.minecraft.server.TickTask(level.getServer().getTickCount(),()->{
            if(!level.hasChunkAt(site))return;
            var chest=level.getBlockEntity(site);
            if(chest!=null&&chest.getPersistentData().getInt("relay_miniboss_cycle")==state.generation){
                chest.getPersistentData().remove("relay_miniboss_deployed");
                chest.setChanged();
            }
        }));
    }

    static void encounter(ServerPlayer player,RelayState state,BlockPos site){
        var level=player.serverLevel();
        if(!level.hasChunkAt(site))return;
        var chest=level.getBlockEntity(site);
        if(chest==null)return;
        var data=chest.getPersistentData();
        if(!data.contains(KIND)||data.getInt("relay_miniboss_cycle")!=state.generation||data.getBoolean("relay_miniboss_deployed"))return;
        if(deploy(player,state,site,Kind.valueOf(data.getString(KIND)))){
            data.putBoolean("relay_miniboss_deployed",true);
            chest.setChanged();
        }
    }

    static boolean deploy(ServerPlayer player,RelayState state,BlockPos site,Kind kind){
        return deploy(player,state,site,kind,false);
    }

    static boolean deploy(ServerPlayer player,RelayState state,BlockPos site,Kind kind,boolean test){
        var level=player.serverLevel();
        int[][] positions=kind.combat==MiniBossCombat.AMBUSH
            ?new int[][]{{-4,-2},{4,2},{-3,4},{3,-4},{0,-8},{0,8},{-8,0},{8,0}}
            :new int[][]{{0,-8},{0,8},{-8,0},{8,0},{0,-12},{0,12},{-12,0},{12,0},{-4,3},{4,-3}};
        for(var offset:positions){
            var column=site.offset(offset[0],0,offset[1]);
            if(!level.hasChunkAt(column)||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,column.getX(),column.getZ()))continue;
            int surface=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,column.getX(),column.getZ());
            for(int y:new int[]{site.getY(),surface}){
                var point=column.atY(y);
                if(Math.abs(y-site.getY())>6||player.distanceToSqr(point.getX()+.5,y,point.getZ()+.5)<16
                    ||!level.getBlockState(point.below()).isSolidRender(level,point.below()))continue;
                if(spawn(level,state,point,site,kind,player,test))return true;
            }
        }
        return false;
    }

    private static boolean spawn(ServerLevel level,RelayState state,BlockPos point,BlockPos site,Kind kind,ServerPlayer target,boolean test){
        var mob=SporeEncounters.create(level,kind.type);
        if(mob==null)return false;
        mob.moveTo(point.getX()+.5,point.getY(),point.getZ()+.5,0,0);
        if(!level.noCollision(mob))return false;
        mob.setCustomName(Component.literal(kind.name));
        mob.setCustomNameVisible(true);
        mob.setPersistenceRequired();
        kind.combat.configure(mob);
        mob.getAttribute(Attributes.MAX_HEALTH).setBaseValue((kind==Kind.CANTEEN?32:48)+8*state.activeDifficulty);
        var damage=mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if(damage!=null)damage.setBaseValue(4+state.activeDifficulty);
        mob.setHealth(mob.getMaxHealth());
        mob.addTag("relay_scaled");
        if(test)mob.addTag(RelayTestCommands.TEST_MOB);
        mob.getPersistentData().putString(KIND,kind.name());
        mob.getPersistentData().putLong("relay_guard_site",site.asLong());
        mob.getPersistentData().putInt("relay_structure_generation",state.generation);
        mob.setTarget(target);
        if(!level.addFreshEntity(mob))return false;
        BossEffects.phase(level,point,kind.theme);
        RaidHud.alert(target,kind.name+" охраняет добычу");
        return true;
    }

    static void second(MinecraftServer server,RelayState state){
        Map<UUID,Set<ServerPlayer>> observed=new HashMap<>();
        if(state.ready&&!state.generating)
            for(var player:server.getPlayerList().getPlayers()){
                var raid=RaidRules.record(player);
                if(raid==null||!raid.getString("status").equals("ACTIVE")||raid.getInt("generation")!=state.generation
                    ||!player.isAlive()||player.isSpectator()||!player.level().dimension().equals(BunkerRelay.key(state.activeDimension)))continue;
                for(var mob:player.serverLevel().getEntitiesOfClass(Mob.class,player.getBoundingBox().inflate(28),
                    entity->entity.isAlive()&&entity.getPersistentData().contains(KIND)
                        &&entity.getPersistentData().getInt("relay_structure_generation")==state.generation)){
                    UUID id=mob.getUUID();
                    var bar=bars.computeIfAbsent(id,key->new ServerBossEvent(mob.getDisplayName(),
                        BossEvent.BossBarColor.YELLOW,BossEvent.BossBarOverlay.NOTCHED_6));
                    var viewers=observed.computeIfAbsent(id,key->new HashSet<>());
                    if(viewers.isEmpty()){
                        float progress=mob.getHealth()/mob.getMaxHealth();
                        bar.setProgress(Math.clamp(progress,0,1));
                        var data=mob.getPersistentData();
                        var kind=Kind.valueOf(data.getString(KIND));
                        var target=player.serverLevel().players().stream()
                            .filter(candidate->candidate.isAlive()&&!candidate.isSpectator()&&RaidRules.active(candidate)
                                &&candidate.distanceToSqr(mob)<28*28)
                            .min(java.util.Comparator.comparingDouble(candidate->candidate.distanceToSqr(mob))).orElse(player);
                        kind.combat.fight(player.serverLevel(),mob,target,kind,state);
                        if(progress<=.5f&&!data.getBoolean("relay_miniboss_phase")){
                            data.putBoolean("relay_miniboss_phase",true);
                            BossEffects.phase(player.serverLevel(),mob.blockPosition(),kind.theme);
                            data.remove("relay_miniboss_next_move");
                        }
                    }
                    viewers.add(player);
                    bar.addPlayer(player);
                }
            }
        bars.entrySet().removeIf(entry->{
            var viewers=observed.get(entry.getKey());
            var bar=entry.getValue();
            if(viewers==null){bar.removeAllPlayers();return true;}
            for(var player:java.util.List.copyOf(bar.getPlayers()))if(!viewers.contains(player))bar.removePlayer(player);
            return false;
        });
    }

    static void died(LivingDeathEvent event){
        if(!(event.getEntity().level() instanceof ServerLevel level))return;
        var entity=event.getEntity();
        var data=entity.getPersistentData();
        if(!data.contains(KIND)||data.getBoolean("relay_miniboss_paid"))return;
        var state=RelayState.get(level.getServer());
        if(!state.ready||data.getInt("relay_structure_generation")!=state.generation
            ||!level.dimension().equals(BunkerRelay.key(state.activeDimension)))return;
        Kind kind=Kind.valueOf(data.getString(KIND));
        data.putBoolean("relay_miniboss_paid",true);
        var bar=bars.remove(entity.getUUID());
        if(bar!=null)bar.removeAllPlayers();
        if(data.contains("relay_guard_site")&&event.getSource().getEntity() instanceof ServerPlayer player&&RaidRules.active(player))
            FieldSecurity.key(level,state,BlockPos.of(data.getLong("relay_guard_site")));
        BossEffects.strike(level,entity.blockPosition(),kind.theme,3);
        entity.spawnAtLocation(new ItemStack(kind.reward,kind==Kind.CANTEEN?2:1));
    }

    static void reset(){
        bars.values().forEach(ServerBossEvent::removeAllPlayers);
        bars.clear();
    }

    private MiniBosses(){}
}
