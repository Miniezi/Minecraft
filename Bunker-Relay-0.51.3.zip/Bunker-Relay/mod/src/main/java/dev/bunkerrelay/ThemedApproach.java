package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.levelgen.Heightmap;

final class ThemedApproach {
    static void build(ServerLevel level, RelayState state, BlockPos room) {
        switch (state.activeTheme) {
            case "industrial" -> {
                path(level, room, Blocks.ANDESITE, 6, 14);
                for (int x : new int[]{-5, 5}) for (int z : new int[]{-8, -12}) {
                    var at = ground(level, room.offset(x, 0, z));
                    level.setBlock(at, Blocks.BARREL.defaultBlockState(), 2);
                    level.setBlock(at.above(), Blocks.IRON_TRAPDOOR.defaultBlockState(), 2);
                }
            }
            case "infected" -> {
                path(level, room, Blocks.SMOOTH_STONE, 2, 15);
                for (int x : new int[]{-3, 3}) for (int z = -14; z <= -9; z++) {
                    var at = ground(level, room.offset(x, 0, z));
                    level.setBlock(at, Blocks.IRON_BARS.defaultBlockState(), 2);
                    level.setBlock(at.above(), Blocks.IRON_BARS.defaultBlockState(), 2);
                }
            }
            case "forest" -> {
                path(level, room, Blocks.COARSE_DIRT, 2, 15);
                for (int x : new int[]{-5, 5}) for (int z = -12; z <= -8; z++) {
                    var at = ground(level, room.offset(x, 0, z));
                    level.setBlock(at, Blocks.SPRUCE_LOG.defaultBlockState(), 2);
                }
            }
            case "ash" -> {
                path(level, room, Blocks.COBBLED_DEEPSLATE, 2, 15);
                for (int x = 2; x <= 6; x++) for (int z = -4; z <= -1; z++)
                    for (int y = -5; y <= -2; y++)
                        level.setBlock(room.offset(x,y,z),
                            (y==-5?Blocks.DEEPSLATE_TILES:Blocks.AIR).defaultBlockState(),2);
                for (int y = -4; y <= 0; y++) {
                    level.setBlock(room.offset(7,y,-2),Blocks.DEEPSLATE_BRICKS.defaultBlockState(),2);
                    level.setBlock(room.offset(6,y,-2),Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.WEST),2);
                }
                level.setBlock(room.offset(3,-4,-3),Blocks.SOUL_LANTERN.defaultBlockState(),2);
            }
        }
    }

    private static void path(ServerLevel level, BlockPos room, Block surface, int width, int end) {
        for (int z = -end; z <= -7; z++) for (int x = -width; x <= width; x++) {
            if (Math.abs(x) <= 1 && z >= -14) continue;
            var at = ground(level, room.offset(x, 0, z)).below();
            level.setBlock(at, surface.defaultBlockState(), 2);
        }
    }

    private static BlockPos ground(ServerLevel level, BlockPos col) {
        int y = Math.min(level.getMaxBuildHeight()-3,level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,col.getX(),col.getZ()));
        return col.atY(y);
    }

    private ThemedApproach() {}
}
