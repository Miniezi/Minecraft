package dev.bunkerrelay.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent;

@EventBusSubscriber(modid="bunkerrelay", value=Dist.CLIENT)
public final class BossModels {
    @SubscribeEvent
    public static void render(RenderLivingEvent.Pre<?, ?> event) {
        var boss=event.getEntity();
        var name=boss.getCustomName();
        if(name==null)return;
        String model=name.getStyle().getInsertion();
        if(model==null||!model.startsWith("bunkerrelay:boss/"))return;

        var mesh=new Mesh(event.getPoseStack(),event.getMultiBufferSource(),event.getPackedLight());
        float partial=event.getPartialTick();
        float walk=boss.walkAnimation.position(partial);
        float stride=Mth.clamp(boss.walkAnimation.speed(partial),0,1);
        float swing=Mth.cos(walk*.66f)*32*stride;
        float attack=boss.getAttackAnim(partial);
        mesh.pose.pushPose();
        mesh.pose.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(partial,boss.yBodyRotO,boss.yBodyRot)));
        switch(model){
            case "bunkerrelay:boss/industrial" -> guardian(mesh,swing);
            case "bunkerrelay:boss/infected" -> echo(mesh,swing,attack);
            case "bunkerrelay:boss/forest" -> ranger(mesh,swing,attack);
            case "bunkerrelay:boss/ash" -> smith(mesh,swing,attack);
            default -> {mesh.pose.popPose();return;}
        }
        mesh.pose.popPose();
        event.setCanceled(true);
    }

    private static void guardian(Mesh m,float swing){
        m.box(Blocks.POLISHED_DEEPSLATE,0,1.35,-.16,1.30,.78,1.45);
        m.box(Blocks.IRON_BLOCK,0,1.53,.48,1.46,.73,.38);
        m.box(Blocks.YELLOW_CONCRETE,0,1.08,.69,1.18,.14,.14);
        m.box(Blocks.CUT_COPPER,0,1.92,.70,.85,.56,.62);
        m.box(Blocks.SEA_LANTERN,0,1.96,1.02,.62,.10,.08);
        for(int side:new int[]{-1,1}){
            m.box(Blocks.IRON_BLOCK,side*.64,1.76,-.30,.34,.41,.90);
            m.leg(Blocks.POLISHED_DEEPSLATE,side*.43,.51,.26,.84,side*swing);
            m.leg(Blocks.POLISHED_DEEPSLATE,side*.43,-.64,.26,.84,-side*swing);
        }
    }

    private static void echo(Mesh m,float swing,float attack){
        humanoid(m,Blocks.SCULK,Blocks.OXIDIZED_COPPER,Blocks.CYAN_CONCRETE,1.95f,swing,attack);
        m.box(Blocks.SLIME_BLOCK,-.35,1.62,-.13,.39,.54,.36);
        m.box(Blocks.SCULK, .33,1.88,-.09,.30,.36,.31);
        m.box(Blocks.SEA_LANTERN,-.10,1.74,.24,.12,.10,.08);
    }

    private static void ranger(Mesh m,float swing,float attack){
        humanoid(m,Blocks.DARK_OAK_PLANKS,Blocks.GREEN_CONCRETE,Blocks.MOSS_BLOCK,1.92f,swing,attack);
        m.box(Blocks.DARK_OAK_PLANKS,0,1.81,.01,.68,.09,.56);
        m.box(Blocks.MOSS_BLOCK,-.33,1.59,-.05,.27,.24,.43);
        m.box(Blocks.BLACK_CONCRETE,0,1.34,-.24,.64,.62,.20);
        m.tool(Blocks.DARK_OAK_PLANKS,Blocks.IRON_BLOCK,swing,attack);
    }

    private static void smith(Mesh m,float swing,float attack){
        humanoid(m,Blocks.POLISHED_BLACKSTONE,Blocks.DEEPSLATE_BRICKS,Blocks.BLACK_CONCRETE,2.32f,swing,attack);
        m.box(Blocks.MAGMA_BLOCK,0,1.54,.21,.39,.37,.09);
        m.box(Blocks.MAGMA_BLOCK,0,2.08,.24,.30,.09,.10);
        m.box(Blocks.CUT_COPPER,0,1.12,0,.65,.14,.46);
        m.tool(Blocks.POLISHED_BLACKSTONE,Blocks.MAGMA_BLOCK,swing,attack);
    }

    private static void humanoid(Mesh m,Block armor,Block cloth,Block helmet,float height,float swing,float attack){
        float shoulder=height-.57f;
        m.box(armor,0,shoulder-.23,0,.62,.63,.39);
        m.box(helmet,0,height-.23,0,.46,.45,.45);
        for(int side:new int[]{-1,1}){
            m.leg(cloth,side*.17,0,.24,shoulder-.5,side*swing);
            m.pose.pushPose();
            m.pose.translate(side*.43,shoulder,0);
            m.pose.mulPose(Axis.XP.rotationDegrees(-side*swing+(side==1?attack*80:0)));
            m.box(armor,0,-.32,0,.24,.75,.27);
            m.box(cloth,0,-.07,0,.32,.23,.34);
            m.pose.popPose();
        }
    }

    private record Mesh(PoseStack pose, MultiBufferSource buffers, int light) {
        void box(Block block,double x,double y,double z,double width,double height,double depth){
            pose.pushPose();
            pose.translate(x-width/2,y-height/2,z-depth/2);
            pose.scale((float)width,(float)height,(float)depth);
            Minecraft.getInstance().getBlockRenderer().renderSingleBlock(block.defaultBlockState(),pose,buffers,light,OverlayTexture.NO_OVERLAY);
            pose.popPose();
        }

        void leg(Block block,double x,double z,double width,double height,float angle){
            pose.pushPose();
            pose.translate(x,height,z);
            pose.mulPose(Axis.XP.rotationDegrees(angle));
            box(block,0,-height/2,0,width,height,width);
            box(block,0,-height+.10,.06,width+.06,.20,width+.17);
            pose.popPose();
        }

        void tool(Block handle,Block head,float swing,float attack){
            pose.pushPose();
            pose.translate(.43,head==Blocks.MAGMA_BLOCK?1.75:1.35,0);
            pose.mulPose(Axis.XP.rotationDegrees(-swing+attack*80));
            box(handle,0,-.67,.16,.09,.61,.09);
            box(head,0,-.88,.26,.22,.23,.36);
            pose.popPose();
        }
    }

    private BossModels(){}
}
