package dev.bunkerrelay;
import net.minecraft.core.*;
import net.minecraft.server.level.ServerLevel;
/** Prepare only the 5x5 arrival chunks, then let vanilla generate on exploration. */
public final class ExpeditionBuilder {
 private final ServerLevel level;private final RelayState state;private int chunk;
 public ExpeditionBuilder(ServerLevel l,RelayState s){level=l;state=s;}
 public int percent(){return Math.min(99,chunk*100/(state.generating?33+ZoneLandmarks.COUNT:33));}
 public boolean tick(){
  if(chunk==0&&state.generating)ExpeditionGrid.plan(level,state);
  if(chunk<25){level.getChunk((state.centerX>>4)+chunk%5-2,(state.centerZ>>4)+chunk/5-2);chunk++;return false;}
  if(chunk<28){FieldRoutes.build(level,state,chunk-25);chunk++;return false;}
  if(chunk<32){
   int index=chunk-28;
   RaidDirector.prepare(level,state,index);

   chunk++;return false;
  }
  if(chunk==32){RaidBosses.prepare(level,state);chunk++;return false;}
  if(state.generating&&chunk<33+ZoneLandmarks.COUNT){
   ZoneLandmarks.build(level,state,chunk-33);
   chunk++;
   return false;
  }
  int y=StructureLevels.floor(level,state,"entry",state.centerX,state.centerZ,5,5,8);state.spawnY=y;
  FieldArchitecture.extraction(level,new BlockPos(state.centerX,y,state.centerZ),false);
  var arrival=new BlockPos(state.centerX,y,state.centerZ+10);
  SurfacePlacement.grade(level,arrival.getX(),arrival.getZ(),2,4,y);
  for(int dx=-2;dx<=2;dx++)for(int dz=-4;dz<=4;dz++){
   var tile=arrival.offset(dx,-1,dz);
   level.setBlock(tile,(Math.abs(dx)==2?net.minecraft.world.level.block.Blocks.SMOOTH_STONE:
       net.minecraft.world.level.block.Blocks.ANDESITE).defaultBlockState(),2);
  }
  for(int side:new int[]{-2,2}){
   var post=arrival.offset(side,0,2);
   level.setBlock(post,net.minecraft.world.level.block.Blocks.STRIPPED_SPRUCE_LOG.defaultBlockState(),2);
   level.setBlock(post.above(),net.minecraft.world.level.block.Blocks.LANTERN.defaultBlockState(),2);
  }
  SurfacePlacement.approach(level,arrival.south(5),Direction.SOUTH);
  state.structureLevels.putBoolean("arrivalPath/"+level.dimension().location(),true);
  var radio=ExpeditionLayout.radio(state);
  state.relayX=radio.getX();state.relayZ=radio.getZ();
  state.relayY=StructureLevels.floor(level,state,"radio",state.relayX,state.relayZ,3,3,8);
  FieldArchitecture.radio(level,new BlockPos(state.relayX,state.relayY,state.relayZ));
  for(int i=0;i<EncounterPressure.of(state).waveSize+1;i++){
   var mob=SporeEncounters.create(level,state,i);
   if(mob!=null){mob.moveTo(state.relayX-2+(i%3)*2,state.relayY,state.relayZ-2+(i/3)*4,0,0);mob.getPersistentData().putInt("relay_structure_generation",state.generation+1);mob.setPersistenceRequired();level.addFreshEntity(mob);}
  }
  RaidMission.prepare(level,state);
  CargoContract.prepare(level,state);
  state.relayPowered=false;state.raidRulesVersion=3;
  level.setWeatherParameters(0,24000,state.activeDifficulty>=3,state.activeDifficulty>=5);state.setDirty();return true;
 }
}
