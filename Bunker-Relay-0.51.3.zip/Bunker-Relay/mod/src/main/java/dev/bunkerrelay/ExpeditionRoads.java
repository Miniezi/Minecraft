package dev.bunkerrelay;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;

final class ExpeditionRoads {
    private record Link(BlockPos owner,BlockPos start,BlockPos junction,String label){
        boolean covers(int x,int z,int margin){
            return x>=Math.min(start.getX(),junction.getX())-margin&&x<=Math.max(start.getX(),junction.getX())+margin
                &&z>=Math.min(start.getZ(),junction.getZ())-margin&&z<=Math.max(start.getZ(),junction.getZ())+margin;
        }
    }

    static void visit(ServerPlayer player,RelayState state){
        if(state.layoutVersion!=3||!state.ready||state.generating)return;
        var level=player.serverLevel();
        var center=player.chunkPosition();
        var links=links(state,RaidDirector.get(player.server));
        Block surface=switch(state.activeTheme){
            case "forest" -> Blocks.DIRT_PATH;
            case "ash" -> Blocks.COBBLED_DEEPSLATE;
            default -> Blocks.ANDESITE;
        };
        for(var link:links){
            int x=(link.start.getX()+link.junction.getX())/2,z=(link.start.getZ()+link.junction.getZ())/2;
            if(Math.hypot(player.getX()-x,player.getZ()-z)>28)continue;
            String key="survey/"+state.generation+"/"+link.owner.asLong();
            long now=level.getGameTime();
            if(state.fieldRoutes.getLong(key)>now)continue;
            boolean marked=TrailSurvey.markDetour(level,state,link.start,link.junction,link.owner,surface);
            state.fieldRoutes.putLong(key,marked?Long.MAX_VALUE:now+200);
            state.setDirty();
        }
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
            int cx=center.x+dx,cz=center.z+dz;
            if(!level.hasChunk(cx,cz))continue;
            int startX=cx<<4,startZ=cz<<4;
            var local=links.stream().filter(link->link.covers(startX+8,startZ+8,20)).toList();
            if(local.isEmpty()&&!crosses(startX-state.centerX)&&!crosses(startZ-state.centerZ))continue;
            String key="routes37/"+level.dimension().location()+"/"+state.centerX+"/"+state.centerZ+"/"+ChunkPos.asLong(cx,cz)+(local.isEmpty()?"":"/"+state.generation);
            if(state.roadChunks.contains(key))continue;
            for(int x=startX;x<startX+16;x++)for(int z=startZ;z<startZ+16;z++){
                Link branch=null;
                for(var link:local)if(link.covers(x,z,1)){branch=link;break;}
                boolean northSouth=road(x-state.centerX);
                if(branch==null&&!northSouth&&!road(z-state.centerZ))continue;
                if(!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,x,z))continue;
                int y=level.getHeight(Heightmap.Types.WORLD_SURFACE,x,z)-1;
                var at=new BlockPos(x,y,z);
                if(StructureLevels.overlapsHistorical(level,state,at,0,branch==null?null:branch.owner))continue;
                if(!level.isEmptyBlock(at.above()))continue;
                if(level.getFluidState(at).is(net.minecraft.tags.FluidTags.WATER)){
                    Direction axis=branch==null?(northSouth?Direction.NORTH:Direction.WEST)
                        :(branch.start.getX()==branch.junction.getX()?Direction.NORTH:Direction.WEST);
                    if(shortWater(level,at,axis)&&shortWater(level,at,axis.getOpposite()))
                        level.setBlock(at,Blocks.SPRUCE_PLANKS.defaultBlockState(),2);
                    continue;
                }
                var ground=level.getBlockState(at);
                if(!ground.is(Blocks.GRASS_BLOCK)&&!ground.is(Blocks.DIRT)&&!ground.is(Blocks.COARSE_DIRT)
                    &&!ground.is(Blocks.PODZOL)&&!ground.is(Blocks.SAND)&&!ground.is(Blocks.GRAVEL)&&!ground.is(Blocks.STONE))continue;
                level.setBlock(at,surface.defaultBlockState(),2);
            }
            for(var link:local)sign(level,cx,cz,link);
            state.roadChunks.putBoolean(key,true);
            state.setDirty();
        }
    }

    private static List<Link> links(RelayState state,RaidDirector director){
        var out=new ArrayList<Link>();
        var exit=new BlockPos(state.centerX,state.spawnY,state.centerZ);
        out.add(new Link(exit,exit.south(7),exit.south(ExpeditionGrid.HALF),"Главный выход"));
        for(var room:director.rooms){
            if(!room.getString("type").equals("landmark")||!room.contains("approach"))continue;
            var center=room.contains("origin")?BlockPos.of(room.getLong("origin")):new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z")-4);
            var start=BlockPos.of(room.getLong("approach"));
            int dx=Integer.compare(start.getX(),center.getX()),dz=Integer.compare(start.getZ(),center.getZ());
            var junction=center.offset(dx*ExpeditionGrid.HALF,0,dz*ExpeditionGrid.HALF);
            out.add(new Link(center,start,junction,room.getString("title")));
        }
        return out;
    }

    private static boolean shortWater(ServerLevel level,BlockPos at,Direction direction){
        for(int step=1;step<=6;step++){
            var point=at.relative(direction,step);
            if(!level.hasChunkAt(point))return false;
            if(level.getFluidState(point).is(net.minecraft.tags.FluidTags.WATER))continue;
            var ground=level.getBlockState(point);
            return ground.isSolidRender(level,point)&&level.isEmptyBlock(point.above());
        }
        return false;
    }

    private static void sign(ServerLevel level,int cx,int cz,Link link){
        var at=link.junction.offset(3,0,3);
        if((at.getX()>>4)!=cx||(at.getZ()>>4)!=cz)return;
        at=at.atY(level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,at.getX(),at.getZ()));
        if(!level.isEmptyBlock(at)||!level.getBlockState(at.below()).isSolidRender(level,at.below()))return;
        level.setBlock(at,Blocks.SPRUCE_SIGN.defaultBlockState(),3);
        if(level.getBlockEntity(at) instanceof SignBlockEntity sign){
            String[] words=link.label.split(" ",3);
            var text=sign.getFrontText().setMessage(0,Component.literal("МАРШРУТ"));
            for(int line=0;line<words.length;line++)text=text.setMessage(line+1,Component.literal(words[line]));
            String direction=RaidHud.direction(at,link.owner);
            if(words.length<3)text=text.setMessage(3,Component.literal(direction));
            sign.setText(text,true);
            sign.setText(text,false);
            sign.setWaxed(true);
            sign.setChanged();
        }
    }

    static boolean road(int offset){
        return Math.abs(Math.floorMod(offset,ExpeditionGrid.SIDE)-ExpeditionGrid.HALF)<=2;
    }

    private static boolean crosses(int start){
        for(int i=0;i<16;i++)if(road(start+i))return true;
        return false;
    }

    private ExpeditionRoads(){}
}
