package dev.bunkerrelay.mixin;

import dev.bunkerrelay.BunkerRelay;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlacedFeature.class)
abstract class ExpeditionDecoration {
    @Inject(method="placeWithBiomeCheck",at=@At("HEAD"),cancellable=true)
    private void skipStructureFeatures(WorldGenLevel world,ChunkGenerator generator,RandomSource random,
        BlockPos origin,CallbackInfoReturnable<Boolean> result){
        if(!BunkerRelay.expedition(world.getLevel()))return;
        var feature=((PlacedFeature)(Object)this).feature().value().feature();
        if(feature==Feature.MONSTER_ROOM||feature==Feature.FOSSIL||feature==Feature.DESERT_WELL)
            result.setReturnValue(false);
    }
}
