package dev.bunkerrelay;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;

final class MeetingSignals {
    private static final int LIFETIME=900;
    private record Inbox(Signal latest,Signal genuine){}
    private static final Map<UUID,Inbox> inbox=new HashMap<>();
    private static final Map<UUID,Long> lastShare=new HashMap<>();

    record Signal(UUID id,UUID recipientRaid,String sender,BlockPos position,int code,long expires,boolean decoy){
        String caption(){
            return sender+" · код "+digits(code)+" · "+position.toShortString();
        }
    }

    static void share(ServerPlayer sender){
        var state=RelayState.get(sender.server);
        var raid=transaction(sender,state);
        if(raid==null)return;
        long now=sender.server.overworld().getGameTime();
        if(now<lastShare.getOrDefault(sender.getUUID(),0L)){
            RaidRules.tell(sender,"Повторить сигнал можно через 5 секунд.");
            return;
        }
        if(!share(sender,state,sender.serverLevel().players())){
            RaidRules.tell(sender,"В зоне нет напарников для передачи точки встречи.");
            return;
        }
        lastShare.put(sender.getUUID(),now+100);
        RaidRules.tell(sender,"Точка встречи передана группе. Ваш код · "+digits(code(raid)));
    }

    static boolean share(ServerPlayer sender,RelayState state,List<ServerPlayer> team){
        var raid=transaction(sender,state);
        if(raid==null)return false;
        boolean delivered=false;
        for(var recipient:team)if(recipient!=sender)
            delivered|=deliver(state,recipient,sender,sender.blockPosition(),code(raid),false);
        return delivered;
    }

    static void imitate(ServerPlayer recipient,ServerPlayer original,RelayState state,BlockPos position){
        if(recipient==original||!RaidHorror.enabled(recipient))return;
        var raid=transaction(original,state);
        if(raid!=null)deliver(state,recipient,original,position,(code(raid)+1+recipient.getRandom().nextInt(9999))%10000,true);
    }

    private static boolean deliver(RelayState state,ServerPlayer recipient,ServerPlayer sender,BlockPos position,int code,boolean decoy){
        var raid=transaction(recipient,state);
        if(raid==null)return false;
        var signal=new Signal(UUID.randomUUID(),raid,sender.getScoreboardName(),position,code,
            recipient.server.overworld().getGameTime()+LIFETIME,decoy);
        var previous=inbox.get(recipient.getUUID());
        inbox.put(recipient.getUUID(),new Inbox(signal,decoy?(previous==null?null:previous.genuine):signal));
        if(recipient.containerMenu instanceof PocketDevice.Menu menu)menu.updateMeeting();
        RaidRules.chat(recipient,"Точка встречи · "+signal.caption()+" · 45 с · КПК → Навигация");
        return true;
    }

    static String ownCode(ServerPlayer player,RelayState state){
        var raid=transaction(player,state);
        return raid==null?"Код выдаётся на вылазке":digits(code(raid));
    }

    static Signal current(ServerPlayer player,RelayState state){
        var messages=inbox.get(player.getUUID());
        if(messages==null)return null;
        var raid=transaction(player,state);
        long now=player.server.overworld().getGameTime();
        if(valid(messages.latest,raid,now)&&(!messages.latest.decoy||RaidHorror.enabled(player)))
            return messages.latest;
        if(valid(messages.genuine,raid,now)){
            inbox.put(player.getUUID(),new Inbox(messages.genuine,messages.genuine));
            return messages.genuine;
        }
        inbox.remove(player.getUUID());
        return null;
    }

    private static boolean valid(Signal signal,UUID raid,long now){
        return signal!=null&&signal.recipientRaid.equals(raid)&&signal.expires>now;
    }

    static void follow(ServerPlayer player){
        var signal=current(player,RelayState.get(player.server));
        if(signal==null){
            RaidRules.tell(player,"Нет активной точки встречи.");
            return;
        }
        player.getPersistentData().putUUID("relay_meeting_signal",signal.id);
        Navigation.route(player,"meeting");
    }

    static Signal tracked(ServerPlayer player,RelayState state){
        var signal=current(player,state);
        var data=player.getPersistentData();
        return signal!=null&&data.hasUUID("relay_meeting_signal")&&signal.id.equals(data.getUUID("relay_meeting_signal"))
            ?signal:null;
    }

    static void clear(ServerPlayer player){
        inbox.remove(player.getUUID());
        lastShare.remove(player.getUUID());
    }

    static void reset(){
        inbox.clear();
        lastShare.clear();
    }

    private static UUID transaction(ServerPlayer player,RelayState state){
        if(!state.ready||state.generating||!player.isAlive()||player.isSpectator()
            ||!player.level().dimension().equals(BunkerRelay.key(state.activeDimension)))return null;
        var raid=RaidRules.record(player);
        return raid!=null&&raid.getString("status").equals("ACTIVE")
            &&raid.getInt("generation")==state.generation&&raid.hasUUID("transaction")?raid.getUUID("transaction"):null;
    }

    private static int code(UUID raid){return Math.floorMod(raid.hashCode(),10000);}
    private static String digits(int code){return String.format(Locale.ROOT,"%04d",code);}
    private MeetingSignals(){}
}
