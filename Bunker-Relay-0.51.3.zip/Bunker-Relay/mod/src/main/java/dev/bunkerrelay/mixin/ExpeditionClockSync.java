package dev.bunkerrelay.mixin;

import dev.bunkerrelay.ExpeditionLight;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftServer.class)
abstract class ExpeditionClockSync {
    @Inject(method="synchronizeTime",at=@At("HEAD"),cancellable=true)
    private void bunkerrelay$syncFixedSky(ServerLevel level,CallbackInfo callback){
        if(!ExpeditionLight.fixed(level))return;
        var packet=new ClientboundSetTimePacket(level.getGameTime(),ExpeditionLight.time(level),false);
        for(var player:level.players())player.connection.send(packet);
        callback.cancel();
    }
}
