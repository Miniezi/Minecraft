package dev.bunkerrelay;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Pose;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

final class DownedPlayers {
    private static final String UNTIL="downedUntil";
    private static final String RESCUE="relay_rescue";
    private static final int WINDOW=500, TREATMENT=80;

    static void register(){
        NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent event)->{
            if(event.getEntity() instanceof ServerPlayer player)player.getPersistentData().remove(RESCUE);
        });
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGH,DownedPlayers::death);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGH,DownedPlayers::damage);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,DownedPlayers::interact);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,(PlayerInteractEvent.RightClickBlock event)->{
            if(event.getEntity() instanceof ServerPlayer player&&down(player))event.setCanceled(true);
        });
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,(PlayerInteractEvent.RightClickItem event)->{
            if(event.getEntity() instanceof ServerPlayer player&&down(player))event.setCanceled(true);
        });
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,(PlayerInteractEvent.LeftClickBlock event)->{
            if(event.getEntity() instanceof ServerPlayer player&&down(player))event.setCanceled(true);
        });
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,(AttackEntityEvent event)->{
            if(event.getEntity() instanceof ServerPlayer player&&down(player))event.setCanceled(true);
        });
    }

    static boolean active(ServerPlayer player,RelayState state){
        var raid=RaidRules.record(player);
        return raid!=null&&raid.getString("status").equals("ACTIVE")&&raid.getInt("generation")==state.generation
            &&state.ready&&!state.generating&&!player.isSpectator()
            &&player.level().dimension().equals(BunkerRelay.key(state.activeDimension));
    }

    static boolean down(ServerPlayer player){
        var raid=RaidRules.record(player);
        return raid!=null&&raid.contains(UNTIL);
    }

    private static void death(LivingDeathEvent event){
        if(!(event.getEntity() instanceof ServerPlayer player)||event.getSource().is(DamageTypes.GENERIC_KILL)
            ||event.getSource().is(DamageTypes.FELL_OUT_OF_WORLD)||down(player))return;
        var state=RelayState.get(player.server);
        if(!active(player,state))return;
        var teammate=player.serverLevel().players().stream().anyMatch(other->other!=player&&other.isAlive()
            &&active(other,state)&&!down(other)&&other.distanceToSqr(player)<=48*48);
        if(!teammate)return;
        event.setCanceled(true);
        start(player,state);
    }

    static void start(ServerPlayer player,RelayState state){
        var raid=RaidRules.record(player);
        int wounds=raid.getInt("wounds")+1;
        int window=Math.max(300,WINDOW-100*Math.min(2,wounds-1));
        raid.putInt("wounds",wounds);
        raid.remove("stabilized");
        raid.putLong(UNTIL,player.level().getGameTime()+window);
        player.setHealth(1);
        player.closeContainer();
        player.stopUsingItem();
        player.stopRiding();
        player.setForcedPose(Pose.SWIMMING);
        CargoContract.drop(player,state);
        RaidJournal.get(player.server).flush(player.server);
        for(var teammate:player.serverLevel().players())
            if(active(teammate,state)&&teammate.distanceToSqr(player)<=48*48)
                RaidRules.chat(teammate,player.getScoreboardName()+" ранен · "+window/20+" сек. · присядьте и нажмите ПКМ с бинтом или аптечкой.");
    }

    private static void damage(LivingIncomingDamageEvent event){
        if(!(event.getEntity() instanceof ServerPlayer player))return;
        player.getPersistentData().remove(RESCUE);
        if(down(player)&&!event.getSource().is(DamageTypes.GENERIC_KILL)
            &&!event.getSource().is(DamageTypes.FELL_OUT_OF_WORLD))event.setCanceled(true);
    }

    private static void interact(PlayerInteractEvent.EntityInteract event){
        if(!(event.getEntity() instanceof ServerPlayer medic))return;
        if(down(medic)){event.setCanceled(true);return;}
        if(event.getHand()!=InteractionHand.MAIN_HAND||!(event.getTarget() instanceof ServerPlayer patient)
            ||!down(patient)||!medic.isShiftKeyDown())return;
        if(!prepare(medic,patient,RelayState.get(medic.server)))return;
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    static boolean prepare(ServerPlayer medic,ServerPlayer patient,RelayState state){
        if(medic==patient||!canTreat(medic,patient,state))return false;
        var data=medic.getPersistentData();
        if(data.getCompound(RESCUE).hasUUID("target"))return true;
        boolean bandage=medic.getMainHandItem().is(Medicine.BANDAGE.get());
        if(bandage&&RaidRules.record(patient).getBoolean("stabilized")){
            RaidRules.tell(medic,"Кровотечение остановлено. Теперь нужна аптечка.");
            return false;
        }
        var attempt=new CompoundTag();
        attempt.putBoolean("bandage",bandage);
        attempt.putUUID("target",patient.getUUID());
        attempt.putLong("end",medic.level().getGameTime()+(bandage?(SkillMenu.has(medic,SkillMenu.Skill.ORDERLY)?20:40):TREATMENT));
        attempt.putDouble("x",medic.getX());attempt.putDouble("y",medic.getY());attempt.putDouble("z",medic.getZ());
        data.put(RESCUE,attempt);
        RaidRules.tell(medic,bandage?"Начата перевязка.":"Подъём · 4 секунды.");
        return true;
    }

    private static boolean canTreat(ServerPlayer medic,ServerPlayer patient,RelayState state){
        return active(medic,state)&&active(patient,state)&&medic.isAlive()&&patient.isAlive()
            &&!down(medic)&&down(patient)&&medic.level()==patient.level()&&medic.distanceToSqr(patient)<=16
            &&(medic.getMainHandItem().is(Medicine.MEDKIT.get())||medic.getMainHandItem().is(Medicine.BANDAGE.get()))&&medic.hasLineOfSight(patient);
    }

    static boolean finish(ServerPlayer medic,ServerPlayer patient,RelayState state,long now){
        var data=medic.getPersistentData();
        var attempt=data.getCompound(RESCUE);
        if(!attempt.hasUUID("target"))return false;
        boolean bandage=attempt.getBoolean("bandage");
        if(!attempt.getUUID("target").equals(patient.getUUID())||!canTreat(medic,patient,state)
            ||bandage!=medic.getMainHandItem().is(Medicine.BANDAGE.get())
            ||now>=RaidRules.record(patient).getLong(UNTIL)
            ||(bandage&&RaidRules.record(patient).getBoolean("stabilized"))||medic.distanceToSqr(attempt.getDouble("x"),attempt.getDouble("y"),attempt.getDouble("z"))>.85*.85){
            data.remove(RESCUE);
            RaidRules.tell(medic,"Оказание помощи прервано.");
            return false;
        }
        if(now<attempt.getLong("end")){
            if(now%20==0)RaidHud.alert(medic,(bandage?"Перевязка":"Подъём")+" · "+((attempt.getLong("end")-now+19)/20)+" сек.");
            return false;
        }
        data.remove(RESCUE);
        medic.getMainHandItem().shrink(1);
        var medicRaid=RaidRules.record(medic);
        String counter=bandage?"bandages":"rescues";
        medicRaid.putInt(counter,medicRaid.getInt(counter)+1);
        if(bandage){
            var raid=RaidRules.record(patient);
            raid.putBoolean("stabilized",true);
            raid.putLong(UNTIL,raid.getLong(UNTIL)+300);
            RaidJournal.get(medic.server).flush(medic.server);
            RelayEconomy.save(medic);
            RaidRules.tell(patient,"Кровотечение остановлено · ещё 15 секунд на помощь.");
            return true;
        }
        clear(patient);
        patient.setHealth(Math.min(SkillMenu.has(medic,SkillMenu.Skill.PARAMEDIC)?12:8,patient.getMaxHealth()));
        RaidJournal.get(medic.server).flush(medic.server);
        RelayEconomy.save(medic);
        RaidRules.tell(patient,"Напарник поднял вас.");
        return true;
    }

    static void tick(ServerPlayer player,RelayState state){
        long now=player.level().getGameTime();
        if(down(player)){
            if(!active(player,state)){clear(player);return;}
            if(now>=RaidRules.record(player).getLong(UNTIL)){
                clear(player);
                player.hurt(player.damageSources().genericKill(),Float.MAX_VALUE);
                return;
            }
            if(now%20==0)RaidHud.alert(player,"До гибели · "+((RaidRules.record(player).getLong(UNTIL)-now+19)/20)+" сек.");
            player.setForcedPose(Pose.SWIMMING);
        }
        var attempt=player.getPersistentData().getCompound(RESCUE);
        if(!attempt.hasUUID("target"))return;
        var patient=player.server.getPlayerList().getPlayer(attempt.getUUID("target"));
        if(patient==null)player.getPersistentData().remove(RESCUE);
        else finish(player,patient,state,now);
    }

    static void clear(ServerPlayer player){
        var raid=RaidRules.record(player);
        if(raid!=null&&raid.contains(UNTIL)){
            raid.remove(UNTIL);
            player.setForcedPose(null);
            RaidJournal.get(player.server).setDirty();
        }
        player.getPersistentData().remove(RESCUE);
    }

    private DownedPlayers(){}
}
