package dev.bunkerrelay.mixin;

import dev.bunkerrelay.CityParcels;
import mcjty.lostcities.worldgen.LostCityTerrainFeature;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.chunk.ChunkAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=LostCityTerrainFeature.class,remap=false)
abstract class LostCityTerrainParcels {
    @Inject(method="generate",at=@At("HEAD"),cancellable=true)
    private void bunkerrelay$protectCorridors(WorldGenRegion region,ChunkAccess chunk,CallbackInfo callback){
        var pos=chunk.getPos();
        if(CityParcels.reserved(region.getLevel().dimension(),pos.x,pos.z))callback.cancel();
    }
}
