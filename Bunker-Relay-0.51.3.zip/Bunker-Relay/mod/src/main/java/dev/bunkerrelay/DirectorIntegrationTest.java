package dev.bunkerrelay;
import java.util.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.common.util.FakePlayer;
public final class DirectorIntegrationTest {
 private static void check(boolean b,String m){if(!b)throw new IllegalStateException("DIRECTOR TEST: "+m);}
 public static void run(MinecraftServer server){
  var s=RelayState.get(server);var d=RaidDirector.get(server);var level=server.getLevel(BunkerRelay.key(s.activeDimension));
  check(d.rooms.size()==4,"four fixed story buildings");var room=d.rooms.getFirst();var at=new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z"));
  check(level.getBlockState(at.offset(0,0,-6)).isAir(),"open entry not blocked by raid use restrictions");
  check(level.getBlockEntity(at.offset(0,0,4)) instanceof ChestBlockEntity,"story chest");
  var p=new FakePlayer(level,new GameProfile(UUID.fromString("54d56635-38d0-485f-aa0a-a9acd834e803"),"DirectorTest"));p.moveTo(at.getX(),at.getY(),at.getZ());p.getPersistentData().putBoolean("relay_quiet",true);
  d.rooms(p,s);check(room.getBoolean("warned")&&!room.getBoolean("fired"),"trap warning grace period");d.elapsed+=3;d.rooms(p,s);check(room.getBoolean("fired"),"trap fires once");
  var rewardPos=at.offset(0,0,4);
  check(level.getBlockEntity(rewardPos) instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity,"personal story cache");
  var chest=(noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity)level.getBlockEntity(rewardPos);
  var template=chest.getInfoReferenceInventory();
  check(!template.get(4).isEmpty(),"trap reward spawned");
  template.set(4,net.minecraft.world.item.ItemStack.EMPTY);
  d.trigger(p,s,room);
  check(level.getBlockEntity(rewardPos)==chest&&chest.getInfoReferenceInventory().get(4).isEmpty(),"one-shot loot cannot be farmed");
  var threat=level.getEntitiesOfClass(Mob.class,new AABB(at).inflate(12),m->m.getTags().contains("relay_threat"));check(room.getInt("spawned")>0,"custom story enemies accepted by level");
  for(var m:threat){check(m.getAttribute(Attributes.MAX_HEALTH).getBaseValue()>=37,"difficulty health");check(SporeEncounters.isSpore(m)&&!m.getPersistentData().contains("relay_expiry"),"spore without expiry timer");m.discard();}
  for(String role:List.of("stalker","screamer","warden")){var m=RaidDirector.spawn(level,s,at.offset(4,0,3),role,p);check(m!=null&&m.getPersistentData().getString("relay_role").equals(role),"spawn role "+role);m.discard();}
  int before=d.rooms.size();d.build(level,s,at.getX(),at.getZ(),"echo");check(d.rooms.size()==before,"fixed structure idempotent");
  // Exercise the actual deterministic exploration path in loaded chunks.
  boolean generated=false;
  for(int gx=1;gx<6&&!generated;gx++){
   int gz=1;long value=RaidDirector.roll(ExpeditionLayout.seed(s),gx,gz);if(Math.floorMod(value,3)==0)continue;
   int x=s.centerX+gx*384+128+(int)Math.floorMod(value,96),z=s.centerZ+gz*384+128+(int)Math.floorMod(value>>>8,96);
   for(int dx:new int[]{-16,0,16})for(int dz:new int[]{-16,0,16})level.getChunk((x+dx)>>4,(z+dz)>>4);
   p.moveTo(x,90,z);d.discover(p,s);generated=d.rooms.size()>before;
  }
  check(generated,"random exploration structure");int count=d.rooms.size();d.discover(p,s);check(d.rooms.size()==count,"random structure not duplicated");
  for(String type:List.of("clinic","archive","watch")){
   var r=d.build(level,s,s.centerX+400,s.centerZ+400+List.of("clinic","archive","watch").indexOf(type)*64,type);
   check(level.getBlockEntity(new BlockPos(r.getInt("x"),r.getInt("y"),r.getInt("z")).offset(0,0,4)) instanceof ChestBlockEntity,"variant "+type);
  }
  // Event time is shared, not multiplied by the player count; all event paths and endings.
  p.moveTo(s.centerX,s.spawnY,s.centerZ);
  d.event="";d.elapsed=d.nextEvent-1;d.advance(level,s,List.of(p));check(!d.event.isEmpty()&&d.warningUntil==d.elapsed+12,"event warning");
  for(String event:List.of("hunt","ash","blackout")){
   d.event=event;d.warningUntil=d.elapsed+1;d.eventUntil=d.elapsed+61;
   p.moveTo(at.getX(),at.getY(),at.getZ()-8);d.advance(level,s,List.of(p));
   d.elapsed=d.eventUntil-1;d.advance(level,s,List.of(p));check(d.event.isEmpty()&&d.nextEvent>d.elapsed,"event ends "+event);
  }
  var saved=d.save(new CompoundTag(),server.registryAccess());var copy=RaidDirector.load(saved,server.registryAccess());check(copy.rooms.size()==d.rooms.size()&&copy.rooms.getFirst().getBoolean("fired")&&copy.elapsed==d.elapsed&&copy.cells.equals(d.cells),"saved data roundtrip");
  d.setDirty();server.overworld().getDataStorage().save();
  System.out.println("RELAY_DIRECTOR_PASS: fixed/random buildings, all variants, three mob roles, trap grace/one-shot loot, three event paths, persisted state");
 }
 public static void reload(MinecraftServer server){var d=RaidDirector.get(server);check(d.rooms.size()>=6&&d.rooms.getFirst().getBoolean("fired")&&!d.cells.isEmpty()&&d.nextEvent>d.elapsed,"director survives actual server restart");System.out.println("RELAY_DIRECTOR_RELOAD_PASS: structures, spent trap, explored cells, event schedule");}
 private DirectorIntegrationTest(){}
}
