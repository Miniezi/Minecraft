package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
public final class Navigation {
 private record Ping(BlockPos pos,int generation,String dimension,long expires){}
 private static Ping ping;private static final Map<UUID,Long> cooldown=new HashMap<>();
 public static void reset(){ping=null;cooldown.clear();MeetingSignals.reset();}
 public static void signal(MinecraftServer server,RelayState s){
  if(s.ready&&s.relayPowered&&s.exitSignalGeneration!=s.generation){s.exitSignalY=s.spawnY;s.exitSignalGeneration=s.generation;s.setDirty();}
  for(var p:server.getPlayerList().getPlayers()){
   boolean visible=s.ready&&RaidRules.active(p)&&!p.getPersistentData().getBoolean("relay_hud_off");
   var exit=new BlockPos(s.centerX,s.spawnY,s.centerZ);
   var tracked=visible?target(p,s):new Target(exit,"");
   net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(p,new ExitSignal(BunkerRelay.key(s.activeDimension).location(),exit,s.ready&&s.relayPowered&&RaidRules.active(p),tracked.label(),tracked.position()));
  }
 }
 public static boolean protectedBlock(RelayState s,BlockPos p){return RaidMission.node(s,p);}
 public static int ping(ServerPlayer p){var s=RelayState.get(p.server);if(!RaidRules.active(p)||!s.ready)return 0;long now=p.server.overworld().getGameTime();if(now<cooldown.getOrDefault(p.getUUID(),0L)){RaidRules.tell(p,"Пинг доступен раз в 5 секунд.");return 0;}var hit=p.pick(64,0,false);BlockPos pos=hit instanceof BlockHitResult b&&hit.getType()==net.minecraft.world.phys.HitResult.Type.BLOCK?b.getBlockPos():p.blockPosition();ping=new Ping(pos,s.generation,s.activeDimension,now+900);cooldown.put(p.getUUID(),now+100);
  for(var other:p.server.getPlayerList().getPlayers())if(RaidRules.active(other)&&other.level().dimension().equals(p.level().dimension()))RaidRules.chat(other,"Метка "+p.getScoreboardName()+": "+pos.toShortString()+" · КПК → метка группы · 45 с");return 1;
 }
 public static int route(ServerPlayer p,String mode){p.getPersistentData().putString("relay_route",mode);return 1;}
 static void waypoint(ServerPlayer player,int generation,BlockPos pos,String title){
  var data=player.getPersistentData();
  data.putInt("relay_waypoint_generation",generation);
  data.putLong("relay_waypoint_pos",pos.asLong());
  data.putString("relay_waypoint_name",title);
  route(player,"waypoint");
 }
 public record Target(BlockPos position,String label){}
 public static String text(ServerPlayer p,RelayState s){var t=target(p,s);return t.label()+" · "+(int)Math.ceil(Math.sqrt(p.blockPosition().distSqr(t.position())))+" м";}
 public static Target target(ServerPlayer p,RelayState s){String route=p.getPersistentData().getString("relay_route");boolean usePing=route.equals("ping")&&ping!=null&&ping.generation==s.generation&&ping.dimension.equals(s.activeDimension)&&ping.expires>p.server.overworld().getGameTime();boolean exit=route.equals("exit")||!route.equals("radio")&&s.relayPowered;
  boolean cargo=route.equals("cargo")&&s.cargoAvailable&&!s.cargoDelivered&&s.cargoCarrier==null;
  var data=p.getPersistentData();
  boolean waypoint=route.equals("waypoint")&&data.getInt("relay_waypoint_generation")==s.generation;
  var meeting=route.equals("meeting")?MeetingSignals.tracked(p,s):null;
  BlockPos target=meeting!=null?meeting.position():waypoint?BlockPos.of(data.getLong("relay_waypoint_pos")):usePing?ping.pos:cargo?BlockPos.of(s.cargoAt):exit?new BlockPos(s.centerX,s.spawnY,s.centerZ):route.equals("radio")?RaidMission.radio(s):RaidMission.target(s);
  return new Target(target,(meeting!=null?"Точка встречи":waypoint?data.getString("relay_waypoint_name"):usePing?"Метка группы":cargo?"Груз":exit?"Выход":route.equals("radio")?"Радиостанция":RaidMission.label(s)));
 }
 private Navigation(){}
}
