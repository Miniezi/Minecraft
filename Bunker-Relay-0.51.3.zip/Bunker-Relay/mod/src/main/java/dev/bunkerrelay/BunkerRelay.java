package dev.bunkerrelay;
import java.util.*;
import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.*;
import net.minecraft.resources.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.level.ExplosionEvent;
import net.neoforged.neoforge.event.server.*;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
@Mod("bunkerrelay")
public final class BunkerRelay {
 public static final ResourceKey<Level> BUNKER=key("bunker"),GARAGE=key("garage"),ZONE=key("expedition"),HUB=key("hub");
 private ExpeditionBuilder builder;private int ticks,smokePhase,progress;private boolean authorisedTravel;
 public static ResourceKey<Level> key(String n){return ResourceKey.create(Registries.DIMENSION,ResourceLocation.fromNamespaceAndPath("bunkerrelay",n));}
 private static BunkerRelay instance;
 public BunkerRelay(net.neoforged.bus.api.IEventBus modBus){
  instance=this;PocketDevice.register();FieldFlashlight.register();RaidHorror.SOUNDS.register(modBus);RelayTerminalBlock.BLOCKS.register(modBus);
  BossTrophies.ITEMS.register("terminal",()->new net.minecraft.world.item.BlockItem(RelayTerminalBlock.TERMINAL.get(),new net.minecraft.world.item.Item.Properties()));
  net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.entity.EntityJoinLevelEvent event)->{
   if(!event.getLevel().isClientSide() && event.getEntity() instanceof com.tacz.guns.entity.EntityKineticBullet bullet
       && bullet.getOwner() instanceof ServerPlayer shooter && StarterKit.marked(shooter.getMainHandItem())
       && shooter.getMainHandItem().getItem() instanceof com.tacz.guns.api.item.IGun)bullet.setShotDamageMultiplier(0.5f);
  });
  TrophyResearch.register();Medicine.register();BossTrophies.ITEMS.register(modBus);RelayMenus.TYPES.register(modBus);StructureLoot.TYPES.register(modBus);modBus.addListener(ExitSignal::register);
  RaidRules.register();DownedPlayers.register();NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.LOWEST,RaidBosses::died);NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.LOWEST,MiniBosses::died);NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.LOWEST,(ServerAboutToStartEvent e)->CityIntegration.profiles());
  NeoForge.EVENT_BUS.addListener(this::clonePlayer);
  NeoForge.EVENT_BUS.addListener(this::commands);NeoForge.EVENT_BUS.addListener(this::started);NeoForge.EVENT_BUS.addListener(this::stopped);NeoForge.EVENT_BUS.addListener(this::tick);
  NeoForge.EVENT_BUS.addListener(this::login);NeoForge.EVENT_BUS.addListener(this::logout);NeoForge.EVENT_BUS.addListener(this::respawn);NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.HIGH,this::interact);
  NeoForge.EVENT_BUS.addListener(this::damage);NeoForge.EVENT_BUS.addListener(this::spawn);NeoForge.EVENT_BUS.addListener(this::explosion);NeoForge.EVENT_BUS.addListener(this::dimensionTravel);NeoForge.EVENT_BUS.addListener(ExpeditionContent::joined);NeoForge.EVENT_BUS.addListener(SporeEncounters::drops);NeoForge.EVENT_BUS.addListener(this::filterHostiles);NeoForge.EVENT_BUS.addListener(this::expeditionPlacement);
 }
 private static final Set<String> ZONES=Set.of("expedition","city","wilds","forest_expedition","infected_city","ashlands");
 public static boolean expedition(Level l){return l.dimension().location().getNamespace().equals("bunkerrelay")&&ZONES.contains(l.dimension().location().getPath());}
 private boolean safe(Level l){return l.dimension().equals(BUNKER)||l.dimension().equals(HUB)||l.dimension().equals(GARAGE);}
 private ResourceKey<Level> home(RelayState s){return s.hubV2?HUB:BUNKER;}
 private BlockPos homePos(RelayState s){return s.hubV2?new BlockPos(0,73,31):new BlockPos(0,31,4);}
 private BlockPos arrival(RelayState s){return extraction(s).south(s.structureLevels.getBoolean("arrivalPath/"+key(s.activeDimension).location())?10:3);}
 private BlockPos extraction(RelayState s){return new BlockPos(s.centerX,s.spawnY,s.centerZ);}
 private void broadcast(MinecraftServer server,String text){for(var p:server.getPlayerList().getPlayers())RaidRules.tell(p,text);System.out.println("[Bunker Relay] "+text);}
 private void borders(MinecraftServer server){
  for(var e:Map.of(BUNKER,97,HUB,256,GARAGE,81).entrySet()){var l=server.getLevel(e.getKey());if(l!=null){l.getWorldBorder().setCenter(0,0);l.getWorldBorder().setSize(e.getValue());}}
  RelayState s=RelayState.get(server);var l=server.getLevel(key(s.activeDimension));if(l!=null){l.getWorldBorder().setCenter(s.centerX,s.centerZ);l.getWorldBorder().setSize(s.activeSize);l.getWorldBorder().setWarningBlocks(24);}
 }
 private void started(ServerStartedEvent e){
  MinecraftServer server=e.getServer();RelayState s=RelayState.get(server);CityIntegration.register(server);
  if(s.ready&&!s.fixedRaidLight){s.fixedRaidLight=true;s.setDirty();}
  boolean testWorkshop=Boolean.getBoolean("bunkerrelay.update16Test");
  if(testWorkshop)server.getLevel(HUB).setBlock(new BlockPos(-18,96,-19),Blocks.DIAMOND_BLOCK.defaultBlockState(),3);
  boolean testUpgrade=Boolean.getBoolean("bunkerrelay.update15UpgradeTest");
  if(testUpgrade)server.getLevel(HUB).setBlock(new BlockPos(52,96,24),Blocks.DIAMOND_BLOCK.defaultBlockState(),3);
  if(s.initialized){borders(server);if(s.hubV2){HubBuilder.upgradeTerminal(server.getLevel(HUB));BunkerAnnex.install(server.getLevel(HUB),s);CourtyardWorkshop.install(server.getLevel(HUB),s);}}
  if(Boolean.getBoolean("bunkerrelay.supplySitesTest")){SupplySitesIntegrationTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.meetingTest")){MeetingIntegrationTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.zone27Test")){Zone27IntegrationTest.start(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.liveRefreshTest")){LiveRefreshTest.start(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.update20Test")){Update20IntegrationTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.update21Test")){Update21IntegrationTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.update22Test")){Update22IntegrationTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.sectorBuildTest")){SectorBuildTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.airdropTest")){AirdropIntegrationTest.run(server,s);return;}
  if(testWorkshop){Update16IntegrationTest.verify(server,s);return;}
  if(testUpgrade){Update15IntegrationTest.upgrade(server,s);return;}
  if(s.initialized&&s.raidRulesVersion<3){s.ready=false;s.setDirty();}
  if(s.generating){if(s.activeDimension.equals("expedition"))ZoneBuilder.forceArea(server.getLevel(ZONE),false);s.generating=false;s.ready=false;s.setDirty();}
  String resetTheme=ExpeditionReset.pending(server);
  if(resetTheme!=null){s.theme=resetTheme;begin(server,s,true);return;}
  if(Boolean.getBoolean("bunkerrelay.update14Test")){Update14IntegrationTest.run(server);return;}
  if(Boolean.getBoolean("bunkerrelay.update13ReloadTest")){Update13IntegrationTest.reload(server);return;}
  if(Boolean.getBoolean("bunkerrelay.update13Test")){Update13IntegrationTest.run(server);return;}
  if(Boolean.getBoolean("bunkerrelay.bossVisualTest")){BossIntegrationTest.run(server,s);return;}
  if(Boolean.getBoolean("bunkerrelay.update12Test")){Update12IntegrationTest.begin(server);return;}
  if(Boolean.getBoolean("bunkerrelay.update11ResetRequest")){Update11IntegrationTest.request(server);return;}
  if(Boolean.getBoolean("bunkerrelay.update10ReloadTest")){Update10IntegrationTest.reload(server);server.halt(false);return;}
  if(Boolean.getBoolean("bunkerrelay.freedomTest")&&!Boolean.getBoolean("bunkerrelay.smokeTest"))freedomSuite(server);
  if(Boolean.getBoolean("bunkerrelay.freedomReloadTest")){SupplyIntegrationTest.reload(server);RaidIntegrationTest.reload(server);FreedomIntegrationTest.reload(server);EconomyIntegrationTest.reload(server);UpgradeIntegrationTest.reload(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.supplyTest")){EconomyIntegrationTest.run(server);SupplyIntegrationTest.run(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.supplyReloadTest")){SupplyIntegrationTest.reload(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.economyTest")){EconomyIntegrationTest.run(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.economyReloadTest")){EconomyIntegrationTest.reload(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.progressionReloadTest")){ProgressionIntegrationTest.reload(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.menuTest")){LootMenuIntegrationTest.run(server);RaidIntegrationTest.run(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.directorReloadTest")){DirectorIntegrationTest.reload(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.raidReloadTest")){RaidIntegrationTest.reload(server);server.halt(false);}
  if(Boolean.getBoolean("bunkerrelay.reloadTest")){
   if(!s.ready||s.generating||s.generation!=2||s.nextSector!=2||!s.hubV2||!s.legacyAvailable||s.activeSize!=8192||!s.activeDimension.equals("forest_expedition"))throw new IllegalStateException("Saved state did not survive reload");
   if(!server.getLevel(HUB).getBlockState(new BlockPos(8,73,25)).is(Blocks.DIAMOND_BLOCK)||!server.getLevel(BUNKER).getBlockState(new BlockPos(10,30,10)).is(Blocks.GOLD_BLOCK)||!server.getLevel(GARAGE).getBlockState(new BlockPos(10,30,10)).is(Blocks.EMERALD_BLOCK))throw new IllegalStateException("Base markers lost on restart");
   if(!server.registryAccess().registryOrThrow(Registries.PAINTING_VARIANT).containsKey(ResourceLocation.parse("tacz:blood_strike_1")))throw new IllegalStateException("Painting fix missing");
   if(!server.getLevel(key(s.activeDimension)).getBlockState(extraction(s)).is(Blocks.LODESTONE))throw new IllegalStateException("Extraction lost on restart");
   System.out.println("RELAY_RELOAD_PASS: state, sector reservation, bases, extraction, painting registry");server.halt(false);
  }
  if(Boolean.getBoolean("bunkerrelay.smokeTest")){
   if(!s.initialized){
    ZoneBuilder.buildBase(server.getLevel(BUNKER),false);ZoneBuilder.buildBase(server.getLevel(GARAGE),true);
    server.getLevel(BUNKER).setBlock(new BlockPos(10,30,10),Blocks.GOLD_BLOCK.defaultBlockState(),3);
    server.getLevel(GARAGE).setBlock(new BlockPos(10,30,10),Blocks.EMERALD_BLOCK.defaultBlockState(),3);
    s.initialized=true;s.setDirty();upgrade(server.createCommandSourceStack());
   }
   if(!s.hubV2||!server.getLevel(BUNKER).getBlockState(new BlockPos(10,30,10)).is(Blocks.GOLD_BLOCK)||!server.getLevel(GARAGE).getBlockState(new BlockPos(10,30,10)).is(Blocks.EMERALD_BLOCK))throw new IllegalStateException("Migration changed legacy bases");
   server.getLevel(HUB).setBlock(new BlockPos(8,73,25),Blocks.DIAMOND_BLOCK.defaultBlockState(),3);
   s.difficulty=3;s.loot=3;s.size=4096;s.theme="industrial";begin(server,s);smokePhase=1;System.out.println("RELAY_MIGRATION_PASS");
  }
 }
 private void freedomSuite(MinecraftServer server){EconomyIntegrationTest.run(server);SupplyIntegrationTest.run(server);RaidIntegrationTest.run(server);FreedomIntegrationTest.run(server);UpgradeIntegrationTest.market(server);UpgradeIntegrationTest.beginWorld(server);}
 private void stopped(ServerStoppedEvent e){RaidRules.resetTimers();RaidBosses.reset();MiniBosses.reset();builder=null;ticks=0;smokePhase=0;}
 private void commands(RegisterCommandsEvent e){
  e.getDispatcher().register(Commands.literal("relay").executes(c->startOrPocket(c.getSource()))
   .then(Commands.literal("bunker").executes(c->travel(c.getSource(),BUNKER)))
   .then(RelayTestCommands.branch()));
 }
 private int fail(CommandSourceStack c,String message){if(c.getEntity() instanceof ServerPlayer p)RaidRules.tell(p,message);else c.sendFailure(Component.literal(message));return 0;}
 private int startOrPocket(CommandSourceStack source)throws CommandSyntaxException{
  var player=source.getPlayerOrException();
  var state=RelayState.get(player.server);
  if(!state.initialized){
   if(!source.hasPermission(2))return fail(source,"Первый запуск выполняет администратор командой /relay.");
   if(init(source)==0)return 0;
   if(travel(source,BUNKER)==0)return 0;
  }else if(player.level().dimension().equals(Level.OVERWORLD)&&!RaidRules.active(player)){
   if(travel(source,BUNKER)==0)return 0;
  }
  PocketDevice.grant(player);
  return PocketDevice.open(player);
 }
 static boolean nearTerminal(ServerPlayer player){
  var state=RelayState.get(player.server);
  var pos=state.hubV2?HubBuilder.TERMINAL:new BlockPos(0,30,0);
  return state.initialized&&!RaidRules.active(player)&&player.isAlive()
   &&player.level().dimension().equals(state.hubV2?HUB:BUNKER)&&player.blockPosition().distSqr(pos)<=64;
 }
 static int openTerminal(ServerPlayer player){
  if(!nearTerminal(player)){RaidRules.tell(player,"Подойдите к терминалу бункера.");return 0;}
  player.openMenu(new net.minecraft.world.SimpleMenuProvider((id,inv,ignored)->new TerminalMenu(id,inv,player),Component.literal("Терминал бункера")));
  return 1;
 }
 static void pocketTravel(ServerPlayer player){instance.menuTravel(player,BUNKER);}
 private void menuTravel(ServerPlayer player,ResourceKey<Level> dimension){
  try{travel(player.createCommandSourceStack(),dimension);}
  catch(CommandSyntaxException error){RaidRules.tell(player,error.getMessage());}
 }
 static void terminalAction(ServerPlayer player,int slot){
  if(!nearTerminal(player))return;
  var state=RelayState.get(player.server);
  var source=player.createCommandSourceStack();
  switch(slot){
    case 0 -> instance.menuTravel(player,BUNKER);
    case 2 -> instance.menuTravel(player,GARAGE);
    case 24 -> instance.menuTravel(player,ZONE);
    case 51 -> {
     if(!state.hubV2||!BunkerAnnex.install(player.serverLevel(),state)){
      RaidRules.tell(player,"Для крыла нет свободной площадки.");return;
     }
     player.closeContainer();
     instance.teleport(player,player.serverLevel(),BunkerAnnex.arrival(state));
    }
    case 25 -> {if(!state.hubV2&&source.hasPermission(2)){if(instance.upgrade(source)==1)instance.menuTravel(player,BUNKER);}else if(state.legacyAvailable)instance.menuTravel(player,key("legacy"));}
    default -> {}
   }
 }
 private int init(CommandSourceStack c){
  MinecraftServer server=c.getServer();RelayState s=RelayState.get(server);if(s.initialized)return fail(c,"База уже создана.");
  var b=server.getLevel(HUB);var g=server.getLevel(GARAGE);if(b==null||g==null)return fail(c,"Измерения отсутствуют: перезапустите сервер с новой версией мода.");
  HubBuilder.build(b);BunkerAnnex.install(b,s);CourtyardWorkshop.install(b,s);ZoneBuilder.buildBase(g,true);s.hubV2=true;s.initialized=true;s.setDirty();borders(server);server.saveEverything(false,true,true);c.sendSuccess(()->Component.literal("Бункер с двором и гараж созданы."),true);return 1;
 }
 private int upgrade(CommandSourceStack c){
  MinecraftServer server=c.getServer();RelayState s=RelayState.get(server);if(!s.initialized)return init(c);if(s.hubV2)return fail(c,"Новый бункер уже создан.");if(s.generating)return fail(c,"Дождитесь завершения генерации.");
  var l=server.getLevel(HUB);if(l==null)return fail(c,"Перезапустите сервер: новое измерение не загружено.");
  HubBuilder.build(l);BunkerAnnex.install(l,s);CourtyardWorkshop.install(l,s);s.hubV2=true;s.legacyAvailable=true;s.setDirty();borders(server);server.saveEverything(false,true,true);c.sendSuccess(()->Component.literal("Новый бункер создан. Старая база доступна через терминал."),true);return 1;
 }
 static boolean launchSelection(ServerPlayer player,ZoneProfile zone,int size,ExpeditionContracts.Type contract){
  if(!nearTerminal(player)||!SectorPlan.validSize(size)||!contract.available(zone))return false;
  var server=player.server;
  var state=RelayState.get(server);
  if(state.generating||server.getPlayerList().getPlayers().stream().anyMatch(p->RaidRules.active(p)||!instance.safe(p.level()))){
   RaidRules.tell(player,"Новая вылазка доступна, когда вся группа на базе.");
   return false;
  }
  var oldTheme=state.theme;
  int oldSize=state.size;
  state.theme=zone.id;state.size=size;
  if(instance.launch(player.createCommandSourceStack(),state)==0){
   state.theme=oldTheme;state.size=oldSize;
   return false;
  }
  state.fieldRoutes.putString("expeditionContract",contract.name());
  state.setDirty();
  return true;
 }
 private int launch(CommandSourceStack c,RelayState s){var server=c.getServer();
  for(String name:ZONES){var l=server.getLevel(key(name));if(l!=null){String blocker=VehicleGuard.resetBlocker(l);if(blocker!=null)return fail(c,blocker);}}
  if(!s.theme.equals("forest")&&!net.neoforged.fml.ModList.get().isLoaded("lostcities"))return fail(c,"Для городских зон нужен Lost Cities; иначе выберите forest.");
  if(s.generating)return fail(c,"Обновление уже идёт.");
  begin(server,s,true);return 1;
 }
 private void begin(MinecraftServer server,RelayState s){begin(server,s,false);}
 private void begin(MinecraftServer server,RelayState s,boolean fixedOrigin){
  RaidRules.closeZone(server);
  var previous=server.getLevel(key(s.activeDimension));
  if(previous!=null){RouteEvents.clear(previous,s);TeamStash.clear(previous);}
  if(previous!=null&&s.ready){StructureLevels.migrate(previous,s);ExpeditionLayout.remember(s);}
  if(previous!=null){
   var oldGuards=new ArrayList<net.minecraft.world.entity.Entity>();
   for(var entity:previous.getAllEntities())if(entity.getPersistentData().contains("relay_structure_generation")||entity.getTags().contains("relay_threat"))oldGuards.add(entity);
   oldGuards.forEach(net.minecraft.world.entity.Entity::discard);
  }
  s.previousBoss=s.bossId;
  if(previous!=null&&s.previousBoss!=null&&previous.getEntity(s.previousBoss)!=null)
   previous.getEntity(s.previousBoss).discard();
  var center=fixedOrigin?new SectorPlan.Center(s.centerX,s.centerZ):SectorPlan.center(s.nextSector);if(fixedOrigin)s.nextSector=Math.max(s.nextSector,1);else s.nextSector++;s.centerX=center.x();s.centerZ=center.z();s.activeSize=s.size;s.activeTheme=s.theme;
  s.activeDimension=ExpeditionReset.dimension(s.theme);
  ExpeditionLight.accept(s);
  s.generating=true;s.ready=false;s.seed=new Random().nextLong();s.activeDifficulty=ZoneProfile.of(s.activeTheme).difficulty(s.seed);s.activeLoot=s.activeDifficulty;s.variableStories=true;s.sectorBuildings=true;s.caches.clear();s.scoutMap=new net.minecraft.nbt.CompoundTag();s.fieldRoutes=new net.minecraft.nbt.CompoundTag();s.setDirty();progress=0;server.saveEverything(false,true,true);borders(server);
  builder=new ExpeditionBuilder(server.getLevel(key(s.activeDimension)),s);broadcast(server,"Обновляем локации "+s.activeSize+"×"+s.activeSize+". Команда может оставаться на базе.");
 }
 private void teleport(ServerPlayer p,ServerLevel l,BlockPos pos){authorisedTravel=true;try{p.stopRiding();p.teleportTo(l,pos.getX()+0.5,pos.getY(),pos.getZ()+0.5,Set.of(),180,0);p.connection.send(new net.minecraft.network.protocol.game.ClientboundInitializeBorderPacket(l.getWorldBorder()));p.fallDistance=0;}finally{authorisedTravel=false;}}
 public static void returnToBunker(ServerPlayer p){
  var s=RelayState.get(p.server);var dimension=s.hubV2?HUB:BUNKER;var pos=s.hubV2?new BlockPos(0,73,31):new BlockPos(0,31,4);
  p.getPersistentData().putBoolean("relay_settling",true);try{p.stopRiding();p.teleportTo(p.server.getLevel(dimension),pos.getX()+0.5,pos.getY(),pos.getZ()+0.5,Set.of(),180,0);p.connection.send(new net.minecraft.network.protocol.game.ClientboundInitializeBorderPacket(p.serverLevel().getWorldBorder()));p.fallDistance=0;}finally{p.getPersistentData().remove("relay_settling");}
 }
 private void sendHome(ServerPlayer p,RelayState s){returnToBunker(p);}
 private int travel(CommandSourceStack c,ResourceKey<Level> destination)throws CommandSyntaxException{
  var p=c.getPlayerOrException();var s=RelayState.get(c.getServer());if(!s.initialized)return fail(c,"Администратор должен выполнить /relay.");
  boolean entering=destination.equals(ZONE);boolean legacy=destination.equals(key("legacy"));
  if(legacy&&!s.legacyAvailable)return fail(c,"В этом мире нет старого бункера.");
  if(destination.equals(BUNKER))destination=home(s);else if(legacy)destination=BUNKER;else if(entering)destination=key(s.activeDimension);
  if(entering&&(!s.ready||s.generating))return fail(c,"Зона ещё не готова.");if(entering&&!safe(p.level()))return fail(c,"Вход доступен из безопасных зон.");
  if(expedition(p.level())&&RaidRules.active(p)){
   var backup=FieldRoutes.point(s,FieldRoutes.EXIT);
   String issue=backup!=null&&p.blockPosition().distSqr(backup)<=144
    ?RaidRules.requestExtraction(p,s,backup):RaidRules.requestExtraction(p,s);
   return issue==null?1:fail(c,issue);
  }
  if(expedition(p.level())&&p.blockPosition().distSqr(extraction(s))>144)return fail(c,"Вернитесь к эвакуации: "+extraction(s).toShortString());
  if(entering&&s.raidRulesVersion<3)return fail(c,"После обновления создайте новую зону через терминал.");
  if(entering){String issue=RaidRules.begin(p,s);if(issue!=null)return fail(c,issue);}
  var target=c.getServer().getLevel(destination);if(target==null)return fail(c,"Измерение отсутствует.");
  var pos=entering?arrival(s):destination.equals(HUB)?new BlockPos(0,73,31):new BlockPos(0,31,4);
  teleport(p,target,pos);p.getPersistentData().putInt("relay_generation",s.generation);if(entering){RaidRules.chat(p,"Выход: "+extraction(s).toShortString()+" · /relay bunker");RaidMission.report(p);}return 1;
 }
 private boolean invalidZone(ServerPlayer p,RelayState s){return !s.ready||s.generating||!p.level().dimension().equals(key(s.activeDimension))||p.getPersistentData().getInt("relay_generation")!=s.generation;}
 private void login(PlayerEvent.PlayerLoggedInEvent e){
  if(!(e.getEntity() instanceof ServerPlayer p))return;var s=RelayState.get(p.server);if(!s.initialized)return;
  if(!p.getPersistentData().getBoolean("relay_joined")||(expedition(p.level())&&invalidZone(p,s))){sendHome(p,s);p.getPersistentData().putBoolean("relay_joined",true);}
  TrashRecovery.login(p);RaidRules.login(p,s);if(!RaidRules.active(p)&&safe(p.level()))PocketDevice.grant(p);
  p.connection.send(new net.minecraft.network.protocol.game.ClientboundInitializeBorderPacket(p.serverLevel().getWorldBorder()));
  RaidRules.tell(p,"КПК · ПКМ в руке или /relay. Терминал установлен в бункере.");
 }

 private void clonePlayer(PlayerEvent.Clone e){if(e.getOriginal() instanceof ServerPlayer original&&e.getEntity() instanceof ServerPlayer copy)PdaProtection.clonePlayer(original,copy);for(String key:new String[]{"relay_reward_receipts","relay_trash_recovery","relay_hud_off",Warehouse.KEY,"relay_pda_issued",RelayEconomy.KEY})if(e.getOriginal().getPersistentData().contains(key))e.getEntity().getPersistentData().put(key,e.getOriginal().getPersistentData().get(key).copy());e.getEntity().getPersistentData().putBoolean("relay_quiet",e.getOriginal().getPersistentData().getBoolean("relay_quiet"));}
 private void logout(PlayerEvent.PlayerLoggedOutEvent e){if(e.getEntity() instanceof ServerPlayer p)RaidRules.logout(p);}
 private void respawn(PlayerEvent.PlayerRespawnEvent e){if(e.getEntity() instanceof ServerPlayer p&&RelayState.get(p.server).initialized){sendHome(p,RelayState.get(p.server));if(RaidRules.active(p))RaidRules.settle(p,false);p.getPersistentData().putBoolean("relay_joined",true);}}
 private void interact(PlayerInteractEvent.RightClickBlock e){
  if(e.getHand()!=InteractionHand.MAIN_HAND||!(e.getEntity() instanceof ServerPlayer player))return;
  var state=RelayState.get(player.server);
  if(!RaidRules.active(player)&&state.annexBuilt&&player.level().dimension().equals(HUB)&&e.getPos().equals(BunkerAnnex.exit(state))){
   teleport(player,player.serverLevel(),homePos(state));e.setCanceled(true);return;
  }
  if(state.annexBuilt&&player.level().dimension().equals(HUB)&&e.getPos().equals(BunkerAnnex.chart(state))){
   ReconChart.open(player);e.setCanceled(true);return;
  }
  if(state.workshopBuilt&&!player.isShiftKeyDown()&&CourtyardWorkshop.nearby(player,state)
    &&e.getPos().equals(CourtyardWorkshop.bench(state))&&e.getLevel().getBlockState(e.getPos()).is(Blocks.SMITHING_TABLE)){
   CourtyardWorkshop.useOrLocate(player);e.setCanceled(true);return;
  }
  if(nearTerminal(player)&&e.getPos().equals(state.hubV2?HubBuilder.TERMINAL:new BlockPos(0,30,0))&&RelayTerminalBlock.isTarget(e.getLevel(),e.getPos())){
   openTerminal(player);e.setCancellationResult(net.minecraft.world.InteractionResult.SUCCESS);e.setCanceled(true);
  }
 }
 private void tick(ServerTickEvent.Post e){
  var server=e.getServer();ticks++;Update12IntegrationTest.tick(server);var s=RelayState.get(server);if(UpgradeIntegrationTest.pending){UpgradeIntegrationTest.tick(server);return;}
  if(builder!=null){try{
   if(builder.tick()){
    server.saveEverything(false,true,true);s.generating=false;s.ready=true;s.generation++;s.setDirty();builder=null;server.saveEverything(false,true,true);ExpeditionReset.complete(server);
    server.getPlayerList().broadcastSystemMessage(Component.literal("[Bunker Relay] ЗОНА СГЕНЕРИРОВАНА! "+s.activeSize+"×"+s.activeSize+". Вход через терминал.").withStyle(st->st.withColor(0x74ff98).withBold(true)),false);
    if(Boolean.getBoolean("bunkerrelay.liveRefreshTest")||Boolean.getBoolean("bunkerrelay.zone27Test"))LiveRefreshTest.verify(server,s);
    if(Boolean.getBoolean("bunkerrelay.update11ResetVerify"))Update11IntegrationTest.verify(server,s);
    System.out.println("RELAY_ZONE_READY "+s.activeDimension+" "+s.activeSize);if(smokePhase>0)smokeCheck(server,s);
   }else if(builder.percent()/25>progress){progress=builder.percent()/25;broadcast(server,"Подготовка входа: "+builder.percent()+"%. Остальной мир генерируется при исследовании.");}
  }catch(Exception error){builder=null;s.generating=false;s.ready=false;s.setDirty();broadcast(server,"Ошибка подготовки зоны. Базы сохранены; подробности в журнале.");error.printStackTrace();if(smokePhase>0)throw new IllegalStateException("Smoke failed",error);}}
  if(ticks%20==0){BasePower.second(server,s);RaidDirector.second(server,s);RaidMission.second(server,s);Navigation.signal(server,s);RaidBosses.second(server,s);MiniBosses.second(server,s);}
  if(ticks%4==0)Airdrop.animate(server,s,ticks%20);
  for(var p:server.getPlayerList().getPlayers()){
   if(ticks%20==0){TrashRecovery.drain(p);RaidHud.pulse(p);CargoContract.signal(p,s);if(p.containerMenu instanceof TerminalMenu menu)menu.refreshPower();}
   DownedPlayers.tick(p,s);
   if(p.tickCount%20==0)PdaProtection.restore(p);
   RaidRules.tick(p,s);
   CargoContract.tick(p,s);
   if(expedition(p.level())){
    if(invalidZone(p,s)){sendHome(p,s);continue;}
    if(!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,p.getX(),p.getZ())){teleport(p,p.serverLevel(),arrival(s));RaidRules.tell(p,"Граница зоны: возвращение к эвакуации.");}
    if(ticks%40==0){ZoneLandmarks.visit(p,s);ExpeditionRoads.visit(p,s);ReconChart.visit(p,s);if(s.sectorBuildings)SectorBuildings.discover(p,s);else ExpeditionContent.nearby(p,s);}
   }
   if(ticks%20==0&&safe(p.level())){p.setRemainingFireTicks(0);p.setAirSupply(p.getMaxAirSupply());p.getFoodData().setFoodLevel(20);if(p.getY()<p.level().getMinBuildHeight()+2)sendHome(p,s);}
  }
 }
 private void smokeCheck(MinecraftServer server,RelayState s){
  var zone=server.getLevel(key(s.activeDimension));String blocker=VehicleGuard.resetBlocker(zone);if(blocker!=null)throw new IllegalStateException(blocker);
  if(!server.getLevel(HUB).getBlockState(new BlockPos(8,73,25)).is(Blocks.DIAMOND_BLOCK))throw new IllegalStateException("Hub changed");
  if(!zone.getBlockState(extraction(s)).is(Blocks.LODESTONE)||zone.getWorldBorder().getSize()!=s.activeSize)throw new IllegalStateException("Extraction/border missing");
  ExpeditionContent.smoke(zone,s);
  if(Boolean.getBoolean("bunkerrelay.update17Test"))Update17IntegrationTest.run(server,s);
  if(Boolean.getBoolean("bunkerrelay.update15Test"))Update15IntegrationTest.verify(server,s);
  if(smokePhase==1){CityIntegration.smoke(zone,s);s.theme="forest";s.size=8192;begin(server,s);smokePhase=2;}
  else{
   int logs=0;
   for(int dx=-24;dx<=24;dx++)for(int dz=-24;dz<=24;dz++){
    int x=s.centerX+dx,z=s.centerZ+dz,top=zone.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE,x,z);
    for(int y=top-14;y<top;y++)if(zone.getBlockState(new BlockPos(x,y,z)).is(net.minecraft.tags.BlockTags.LOGS))logs++;
   }
   if(logs==0)throw new IllegalStateException("Forest trees missing");
   System.out.println("RELAY_FOREST_PASS logs="+logs);if(Boolean.getBoolean("bunkerrelay.directorTest"))DirectorIntegrationTest.run(server);if(Boolean.getBoolean("bunkerrelay.progressionTest")){ProgressionIntegrationTest.run(server);LootMenuIntegrationTest.run(server);}if(Boolean.getBoolean("bunkerrelay.raidTest"))RaidIntegrationTest.run(server);if(Boolean.getBoolean("bunkerrelay.update10Test"))Update10IntegrationTest.run(server);System.out.println("RELAY_SMOKE_PASS: migration, cities, forest, 4096/8192 borders, hub, loot, TaCZ, Create, Sable guard");smokePhase=0;if(Boolean.getBoolean("bunkerrelay.freedomTest"))freedomSuite(server);else server.halt(false);
  }
 }
 private void dimensionTravel(net.neoforged.neoforge.event.entity.EntityTravelToDimensionEvent e){if(!authorisedTravel&&!e.getEntity().getPersistentData().getBoolean("relay_settling")&&expedition(e.getEntity().level())&&e.getEntity() instanceof ServerPlayer p){e.setCanceled(true);RaidRules.tell(p,"Выход из зоны — через эвакуацию: /relay bunker.");}}

 private void filterHostiles(net.neoforged.neoforge.event.entity.EntityJoinLevelEvent e){
  if(!(e.getLevel() instanceof ServerLevel level)||!(e.getEntity() instanceof net.minecraft.world.entity.Mob mob))return;
  boolean spore=SporeEncounters.isSpore(mob);
  if(spore&&hostile(mob)&&expedition(level)&&!e.loadedFromDisk()){
   var state=RelayState.get(level.getServer());
   var data=mob.getPersistentData();
   if(state.ready&&!state.generating&&level.dimension().equals(key(state.activeDimension))
       &&!data.getBoolean("relay_boss")&&!data.contains("relay_miniboss")
       &&!EncounterPressure.of(state).room(level,mob.blockPosition(),false)){
    e.setCanceled(true);return;
   }
  }
  if((safe(level)&&spore)||(!spore&&hostile(mob)&&(expedition(level)||vanilla(mob)))){
   if(expedition(level)){
    var state=RelayState.get(level.getServer());
    if(mob.getUUID().equals(state.bossId)){state.bossId=null;state.setDirty();}
    MiniBosses.replaceLegacy(level,state,mob);
   }
   e.setCanceled(true);
  }
 }
 private static boolean hostile(net.minecraft.world.entity.Mob mob){
  return mob instanceof Enemy||mob.getType().getCategory()==net.minecraft.world.entity.MobCategory.MONSTER;
 }
 private static boolean vanilla(net.minecraft.world.entity.Mob mob){
  return net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).getNamespace().equals("minecraft");
 }
 private void expeditionPlacement(net.neoforged.neoforge.event.level.BlockEvent.EntityPlaceEvent e){
  if(!(e.getLevel() instanceof ServerLevel level)||!expedition(level))return;
  var s=RelayState.get(level.getServer());
  if(!s.ready||!level.dimension().equals(key(s.activeDimension)))return;
  if(e instanceof net.neoforged.neoforge.event.level.BlockEvent.EntityMultiPlaceEvent multi){
   if(multi.getReplacedBlockSnapshots().stream().anyMatch(snapshot->outsideBorder(s,snapshot.getPos())))e.setCanceled(true);
  }else if(outsideBorder(s,e.getPos()))e.setCanceled(true);
 }
 private static boolean outsideBorder(RelayState s,BlockPos pos){
  return !SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,pos.getX()+0.5,pos.getZ()+0.5);
 }
 private void damage(LivingIncomingDamageEvent e){if(safe(e.getEntity().level())&&e.getEntity() instanceof ServerPlayer)e.setCanceled(true);}
 private void spawn(MobSpawnEvent.PositionCheck e){
  var mob=e.getEntity();
  boolean spore=SporeEncounters.isSpore(mob);
  if(!spore&&!hostile(mob))return;
  var level=e.getLevel().getLevel();
  if(safe(level)){e.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);return;}
  if(!spore&&(expedition(level)||vanilla(mob))){e.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);return;}
  if(!expedition(level)||e.getSpawnType()!=MobSpawnType.NATURAL)return;
  var state=RelayState.get(level.getServer());
  if(!state.ready||state.generating||!level.dimension().equals(key(state.activeDimension))
      ||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,mob.getX(),mob.getZ())
      ||Math.hypot(mob.getX()-state.centerX,mob.getZ()-state.centerZ)<32){
   e.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);return;
  }
  if(!EncounterPressure.of(state).natural(level,mob,state.nightRaid))
   e.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);
 }
 private void explosion(ExplosionEvent.Start e){if(safe(e.getLevel()))e.setCanceled(true);}
}
