package dev.bunkerrelay;

import java.util.*;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.AABB;

/** Server-only encounters: persisted one-shot rooms and one shared event clock per expedition. */
public final class RaidDirector extends SavedData {
 public int sectorX=Integer.MIN_VALUE,sectorZ,elapsed,nextEvent=90,warningUntil,eventUntil,eventIndex;
 public String event="";
 public int dropDue=150;
 public long dropPosition;
 public boolean dropPending,dropLanded;
 CompoundTag dropSecurity=new CompoundTag();
 public final List<CompoundTag> rooms=new ArrayList<>();
 public final Set<Long> cells=new HashSet<>();
 public static RaidDirector get(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(RaidDirector::new,RaidDirector::load),"bunkerrelay_director");}
 public static RaidDirector load(CompoundTag t,HolderLookup.Provider registry){
  var d=new RaidDirector();d.sectorX=t.getInt("x");d.sectorZ=t.getInt("z");d.elapsed=t.getInt("elapsed");d.nextEvent=t.getInt("next");d.warningUntil=t.getInt("warning");d.eventUntil=t.getInt("until");d.eventIndex=t.getInt("index");d.event=t.getString("event");
  d.dropDue=t.contains("dropDue")?t.getInt("dropDue"):Math.max(150,d.elapsed+20);
  d.dropPosition=t.getLong("dropPosition");d.dropPending=t.getBoolean("dropPending");d.dropLanded=t.getBoolean("dropLanded");d.dropSecurity=t.getCompound("dropSecurity").copy();
  for(Tag r:t.getList("rooms",Tag.TAG_COMPOUND))d.rooms.add(((CompoundTag)r).copy());for(long c:t.getLongArray("cells"))d.cells.add(c);return d;
 }
 @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider registry){
  t.putInt("x",sectorX);t.putInt("z",sectorZ);t.putInt("elapsed",elapsed);t.putInt("next",nextEvent);t.putInt("warning",warningUntil);t.putInt("until",eventUntil);t.putInt("index",eventIndex);t.putString("event",event);
  t.putInt("dropDue",dropDue);t.putLong("dropPosition",dropPosition);t.putBoolean("dropPending",dropPending);t.putBoolean("dropLanded",dropLanded);t.put("dropSecurity",dropSecurity.copy());
  var list=new ListTag();for(var r:rooms)list.add(r.copy());t.put("rooms",list);t.putLongArray("cells",cells.stream().mapToLong(Long::longValue).toArray());return t;
 }
 public void reset(RelayState s){sectorX=s.centerX;sectorZ=s.centerZ;elapsed=0;nextEvent=90;warningUntil=0;eventUntil=0;eventIndex=0;event="";dropDue=150;dropPosition=0;dropPending=false;dropLanded=false;dropSecurity=new CompoundTag();rooms.clear();cells.clear();setDirty();}
 public static void prepare(ServerLevel level,RelayState s,int index){
  var d=get(level.getServer());if(index==0)d.reset(s);
  var point=ExpeditionLayout.story(s,index);
  String type=new String[]{"echo","signal","clinic","archive"}[index];
  if(!s.variableStories){d.build(level,s,point.getX(),point.getZ(),type);return;}
  int variant=Math.floorMod(s.generation+(s.generating?1:0)+type.hashCode(),3);
  var site=SporeStorySites.build(level,s,point.getX(),point.getZ(),type,variant);
  if(site==null){d.build(level,s,point.getX(),point.getZ(),type);return;}
  int y=site.origin().getY();
  var room=new CompoundTag();
  room.putInt("x",point.getX());room.putInt("y",y);room.putInt("z",point.getZ());
  room.putString("type",type);room.putString("template",site.template());room.putInt("variant",variant);
  d.rooms.add(room);d.setDirty();
  stockStoryChest(level,s,point.atY(y),type);
 }
 public static long roll(long seed,int x,int z){long n=seed^(x*341873128712L)^(z*132897987541L);n=(n^(n>>>30))*0xbf58476d1ce4e5b9L;n=(n^(n>>>27))*0x94d049bb133111ebL;return n^(n>>>31);}
 public static String roomName(String type){return switch(type){case "echo"->"Лаборатория «Эхо»";case "signal"->"Блокпост «Последний сигнал»";case "clinic"->"Полевой лазарет";case "archive"->"Затопленный архив";default->"Пост наблюдения";};}
 private static BlockPos pos(CompoundTag r){return new BlockPos(r.getInt("x"),r.getInt("y"),r.getInt("z"));}
 public CompoundTag build(ServerLevel level,RelayState s,int x,int z,String type){
  for(var existing:rooms)if(existing.getInt("x")==x&&existing.getInt("z")==z)return existing;
  int y=StructureLevels.floor(level,s,"story",x,z,8,6,14);
  int variant=Math.floorMod(s.generation+(s.generating?1:0)+type.hashCode(),3);
  int passage=new int[]{-3,0,3}[variant];
  Block wall=switch(type){case "echo"->Blocks.POLISHED_DEEPSLATE;case "clinic"->Blocks.WHITE_TERRACOTTA;
   case "signal"->Blocks.GRAY_CONCRETE;case "archive"->Blocks.MOSSY_STONE_BRICKS;default->Blocks.CRACKED_STONE_BRICKS;};
  Block ceiling=switch(type){case "echo"->Blocks.LIGHT_BLUE_STAINED_GLASS;case "clinic"->Blocks.SMOOTH_QUARTZ;
   case "signal"->Blocks.DEEPSLATE_TILES;case "archive"->Blocks.DARK_OAK_PLANKS;default->Blocks.CRACKED_DEEPSLATE_BRICKS;};
  for(int dx=-8;dx<=8;dx++)for(int dz=-6;dz<=6;dz++){
   for(int h=-1;h<=5;h++){
    Block block=h==-1?Blocks.DEEPSLATE_TILES:h==5?ceiling:(Math.abs(dx)==8||Math.abs(dz)==6)?wall:Blocks.AIR;
    if(h>=1&&h<=2&&Math.abs(dx)==8&&Math.abs(dz)<4)block=Blocks.IRON_BARS;
    if(Math.abs(dx)<=(type.equals("signal")?2:1)&&dz==-6&&h>=0&&h<=2)block=Blocks.AIR;
    if(h==-1&&Math.abs(dx)<=1)block=type.equals("clinic")?Blocks.WHITE_CONCRETE:type.equals("archive")?Blocks.DARK_OAK_PLANKS:Blocks.YELLOW_CONCRETE;
    level.setBlock(new BlockPos(x+dx,y+h,z+dz),block.defaultBlockState(),2);
   }
  }
  for(int dx=-8;dx<=8;dx++)for(int dz=-6;dz<=6;dz++)
   level.setBlock(new BlockPos(x+dx,y+6,z+dz),Blocks.AIR.defaultBlockState(),2);
  // Visible approach ramp works even when the structure is placed on uneven terrain.
  for(int step=0;step<8;step++)for(int dx=-1;dx<=1;dx++){
   int floor=y-1-step;var b=new BlockPos(x+dx,floor,z-7-step);
   level.setBlock(b,Blocks.COBBLESTONE.defaultBlockState(),2);for(int h=1;h<4;h++)level.setBlock(b.above(h),Blocks.AIR.defaultBlockState(),2);
  }
  int approachGround=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x+2,z-7);
  for(int h=approachGround;h<y;h++){
   level.setBlock(new BlockPos(x+3,h,z-7),wall.defaultBlockState(),2);
   level.setBlock(new BlockPos(x+2,h,z-7),Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.WEST),2);
  }
  for(int dx:new int[]{-7,7})for(int dz:new int[]{-5,5}){
   int ground=level.getHeight(Heightmap.Types.OCEAN_FLOOR,x+dx,z+dz);for(int h=Math.max(y-20,ground-1);h<y-1;h++)level.setBlock(new BlockPos(x+dx,h,z+dz),wall.defaultBlockState(),2);
  }
  for(int dx=-6;dx<=6;dx++)if(dx!=passage&&dx!=passage+1)for(int h=0;h<4;h++)level.setBlock(new BlockPos(x+dx,y+h,z+1),Blocks.IRON_BARS.defaultBlockState(),2);
  for(int dx:new int[]{-5,5}){
   level.setBlock(new BlockPos(x+dx,y,z+4),Blocks.POLISHED_ANDESITE.defaultBlockState(),2);
   level.setBlock(new BlockPos(x+dx,y+1,z+4),Blocks.REDSTONE_LAMP.defaultBlockState(),2);
   level.setBlock(new BlockPos(x+dx,y+2,z+4),Blocks.REDSTONE_BLOCK.defaultBlockState(),2);
  }
  level.setBlock(new BlockPos(x-6,y,z-3),Blocks.COBWEB.defaultBlockState(),2);
  level.setBlock(new BlockPos(x+6,y,z-3),type.equals("clinic")?Blocks.CAULDRON.defaultBlockState():Blocks.CHISELED_BOOKSHELF.defaultBlockState(),2);
  if(type.equals("echo")){
   for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)for(int h=0;h<3;h++)level.setBlock(new BlockPos(x-4+dx,y+h,z-3+dz),(Math.abs(dx)==1||Math.abs(dz)==1?Blocks.TINTED_GLASS:h==1?Blocks.SEA_LANTERN:Blocks.IRON_BLOCK).defaultBlockState(),2);
  }else if(type.equals("signal")||type.equals("watch")){
   for(int h=0;h<11;h++){level.setBlock(new BlockPos(x+7,y+h,z+5),Blocks.IRON_BARS.defaultBlockState(),2);if(h<9)level.setBlock(new BlockPos(x+6,y+h,z+5),Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.WEST),2);}
   for(int dx=3;dx<=7;dx++)for(int dz=2;dz<=5;dz++)level.setBlock(new BlockPos(x+dx,y+8,z+dz),Blocks.STONE_BRICK_SLAB.defaultBlockState(),2);
   level.setBlock(new BlockPos(x+7,y+11,z+5),Blocks.REDSTONE_LAMP.defaultBlockState(),2);
  }else if(type.equals("clinic")){
   for(int dz=-4;dz<=-2;dz+=2)for(int dx=3;dx<=6;dx++)level.setBlock(new BlockPos(x+dx,y,z+dz),(dx==6?Blocks.WHITE_WOOL:Blocks.SMOOTH_QUARTZ_SLAB).defaultBlockState(),2);
  }else if(type.equals("archive")){
   for(int dx=-6;dx<=-4;dx+=2)for(int dz=-4;dz<=0;dz++)for(int h=0;h<3;h++)level.setBlock(new BlockPos(x+dx,y+h,z+dz),Blocks.BOOKSHELF.defaultBlockState(),2);
  }
  level.setBlock(new BlockPos(x,y,z+4),Blocks.CHEST.defaultBlockState(),3);
  if(type.equals("archive"))for(int dx=2;dx<6;dx++)level.setBlock(new BlockPos(x+dx,y,z+3),Blocks.WATER.defaultBlockState(),2);
  var origin=new BlockPos(x,y,z);
  switch(type){
   case "echo" -> {
    for(int dx=2;dx<=6;dx++)for(int h=0;h<4;h++)
     level.setBlock(origin.offset(dx,h,-2),(h==0?Blocks.IRON_BLOCK:Blocks.TINTED_GLASS).defaultBlockState(),2);
    level.setBlock(origin.offset(4,0,-4),Blocks.BREWING_STAND.defaultBlockState(),2);
   }
   case "clinic" -> {
    for(int dz:new int[]{-3,0,3})for(int dx=-7;dx<=-4;dx++)
     level.setBlock(origin.offset(dx,0,dz),(dx==-7?Blocks.WHITE_WOOL:Blocks.QUARTZ_SLAB).defaultBlockState(),2);
    level.setBlock(origin.offset(-6,1,3),Blocks.LANTERN.defaultBlockState(),2);
   }
   case "archive" -> {
    for(int dz=-3;dz<=1;dz++)for(int h=0;h<4;h++)
     level.setBlock(origin.offset(6,h,dz),Blocks.BOOKSHELF.defaultBlockState(),2);
    for(int dx=1;dx<=5;dx++)level.setBlock(origin.offset(dx,0,0),Blocks.SPRUCE_SLAB.defaultBlockState(),2);
   }
   default -> {
    for(int dx:new int[]{-6,6})for(int dz=-4;dz<=-2;dz++)
     level.setBlock(origin.offset(dx,0,dz),Blocks.SANDSTONE.defaultBlockState(),2);
   }
  }
  for(int dz=-4;dz<=-2;dz++){
   int xOffset=new int[]{-1,0,1}[variant];
   level.setBlock(origin.offset(xOffset,1,dz),(variant==0?Blocks.IRON_BARS:variant==1?Blocks.TINTED_GLASS:Blocks.STONE_BRICK_WALL).defaultBlockState(),2);
  }
  if(s.variableStories)stockStoryChest(level,s,origin,type);
  ThemedApproach.build(level,s,origin);
  var r=new CompoundTag();r.putInt("x",x);r.putInt("y",y);r.putInt("z",z);r.putString("type",type);r.putInt("variant",variant);rooms.add(r);setDirty();return r;
 }
 public void discover(ServerPlayer p,RelayState s){
  int gx=Math.floorDiv(p.getBlockX()-s.centerX,384),gz=Math.floorDiv(p.getBlockZ()-s.centerZ,384);long cell=ChunkPos.asLong(gx,gz);
  if(cells.contains(cell))return;
  long value=roll(ExpeditionLayout.seed(s),gx,gz);int x=s.centerX+gx*384+128+(int)Math.floorMod(value,96),z=s.centerZ+gz*384+128+(int)Math.floorMod(value>>>8,96);
  if(p.distanceToSqr(x,p.getY(),z)>80*80)return;
  if(Math.floorMod(value,3)==0||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,x-16,z-16)||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,x+16,z+16)||Math.hypot(x-s.centerX,z-s.centerZ)<100||Math.hypot(x-s.relayX,z-s.relayZ)<50||rooms.stream().anyMatch(r->Math.hypot(x-r.getInt("x"),z-r.getInt("z"))<64)){cells.add(cell);setDirty();return;}
  var level=p.serverLevel();for(int dx:new int[]{-16,16})for(int dz:new int[]{-16,16})if(!level.hasChunkAt(new BlockPos(x+dx,80,z+dz)))return;
  cells.add(cell);build(level,s,x,z,new String[]{"clinic","archive","watch"}[(int)Math.floorMod(value>>>16,3)]);setDirty();
 }
 public static int toggleScares(ServerPlayer p){boolean off=!p.getPersistentData().getBoolean("relay_quiet");p.getPersistentData().putBoolean("relay_quiet",off);if(off)MeetingSignals.current(p,RelayState.get(p.server));RaidRules.tell(p,off?"Резкие звуки, надписи-скримеры и темнота отключены. Опасности остаются.":"Скримеры включены.");return 1;}
 public static void scare(ServerPlayer p,String text){
  if(p.getPersistentData().getBoolean("relay_quiet")){RaidRules.tell(p,text);return;}
  p.connection.send(new ClientboundSetTitlesAnimationPacket(0,25,15));p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(text).withStyle(net.minecraft.ChatFormatting.DARK_RED)));
  p.playNotifySound(SoundEvents.ENDERMAN_SCREAM,SoundSource.HOSTILE,0.65f,0.7f);p.addEffect(new MobEffectInstance(MobEffects.DARKNESS,50,0,false,false));
 }
 private static void radio(List<ServerPlayer> players,String text){for(var p:players)RaidHud.alert(p,"[Радио] "+text);}
 public static void second(MinecraftServer server,RelayState s){
  if(!s.ready||s.generating)return;var d=get(server);if(d.sectorX!=s.centerX||d.sectorZ!=s.centerZ)return; // Existing 0.3 zones are left untouched.
  var players=server.getPlayerList().getPlayers().stream().filter(p->RaidRules.active(p)&&p.isAlive()&&!p.isSpectator()&&p.level().dimension().equals(BunkerRelay.key(s.activeDimension))).toList();
  if(players.isEmpty())return;var level=server.getLevel(BunkerRelay.key(s.activeDimension));d.advance(level,s,players);
 }
 static String chooseEvent(long roll, boolean split){
  if(split&&Math.floorMod(roll,3)==0)return "double";
  return switch(Math.floorMod(roll,7)){
   case 0->"hunt";
   case 1->"ash";
   case 2->"blackout";
   case 3->"echo";
   case 4->"stalker";
   case 5->"footsteps";
   default->"siren";
  };
 }
 public void advance(ServerLevel level,RelayState s,List<ServerPlayer> players){
  elapsed++;
  RouteEvents.tick(level,s,elapsed,players);
  var pressure=EncounterPressure.of(s);
  if(pressure==EncounterPressure.INDUSTRIAL&&elapsed%(s.nightRaid?150:85)==45)
   for(var p:players)if(p.distanceToSqr(s.centerX,p.getY(),s.centerZ)>48*48&&level.canSeeSky(p.blockPosition())){
    spawnNear(p,s,"patrol_site",35,players);
    spawnNear(p,s,"patrol_site",40,players);
   }
  FieldSecurity.tick(level,s,players);Airdrop.tick(level,s,this,players);for(var p:players){if(!s.sectorBuildings)discover(p,s);rooms(p,s);}
  if(event.isEmpty()&&elapsed>=nextEvent){
   boolean split=players.stream().anyMatch(player->RaidDoubles.isolated(player,players));
   long roll=roll(s.seed,eventIndex++,31);
   event=chooseEvent(roll,split);
   warningUntil=elapsed+12;eventUntil=warningUntil+60;
   radio(players,switch(event){
    case "hunt"->"Движение на дальнем периметре. Волна через 12 секунд.";
    case "ash"->"Пепельный фронт через 12 секунд. Укройтесь под крышей.";
    case "echo"->"Передатчик ловит шаги. Проверьте, кто идёт следом.";
    case "stalker"->"Радио · три удара в эфире. Источник сигнала приближается.";
    case "footsteps"->"Датчики молчат. Шаги слышны даже там, где патрулей нет.";
    case "siren"->"Старая сирена включится через 12 секунд. Уйдите под крышу, чтобы переждать патруль.";
    case "double"->"Радио повторяет голоса группы. Сверьте, кто где находится.";
    default->"Помехи. Через 12 секунд ожидается провал видимости.";
   });
  }
  if(event.equals("stalker")&&(elapsed==warningUntil-8||elapsed==warningUntil-3)){
   for(var p:players)if(p.distanceToSqr(s.centerX,p.getY(),s.centerZ)>=24*24)RaidHorror.facelessClue(p);
  }
  if(!event.isEmpty()&&elapsed>=warningUntil&&elapsed<eventUntil){
   for(var p:players){
    if(p.distanceToSqr(s.centerX,p.getY(),s.centerZ)<24*24)continue; // Extraction remains a refuge from director attacks.
    if(event.equals("hunt")&&(elapsed==warningUntil||s.activeDifficulty>=3&&elapsed==warningUntil+20))
     for(int n=0;n<pressure.waveSize;n++)spawnNear(p,s,n%2==0?"stalker":"screamer",38+n*5,players);
    if(event.equals("double")&&elapsed==warningUntil&&RaidDoubles.isolated(p,players)){
     var teammate=players.stream().filter(other->other!=p).min(Comparator.comparingDouble(p::distanceToSqr)).orElseThrow();
     RaidDoubles.spawn(level,s,p,teammate);
    }
    if(event.equals("echo")&&elapsed%8==0&&RaidHorror.enabled(p)){
     p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT,SoundSource.HOSTILE,.55f,.68f);
     level.sendParticles(net.minecraft.core.particles.ParticleTypes.SMOKE,p.getX()+2,p.getY()+.2,p.getZ()-3,12,1,.2,1,.01);
    }
    if(event.equals("footsteps")&&(elapsed-warningUntil)%7==0&&RaidHorror.enabled(p))
     RaidHorror.footsteps(p,roll(s.seed,elapsed,p.getId()));
    if(event.equals("siren")&&(elapsed==warningUntil||elapsed==warningUntil+25)){
     if(RaidHorror.enabled(p))p.playNotifySound(SoundEvents.BELL_BLOCK,SoundSource.AMBIENT,.65f,.55f);
     if(level.canSeeSky(p.blockPosition()))spawnNear(p,s,"stalker",44,players);
    }
    if(event.equals("stalker")&&elapsed==warningUntil){
     RaidHorror.atmosphere(p);
     spawnNear(p,s,"faceless",42,players);
    }
    if(event.equals("ash")&&level.canSeeSky(p.blockPosition())){p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,40,0,false,true));level.sendParticles(net.minecraft.core.particles.ParticleTypes.ASH,p.getX(),p.getY()+1,p.getZ(),12,5,2,5,0.02);if(elapsed%5==0)p.hurt(p.damageSources().magic(),1);}
    if(event.equals("blackout")){if(!p.getPersistentData().getBoolean("relay_quiet"))p.addEffect(new MobEffectInstance(MobEffects.DARKNESS,50,0,false,false));if(elapsed==warningUntil){scare(p,"НЕ ОБОРАЧИВАЙСЯ");spawnNear(p,s,"stalker",36,players);}}
   }
  }
  if(!event.isEmpty()&&elapsed>=eventUntil){radio(players,"Помехи стихли. Продолжайте поиск и возвращайтесь к эвакуации.");event="";nextEvent=elapsed+240+(int)Math.floorMod(roll(s.seed,eventIndex,73),181);}
  Set<UUID> visited=new HashSet<>();for(var p:players){
   if(elapsed%80==36&&p.distanceToSqr(s.centerX,p.getY(),s.centerZ)>32*32)RaidHorror.atmosphere(p);
   if(elapsed%35==0&&!p.getPersistentData().getBoolean("relay_quiet"))p.playNotifySound(SoundEvents.AMBIENT_CAVE.value(),SoundSource.AMBIENT,0.35f,0.7f);
   for(var mob:level.getEntitiesOfClass(Mob.class,p.getBoundingBox().inflate(64),m->m.getTags().contains("relay_threat")))if(visited.add(mob.getUUID()))ability(mob,s,players);
  }
  setDirty();
 }
 public void rooms(ServerPlayer p,RelayState s){
  for(var r:rooms){if(r.getString("type").equals("landmark"))continue;var at=pos(r);if(Math.abs(p.getX()-at.getX())>7||Math.abs(p.getZ()-at.getZ())>5||Math.abs(p.getY()-at.getY())>4)continue;
   if(!r.getBoolean("warned")){r.putBoolean("warned",true);r.putInt("triggerAt",elapsed+3);RaidHud.alert(p,"Ловушка! Отойдите от дальней комнаты. "+roomName(r.getString("type"))+": «Журнал 17: сигнал идёт снизу. Персонал не открывает двери. НЕ ОТВЕЧАЙТЕ НА ГОЛОС». Слышен щелчок; отойдите от дальней комнаты! ");setDirty();}
   if(!r.getBoolean("fired")&&elapsed>=r.getInt("triggerAt")&&p.getZ()>at.getZ()-1)trigger(p,s,r);
  }
 }
 public void trigger(ServerPlayer p,RelayState s,CompoundTag r){
  if(r.getBoolean("fired"))return;r.putBoolean("fired",true);setDirty();var at=pos(r);var level=p.serverLevel();
  scare(p,r.getString("type").equals("echo")?"ОН СЛЫШИТ ТЕБЯ":"СИГНАЛ НЕ НАШ");
  for(var q:level.getEntitiesOfClass(ServerPlayer.class,new AABB(at).inflate(7,4,5),q->RaidRules.active(q))){q.addEffect(new MobEffectInstance(MobEffects.POISON,80,0,false,true));q.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,60,0,false,true));}
  level.sendParticles(net.minecraft.core.particles.ParticleTypes.SPORE_BLOSSOM_AIR,at.getX(),at.getY()+1,at.getZ()+2,50,5,1,2,0.03);
  int spawned=spawn(level,s,at.offset(4,0,3),r.getString("type").equals("echo")?"warden":"screamer",p)!=null?1:0;
  if(s.activeDifficulty>=3&&spawn(level,s,at.offset(-4,0,3),"stalker",p)!=null)spawned++;r.putInt("spawned",spawned);
  stockStoryChest(level,s,at,r.getString("type"));
  MiniBosses.encounter(p,s,at.south(4));
 }
 private static void stockStoryChest(ServerLevel level,RelayState state,BlockPos origin,String type){
  var pos=origin.south(4);
  if(!(level.getBlockEntity(pos) instanceof ChestBlockEntity chest)
     ||chest instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity)return;
  RaidLoot.fill(chest,level,state,origin);
  var note=new ItemStack(Items.PAPER);
  note.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,Component.literal("Журнал · "+roomName(type)));
  String entry=switch(Math.floorMod(roll(state.seed,origin.getX(),origin.getZ()),4)){
   case 0 -> "Патруль потерял связь по дороге к радиостанции.";
   case 1 -> "Слышали знакомый голос. Дверь больше не открываем.";
   case 2 -> "После помех обнаружились следы у северной стены.";
   default -> "Запчасти оставили на блокпосту. Выход обозначен на карте.";
  };
  var lines=new ArrayList<Component>();
  lines.add(Component.literal(entry));
  var power=FieldRoutes.point(state,FieldRoutes.SUBSTATION);
  if(type.equals("signal")&&power!=null)lines.add(Component.literal("Схема сети · подстанция "+power.toShortString()));
  note.set(net.minecraft.core.component.DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(lines));
  chest.setItem(3,note);
  PersonalLoot.convert(level,pos,chest);
  MiniBosses.arm(level,state,pos,MiniBosses.story(type));
 }
 public static Mob spawn(ServerLevel level,RelayState s,BlockPos at,String role,ServerPlayer target){
  if(!level.hasChunkAt(at)||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,at.getX(),at.getZ()))return null;
  var pressure=EncounterPressure.of(s);
  if(target!=null&&!pressure.room(level,target.blockPosition(),false))return null;
  Mob mob=switch(role){
   case "faceless" -> SporeEncounters.create(level,"stalker");
   case "patrol_site" -> SporeEncounters.create(level,"inf_pillager");
   case "screamer" -> SporeEncounters.create(level,pressure==EncounterPressure.FOREST?"inf_husk":"howler");
   case "infested_site" -> SporeEncounters.create(level,pressure==EncounterPressure.FOREST?"inf_hazmat":"slasher");
   case "site_guard","site_heavy" -> SporeEncounters.create(level,pressure.fieldSpecies(role.equals("site_heavy")));
   case "stalker" -> SporeEncounters.create(level,pressure.fieldSpecies(false));
   default -> SporeEncounters.create(level,s,0);
  };
  if(mob==null)return null;
  mob.moveTo(at.getX()+0.5,at.getY(),at.getZ()+0.5,0,0);if(!level.noCollision(mob))return null;
  mob.addTag("relay_threat");
  mob.getPersistentData().putInt("relay_structure_generation",s.generating?s.generation+1:s.generation);
  mob.getPersistentData().putString("relay_role",role);
  if(role.equals("faceless"))mob.setCustomName(Component.literal("Безликий"));
  mob.setTarget(target);
  if(!level.addFreshEntity(mob))return null;
  if(role.equals("faceless")&&target!=null)RaidVisuals.apparition(target,mob);
  return mob;
 }
 public static void spawnNear(ServerPlayer p,RelayState s,String role,int distance){
  spawnNear(p,s,role,distance,List.of());
 }
 static void spawnNear(ServerPlayer p,RelayState s,String role,int distance,List<ServerPlayer> keepAway){
  var l=p.serverLevel();for(int a=0;a<8;a++){
   double angle=a*Math.PI/4+p.getYRot()*Math.PI/180;int x=p.getBlockX()+(int)(Math.cos(angle)*distance),z=p.getBlockZ()+(int)(Math.sin(angle)*distance);var col=new BlockPos(x,p.getBlockY(),z);
   if(!l.hasChunkAt(col)||Math.hypot(x-s.centerX,z-s.centerZ)<24||keepAway.stream().anyMatch(player->player.distanceToSqr(x,player.getY(),z)<30*30))continue;
   int y=l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z);if(Math.abs(y-p.getY())>12||!l.getBlockState(new BlockPos(x,y-1,z)).isSolidRender(l,new BlockPos(x,y-1,z)))continue;
   if(spawn(l,s,new BlockPos(x,y,z),role,p)!=null)return;
  }
 }
 private static void ability(Mob mob,RelayState s,List<ServerPlayer> players){
  var l=(ServerLevel)mob.level();long now=l.getGameTime();var data=mob.getPersistentData();
  ServerPlayer p=players.stream().filter(q->q.distanceToSqr(mob)<24*24&&q.distanceToSqr(s.centerX,q.getY(),s.centerZ)>=24*24).min(Comparator.comparingDouble(q->q.distanceToSqr(mob))).orElse(null);
  if(p==null)return;mob.setTarget(p);if(!mob.hasLineOfSight(p)||now<data.getLong("relay_ability"))return;data.putLong("relay_ability",now+400);
  switch(data.getString("relay_role")){
   case "faceless"->{
    mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,1,false,true));
    if(RaidHorror.enabled(p)){
     p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT,SoundSource.HOSTILE,.65f,.7f);
     p.addEffect(new MobEffectInstance(MobEffects.DARKNESS,45,0,false,false));
    }
   }
   case "stalker"->mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,60,1,false,true));
   case "screamer"->{scare(p,"РУПОР ЗОВЁТ ОСТАЛЬНЫХ");if(!data.getBoolean("relay_called")){data.putBoolean("relay_called",true);spawnNear(p,s,"stalker",16);}}
   case "warden"->{if(p.distanceToSqr(mob)<8*8){p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,60,1,false,true));p.playNotifySound(SoundEvents.IRON_GOLEM_ATTACK,SoundSource.HOSTILE,0.7f,0.6f);}}
  }
 }
 public static int report(ServerPlayer p){var s=RelayState.get(p.server);var d=get(p.server);if(d.sectorX!=s.centerX||d.sectorZ!=s.centerZ){RaidRules.tell(p,"Создайте новую зону, чтобы появились сюжетные объекты.");return 0;}if(s.bossGeneration==s.generation)RaidRules.chat(p,RaidBosses.name(s)+(s.bossDefeated?" · повержен":" · необязательный босс")+": "+RaidBosses.arena(s).toShortString());for(var r:d.rooms)if(Set.of("echo","signal").contains(r.getString("type")))RaidRules.chat(p,roomName(r.getString("type"))+": "+pos(r).toShortString());ZoneLandmarks.report(p,d);return 1;}
}
