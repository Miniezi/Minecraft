package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
/** Durable per-player transaction. Pending settlement is replayed idempotently on login. */
public final class RaidJournal extends SavedData {
 public CompoundTag stash=new CompoundTag(),stashPending=new CompoundTag();
 public ListTag reports=new ListTag();
 public final Map<UUID,CompoundTag> raids=new HashMap<>();
 public final Map<UUID,ListTag> mail=new HashMap<>();
 public final Set<String> completed=new HashSet<>();
 public static RaidJournal get(MinecraftServer s){return s.overworld().getDataStorage().computeIfAbsent(new Factory<>(RaidJournal::new,RaidJournal::load),"bunkerrelay_raids");}
 public static RaidJournal load(CompoundTag t,HolderLookup.Provider r){var j=new RaidJournal();j.stash=t.getCompound("stash");j.stashPending=t.getCompound("stashPending");j.reports=t.getList("reports",Tag.TAG_COMPOUND);var entries=t.getCompound("raids");for(String k:entries.getAllKeys())j.raids.put(UUID.fromString(k),entries.getCompound(k));var mail=t.getCompound("mail");for(String k:mail.getAllKeys())j.mail.put(UUID.fromString(k),mail.getList(k,Tag.TAG_COMPOUND));for(Tag v:t.getList("completed",Tag.TAG_STRING))j.completed.add(v.getAsString());return j;}
 @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider r){t.put("stash",stash.copy());t.put("stashPending",stashPending.copy());t.put("reports",reports.copy());var entries=new CompoundTag();raids.forEach((id,v)->entries.put(id.toString(),v.copy()));t.put("raids",entries);var messages=new CompoundTag();mail.forEach((id,v)->messages.put(id.toString(),v.copy()));t.put("mail",messages);var paid=new ListTag();completed.forEach(id->paid.add(StringTag.valueOf(id)));t.put("completed",paid);return t;}
 public void flush(MinecraftServer s){setDirty();s.overworld().getDataStorage().save();}
}
