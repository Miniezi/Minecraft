package dev.bunkerrelay;

import net.minecraft.server.level.ServerLevel;

final class StructureLevels {
    static int floor(ServerLevel level,RelayState state,String kind,int x,int z,int width,int depth,int headroom){
        String key=key(level.dimension().location().toString(),kind,x,z);
        int y=SurfacePlacement.floor(level,x,z,width,depth,headroom);
        SurfacePlacement.grade(level,x,z,width,depth,y);
        state.structureLevels.putInt(key,y);
        state.setDirty();
        return y;
    }

    static boolean known(ServerLevel level,RelayState state,String kind,int x,int z){
        return state.structureLevels.contains(key(level.dimension().location().toString(),kind,x,z));
    }

    static void migrate(ServerLevel level,RelayState state){
        if(state.raidRulesVersion<3)return;
        String dim=level.dimension().location().toString();
        remember(state,dim,"entry",state.centerX,state.centerZ,state.spawnY);
        remember(state,dim,"radio",state.relayX,state.relayZ,state.relayY);
        if(state.bossGeneration==state.generation){
            var arena=RaidBosses.arena(state);
            remember(state,dim,"arena",arena.getX(),arena.getZ(),arena.getY());
        }
        var director=RaidDirector.get(level.getServer());
        if(director.sectorX!=state.centerX||director.sectorZ!=state.centerZ)return;
        for(var room:director.rooms){
            boolean landmark=room.getString("type").equals("landmark");
            var origin=room.contains("origin")?net.minecraft.core.BlockPos.of(room.getLong("origin"))
                :new net.minecraft.core.BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z")-(landmark?4:0));
            remember(state,dim,landmark?"landmark":room.contains("template")?"spore_story":"story",
                origin.getX(),origin.getZ(),origin.getY());
        }
    }

    private static void remember(RelayState s,String dim,String kind,int x,int z,int y){
        String id=key(dim,kind,x,z);
        if(!s.structureLevels.contains(id)){s.structureLevels.putInt(id,y);s.setDirty();}
    }

    static void rememberSector(ServerLevel level,RelayState state,net.minecraft.core.BlockPos pos){
        remember(state,level.dimension().location().toString(),"sector",pos.getX(),pos.getZ(),pos.getY());
    }

    static int sectorY(ServerLevel level,RelayState state,net.minecraft.core.BlockPos pos){
        return state.structureLevels.getInt(key(level.dimension().location().toString(),"sector",pos.getX(),pos.getZ()));
    }

    static boolean overlapsHistorical(ServerLevel level,RelayState state,net.minecraft.core.BlockPos pos){
        return overlapsHistorical(level,state,pos,0);
    }

    static boolean overlapsHistorical(ServerLevel level,RelayState state,net.minecraft.core.BlockPos pos,int allowance){
        return overlapsHistorical(level,state,pos,allowance,null);
    }

    static boolean overlapsHistorical(ServerLevel level,RelayState state,net.minecraft.core.BlockPos pos,int allowance,
                                      net.minecraft.core.BlockPos except){
        String prefix=level.dimension().location()+"/";
        for(String id:state.structureLevels.getAllKeys()){
            if(!id.startsWith(prefix))continue;
            String[] coordinates=id.substring(prefix.length()).split("/");
            if(coordinates.length!=3)continue;
            int x=Integer.parseInt(coordinates[1]),z=Integer.parseInt(coordinates[2]);
            if(except!=null&&except.getX()==x&&except.getZ()==z)continue;
            if(coordinates[0].equals("sector")&&pos.getX()==x&&pos.getZ()==z)continue;
            int margin=coordinates[0].equals("arena")?52:(coordinates[0].equals("spore_story")||coordinates[0].equals("landmark"))?44:coordinates[0].equals("story")?37:26;
            if(Math.abs(pos.getX()-x)<=margin+allowance&&Math.abs(pos.getZ()-z)<=margin+allowance)return true;
        }
        return false;
    }

    private static String key(String dimension,String kind,int x,int z){return dimension+"/"+kind+"/"+x+"/"+z;}
    private StructureLevels(){}
}
