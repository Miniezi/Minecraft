package dev.bunkerrelay;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemLore;
/** Server-authoritative action panel with a dedicated client screen. */
public final class TerminalMenu extends ChestMenu {
 private int page;
 private java.util.List<net.minecraft.nbt.CompoundTag> reportRows=java.util.List.of();
 private int reportPage;
 private ZoneProfile zone;
 private int expeditionSize;
 private boolean previewNight;
 private ExpeditionContracts.Type contract=ExpeditionContracts.Type.STANDARD;
 private final ServerPlayer owner;private final SimpleContainer buttons;
 public TerminalMenu(int id,Inventory inv){super(RelayMenus.TERMINAL.get(),id,inv,new SimpleContainer(54),6);owner=null;buttons=(SimpleContainer)getContainer();}
 public TerminalMenu(int id,Inventory inv,ServerPlayer p){this(id,inv,p,new SimpleContainer(54));}
 private TerminalMenu(int id,Inventory inv,ServerPlayer p,SimpleContainer c){super(RelayMenus.TERMINAL.get(),id,inv,c,6);owner=p;buttons=c;refresh();}
 private void icon(int slot,Item item,String name,String hint){var stack=new ItemStack(item);stack.set(DataComponents.CUSTOM_NAME,Component.literal(name));stack.set(DataComponents.LORE,new ItemLore(List.of(Component.literal(hint))));buttons.setItem(slot,stack);}
 private void refresh(){buttons.clearContent();for(var m:RelayEconomy.Merchant.values())icon(36+m.ordinal(),m.icon,m.title,"ЛКМ — 1 шт. · ПКМ — максимум");icon(42,Items.HOPPER,"Скупщик","Продать вещи по оценке");icon(44,Items.WRITABLE_BOOK,"Заказы снабжения",SupplyOrders.title(owner));icon(46,Items.CHEST,"Забрать награды","Почта наград");icon(48,Items.COMPASS,"Компас в углу экрана","Включить или выключить навигацию");icon(50,Items.GOLD_NUGGET,"Счёт: "+RelayEconomy.balance(owner)+" кр.","Бюджет скупщика: "+RelayEconomy.account(owner).getInt("budget"));var s=RelayState.get(owner.server);
  icon(0,Items.IRON_DOOR,"Бункер","Вернуться домой");icon(2,Items.CHEST_MINECART,"Гараж","Перейти в гараж");
  icon(4,Items.COMPASS,s.ready?"Зона открыта":"Зона закрыта",s.generating?"Подготовка входа…":s.ready?"Эвакуация: "+s.centerX+", "+s.spawnY+", "+s.centerZ:"Выберите настройки и запустите цикл");
  icon(6,Items.PAPER,"Сюжетные объекты","Выбрать цель для компаса");icon(8,Items.NOTE_BLOCK,"Скримеры: "+(owner.getPersistentData().getBoolean("relay_quiet")?"выкл.":"вкл."),"Переключить резкие звуки, надписи и темноту");
  icon(26,Items.GOLD_NUGGET,"Торговец · "+RelayEconomy.balance(owner)+" кр.","Магазин, скупщик и поставки после вылазок");
  icon(18,Items.WRITABLE_BOOK,"Журнал вылазки","Цели, прогресс и почта наград");
  icon(47,Items.PAPER,"Отчёт команды","Результаты последнего цикла");
  icon(22,Items.MAP,"Новая вылазка","Выбрать зону, размер и контракт");
  if(!s.hubV2&&owner.hasPermissions(2))icon(25,Items.BRICKS,"Обновить бункер","Старая база остаётся доступной");
  else if(s.legacyAvailable)icon(25,Items.BRICKS,"Старая база","Перейти в прежний бункер");
  icon(32,Items.ANVIL,"Разбор и улучшения","Список деталей и эффектов");
  icon(34,Items.COAL,"Заправить резерв","Уголь в основной руке");
  icon(35,Items.SHEARS,"Разобрать трофей","Трофей в основной руке");
  icon(43,Items.REDSTONE,"Установить деталь","Деталь в основной руке");
  icon(33,Items.REDSTONE_TORCH,BasePower.label(s),"Нажмите для координат аккумулятора и заправки");
  icon(27,Items.COMPASS,"Задача вылазки",s.ready?RaidMission.label(s):"Зона ещё не готова");
  for(var upgrade:BaseUpgrades.Upgrade.values())icon(28+upgrade.ordinal(),Items.EMERALD,upgrade.title,
      BaseUpgrades.has(owner,upgrade)?"Открыто · нажмите для использования":upgrade.price+" кр. · купить для команды");
  for(var request:BunkerRequests.Request.values())
   icon(15+request.ordinal(),request.item().getItem(),request.title,request.status(s)+" · "+request.reward);
  icon(17,Items.SHEARS,"Разборка оружия","Выбрать оружие и посмотреть детали");
  if(s.hubV2)icon(51,Items.IRON_BLOCK,"Склад и картографическая","Служебное крыло");
  if(s.workshopBuilt)icon(53,Items.SMITHING_TABLE,"Мастерская во дворе",CourtyardWorkshop.hint(owner,s));
  icon(52,Items.EXPERIENCE_BOTTLE,"Навыки","Очки: "+SkillMenu.points(owner));

  icon(24,Items.ENDER_PEARL,"Начать вылазку","Снаряжение сохраняется перед выходом");
  int[] visible=switch(page){
   case 1->new int[]{28,36,37,38,39,40,41,42,44,50};
   case 2->new int[]{0,2,8,15,16,17,25,28,29,30,31,32,33,34,35,43,48,51,52,53};
   case 3,4->new int[]{};
   default->new int[]{4,6,22,24,27,18,46,47,52};
  };
  var slots=new java.util.BitSet(54);
  for(int slot:visible)slots.set(slot);
  for(int slot=0;slot<54;slot++)if(!slots.get(slot))buttons.setItem(slot,ItemStack.EMPTY);
  if(page==3){
   for(var profile:ZoneProfile.values())
    icon(10+profile.ordinal(),Items.MAP,(zone==profile?"• ":"")+profile.title,"Выбрать район вылазки");
   icon(14,Items.COMPASS,"Размер · "+expeditionSize,"Сменить размер");
   for(var option:ExpeditionContracts.Type.values())if(option.available(zone))
    icon(18+option.ordinal(),Items.PAPER,(contract==option?"• ":"")+option.title,option.hint);
   boolean night=ExpeditionLight.offer(s,zone);
   previewNight=night;
   icon(23,night?Items.CLOCK:Items.SUNFLOWER,night?"Ночная вылазка":"Дневная вылазка","Время зафиксировано до конца рейда");
   icon(24,Items.LIME_DYE,"Принять вылазку",zone.title+" · "+contract.title);
   icon(26,Items.ARROW,"Пропустить предложение","Получить новый вариант для этой зоны");
  }
  if(page==4){
   reportRows=ExpeditionReport.latest(owner);
   reportPage=Math.clamp(reportPage,0,Math.max(0,(reportRows.size()-1)/36));
   for(int i=0;i<36&&reportPage*36+i<reportRows.size();i++){
    var result=reportRows.get(reportPage*36+i);
    icon(9+i,Items.PAPER,result.getString("player"),ExpeditionReport.outcome(result));
   }
   if(reportRows.isEmpty())icon(22,Items.BOOK,"Отчётов пока нет","Завершите вылазку");
   if(reportPage>0)icon(45,Items.ARROW,"Предыдущая страница","");
   if((reportPage+1)*36<reportRows.size())icon(46,Items.ARROW,"Следующая страница","");
  }
  icon(1,Items.COMPASS,(page==0?"• ":"")+"Вылазка","");
  icon(3,Items.EMERALD,(page==1?"• ":"")+"Магазин","");
  icon(5,Items.IRON_BLOCK,(page==2?"• ":"")+"База","");

 }
 void refreshPower(){
  if(page!=2)return;
  icon(33,Items.REDSTONE_TORCH,BasePower.label(RelayState.get(owner.server)),"Нажмите для координат аккумулятора и заправки");
  broadcastChanges();
 }
 @Override public void clicked(int slot,int button,ClickType type,Player player){
  if(player!=owner||!stillValid(player)||type!=ClickType.PICKUP||button!=0||slot<0||slot>=54||buttons.getItem(slot).isEmpty())return;
  if(slot==1||slot==3||slot==5){page=(slot-1)/2;refresh();sendAllDataToRemote();return;}
  if(page==0&&slot==47){page=4;reportPage=0;refresh();sendAllDataToRemote();return;}
  if(page==4){
   if(slot==45)reportPage--;
   else if(slot==46)reportPage++;
   else if(slot>=9&&slot<45&&reportPage*36+slot-9<reportRows.size())
    ExpeditionReport.details(owner,reportRows.get(reportPage*36+slot-9));
   refresh();sendAllDataToRemote();return;
  }
  if(page==0&&slot==22){
   var state=RelayState.get(owner.server);
   zone=ZoneProfile.of(state.theme);expeditionSize=state.size;contract=ExpeditionContracts.Type.STANDARD;
   page=3;refresh();sendAllDataToRemote();return;
  }
  if(page==3){
   if(slot>=10&&slot<=13){
    zone=ZoneProfile.values()[slot-10];
    if(!contract.available(zone))contract=ExpeditionContracts.Type.STANDARD;
   }else if(slot==14)expeditionSize=expeditionSize==2048?4096:expeditionSize==4096?8192:2048;
   else if(slot>=18&&slot<=21)contract=ExpeditionContracts.Type.values()[slot-18];
   else if(slot==26)ExpeditionLight.reroll(RelayState.get(owner.server),zone);
   else if(slot==24){
    if(previewNight!=ExpeditionLight.offer(RelayState.get(owner.server),zone))
     RaidRules.tell(owner,"Предложение изменилось. Проверьте время вылазки.");
    else if(BunkerRelay.launchSelection(owner,zone,expeditionSize,contract))page=0;
   }
   refresh();sendAllDataToRemote();return;
  }
  if(slot>=36&&slot<36+RelayEconomy.Merchant.values().length){RelayEconomy.open(owner,false,RelayEconomy.Merchant.values()[slot-36]);return;}
  switch(slot){
   case 6 -> ReconChart.targets(owner);
   case 8 -> RaidDirector.toggleScares(owner);
   case 15,16 -> BunkerRequests.contribute(owner,BunkerRequests.Request.values()[slot-15]);
   case 17 -> DismantleMenu.open(owner,false);
   case 18 -> RaidContracts.open(owner);
   case 26 -> RelayEconomy.open(owner,false);
   case 27 -> RaidMission.report(owner);
   case 28 -> {if(BaseUpgrades.has(owner,BaseUpgrades.Upgrade.STORAGE))BaseUpgrades.locker(owner);else BaseUpgrades.buy(owner,BaseUpgrades.Upgrade.STORAGE);}
   case 29 -> {if(BaseUpgrades.has(owner,BaseUpgrades.Upgrade.SUPPLY))BaseUpgrades.status(owner);else BaseUpgrades.buy(owner,BaseUpgrades.Upgrade.SUPPLY);}
   case 30 -> {if(BaseUpgrades.has(owner,BaseUpgrades.Upgrade.WORKSHOP))BaseUpgrades.repair(owner);else BaseUpgrades.buy(owner,BaseUpgrades.Upgrade.WORKSHOP);}
   case 31 -> {if(BaseUpgrades.has(owner,BaseUpgrades.Upgrade.INTEL))BaseUpgrades.intel(owner);else BaseUpgrades.buy(owner,BaseUpgrades.Upgrade.INTEL);}
   case 32 -> TrophyResearch.report(owner);
   case 33 -> BasePower.report(owner);
   case 34 -> BasePower.fuel(owner);
   case 35 -> TrophyResearch.dismantle(owner);
   case 42 -> RelayEconomy.open(owner,true);
   case 43 -> TrophyResearch.install(owner);
   case 44 -> SupplyOrders.open(owner);
   case 46 -> RaidContracts.claim(owner);
   case 48 -> RaidHud.toggle(owner);
   case 52 -> SkillMenu.open(owner);
   case 53 -> CourtyardWorkshop.useOrLocate(owner);
   default -> BunkerRelay.terminalAction(owner,slot);
  }
  if(owner.containerMenu==this){refresh();broadcastChanges();}
 }
 @Override public ItemStack quickMoveStack(Player p,int slot){return ItemStack.EMPTY;}
 @Override public boolean stillValid(Player p){return p==owner&&BunkerRelay.nearTerminal(owner);}
}
