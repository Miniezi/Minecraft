package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update20IntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var names=new HashSet<String>();
        var origin=new BlockPos(state.centerX+80,235,state.centerZ+80);
        String previousTheme=state.activeTheme;
        var fingerprints=new HashSet<String>();
        for(String theme:List.of("industrial","infected","forest","ash")){
            state.activeTheme=theme;
            for(int variant=0;variant<6;variant++){
                check(names.add(SiteDetails.name(theme,variant)),"distinct location name");
                SectorBuildings.build(level,state,origin,variant);
                check(!level.isEmptyBlock(origin.below())&&level.isEmptyBlock(origin),"entrance and floor");
                var signature=new StringBuilder();
                for(int x=-7;x<=7;x++)for(int z=-7;z<=7;z++)for(int y=0;y<=6;y++)
                    signature.append(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getId(level.getBlockState(origin.offset(x,y,z)).getBlock())).append(',');
                check(fingerprints.add(signature.toString()),"distinct physical layout");
            }
        }
        state.activeTheme=previousTheme;
        for (int index = 0; index < 4; index++) RaidDirector.prepare(level, state, index);
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"Relay20Horror"));
        for(int mission:new int[]{5,6}){
            state.seed=mission-1;
            state.relayPowered=false;
            RaidMission.prepare(level,state);
            check(state.mission==mission&&state.missionNodes.length==2,"new mission nodes");
            var first=BlockPos.of(state.missionNodes[0]);
            var second=BlockPos.of(state.missionNodes[1]);
            RaidMission.use(player,state,second);
            check((state.missionProgress==0)==(mission==5),"sequence requirement");
            RaidMission.use(player,state,first);
            RaidMission.use(player,state,second);
            RaidMission.use(player,state,RaidMission.radio(state));
            check(mission==5?state.relayPowered:state.missionStarted&&!state.relayPowered,"mission finale");
        }
        var spawn=origin.east(20);
        level.setBlock(spawn.below(),Blocks.STONE.defaultBlockState(),3);
        var mob=RaidDirector.spawn(level,state,spawn,"faceless",player);
        check(mob!=null&&mob.getCustomName()!=null&&mob.getCustomName().getString().equals("Безликий"),"faceless mob");
        player.getPersistentData().putBoolean("relay_quiet",true);
        check(!RaidHorror.enabled(player)&&RaidHorror.DRONE.get()!=null,"quiet mode and sound event");
        System.out.println("RELAY_020_PASS layouts="+names.size()+" missions=2 horror=true");
        server.halt(false);
    }
    private static void check(boolean value,String message){if(!value)throw new IllegalStateException("RELAY_020 "+message);}
    private Update20IntegrationTest(){}
}
