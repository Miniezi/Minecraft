package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.UUID;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.neoforged.neoforge.common.util.FakePlayer;

final class RelayTestCommandsIntegrationTest {
    static void verify(MinecraftServer server,RelayState state){
        var dispatcher=server.getCommands().getDispatcher();
        var console=server.createCommandSourceStack().withSuppressedOutput();
        var player=new FakePlayer(server.getLevel(BunkerRelay.HUB),new GameProfile(UUID.randomUUID(),"RelayAdminTest"));
        var admin=player.createCommandSourceStack().withPermission(2).withSuppressedOutput();
        var user=admin.withPermission(0);
        var offers=state.lightOffers.copy();
        try{
            require(dispatcher.execute("relay test status",console)==1,"console diagnostics");
            require(dispatcher.execute("relay test points",console)==1,"coordinates");
            boolean denied=false;
            try{dispatcher.execute("relay test offer forest night",user);}catch(CommandSyntaxException blocked){denied=true;}
            require(denied&&state.lightOffers.equals(offers),"permission boundary");
            require(dispatcher.execute("relay test offer forest night",admin)==1&&state.lightOffers.getBoolean("forest"),"test offer");
            require(dispatcher.execute("relay test offer forest day",admin)==1&&!state.lightOffers.getBoolean("forest"),"day offer");
            boolean inRaidOnly=false;
            try{dispatcher.execute("relay test wave 3",admin);}catch(CommandSyntaxException blocked){inRaidOnly=true;}
            require(inRaidOnly,"wave blocked on base");
            long balance=RelayEconomy.balance(player);
            require(dispatcher.execute("relay test fund 50",admin)==1&&RelayEconomy.balance(player)==balance+50,"own test credits");
            require(dispatcher.execute("relay test gear flashlight",admin)==1&&player.getInventory().items.stream()
                .anyMatch(item->BuiltInRegistries.ITEM.getKey(item.getItem()).equals(ResourceLocation.parse("relaylights:flashlight"))),"test flashlight");
        }catch(CommandSyntaxException error){
            throw new IllegalStateException("Relay test command failed",error);
        }finally{
            state.lightOffers=offers;
            state.setDirty();
        }
        System.out.println("RELAY_ADMIN_COMMANDS_PASS");
    }

    private static void require(boolean condition,String check){
        if(!condition)throw new IllegalStateException("Relay test command: "+check);
    }
}
