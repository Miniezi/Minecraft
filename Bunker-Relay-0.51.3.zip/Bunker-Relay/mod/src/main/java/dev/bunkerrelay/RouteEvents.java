package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;

final class RouteEvents {
    private record Signal(String title,String clue,SupplySites.Kind supplies){}

    private static Signal signal(RelayState state){
        return switch(ZoneProfile.of(state.activeTheme)){
            case FOREST -> new Signal("Потерянный разведчик","Слабый сигнал с полевой тропы. Проверьте оставленный груз.",SupplySites.Kind.CANTEEN);
            case INDUSTRIAL -> new Signal("Аварийная передача","Промышленный передатчик работает от резерва, рядом остался технический ящик.",SupplySites.Kind.FACTORY);
            case INFECTED -> new Signal("Сигнал санбригады","У дороги слышен аварийный маяк медиков.",SupplySites.Kind.CANTEEN);
            case ASH -> new Signal("Застрявший грузовик","В эфир попала запись водителя. Проверьте сброшенный груз у дороги.",SupplySites.Kind.WAREHOUSE);
        };
    }

    static void tick(ServerLevel level,RelayState state,int seconds,List<ServerPlayer> players){
        var event=state.routeEvent;
        if(event.contains("position")){
            var pos=BlockPos.of(event.getLong("position"));
            if(seconds>=event.getInt("until")){
                if(!level.hasChunkAt(pos))return;
                clear(level,state);
                return;
            }
            if(seconds%3==0&&level.hasChunkAt(pos))
                level.sendParticles(ParticleTypes.SMOKE,pos.getX()+.5,pos.getY()+1,pos.getZ()+.5,3,.25,.2,.25,.01);
            if(!event.getBoolean("alerted"))for(var player:players){
                if(player.blockPosition().distSqr(pos)>14*14)continue;
                event.putBoolean("alerted",true);
                state.setDirty();
                for(var side:new BlockPos[]{pos.east(5),pos.west(5),pos.north(5)}){
                    if(!level.getBlockState(side.below()).isSolidRender(level,side.below()))continue;
                    if(RaidDirector.spawn(level,state,side,"stalker",player)!=null)break;
                }
                break;
            }
            return;
        }
        if(seconds<165||seconds%15!=0||event.getInt("used")>=2||seconds<event.getInt("next"))return;
        find(level,state,seconds,players);
    }

    static boolean find(ServerLevel level,RelayState state,int seconds,List<ServerPlayer> players){
        if(state.routeEvent.contains("position"))return false;
        for(var player:players){
            if(Math.hypot(player.getX()-state.centerX,player.getZ()-state.centerZ)<72)continue;
            var random=net.minecraft.util.RandomSource.create(state.seed^seconds^player.blockPosition().asLong());
            for(int i=0;i<12;i++){
                double angle=random.nextDouble()*Math.PI*2;
                int distance=30+random.nextInt(27);
                int x=player.getBlockX()+(int)(Math.cos(angle)*distance);
                int z=player.getBlockZ()+(int)(Math.sin(angle)*distance);
                var column=new BlockPos(x,0,z);
                if(!level.hasChunkAt(column)||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,x,z))continue;
                var pos=column.atY(level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z));
                if(Math.abs(pos.getY()-player.getY())>12||!place(level,state,pos,seconds))continue;
                for(var teammate:players)RaidRules.chat(teammate,"Радио · "+signal(state).title+" · КПК → Сигнал по пути");
                return true;
            }
        }
        return false;
    }

    static void clear(ServerLevel level,RelayState state){
        var event=state.routeEvent;
        if(!event.contains("position"))return;
        var pos=BlockPos.of(event.getLong("position"));
        var chest=level.getChunkAt(pos).getBlockEntity(pos);
        if(chest!=null&&chest.getPersistentData().getBoolean("relay_route_event"))level.removeBlock(pos,false);
        event.remove("position");
        state.setDirty();
    }

    static boolean place(ServerLevel level,RelayState state,BlockPos pos,int seconds){
        if(!level.isEmptyBlock(pos)||!level.isEmptyBlock(pos.above())||!level.getFluidState(pos).isEmpty()
            ||!level.getBlockState(pos.below()).isSolidRender(level,pos.below())
            ||StructureLevels.overlapsHistorical(level,state,pos,6))return false;
        level.setBlock(pos,Blocks.CHEST.defaultBlockState(),2);
        if(!(level.getBlockEntity(pos) instanceof ChestBlockEntity chest))return false;
        chest.setItem(0,new ItemStack(Items.IRON_NUGGET,2+state.activeLoot));
        RaidLoot.specialist(chest,level,state,pos,signal(state).supplies);
        PersonalLoot.convert(level,pos,chest);
        var personal=level.getBlockEntity(pos);
        if(personal!=null){personal.getPersistentData().putBoolean("relay_route_event",true);personal.setChanged();}
        var event=state.routeEvent;
        event.putLong("position",pos.asLong());
        event.putInt("until",seconds+140);
        event.putInt("next",seconds+260);
        event.putInt("used",event.getInt("used")+1);
        event.putBoolean("alerted",false);
        state.setDirty();
        return true;
    }

    static String status(RelayState state){
        return state.routeEvent.contains("position")?signal(state).title+" · нажмите для ориентира":"Свежих сигналов пока нет";
    }

    static void track(ServerPlayer player,RelayState state){
        if(!RaidRules.active(player)||!state.routeEvent.contains("position")){RaidRules.tell(player,"Нет активного полевого сигнала.");return;}
        var signal=signal(state);
        Navigation.waypoint(player,state.generation,BlockPos.of(state.routeEvent.getLong("position")),signal.title);
        RaidRules.chat(player,signal.clue);
    }

    private RouteEvents(){}
}
