package dev.bunkerrelay;

import java.util.*;
import com.tacz.guns.api.item.builder.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemLore;

/** Account, stock and inventory are saved together in vanilla player data. Server-thread only. */
public final class RelayEconomy {
 public static final String KEY="relay_economy";
 public static final long MAX_BALANCE=1_000_000_000L;
 public record Offer(String id,String name,String item,int quantity,int buy,int sell,int stock,boolean staple) {
  public ItemStack stack(ServerPlayer p){
   if(item.startsWith("ammo/"))return AmmoItemBuilder.create().setId(ResourceLocation.parse("tacz:"+item.substring(5))).setCount(quantity).build();
   if(item.startsWith("attachment/"))return AttachmentItemBuilder.create().setId(ResourceLocation.parse("tacz:"+item.substring(11))).build();
   if(item.startsWith("gun/"))return GunItemBuilder.create().setId(ResourceLocation.parse("tacz:"+item.substring(4))).setAmmoCount(0).build(p.registryAccess());
   return new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse(item)),quantity);
  }
 }
 private static final List<Offer> ORIGINAL=List.of(
  new Offer("9mm","Патроны 9 mm ×32","ammo/9mm",32,96,32,8,true),
  new Offer("762","Патроны 7.62×39 ×32","ammo/762x39",32,160,48,6,true),
  new Offer("glock","Glock 17 · без патронов","gun/glock_17",1,480,105,1,true),
  new Offer("bread","Хлеб ×8","minecraft:bread",8,32,8,6,true),
  new Offer("iron","Железо ×8","minecraft:iron_ingot",8,160,48,4,true),
  new Offer("copper","Медь ×16","minecraft:copper_ingot",16,96,24,4,true),
  new Offer("redstone","Редстоун ×16","minecraft:redstone",16,96,32,4,true),
  new Offer("ak47","АК-47 · без патронов","gun/ak47",1,1720,390,1,false),
  new Offer("gold","Золото ×4","minecraft:gold_ingot",4,200,60,3,false),
  new Offer("diamond","Алмаз","minecraft:diamond",1,400,120,2,false),
  new Offer("emerald","Изумруды ×4","minecraft:emerald",4,240,80,3,false),
  new Offer("quartz","Кварц ×16","minecraft:quartz",16,128,32,3,false),
  new Offer("coal","Уголь ×16","minecraft:coal",16,64,16,4,false),
  new Offer("slime","Слизь ×4","minecraft:slime_ball",4,120,32,3,false),
  new Offer("leather","Кожа ×8","minecraft:leather",8,96,24,3,false),
  new Offer("andesite","Андезит ×32","minecraft:andesite",32,64,16,4,false),
  new Offer("zinc","Цинк ×8","create:zinc_ingot",8,160,48,3,false),
  new Offer("brass","Латунь ×8","create:brass_ingot",8,320,80,2,false),
  new Offer("alloy","Андезитовый сплав ×8","create:andesite_alloy",8,160,40,3,false),
  new Offer("apple","Золотое яблоко","minecraft:golden_apple",1,240,60,2,false)
 );
 public enum Merchant { WEAPONS("Оружейник",Items.CROSSBOW),MECHANISMS("Механик",Items.PISTON),RESOURCES("Ресурсы",Items.IRON_INGOT),BUILDING("Строитель",Items.BRICKS),SUPPLIES("Снаряжение",Items.BREAD),MEDIC("Медик",Items.POTION);public final String title;public final Item icon;Merchant(String title,Item icon){this.title=title;this.icon=icon;} }
 private static final Map<String,Merchant> categories=new HashMap<>();
 public static final List<Offer> CATALOG=catalog();
 private static List<Offer> catalog(){var list=new ArrayList<>(ORIGINAL);
  list.add(new Offer("bandage","Бинт","bunkerrelay:bandage",1,20,5,16,true));categories.put("bandage",Merchant.MEDIC);
  list.add(new Offer("medkit","Аптечка","bunkerrelay:medkit",1,58,14,6,true));categories.put("medkit",Merchant.MEDIC);
  list.add(new Offer("m1911","M1911 · разряжено","gun/m1911",1,560,120,1,true));categories.put("m1911",Merchant.WEAPONS);
  list.add(new Offer("hk_mp5a5","MP5 · разряжено","gun/hk_mp5a5",1,1080,240,1,false));categories.put("hk_mp5a5",Merchant.WEAPONS);
  list.add(new Offer("m870","M870 · разряжено","gun/m870",1,900,205,1,false));categories.put("m870",Merchant.WEAPONS);
  list.add(new Offer("m4a1","M4A1 · разряжено","gun/m4a1",1,2350,515,1,false));categories.put("m4a1",Merchant.WEAPONS);
  list.add(new Offer("m700","M700 · разряжено","gun/m700",1,2400,600,1,false));categories.put("m700",Merchant.WEAPONS);
  list.add(new Offer("hk416d","HK416 · разряжено","gun/hk416d",1,2600,650,1,false));categories.put("hk416d",Merchant.WEAPONS);
  list.add(new Offer("scar_h","SCAR-H · разряжено","gun/scar_h",1,3100,685,1,false));categories.put("scar_h",Merchant.WEAPONS);
  list.add(new Offer("ak74m","АК-74М · разряжено","gun/ak74m",1,2100,525,1,false));categories.put("ak74m",Merchant.WEAPONS);
  list.add(new Offer("556x45","Патроны 556x45","ammo/556x45",32,160,48,5,true));categories.put("556x45",Merchant.WEAPONS);
  list.add(new Offer("12g","Патроны 12g","ammo/12g",32,128,48,6,true));categories.put("12g",Merchant.WEAPONS);
  list.add(new Offer("45acp","Патроны 45acp","ammo/45acp",32,128,48,6,true));categories.put("45acp",Merchant.WEAPONS);
  list.add(new Offer("308","Патроны 308","ammo/308",32,224,48,4,true));categories.put("308",Merchant.WEAPONS);
  list.add(new Offer("30_06","Патроны 30_06","ammo/30_06",32,208,48,4,true));categories.put("30_06",Merchant.WEAPONS);
  list.add(new Offer("545x39","Патроны 545x39","ammo/545x39",32,160,48,5,true));categories.put("545x39",Merchant.WEAPONS);
  list.add(new Offer("extended_mag_1","Магазин I","attachment/extended_mag_1",1,300,75,2,true));categories.put("extended_mag_1",Merchant.WEAPONS);
  list.add(new Offer("extended_mag_2","Магазин II","attachment/extended_mag_2",1,550,137,2,true));categories.put("extended_mag_2",Merchant.WEAPONS);
  list.add(new Offer("grip_vertical_military","Вертикальная рукоять","attachment/grip_vertical_military",1,360,90,2,true));categories.put("grip_vertical_military",Merchant.WEAPONS);
  list.add(new Offer("grip_magpul_afg","Рукоять Magpul","attachment/grip_magpul_afg",1,420,105,2,true));categories.put("grip_magpul_afg",Merchant.WEAPONS);
  list.add(new Offer("muzzle_silencer_socom_rc1","Глушитель SOCOM","attachment/muzzle_silencer_socom_rc1",1,680,170,2,true));categories.put("muzzle_silencer_socom_rc1",Merchant.WEAPONS);
  list.add(new Offer("muzzle_brake_cyclone_d2","Дульный тормоз Cyclone","attachment/muzzle_brake_cyclone_d2",1,440,110,2,true));categories.put("muzzle_brake_cyclone_d2",Merchant.WEAPONS);
  list.add(new Offer("scope_acog_ta31","Прицел ACOG","attachment/scope_acog_ta31",1,720,180,2,true));categories.put("scope_acog_ta31",Merchant.WEAPONS);
  list.add(new Offer("scope_retro_2x","Прицел 2×","attachment/scope_retro_2x",1,500,125,2,true));categories.put("scope_retro_2x",Merchant.WEAPONS);
  list.add(new Offer("shaft","Вал","create:shaft",1,12,3,8,true));categories.put("shaft",Merchant.MECHANISMS);
  list.add(new Offer("cogwheel","Шестерня","create:cogwheel",1,20,5,8,true));categories.put("cogwheel",Merchant.MECHANISMS);
  list.add(new Offer("large_cogwheel","Большая шестерня","create:large_cogwheel",1,32,8,8,true));categories.put("large_cogwheel",Merchant.MECHANISMS);
  list.add(new Offer("belt_connector","Ремень","create:belt_connector",1,40,10,8,true));categories.put("belt_connector",Merchant.MECHANISMS);
  list.add(new Offer("andesite_casing","Андезитовый корпус","create:andesite_casing",1,32,8,8,true));categories.put("andesite_casing",Merchant.MECHANISMS);
  list.add(new Offer("gearbox","Редуктор","create:gearbox",1,80,20,8,true));categories.put("gearbox",Merchant.MECHANISMS);
  list.add(new Offer("mechanical_press","Пресс","create:mechanical_press",1,240,60,8,true));categories.put("mechanical_press",Merchant.MECHANISMS);
  list.add(new Offer("mechanical_mixer","Смеситель","create:mechanical_mixer",1,280,70,8,true));categories.put("mechanical_mixer",Merchant.MECHANISMS);
  list.add(new Offer("basin","Чаша","create:basin",1,100,25,8,true));categories.put("basin",Merchant.MECHANISMS);
  list.add(new Offer("encased_fan","Вентилятор","create:encased_fan",1,200,50,8,true));categories.put("encased_fan",Merchant.MECHANISMS);
  list.add(new Offer("depot","Депо","create:depot",1,32,8,8,true));categories.put("depot",Merchant.MECHANISMS);
  list.add(new Offer("chute","Жёлоб","create:chute",1,40,10,8,true));categories.put("chute",Merchant.MECHANISMS);
  list.add(new Offer("andesite_funnel","Воронка","create:andesite_funnel",1,48,12,8,true));categories.put("andesite_funnel",Merchant.MECHANISMS);
  list.add(new Offer("water_wheel","Водяное колесо","create:water_wheel",1,180,45,8,true));categories.put("water_wheel",Merchant.MECHANISMS);
  list.add(new Offer("mechanical_pump","Помпа","create:mechanical_pump",1,180,45,8,true));categories.put("mechanical_pump",Merchant.MECHANISMS);
  list.add(new Offer("fluid_pipe","Труба","create:fluid_pipe",1,24,6,8,true));categories.put("fluid_pipe",Merchant.MECHANISMS);
  list.add(new Offer("mechanical_drill","Бур","create:mechanical_drill",1,320,80,8,true));categories.put("mechanical_drill",Merchant.MECHANISMS);
  list.add(new Offer("mechanical_saw","Пила","create:mechanical_saw",1,320,80,8,true));categories.put("mechanical_saw",Merchant.MECHANISMS);
  list.add(new Offer("deployer","Манипулятор","create:deployer",1,600,150,8,true));categories.put("deployer",Merchant.MECHANISMS);
  list.add(new Offer("lapis_lazuli","Лазурит","minecraft:lapis_lazuli",16,64,16,6,true));categories.put("lapis_lazuli",Merchant.RESOURCES);
  list.add(new Offer("flint","Кремень","minecraft:flint",16,64,16,6,true));categories.put("flint",Merchant.RESOURCES);
  list.add(new Offer("gunpowder","Порох","minecraft:gunpowder",16,64,16,6,true));categories.put("gunpowder",Merchant.RESOURCES);
  list.add(new Offer("string","Нить","minecraft:string",16,64,16,6,true));categories.put("string",Merchant.RESOURCES);
  list.add(new Offer("paper","Бумага","minecraft:paper",16,64,16,6,true));categories.put("paper",Merchant.RESOURCES);
  list.add(new Offer("bone","Кость","minecraft:bone",16,64,16,6,true));categories.put("bone",Merchant.RESOURCES);
  list.add(new Offer("clay_ball","Глина","minecraft:clay_ball",16,64,16,6,true));categories.put("clay_ball",Merchant.RESOURCES);
  list.add(new Offer("stone","Камень","minecraft:stone",1,2,1,128,true));categories.put("stone",Merchant.BUILDING);
  list.add(new Offer("cobblestone","Булыжник","minecraft:cobblestone",1,2,1,128,true));categories.put("cobblestone",Merchant.BUILDING);
  list.add(new Offer("dirt","Земля","minecraft:dirt",1,2,1,128,true));categories.put("dirt",Merchant.BUILDING);
  list.add(new Offer("sand","Песок","minecraft:sand",1,3,1,128,true));categories.put("sand",Merchant.BUILDING);
  list.add(new Offer("gravel","Гравий","minecraft:gravel",1,3,1,128,true));categories.put("gravel",Merchant.BUILDING);
  list.add(new Offer("oak_log","Дубовое бревно","minecraft:oak_log",1,8,2,128,true));categories.put("oak_log",Merchant.BUILDING);
  list.add(new Offer("spruce_log","Еловое бревно","minecraft:spruce_log",1,8,2,128,true));categories.put("spruce_log",Merchant.BUILDING);
  list.add(new Offer("oak_planks","Дубовые доски","minecraft:oak_planks",1,3,1,128,true));categories.put("oak_planks",Merchant.BUILDING);
  list.add(new Offer("glass","Стекло","minecraft:glass",1,5,1,128,true));categories.put("glass",Merchant.BUILDING);
  list.add(new Offer("stone_bricks","Каменные кирпичи","minecraft:stone_bricks",1,4,1,128,true));categories.put("stone_bricks",Merchant.BUILDING);
  list.add(new Offer("deepslate_bricks","Глубинный кирпич","minecraft:deepslate_bricks",1,4,1,128,true));categories.put("deepslate_bricks",Merchant.BUILDING);
  list.add(new Offer("bricks","Кирпичи","minecraft:bricks",1,5,1,128,true));categories.put("bricks",Merchant.BUILDING);
  list.add(new Offer("gray_concrete","Серый бетон","minecraft:gray_concrete",1,5,1,128,true));categories.put("gray_concrete",Merchant.BUILDING);
  list.add(new Offer("white_concrete","Белый бетон","minecraft:white_concrete",1,5,1,128,true));categories.put("white_concrete",Merchant.BUILDING);
  list.add(new Offer("iron_bars","Прутья","minecraft:iron_bars",1,8,2,128,true));categories.put("iron_bars",Merchant.BUILDING);
  list.add(new Offer("ladder","Лестница","minecraft:ladder",1,4,1,128,true));categories.put("ladder",Merchant.BUILDING);
  list.add(new Offer("iron_door","Железная дверь","minecraft:iron_door",1,40,10,128,true));categories.put("iron_door",Merchant.BUILDING);
  list.add(new Offer("iron_trapdoor","Железный люк","minecraft:iron_trapdoor",1,32,8,128,true));categories.put("iron_trapdoor",Merchant.BUILDING);
  list.add(new Offer("lantern","Фонарь","minecraft:lantern",1,20,5,128,true));categories.put("lantern",Merchant.BUILDING);
  list.add(new Offer("chain","Цепь","minecraft:chain",1,12,3,128,true));categories.put("chain",Merchant.BUILDING);
  list.add(new Offer("smooth_stone","Гладкий камень","minecraft:smooth_stone",1,3,1,128,true));categories.put("smooth_stone",Merchant.BUILDING);
  list.add(new Offer("polished_andesite","Полированный андезит","minecraft:polished_andesite",1,4,1,128,true));categories.put("polished_andesite",Merchant.BUILDING);
  list.add(new Offer("chest","Сундук","minecraft:chest",1,20,5,128,true));categories.put("chest",Merchant.BUILDING);
  list.add(new Offer("barrel","Бочка","minecraft:barrel",1,20,5,128,true));categories.put("barrel",Merchant.BUILDING);
  list.add(new Offer("furnace","Печь","minecraft:furnace",1,20,5,128,true));categories.put("furnace",Merchant.BUILDING);
  list.add(new Offer("crafting_table","Верстак","minecraft:crafting_table",1,12,3,128,true));categories.put("crafting_table",Merchant.BUILDING);
  list.add(new Offer("lever","Рычаг","minecraft:lever",1,4,1,128,true));categories.put("lever",Merchant.BUILDING);
  list.add(new Offer("torch","Факел","minecraft:torch",1,3,1,128,true));categories.put("torch",Merchant.BUILDING);
  list.add(new Offer("oak_fence","Забор","minecraft:oak_fence",1,4,1,128,true));categories.put("oak_fence",Merchant.BUILDING);
  list.add(new Offer("stone_brick_stairs","Ступени","minecraft:stone_brick_stairs",1,5,1,128,true));categories.put("stone_brick_stairs",Merchant.BUILDING);
  list.add(new Offer("stone_brick_slab","Плита","minecraft:stone_brick_slab",1,3,1,128,true));categories.put("stone_brick_slab",Merchant.BUILDING);
  list.add(new Offer("spruce_stairs","Еловые ступени","minecraft:spruce_stairs",1,5,1,128,true));categories.put("spruce_stairs",Merchant.BUILDING);
  list.add(new Offer("redstone_lamp","Лампа","minecraft:redstone_lamp",1,40,10,128,true));categories.put("redstone_lamp",Merchant.BUILDING);
  list.add(new Offer("sea_lantern","Морской фонарь","minecraft:sea_lantern",1,60,15,128,true));categories.put("sea_lantern",Merchant.BUILDING);
  list.add(new Offer("tinted_glass","Тонированное стекло","minecraft:tinted_glass",1,20,5,128,true));categories.put("tinted_glass",Merchant.BUILDING);
  list.add(new Offer("black_concrete","Чёрный бетон","minecraft:black_concrete",1,5,1,128,true));categories.put("black_concrete",Merchant.BUILDING);
  list.add(new Offer("iron_block","Железный блок","minecraft:iron_block",1,200,50,128,true));categories.put("iron_block",Merchant.BUILDING);
  list.add(new Offer("cooked_beef","Стейк","minecraft:cooked_beef",1,12,3,8,true));categories.put("cooked_beef",Merchant.SUPPLIES);
  list.add(new Offer("baked_potato","Картофель","minecraft:baked_potato",1,6,1,8,true));categories.put("baked_potato",Merchant.SUPPLIES);
  list.add(new Offer("golden_carrot","Золотая морковь","minecraft:golden_carrot",1,28,7,8,true));categories.put("golden_carrot",Merchant.SUPPLIES);
  list.add(new Offer("shield","Щит","minecraft:shield",1,100,25,8,true));categories.put("shield",Merchant.SUPPLIES);
  list.add(new Offer("iron_pickaxe","Кирка","minecraft:iron_pickaxe",1,140,35,8,true));categories.put("iron_pickaxe",Merchant.SUPPLIES);
  list.add(new Offer("iron_axe","Топор","minecraft:iron_axe",1,140,35,8,true));categories.put("iron_axe",Merchant.SUPPLIES);
  list.add(new Offer("bucket","Ведро","minecraft:bucket",1,100,25,8,true));categories.put("bucket",Merchant.SUPPLIES);
  list.add(new Offer("compass","Компас","minecraft:compass",1,120,30,8,true));categories.put("compass",Merchant.SUPPLIES);
  list.add(new Offer("white_bed","Кровать","minecraft:white_bed",1,60,15,8,true));categories.put("white_bed",Merchant.SUPPLIES);
  list.add(new Offer("iron_helmet","Шлем","minecraft:iron_helmet",1,200,50,8,true));categories.put("iron_helmet",Merchant.SUPPLIES);
  list.add(new Offer("iron_chestplate","Нагрудник","minecraft:iron_chestplate",1,320,80,8,true));categories.put("iron_chestplate",Merchant.SUPPLIES);
  list.add(new Offer("iron_leggings","Поножи","minecraft:iron_leggings",1,280,70,8,true));categories.put("iron_leggings",Merchant.SUPPLIES);
  list.add(new Offer("iron_boots","Ботинки","minecraft:iron_boots",1,160,40,8,true));categories.put("iron_boots",Merchant.SUPPLIES);
  categories.put("andesite",Merchant.BUILDING);categories.put("bread",Merchant.SUPPLIES);categories.put("apple",Merchant.SUPPLIES);  list.add(new Offer("aeronautics_wooden_propeller","Деревянный пропеллер","aeronautics:wooden_propeller",1,180,36,8,true));categories.put("aeronautics_wooden_propeller",Merchant.MECHANISMS);
  list.add(new Offer("aeronautics_andesite_propeller","Андезитовый пропеллер","aeronautics:andesite_propeller",1,320,64,8,true));categories.put("aeronautics_andesite_propeller",Merchant.MECHANISMS);
  list.add(new Offer("aeronautics_propeller_bearing","Подшипник пропеллера","aeronautics:propeller_bearing",1,650,130,8,true));categories.put("aeronautics_propeller_bearing",Merchant.MECHANISMS);
  list.add(new Offer("aeronautics_adjustable_burner","Горелка аэростата","aeronautics:adjustable_burner",1,750,150,2,true));categories.put("aeronautics_adjustable_burner",Merchant.MECHANISMS);
  list.add(new Offer("aeronautics_white_envelope","Оболочка аэростата","aeronautics:white_envelope",1,90,18,32,true));categories.put("aeronautics_white_envelope",Merchant.MECHANISMS);
  list.add(new Offer("simulated_physics_assembler","Сборщик физической конструкции","simulated:physics_assembler",1,1200,240,2,true));categories.put("simulated_physics_assembler",Merchant.MECHANISMS);
  list.add(new Offer("offroad_wheel_mount","Крепление колеса","offroad:wheel_mount",1,420,84,8,true));categories.put("offroad_wheel_mount",Merchant.MECHANISMS);
  list.add(new Offer("offroad_tire","Шина","offroad:tire",1,180,36,8,true));categories.put("offroad_tire",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_conductive_casing","Проводящий корпус","powergrid:conductive_casing",1,110,22,8,true));categories.put("powergrid_conductive_casing",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_device_connector","Разъём питания","powergrid:device_connector",1,70,14,32,true));categories.put("powergrid_device_connector",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_battery","Батарея","powergrid:battery",1,850,170,2,false));categories.put("powergrid_battery",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_electric_motor","Электромотор Power Grid","powergrid:electric_motor",1,1400,280,2,false));categories.put("powergrid_electric_motor",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_current_gauge","Амперметр","powergrid:current_gauge",1,240,48,8,true));categories.put("powergrid_current_gauge",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_solar_panel","Солнечная панель","powergrid:solar_panel",1,1000,200,2,false));categories.put("powergrid_solar_panel",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_lv_switch","Выключатель низкого напряжения","powergrid:lv_switch",1,60,12,32,true));categories.put("powergrid_lv_switch",Merchant.MECHANISMS);
  list.add(new Offer("powergrid_factory_light","Промышленный светильник","powergrid:factory_light",1,110,22,8,true));categories.put("powergrid_factory_light",Merchant.MECHANISMS);
  list.add(new Offer("createaddition_copper_wire","Медный провод","createaddition:copper_wire",1,20,4,32,true));categories.put("createaddition_copper_wire",Merchant.MECHANISMS);
  list.add(new Offer("createaddition_capacitor","Конденсатор","createaddition:capacitor",1,90,18,32,true));categories.put("createaddition_capacitor",Merchant.MECHANISMS);
  list.add(new Offer("createaddition_connector","Коннектор","createaddition:connector",1,80,16,32,true));categories.put("createaddition_connector",Merchant.MECHANISMS);
  list.add(new Offer("createaddition_rolling_mill","Прокатный стан","createaddition:rolling_mill",1,650,130,8,true));categories.put("createaddition_rolling_mill",Merchant.MECHANISMS);
  list.add(new Offer("createaddition_electric_motor","Электромотор FE","createaddition:electric_motor",1,1400,280,2,false));categories.put("createaddition_electric_motor",Merchant.MECHANISMS);
  list.add(new Offer("createaddition_alternator","Генератор FE","createaddition:alternator",1,1200,240,2,false));categories.put("createaddition_alternator",Merchant.MECHANISMS);
  list.add(new Offer("create_connected_brake","Тормоз","create_connected:brake",1,160,32,8,true));categories.put("create_connected_brake",Merchant.MECHANISMS);
  list.add(new Offer("create_connected_cross_connector","Перекрёстный вал","create_connected:cross_connector",1,90,18,32,true));categories.put("create_connected_cross_connector",Merchant.MECHANISMS);
  list.add(new Offer("create_connected_brass_gearbox","Латунный редуктор","create_connected:brass_gearbox",1,160,32,8,true));categories.put("create_connected_brass_gearbox",Merchant.MECHANISMS);
  list.add(new Offer("create_enchantment_industry_mechanical_grindstone","Механическое точило","create_enchantment_industry:mechanical_grindstone",1,600,120,8,true));categories.put("create_enchantment_industry_mechanical_grindstone",Merchant.MECHANISMS);
  list.add(new Offer("create_enchantment_industry_experience_hatch","Приёмник опыта","create_enchantment_industry:experience_hatch",1,260,52,8,true));categories.put("create_enchantment_industry_experience_hatch",Merchant.MECHANISMS);
  list.add(new Offer("create_enchantment_industry_printer","Принтер зачарований","create_enchantment_industry:printer",1,1500,300,2,false));categories.put("create_enchantment_industry_printer",Merchant.MECHANISMS);
  list.add(new Offer("copycats_copycat_block","Мимик-блок","copycats:copycat_block",1,22,4,32,true));categories.put("copycats_copycat_block",Merchant.BUILDING);
  list.add(new Offer("copycats_copycat_door","Мимик-дверь","copycats:copycat_door",1,40,8,32,true));categories.put("copycats_copycat_door",Merchant.BUILDING);
  list.add(new Offer("createdeco_andesite_catwalk","Промышленный настил","createdeco:andesite_catwalk",1,16,3,32,true));categories.put("createdeco_andesite_catwalk",Merchant.BUILDING);
  list.add(new Offer("createdeco_andesite_door","Промышленная дверь","createdeco:andesite_door",1,65,13,32,true));categories.put("createdeco_andesite_door",Merchant.BUILDING);
  list.add(new Offer("deagle","Desert Eagle", "gun/deagle",1,1080,240,1,false));
  list.add(new Offer("cz75","CZ 75", "gun/cz75",1,780,195,1,false));
  list.add(new Offer("hk_mp7a1","MP7A1", "gun/hk_mp7a1",1,1550,387,1,false));
  list.add(new Offer("ump45","UMP45", "gun/ump45",1,1450,362,1,false));
  list.add(new Offer("p90","P90", "gun/p90",1,1850,462,1,false));
  list.add(new Offer("vector45","Vector .45", "gun/vector45",1,1900,475,1,false));
  list.add(new Offer("aug","AUG", "gun/aug",1,2150,537,1,false));
  list.add(new Offer("g36k","G36K", "gun/g36k",1,2050,512,1,false));
  list.add(new Offer("fn_fal","FN FAL", "gun/fn_fal",1,2750,687,1,false));
  list.add(new Offer("sks_tactical","СКС Tactical", "gun/sks_tactical",1,1900,475,1,false));
  list.add(new Offer("m1014","M1014", "gun/m1014",1,1650,412,1,false));
  list.add(new Offer("spas_12","SPAS-12", "gun/spas_12",1,1900,475,1,false));
  list.add(new Offer("kar98","Kar98k", "gun/kar98",1,1700,425,1,false));
  list.add(new Offer("svd","СВД", "gun/svd",1,2750,687,1,false));
  list.add(new Offer("ai_awp","AWP", "gun/ai_awp",1,3200,800,1,false));
  list.add(new Offer("rpk","РПК", "gun/rpk",1,2800,700,1,false));
  list.add(new Offer("extended_mag_3","Магазин III", "attachment/extended_mag_3",1,800,200,3,true));
  list.add(new Offer("grip_cobra","Рукоять Cobra", "attachment/grip_cobra",1,420,105,3,true));
  list.add(new Offer("grip_td","Рукоять TD", "attachment/grip_td",1,400,100,3,true));
  list.add(new Offer("laser_peq15","PEQ-15 · подсветка K", "attachment/laser_peq15",1,540,135,3,true));
  list.add(new Offer("laser_ngal","NGAL · подсветка K", "attachment/laser_ngal",1,620,155,3,true));
  list.add(new Offer("muzzle_choke_sg","Чок для дробовика", "attachment/muzzle_choke_sg",1,350,87,3,true));
  list.add(new Offer("muzzle_silencer_sg","Глушитель для дробовика", "attachment/muzzle_silencer_sg",1,750,187,3,true));
  list.add(new Offer("muzzle_silencer_knight_qd","Глушитель Knight QD", "attachment/muzzle_silencer_knight_qd",1,720,180,3,true));
  list.add(new Offer("scope_lpvo_1_6","Прицел LPVO 1–6×", "attachment/scope_lpvo_1_6",1,820,205,3,true));
  list.add(new Offer("scope_pso_1","Прицел ПСО-1", "attachment/scope_pso_1",1,760,190,3,true));
  list.add(new Offer("scope_mk5hd","Прицел Mk5HD", "attachment/scope_mk5hd",1,980,245,3,true));
  list.add(new Offer("sight_t2","Коллиматор T2", "attachment/sight_t2",1,475,118,3,true));
  list.add(new Offer("sight_rmr_dot","Коллиматор RMR", "attachment/sight_rmr_dot",1,420,105,3,true));
  list.add(new Offer("ie_copper_wire","Катушка медного провода","immersiveengineering:wirecoil_copper",1,48,10,16,true));categories.put("ie_copper_wire",Merchant.MECHANISMS);
  list.add(new Offer("ie_electrum_wire","Катушка электрумового провода","immersiveengineering:wirecoil_electrum",1,110,22,12,true));categories.put("ie_electrum_wire",Merchant.MECHANISMS);
  list.add(new Offer("ie_lv_connector","Разъём НН","immersiveengineering:connector_lv",1,56,12,16,true));categories.put("ie_lv_connector",Merchant.MECHANISMS);
  list.add(new Offer("ie_lv_relay","Реле НН","immersiveengineering:connector_lv_relay",1,38,8,16,true));categories.put("ie_lv_relay",Merchant.MECHANISMS);
  list.add(new Offer("mek_osmium","Слиток осмия","mekanism:ingot_osmium",4,96,20,6,true));
  list.add(new Offer("mek_uranium","Слиток урана","mekanism:ingot_uranium",4,160,32,4,true));
  list.add(new Offer("mek_fluorite","Флюорит","mekanism:fluorite_gem",4,120,24,4,true));
  for(String id:List.of("mek_osmium","mek_uranium","mek_fluorite"))categories.put(id,Merchant.MECHANISMS);
  list.add(new Offer("mek_basic","Базовая схема","mekanism:basic_control_circuit",1,96,25,6,true));categories.put("mek_basic",Merchant.MECHANISMS);
  list.add(new Offer("mek_advanced","Продвинутая схема","mekanism:advanced_control_circuit",1,228,64,2,false));categories.put("mek_advanced",Merchant.MECHANISMS);
  list.add(new Offer("mek_elite","Элитная схема","mekanism:elite_control_circuit",1,520,125,1,false));categories.put("mek_elite",Merchant.MECHANISMS);
  list.add(new Offer("field_flashlight","Ручной фонарь · клавиша K","relaylights:flashlight",1,64,16,4,true));categories.put("field_flashlight",Merchant.SUPPLIES);
  return list.stream().map(o->{
   int factor=o.id().equals("glock")?85:o.item().startsWith("gun/")?180:o.item().startsWith("attachment/")?140:
       o.item().startsWith("ammo/")?115:merchant(o)==Merchant.MEDIC?90:merchant(o)==Merchant.MECHANISMS?130:110;
   return new Offer(o.id(),o.name(),o.item(),o.quantity(),(o.buy()*factor+99)/100,
       Math.max(1,o.sell()*factor/100),o.stock(),o.staple());
  }).toList();}
 public static Merchant merchant(Offer o){return o.item().contains("/")?Merchant.WEAPONS:categories.getOrDefault(o.id(),Merchant.RESOURCES);}
 public static int unitSell(Offer o){return Math.max(1,o.sell()/o.quantity());}
 public static int unitBuy(ServerPlayer p,Offer o){return Math.max(unitSell(o)+1,(price(p,o)+o.quantity()-1)/o.quantity());}
 public static int remainingUnits(ServerPlayer p,Offer o){return Math.max(0,o.stock()*o.quantity()-account(p).getCompound("bought").getInt(o.id())*o.quantity()-account(p).getCompound("boughtUnits").getInt(o.id()));}
 public static int owned(ServerPlayer p,Offer o){var target=o.stack(p);if(target.isEmpty())return 0;return p.getInventory().items.stream().filter(s->ItemStack.isSameItemSameComponents(s,target)).mapToInt(ItemStack::getCount).sum();}
 public static String trade(ServerPlayer p,Offer o,boolean selling,int requested){
  if(!safe(p)||!CATALOG.contains(o)||requested<=0)return "Сделка недоступна.";var a=account(p);var target=o.stack(p);if(target.isEmpty())return "Товар отсутствует в установленных модах.";
  int cost=selling?unitSell(o):unitBuy(p,o),count;
  if(selling)count=(int)Math.min(Math.min(requested,owned(p,o)),Math.min(a.getInt("budget")/cost,(MAX_BALANCE-balance(p))/cost));
  else{if(!offers(p).contains(o))return "Товар отсутствует в поставке.";count=(int)Math.min(Math.min(requested,remainingUnits(p,o)),Math.min(balance(p)/cost,SafeInventory.capacity(p.getInventory(),target)));}
  if(count<=0)return selling?"Нет подходящих предметов или исчерпан бюджет.":"Недостаточно денег, места или товара.";
  if(selling){int left=count;for(var stack:p.getInventory().items)if(left>0&&ItemStack.isSameItemSameComponents(stack,target)){int n=Math.min(left,stack.getCount());stack.shrink(n);left-=n;}a.putLong("balance",balance(p)+(long)count*cost);a.putInt("budget",a.getInt("budget")-count*cost);}
  else{target.setCount(count);SafeInventory.insert(p.getInventory(),target);a.putLong("balance",balance(p)-(long)count*cost);var bought=a.getCompound("boughtUnits");bought.putInt(o.id(),bought.getInt(o.id())+count);a.put("boughtUnits",bought);}
  save(p);return (selling?"Продано":"Куплено")+": "+count+" шт. · "+((long)count*cost)+" кр. · счёт "+balance(p);
 }
 public static CompoundTag account(ServerPlayer p){
  var data=p.getPersistentData();if(!data.contains(KEY,Tag.TAG_COMPOUND)){var a=new CompoundTag();a.putLong("balance",300);a.putInt("budget",600);data.put(KEY,a);}var a=data.getCompound(KEY);if(a.getInt("tradeVersion")<2){a.putInt("budget",Math.min(1200,Math.max(0,a.getInt("budget"))+600));a.putInt("tradeVersion",2);}return a;
 }
 public static long balance(ServerPlayer p){return account(p).getLong("balance");}
 public static boolean safe(ServerPlayer p){return p.isAlive()&&!RaidRules.active(p)&&Set.of(BunkerRelay.HUB,BunkerRelay.BUNKER,BunkerRelay.GARAGE).contains(p.level().dimension());}
 public static void save(ServerPlayer p){p.getInventory().setChanged();p.inventoryMenu.broadcastChanges();p.server.getPlayerList().saveAll();}
 public static List<Offer> offers(ServerPlayer p){
  int rotation=account(p).getInt("rotation");
  var list=new ArrayList<Offer>();
  for(var merchant:Merchant.values()){
   var stock=CATALOG.stream().filter(o->merchant(o)==merchant).toList();
   stock.stream().filter(RelayEconomy::permanent).forEach(list::add);
   if(merchant==Merchant.WEAPONS){
    rotate(list,stock.stream().filter(o->!permanent(o)&&o.item().startsWith("gun/")).toList(),p,rotation,4);
    rotate(list,stock.stream().filter(o->!permanent(o)&&o.item().startsWith("attachment/")).toList(),p,rotation,9);
   }else rotate(list,stock.stream().filter(o->!permanent(o)).toList(),p,rotation,5);
  }
  return list;
 }
 private static boolean permanent(Offer offer){
  if(offer.item().startsWith("attachment/"))return offer.staple()&&(offer.buy()<=420||offer.id().equals("laser_peq15"));
  return offer.staple();
 }
 private static void rotate(List<Offer> output,List<Offer> offers,ServerPlayer p,int rotation,int size){
  if(offers.isEmpty())return;
  int offset=Math.floorMod((long)p.getUUID().hashCode()+rotation*(long)size,offers.size());
  for(int i=0;i<Math.min(size,offers.size());i++)output.add(offers.get((offset+i)%offers.size()));
 }
 public static int extractionReward(int difficulty){
  int tier=Math.clamp(difficulty,1,5);
  return 130+50*tier+5*tier*tier;
 }
 public static int price(ServerPlayer p,Offer o){return (o.buy()*(100-SupplyOrders.discount(p)-(BaseUpgrades.has(p,BaseUpgrades.Upgrade.SUPPLY)?5:0)-(merchant(o)==Merchant.MEDIC&&BunkerRequests.Request.MEDIC.complete(RelayState.get(p.server))?15:0))+99)/100;}
 public static int remaining(ServerPlayer p,Offer o){return remainingUnits(p,o)/o.quantity();}
 public static String buy(ServerPlayer p,Offer o){return trade(p,o,false,o.quantity());}
 public static String sell(ServerPlayer p,Offer o){return trade(p,o,true,o.quantity());}
 static int extractionCredit(ServerPlayer p,CompoundTag raid){
  if(!raid.contains("contractCycle")||account(p).getCompound("paidZones").contains(raid.getString("contractCycle")))return 0;
  int reward=extractionReward(raid.getInt("economyDifficulty"))+(SkillMenu.has(p,SkillMenu.Skill.DEALER)?60:0);
  return (int)Math.min(reward,MAX_BALANCE-balance(p));
 }
 /** Persist receipt and credit in the same player save before removing the raid journal entry. */
 public static void extracted(ServerPlayer p,CompoundTag raid){
  if(!raid.getString("status").equals("COMMIT")||!raid.contains("contractCycle"))return;
  var a=account(p);String cycle=raid.getString("contractCycle");var paid=a.getCompound("paidZones");if(paid.contains(cycle))return;
  int tier=Math.clamp(raid.getInt("economyDifficulty"),1,5);
  int reward=extractionCredit(p,raid);
  a.putLong("balance",Math.min(MAX_BALANCE,balance(p)+reward));paid.putBoolean(cycle,true);a.put("paidZones",paid);a.putInt("rotation",a.getInt("rotation")+1);a.putInt("budget",(600+200*tier+(BaseUpgrades.has(p,BaseUpgrades.Upgrade.SUPPLY)?400:0))+(TrophyResearch.has(RelayState.get(p.server),TrophyResearch.Part.SCANNER)?200:0)+(SkillMenu.has(p,SkillMenu.Skill.BROKER)?250:0));a.remove("bought");a.remove("boughtUnits");SupplyOrders.onExtract(p);save(p);
  RaidRules.tell(p,"На счёт начислено "+reward+" кр. Поставка торговца обновлена; бюджет скупщика: "+a.getInt("budget")+" кр. Торговля через терминал.");
 }
 public static int wallet(ServerPlayer p){RaidRules.tell(p,"Счёт: "+balance(p)+" кр. Бюджет скупщика: "+account(p).getInt("budget")+" кр. Торговля через терминал. · /relay sell");return 1;}
 public static int open(ServerPlayer p,boolean selling){if(!safe(p)){RaidRules.tell(p,"Магазин доступен только в бункере или гараже после вылазки.");return 0;}account(p);save(p);p.openMenu(new SimpleMenuProvider((id,inv,player)->new MarketMenu(id,inv,p,selling),Component.literal(selling?"Скупщик · кредиты":"Торговец · кредиты")));return 1;}
 public static int open(ServerPlayer p,boolean selling,Merchant merchant){if(!safe(p))return 0;save(p);p.openMenu(new SimpleMenuProvider((id,inv,player)->new MarketMenu(id,inv,p,selling,merchant),Component.literal(selling?"Скупщик":"Торговцы базы")));return 1;}
 static int openPocket(ServerPlayer p,boolean selling,Merchant merchant){
  if(!safe(p))return 0;
  save(p);p.openMenu(new SimpleMenuProvider((id,inv,player)->new MarketMenu(id,inv,p,selling,merchant,new SimpleContainer(54),true),
   Component.literal(selling?"Скупщик":"Торговцы базы")));return 1;
 }
 public static final class MarketMenu extends ChestMenu {
  private final ServerPlayer owner;private final SimpleContainer panel;private final boolean pocket;private boolean selling;private Merchant category;private int page,rotation,armoryFilter;private List<Offer> visible;
  public MarketMenu(int id,Inventory inv){super(RelayMenus.MARKET.get(),id,inv,new SimpleContainer(54),6);owner=null;panel=(SimpleContainer)getContainer();pocket=false;}
 public MarketMenu(int id,Inventory inv,ServerPlayer p,boolean selling){this(id,inv,p,selling,Merchant.WEAPONS);}
  public MarketMenu(int id,Inventory inv,ServerPlayer p,boolean selling,Merchant category){this(id,inv,p,selling,category,new SimpleContainer(54),false);}
  private MarketMenu(int id,Inventory inv,ServerPlayer p,boolean selling,Merchant category,SimpleContainer c,boolean pocket){super(RelayMenus.MARKET.get(),id,inv,c,6);owner=p;panel=c;this.pocket=pocket;this.selling=selling;this.category=category;rotation=account(p).getInt("rotation");relist();refresh();}
  private void relist(){visible=(selling?CATALOG:offers(owner)).stream().filter(o->merchant(o)==category).filter(o->category!=Merchant.WEAPONS||armoryFilter==0||o.item().startsWith(armoryFilter==1?"gun/":armoryFilter==2?"attachment/":"ammo/")).toList();page=0;}
  private void icon(int slot,ItemStack stack,String title,String... lore){stack=stack.copyWithCount(1);stack.set(DataComponents.CUSTOM_NAME,Component.literal(title));stack.set(DataComponents.LORE,new ItemLore(Arrays.stream(lore).map(Component::literal).map(c->(Component)c).toList()));panel.setItem(slot,stack);}
  private void refresh(){panel.clearContent();var warehouse=new Warehouse(owner);for(var m:Merchant.values())icon(m.ordinal(),new ItemStack(m.icon),(m==category?"▶ ":"")+m.title,"Открыть раздел");
   icon(7,new ItemStack(Items.GOLD_NUGGET),"Счёт: "+balance(owner)+" кр.","Бюджет скупщика: "+account(owner).getInt("budget"));icon(8,new ItemStack(selling?Items.HOPPER:Items.EMERALD),selling?"СКУПКА":"МАГАЗИН","ЛКМ: 1 шт. · ПКМ: максимум");
   if(selling){for(int i=0;i<36;i++){
    var stack=getSlot(54+i).getItem();if(stack.isEmpty())continue;
    int quote=SalvageValue.price(stack);
    icon(9+i,stack,stack.getHoverName().getString(),(quote>0?quote+" кр./шт. · "+stack.getCount()+" шт.":"Не принимается")+" · склад "+warehouse.count(stack),
      "ЛКМ — 1 шт. · ПКМ — максимум");
   }}
   if(!selling)for(int i=0;i<36&&page*36+i<visible.size();i++){var o=visible.get(page*36+i);var stack=o.stack(owner);if(!stack.isEmpty())icon(9+i,stack,o.name().replaceAll(" ×[0-9]+$",""),unitBuy(owner,o)+" кр./шт. · запас "+remainingUnits(owner,o)+" · склад "+warehouse.count(stack),"В рюкзаке "+owned(owner,o),(permanent(o)?"Постоянный товар":"Поставка №"+rotation),"ЛКМ — 1 шт. · ПКМ — максимум",o.item().startsWith("attachment/")?"Совместимость зависит от оружия":"Принимаются предметы без изменений");}
   if(BaseUpgrades.has(owner,BaseUpgrades.Upgrade.STORAGE))icon(51,new ItemStack(Items.BARREL),"Продать со склада",warehouse.entries().size()+" позиций в каталоге");
   if(!selling&&category==Merchant.WEAPONS)icon(6,new ItemStack(Items.SPYGLASS),new String[]{"Вся оружейная","Оружие","Модули","Боеприпасы"}[armoryFilter],"Нажмите для смены фильтра");
   if(!selling){icon(45,new ItemStack(Items.ARROW),"Назад","");icon(46,new ItemStack(Items.ARROW),"Далее","");}icon(48,new ItemStack(Items.CHEST),selling?"Купить":"Продать","Смена режима");icon(49,new ItemStack(Items.PAPER),"Страница "+(page+1)+" / "+Math.max(1,(visible.size()+35)/36),"Поставка №"+rotation);icon(50,new ItemStack(Items.WRITABLE_BOOK),"Заказы",SupplyOrders.title(owner));icon(52,new ItemStack(Items.LODESTONE),pocket?"КПК · Магазин":"Терминал","");icon(53,new ItemStack(Items.BOOK),"ЛКМ: 1 · ПКМ: максимум","Скупка по оценке предмета","Контейнеры с содержимым исключены.");
  }
  @Override public void clicked(int slot,int button,ClickType type,Player p){if(p!=owner||!safe(owner)||type!=ClickType.PICKUP||button<0||button>1)return;if(rotation!=account(owner).getInt("rotation")){rotation=account(owner).getInt("rotation");relist();refresh();sendAllDataToRemote();return;}
   if(slot>=0&&slot<Merchant.values().length){category=Merchant.values()[slot];relist();}else if(slot==6&&category==Merchant.WEAPONS){armoryFilter=(armoryFilter+1)%4;relist();}else if(slot>=9&&slot<45){int index=page*36+slot-9;if(selling)RaidRules.tell(owner,SalvageValue.sellSlot(owner,getSlot(54+slot-9).getItem(),button==0?1:Integer.MAX_VALUE));else if(index<visible.size())RaidRules.tell(owner,trade(owner,visible.get(index),false,button==0?1:Integer.MAX_VALUE));}
   else if(slot>=54&&slot<slots.size()&&selling){RaidRules.tell(owner,SalvageValue.sellSlot(owner,getSlot(slot).getItem(),button==0?1:Integer.MAX_VALUE));}
   else if(slot==45)page=Math.max(0,page-1);else if(slot==46)page=Math.min(Math.max(0,(visible.size()-1)/36),page+1);else if(slot==48){selling=!selling;relist();}else if(slot==50){if(pocket)SupplyOrders.openPocket(owner);else SupplyOrders.open(owner);return;}else if(slot==51){BaseUpgrades.locker(owner,pocket,true,category);return;}else if(slot==52){if(pocket)PocketDevice.open(owner,PocketDevice.Page.SHOP);else BunkerRelay.openTerminal(owner);return;}refresh();sendAllDataToRemote();
  }
  @Override public ItemStack quickMoveStack(Player p,int slot){return ItemStack.EMPTY;}
  @Override public boolean stillValid(Player p){return p==owner&&safe(owner);}
 }
 private RelayEconomy(){}
}
