package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class MeetingIntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        var zone=server.getLevel(BunkerRelay.key(state.activeDimension));
        state.activeSize=2048;
        state.ready=true;
        int y=zone.getMaxBuildHeight()-24;
        var receiver=new FakePlayer(zone,new GameProfile(UUID.randomUUID(),"MeetingReceiver"));
        var sender=new FakePlayer(zone,new GameProfile(UUID.randomUUID(),"MeetingSender"));
        receiver.moveTo(100.5,y,.5,0,0);
        sender.moveTo(240.5,y,.5,0,0);
        check(RaidRules.begin(receiver,state)==null&&RaidRules.begin(sender,state)==null,"active teammates");
        check(!MeetingSignals.share(sender,state,List.of(sender))&&!RaidDoubles.isolated(sender,List.of(sender)),"solo raid");
        check(RaidDoubles.isolated(receiver,List.of(receiver,sender)),"split team");
        var menu=new PocketDevice.Menu(12,receiver.getInventory(),receiver,PocketDevice.Page.ROUTES);
        receiver.containerMenu=menu;
        check(menu.getSlot(13).getItem().get(DataComponents.LORE).lines().getFirst().getString()
            .equals(MeetingSignals.ownCode(receiver,state)),"group code visible in PDA");

        check(MeetingSignals.share(sender,state,List.of(sender,receiver)),"real signal");
        var real=MeetingSignals.current(receiver,state);
        check(real!=null&&real.position().equals(sender.blockPosition())&&!real.decoy()
            &&real.caption().contains(MeetingSignals.ownCode(sender,state)),"authentic position and code");
        menu.clicked(15,0,ClickType.PICKUP,receiver);
        check(MeetingSignals.tracked(receiver,state)==real&&Navigation.text(receiver,state).contains("Точка встречи"),"PDA route");

        var spawn=new BlockPos(136,y,0);
        zone.setBlock(spawn.below(),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        check(RaidDoubles.spawn(zone,state,receiver,sender),"actual double spawned");
        var decoy=MeetingSignals.current(receiver,state);
        check(decoy!=null&&decoy.position().equals(spawn)&&decoy.decoy()&&decoy.code()!=real.code()
            &&decoy.sender().equals(real.sender()),"deceptive position and mismatched code");
        check(MeetingSignals.current(sender,state)==null&&MeetingSignals.tracked(receiver,state)==null,"personal inbox and deliberate routing");
        menu.clicked(15,0,ClickType.PICKUP,receiver);
        check(MeetingSignals.tracked(receiver,state)==decoy,"explicit decoy tracking");

        RaidDirector.toggleScares(receiver);
        check(MeetingSignals.current(receiver,state)==real&&MeetingSignals.tracked(receiver,state)==null,"quiet mode removes decoy but restores genuine signal");
        MeetingSignals.imitate(receiver,sender,state,spawn);
        check(MeetingSignals.current(receiver,state)==real,"quiet mode prevents new decoys");
        check(MeetingSignals.share(sender,state,List.of(sender,receiver)),"quiet mode keeps team signals");
        state.generation++;
        check(MeetingSignals.current(receiver,state)==null,"signal cannot cross cycle");
        MeetingSignals.reset();
        System.out.println("RELAY_MEETING_PASS pda=true real=true decoy=true quiet=true solo=true cycle=true");
        server.halt(false);
    }

    private static void check(boolean condition,String message){
        if(!condition)throw new IllegalStateException("Meeting test: "+message);
    }

    private MeetingIntegrationTest(){}
}
