package dev.bunkerrelay;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.level.ServerLevel;

public final class ExpeditionLight {
    static boolean offer(RelayState state,ZoneProfile zone){
        if(!state.lightOffers.contains(zone.id))reroll(state,zone);
        return state.lightOffers.getBoolean(zone.id);
    }

    static void reroll(RelayState state,ZoneProfile zone){
        state.lightOffers.putBoolean(zone.id,ThreadLocalRandom.current().nextInt(100)<35);
        state.setDirty();
    }

    static void accept(RelayState state){
        var zone=ZoneProfile.of(state.activeTheme);
        state.nightRaid=offer(state,zone);
        state.fixedRaidLight=true;
        state.lightOffers.remove(zone.id);
        state.routeEvent=new net.minecraft.nbt.CompoundTag();
        state.setDirty();
    }

    public static boolean fixed(ServerLevel level){
        if(!BunkerRelay.expedition(level))return false;
        var state=RelayState.get(level.getServer());
        return state.fixedRaidLight&&(state.ready||state.generating)
            &&level.dimension().equals(BunkerRelay.key(state.activeDimension));
    }

    public static long time(ServerLevel level){
        return RelayState.get(level.getServer()).nightRaid?18000:6000;
    }

    private ExpeditionLight(){}
}
