package dev.bunkerrelay;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.BackpackStorage;
/** Frozen inventory + complete external UUID graph, restored under fresh private UUIDs. */
public final class RaidSnapshot {
 private static final String UUID_KEY="sophisticatedcore:storage_uuid";
 public static CompoundTag capture(ServerPlayer p){
  CompoundTag out=new CompoundTag();ListTag inventory=p.getInventory().save(new ListTag());
  validate(inventory,0);Map<UUID,UUID> ids=new LinkedHashMap<>();CompoundTag packs=new CompoundTag();
  discover(inventory,ids,packs,0);remap(inventory,ids,0);
  CompoundTag cloned=new CompoundTag();for(String k:packs.getAllKeys()){var data=packs.getCompound(k).copy();remap(data,ids,0);cloned.put(ids.get(UUID.fromString(k)).toString(),data);}
  out.put("inventory",inventory);out.put("packs",cloned);out.putInt("selected",p.getInventory().selected);out.putInt("xpTotal",p.totalExperience);out.putInt("xpLevel",p.experienceLevel);out.putFloat("xpProgress",p.experienceProgress);return out;
 }
 /** Recovery checkpoint of the successful exit; preserve live backpack identities. */
 public static CompoundTag captureLive(ServerPlayer p){
  var out=new CompoundTag();var inventory=p.getInventory().save(new ListTag());var packs=new CompoundTag();
  discover(inventory,new LinkedHashMap<>(),packs,0);
  out.put("inventory",inventory);out.put("packs",packs);out.putInt("selected",p.getInventory().selected);out.putInt("xpTotal",p.totalExperience);out.putInt("xpLevel",p.experienceLevel);out.putFloat("xpProgress",p.experienceProgress);return out;
 }
 public static void apply(ServerPlayer p,CompoundTag snapshot){
  CompoundTag packs=snapshot.getCompound("packs");
  for(String k:packs.getAllKeys()){
   UUID id=UUID.fromString(k);BackpackStorage.get(p.serverLevel()).removeBackpackContents(id);
   BackpackStorage.get(p.serverLevel()).setBackpackContents(id,packs.getCompound(k).copy());
  }
  p.getInventory().clearContent();p.getInventory().load(snapshot.getList("inventory",Tag.TAG_COMPOUND).copy());p.getInventory().selected=snapshot.getInt("selected");
  p.totalExperience=snapshot.getInt("xpTotal");p.experienceLevel=snapshot.getInt("xpLevel");p.experienceProgress=snapshot.getFloat("xpProgress");p.getInventory().setChanged();
 }
 public static String reject(ItemStack stack,ServerPlayer p){return reject(stack,p.registryAccess());}
 public static String reject(ItemStack stack,net.minecraft.core.HolderLookup.Provider registry){
  try{if(!stack.isEmpty()){Tag t=stack.save(registry);validate(t,0);discover(t,new LinkedHashMap<>(),new CompoundTag(),0);}return null;}catch(IllegalArgumentException ex){return ex.getMessage();}
 }
 private static void discover(Tag t,Map<UUID,UUID> ids,CompoundTag packs,int depth){
  if(depth>64||ids.size()>128)throw new IllegalArgumentException("Слишком сложная вложенность рюкзаков (до 128 хранилищ).");
  if(t instanceof CompoundTag c){
   if(c.hasUUID(UUID_KEY)){
    UUID old=c.getUUID(UUID_KEY);if(!ids.containsKey(old)){
     ids.put(old,UUID.randomUUID());CompoundTag contents=BackpackStorage.get().getOrCreateBackpackContents(old).copy();validate(contents,0);packs.put(old.toString(),contents);discover(contents,ids,packs,depth+1);
    }
   }
   for(String key:c.getAllKeys())discover(c.get(key),ids,packs,depth+1);
  }else if(t instanceof ListTag l)for(Tag v:l)discover(v,ids,packs,depth+1);
 }
 private static void remap(Tag t,Map<UUID,UUID> ids,int depth){
  if(depth>64)throw new IllegalArgumentException("Слишком глубокий NBT.");
  if(t instanceof CompoundTag c){if(c.hasUUID(UUID_KEY))c.putUUID(UUID_KEY,ids.get(c.getUUID(UUID_KEY)));for(String k:c.getAllKeys())remap(c.get(k),ids,depth+1);}
  else if(t instanceof ListTag l)for(Tag v:l)remap(v,ids,depth+1);
 }
 private static void validate(Tag t,int depth){
  if(depth>64)throw new IllegalArgumentException("Слишком глубокий NBT.");
  if(t instanceof CompoundTag c){
   for(String k:c.getAllKeys()){
    validate(c.get(k),depth+1);
   }
  }else if(t instanceof ListTag l)for(Tag v:l)validate(v,depth+1);
 }
 private RaidSnapshot(){}
}
