package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;

final class RaidVisuals {
    static double descentHeight(double secondsLeft) {
        return 2.5 * Math.clamp(secondsLeft, 0, 20);
    }

    static void dropFrame(ServerLevel level, BlockPos site, double secondsLeft) {
        double x=site.getX()+.5, y=site.getY()+descentHeight(secondsLeft), z=site.getZ()+.5;
        if (y+3.4>=level.getMaxBuildHeight()) return;
        for (ServerPlayer viewer : level.players()) {
            if (viewer.distanceToSqr(x,site.getY(),z)>64*64) continue;
            level.sendParticles(viewer,ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,true,x,y+.3,z,2,.18,.12,.18,.005);
            for (int i=0;i<8;i++) {
                double angle=i*Math.PI/4;
                double dx=Math.cos(angle),dz=Math.sin(angle);
                dropDot(viewer,ParticleTypes.END_ROD,x+dx*1.5,y+2.6,z+dz*1.5);
                if(i%2==0) {
                    dropDot(viewer,ParticleTypes.ELECTRIC_SPARK,x+dx*.75,y+1.5,z+dz*.75);
                    dropDot(viewer,ParticleTypes.WAX_ON,x+dx*.32,y+.35,z+dz*.32);
                }
            }
            dropDot(viewer,ParticleTypes.END_ROD,x,y+3.1,z);
        }
    }

    private static void dropDot(ServerPlayer viewer,ParticleOptions particle,double x,double y,double z) {
        viewer.serverLevel().sendParticles(viewer,particle,true,x,y,z,1,0,0,0,0);
    }

    static void landing(ServerLevel level, BlockPos site) {
        level.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,site.getX()+.5,site.getY()+.65,site.getZ()+.5,24,.5,.3,.5,.035);
        ring(level,site,2.1,.25,16,0,ParticleTypes.POOF);
    }

    static void beacon(ServerLevel level,BlockPos site,long tick) {
        double phase=tick*.14;
        ring(level,site,1.15,.85,6,phase,ParticleTypes.FLAME);
        dot(level,ParticleTypes.END_ROD,site.getX()+.5,site.getY()+1.25,site.getZ()+.5);
    }

    static void breachFrame(ServerLevel level,BlockPos site,double fraction) {
        int steps=Math.clamp(1+(int)(fraction*12),1,12);
        ring(level,site,1.05,1.05,12,0,ParticleTypes.SMOKE);
        for(int i=0;i<steps;i++) {
            double angle=i*Math.PI/6;
            dot(level,ParticleTypes.ELECTRIC_SPARK,site.getX()+.5+Math.cos(angle)*1.05,site.getY()+1.15,
                site.getZ()+.5+Math.sin(angle)*1.05);
        }
    }

    static void unlocked(ServerLevel level,BlockPos crate) {
        ring(level,crate,1.1,.95,12,0,ParticleTypes.HAPPY_VILLAGER);
        level.sendParticles(ParticleTypes.WAX_ON,crate.getX()+.5,crate.getY()+1,crate.getZ()+.5,12,.35,.22,.35,.015);
    }

    static void extraction(ServerLevel level,BlockPos point,int ticksLeft) {
        double phase=level.getGameTime()*.11;
        double radius=ticksLeft<=60?1.2+ticksLeft/60.0:2.2;
        ring(level,point,radius,.18,8,phase,ParticleTypes.WAX_ON);
        if(ticksLeft<=60) ring(level,point,radius,1.2,8,-phase,ParticleTypes.END_ROD);
    }

    static void apparition(ServerPlayer target,Mob mob) {
        if(!RaidHorror.enabled(target))return;
        target.serverLevel().sendParticles(target,ParticleTypes.SMOKE,true,mob.getX(),mob.getY()+.8,mob.getZ(),
            18,.48,.6,.48,.016);
    }

    static void clue(ServerPlayer player,double x,double z) {
        for (int i=0;i<3;i++) {
            double fraction=1-i*.1;
            player.serverLevel().sendParticles(player,ParticleTypes.LARGE_SMOKE,false,
                player.getX()+(x-player.getX())*fraction,player.getY()+.18,
                player.getZ()+(z-player.getZ())*fraction,1,.06,.02,.06,.004);
        }
    }

    private static void ring(ServerLevel level,BlockPos site,double radius,double height,int steps,double phase,ParticleOptions particle) {
        for (int i=0;i<steps;i++) {
            double angle=phase+i*2*Math.PI/steps;
            dot(level,particle,site.getX()+.5+radius*Math.cos(angle),site.getY()+height,site.getZ()+.5+radius*Math.sin(angle));
        }
    }

    private static void dot(ServerLevel level,ParticleOptions particle,double x,double y,double z) {
        level.sendParticles(particle,x,y,z,1,0,0,0,0);
    }

    private RaidVisuals() {}
}
