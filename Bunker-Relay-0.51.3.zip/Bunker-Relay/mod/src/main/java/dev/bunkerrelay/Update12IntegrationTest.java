package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.energy.EnergyStorage;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

final class Update12IntegrationTest {
    private static long start=-1;

    static void begin(MinecraftServer server) {
        var state=RelayState.get(server);
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var arena=RaidBosses.arena(state);
        level.setChunkForced(arena.getX()>>4,arena.getZ()>>4,true);
        level.getChunkAt(arena);
        start=server.getTickCount();
    }

    static void tick(MinecraftServer server) {
        if(start<0||server.getTickCount()-start<100)return;
        start=-1;
        run(server);
    }

    private static void run(MinecraftServer server) {
        var state=RelayState.get(server);
        var hub=server.getLevel(BunkerRelay.HUB);
        var trader=new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay12Trader"));
        var terminal=HubBuilder.TERMINAL;
        trader.moveTo(terminal.getX(),terminal.getY(),terminal.getZ());
        var account=RelayEconomy.account(trader);
        account.putInt("budget",900);
        long before=RelayEconomy.balance(trader);
        var unknown=new ItemStack(Items.COBBLED_DEEPSLATE,12);
        trader.getInventory().setItem(0,unknown);
        SalvageValue.sellSlot(trader,unknown,5);
        check(unknown.getCount()==7&&RelayEconomy.balance(trader)==before+5,"unlisted block sale");
        check(SalvageValue.price(new ItemStack(Items.SHULKER_BOX))==0,"storage guard");
        var damaged=new ItemStack(Items.NETHERITE_PICKAXE);
        int clean=SalvageValue.price(damaged);
        damaged.setDamageValue(damaged.getMaxDamage()-1);
        check(clean>SalvageValue.price(damaged),"durability changes value");

        state.reserveSeconds=0;
        trader.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(Items.COAL,2));
        check(BasePower.fuel(trader)==1&&trader.getMainHandItem().getCount()==1,"fuel consumed");
        var battery=new EnergyStorage(1000);
        battery.receiveEnergy(200,false);
        BasePower.updateSource(state,battery);
        check(state.powerSource.equals("grid")&&battery.getEnergyStored()==40&&state.reserveSeconds==120,"grid chosen first");
        BasePower.updateSource(state,battery);
        check(state.powerSource.equals("reserve")&&state.reserveSeconds==119&&battery.getEnergyStored()==40,"reserve fallback");

        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        check(state.ready&&state.bossId==null,"ready test arena");
        var arena=RaidBosses.arena(state);
        level.getChunkAt(arena);
        var raider=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"Relay12Boss"));
        raider.moveTo(arena.getX()+4,arena.getY(),arena.getZ());
        RaidBosses.encounter(server,state,level,List.of(raider));
        var boss=(net.minecraft.world.entity.LivingEntity)level.getEntity(state.bossId);
        check(boss!=null&&RaidBosses.bar!=null&&RaidBosses.bar.getPlayers().contains(raider),"boss bar attached");
        boss.setHealth(boss.getMaxHealth()/3);
        RaidBosses.encounter(server,state,level,List.of(raider));
        check(RaidBosses.bar.getName().getString().contains("Фаза II")&&RaidBosses.bar.getProgress()<0.5,"phase and bar health");
        var deathSource=level.damageSources().genericKill();
        boss.hurt(deathSource,Float.MAX_VALUE);
        check(state.bossDefeated&&RaidBosses.bar==null,"victory and bar cleanup");
        var drops=level.getEntitiesOfClass(ItemEntity.class,new AABB(arena).inflate(12));
        check(drops.stream().anyMatch(item->BossTrophies.isTrophy(item.getItem())),"physical trophy");
        RaidBosses.died(new LivingDeathEvent(boss,deathSource));
        check(level.getEntitiesOfClass(ItemEntity.class,new AABB(arena).inflate(12)).size()==drops.size(),"one reward");
        var trophy=new ItemStack(BossTrophies.trophy(state.activeTheme));
        check(RelayEconomy.CATALOG.stream().noneMatch(o->o.stack(trader).is(trophy.getItem())),"trophy absent from catalog");
        before=RelayEconomy.balance(trader);
        trader.getInventory().setItem(1,trophy);
        SalvageValue.sellSlot(trader,trophy,1);
        check(trophy.isEmpty()&&RelayEconomy.balance(trader)==before+420,"trophy redeemable");
        level.setChunkForced(arena.getX()>>4,arena.getZ()>>4,false);
        server.saveEverything(false,true,true);
        System.out.println("RELAY_012_PASS grid=true reserve=true boss_bar=true two_phases=true unique_trophy=true valuation=true");
        server.halt(false);
    }

    private static void check(boolean condition,String description) {
        if(!condition)throw new IllegalStateException("RELAY_012 "+description);
    }

    private Update12IntegrationTest() {}
}
