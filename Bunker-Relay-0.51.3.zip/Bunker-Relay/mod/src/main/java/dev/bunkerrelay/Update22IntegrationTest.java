package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update22IntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        verify(server,state);
        server.halt(false);
    }

    static void verify(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        check(level!=null,"expedition level");
        state.variableStories=true;
        var builder=new ExpeditionBuilder(level,state);
        for(int step=0;step<=33;step++)
            check(builder.tick()==(step==33),"builder step "+step);
        var power=FieldRoutes.point(state,FieldRoutes.SUBSTATION);
        var vault=FieldRoutes.point(state,FieldRoutes.VAULT);
        var exit=FieldRoutes.point(state,FieldRoutes.EXIT);
        for(var point:new net.minecraft.core.BlockPos[]{power,vault,exit})
            check(point!=null&&SectorBuildings.inBounds(state,point)
                &&level.getBlockState(point).is(Blocks.LODESTONE)&&level.isEmptyBlock(point.south()),"surface control " + point);
        var main=new net.minecraft.core.BlockPos(state.centerX,state.spawnY,state.centerZ);
        var radio=new net.minecraft.core.BlockPos(state.relayX,state.relayY,state.relayZ);
        check(level.getBlockState(power.offset(3,6,-2)).is(Blocks.COPPER_BLOCK),"substation busbar");
        check(level.getBlockState(vault.offset(0,3,1)).is(Blocks.GREEN_CONCRETE),"vault canopy");
        check(level.getBlockState(exit.offset(2,3,2)).is(Blocks.ORANGE_CONCRETE),"backup gantry");
        check(level.getBlockState(main.offset(2,3,2)).is(Blocks.LIGHT_BLUE_CONCRETE),"main gantry");
        check(level.getBlockState(radio.offset(2,5,2)).is(Blocks.SEA_LANTERN),"radio mast");
        for(var point:new net.minecraft.core.BlockPos[]{power,vault,exit,main,radio})
            for(int z=1;z<=3;z++)for(int y=0;y<=1;y++)
                check(level.isEmptyBlock(point.offset(0,y,z)),"clear walking approach to "+point);
        check(power.distSqr(vault)>64*64&&power.distSqr(exit)>64*64&&vault.distSqr(exit)>64*64,"separate routes");
        var signal=RaidDirector.get(server).rooms.stream().filter(room->room.getString("type").equals("signal")).findFirst().orElseThrow();
        var cluePos=new net.minecraft.core.BlockPos(signal.getInt("x"),signal.getInt("y"),signal.getInt("z")+4);
        var clue=PersonalLoot.templateItem(level,cluePos,3).get(net.minecraft.core.component.DataComponents.LORE);
        check(clue!=null&&clue.lines().stream().anyMatch(line->line.getString().contains(power.toShortString())),"substation clue");
        state.ready=true;
        state.generating=false;
        state.relayPowered=false;
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"Relay22Scout")){
            @Override
            public boolean teleportTo(net.minecraft.server.level.ServerLevel destination,double x,double y,double z,
                java.util.Set<net.minecraft.world.entity.RelativeMovement> relative,float yaw,float pitch){
                setServerLevel(destination);
                moveTo(x,y,z,yaw,pitch);
                return true;
            }
        };
        var journal=RaidJournal.get(server);
        check(RaidRules.begin(player,state)==null,"start raid");
        try {
            check(!FieldRoutes.known(state,FieldRoutes.EXIT),"backup hidden");
            player.moveTo(exit.getX()+.5,exit.getY(),exit.getZ()+.5);
            check(RaidRules.requestExtraction(player,state,exit)!=null,"backup locked");
            FieldRoutes.interact(player,state,vault);
            check(level.getBlockState(vault.north(2)).is(Blocks.IRON_BLOCK),"vault locked");
            player.moveTo(power.getX()+.5,power.getY(),power.getZ()+.5);
            ReconChart.visit(player,state);
            check(!state.scoutMap.isEmpty(),"scouted sector");
            FieldRoutes.interact(player,state,power);
            check(FieldRoutes.known(state,FieldRoutes.EXIT),"backup revealed");
            check(RaidRules.requestExtraction(player,state,exit)!=null,"no remote extraction");
            player.moveTo(vault.getX()+.5,vault.getY(),vault.getZ()+.5);
            FieldRoutes.interact(player,state,vault);
            var chest=level.getBlockEntity(vault.north(2));
            check(chest instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity,"personal vault");
            FieldRoutes.interact(player,state,vault);
            check(level.getBlockEntity(vault.north(2))==chest,"vault opens once");
            player.moveTo(exit.getX()+.5,exit.getY(),exit.getZ()+.5);
            player.getInventory().setItem(0,new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.EMERALD));
            check(RaidRules.requestExtraction(player,state,exit)==null&&!RaidRules.active(player)
                &&player.serverLevel()==server.getLevel(state.hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER)
                &&player.getInventory().getItem(0).is(net.minecraft.world.item.Items.EMERALD),"instant backup preserves loot");
            check(RaidRules.requestExtraction(player,state,exit)!=null,"no duplicate payout");
            player.setServerLevel(level);
            player.moveTo(state.centerX+.5,state.spawnY,state.centerZ+.5);
            check(RaidRules.begin(player,state)==null,"second raid");
            check(RaidRules.requestExtraction(player,state)!=null,"main radio required");
            state.relayPowered=true;
            check(RaidRules.requestExtraction(player,state)==null&&!RaidRules.active(player),"instant main extraction");
            var saved=state.save(new CompoundTag(),server.registryAccess());
            check(saved.getCompound("fieldRoutes").getBoolean("opened")&&!saved.getCompound("scoutMap").isEmpty(),"saved expedition data");
        } finally {
            journal.raids.remove(player.getUUID());
            RaidRules.resetTimers();
        }
        System.out.println("RELAY_022_PASS map=true vault=true backup=true");
    }
    private static void check(boolean valid,String check){if(!valid)throw new IllegalStateException("RELAY_022 "+check);}
    private Update22IntegrationTest(){}
}
