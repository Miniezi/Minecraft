package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/** Separate base wing. Existing construction is never replaced during migration. */
final class BunkerAnnex {
    static boolean install(ServerLevel level,RelayState state){
        if(state.annexBuilt)return true;
        for(int x:new int[]{52,82,-54,-84})for(int z:new int[]{24,55,-34}){
            var origin=new BlockPos(x,96,z);
            if(!vacant(level,origin))continue;
            build(level,origin);
            state.annexOrigin=origin.asLong();
            state.annexBuilt=true;
            state.setDirty();
            return true;
        }
        return false;
    }

    private static boolean vacant(ServerLevel level,BlockPos origin){
        for(int x=-10;x<=10;x++)for(int z=-8;z<=8;z++)for(int y=0;y<=7;y++)
            if(!level.getBlockState(origin.offset(x,y,z)).isAir())return false;
        return true;
    }

    private static void build(ServerLevel level,BlockPos origin){
        for(int x=-10;x<=10;x++)for(int z=-8;z<=8;z++){
            set(level,origin.offset(x,0,z),Math.abs(x)<=1?Blocks.SMOOTH_STONE:Blocks.POLISHED_DEEPSLATE);
            set(level,origin.offset(x,7,z),x%5==0&&z%4==0?Blocks.SEA_LANTERN:Blocks.DEEPSLATE_TILES);
            if(Math.abs(x)!=10&&Math.abs(z)!=8)continue;
            for(int y=1;y<7;y++)set(level,origin.offset(x,y,z),
                y>=3&&y<=4&&Math.abs(x)%4<=1?Blocks.TINTED_GLASS:Blocks.GRAY_CONCRETE);
        }
        for(int z:new int[]{-3,3})for(int x=-9;x<=9;x++){
            if(Math.abs(x)<=2)continue;
            for(int y=1;y<=5;y++)set(level,origin.offset(x,y,z),y>=3?Blocks.GLASS:Blocks.SMOOTH_STONE);
        }
        for(int x:new int[]{-7,7}){
            for(int z:new int[]{-6,6}){
                set(level,origin.offset(x,1,z),Blocks.BARREL);
                set(level,origin.offset(x,2,z),Blocks.LANTERN);
                set(level,origin.offset(x/2,1,z),z<0?Blocks.SMITHING_TABLE:Blocks.CARTOGRAPHY_TABLE);
            }
            set(level,origin.offset(x,1,0),Blocks.CRAFTING_TABLE);
        }
        set(level,origin.offset(0,1,6),Blocks.LODESTONE);
        set(level,origin.offset(0,1,-6),Blocks.LECTERN);
    }

    static BlockPos arrival(RelayState state){return BlockPos.of(state.annexOrigin).above();}
    static BlockPos chart(RelayState state){return BlockPos.of(state.annexOrigin).offset(0,1,-6);}
    static BlockPos exit(RelayState state){return BlockPos.of(state.annexOrigin).offset(0,1,6);}
    private static void set(ServerLevel level,BlockPos pos,Block block){level.setBlock(pos,block.defaultBlockState(),2);}
    private BunkerAnnex(){}
}
