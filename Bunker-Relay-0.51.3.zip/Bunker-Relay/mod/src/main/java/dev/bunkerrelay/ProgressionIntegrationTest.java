package dev.bunkerrelay;
import java.util.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.BackpackWrapper;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
public final class ProgressionIntegrationTest {
 private static final UUID PLAYER=UUID.fromString("fb82244b-c3aa-47fb-a2d0-88d4348922f2"),FIXTURE=UUID.fromString("f06f72f7-3e30-4ee4-b2df-7da7af9fbb31");
 private static void check(boolean b,String message){if(!b)throw new IllegalStateException("PROGRESSION TEST: "+message);}
 private static FakePlayer home(MinecraftServer server){return new FakePlayer(server.getLevel(BunkerRelay.HUB),new GameProfile(PLAYER,"ProgressionTest"));}
 private static int count(FakePlayer p,Item item){return p.getInventory().items.stream().filter(s->s.is(item)).mapToInt(ItemStack::getCount).sum();}
 private static void fill(FakePlayer p){p.getInventory().clearContent();for(int i=0;i<36;i++)p.getInventory().setItem(i,new ItemStack(Items.COBBLESTONE,64));}
 public static void run(MinecraftServer server){
  var s=RelayState.get(server);var j=RaidJournal.get(server);j.raids.remove(PLAYER);j.mail.remove(PLAYER);
  var zone=server.getLevel(BunkerRelay.key(s.activeDimension));var p=new FakePlayer(zone,new GameProfile(PLAYER,"ProgressionTest"));check(RaidRules.begin(p,s)==null,"entry initialized");
  var r=RaidRules.record(p);var director=RaidDirector.get(server);
  for(var room:director.rooms)if(Set.of("echo","signal").contains(room.getString("type"))){p.moveTo(room.getInt("x"),room.getInt("y"),room.getInt("z"));RaidContracts.tick(p,s);}
  check(r.getBoolean("visit_echo")&&r.getBoolean("visit_signal"),"both buildings visited");
  var ordinary=EntityType.HUSK.create(zone);ordinary.moveTo(p.getX(),p.getY(),p.getZ());NeoForge.EVENT_BUS.post(new LivingDeathEvent(ordinary,p.damageSources().playerAttack(p)));check(r.getInt("hunts")==0,"ordinary enemy excluded");
  for(int i=0;i<3;i++){var enemy=EntityType.HUSK.create(zone);enemy.addTag("relay_threat");enemy.moveTo(p.getX(),p.getY(),p.getZ());var death=new LivingDeathEvent(enemy,p.damageSources().playerAttack(p));NeoForge.EVENT_BUS.post(death);NeoForge.EVENT_BUS.post(death);check(r.getInt("hunts")==i+1,"one kill credit per threat");}
  RaidContracts.award(p,r);check(RaidContracts.count(p)==0,"active raid cannot award");r.putString("status","RESTORE");RaidContracts.award(p,r);check(RaidContracts.count(p)==0,"failed raid cannot award");r.putString("status","ACTIVE");
  var h=home(server);RaidRules.settle(h,true);check(!RaidRules.active(h)&&RaidContracts.count(h)==2,"successful settlement queues both rewards");
  var originalMail=j.mail.get(PLAYER).copy();fill(h);check(RaidContracts.claim(h)==0&&RaidContracts.count(h)==2,"full inventory preserves mail");h.getInventory().setItem(0,ItemStack.EMPTY);check(RaidContracts.claim(h)==1&&RaidContracts.count(h)==1,"one slot claims one full reward");h.getInventory().setItem(1,ItemStack.EMPTY);check(RaidContracts.claim(h)==1&&count(h,Items.IRON_BLOCK)==2&&count(h,Items.EMERALD)==6,"exact reward amounts");
  j.mail.put(PLAYER,originalMail);check(RaidContracts.claim(h)==0&&RaidContracts.count(h)==0&&count(h,Items.EMERALD)==6,"saved receipts prevent replay duplicate");
  var replay=r.copy();replay.putUUID("transaction",UUID.randomUUID());RaidContracts.award(h,replay);check(RaidContracts.count(h)==0,"same zone cannot farm rewards on new entry");
  var next=replay.copy();next.putString("contractCycle",replay.getString("contractCycle")+":next");next.putInt("hunts",2);next.putBoolean("visit_signal",false);RaidContracts.award(h,next);check(RaidContracts.count(h)==0,"incomplete tasks cannot award");next.putInt("hunts",3);next.putBoolean("visit_signal",true);RaidContracts.award(h,next);check(RaidContracts.count(h)==2,"new zone can award");
  h.getInventory().clearContent();var trash=new SimpleContainer(27);trash.setItem(0,new ItemStack(Items.DIAMOND,5));
  var bag=new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse("sophisticatedbackpacks:backpack")));BackpackWrapper.fromStack(bag).getInventoryHandler().setStackInSlot(0,new ItemStack(Items.GOLD_INGOT,7));trash.setItem(1,bag);
  TrashRecovery.checkpoint(h,trash,new ItemStack(Items.IRON_INGOT,3));var fixture=new CompoundTag();fixture.put("playerData",h.getPersistentData().copy());fixture.put("inventory",h.getInventory().save(new ListTag()));j.raids.put(FIXTURE,fixture);
  TrashRecovery.login(h);check(count(h,Items.DIAMOND)==5&&count(h,Items.IRON_INGOT)==3&&!TrashRecovery.pending(h),"open trash and cursor recovered");TrashRecovery.login(h);check(count(h,Items.DIAMOND)==5,"recovery cannot repeat");
  fill(h);TrashRecovery.checkpoint(h,trash,new ItemStack(Items.IRON_INGOT,3));TrashRecovery.login(h);check(TrashRecovery.pending(h),"full inventory queues recovered trash");h.getInventory().setItem(0,ItemStack.EMPTY);TrashRecovery.drain(h);check(count(h,Items.DIAMOND)==5&&TrashRecovery.pending(h),"partial recovery preserves remainder");h.getInventory().clearContent();TrashRecovery.drain(h);check(!TrashRecovery.pending(h),"remaining recovery completes");
  var menu=new TrashMenu(12,h.getInventory(),h);menu.getSlot(0).set(new ItemStack(Items.DIRT,8));menu.broadcastChanges();check(h.getPersistentData().getList("relay_open_trash",10).size()==1,"open menu checkpoint");menu.removed(h);menu.broadcastChanges();check(!h.getPersistentData().contains("relay_open_trash"),"explicit close clears checkpoint permanently");
  h.getInventory().clearContent();var journalMenu=new RaidContracts.JournalMenu(13,h.getInventory(),h);journalMenu.clicked(10,0,net.minecraft.world.inventory.ClickType.PICKUP,h);check(h.getInventory().isEmpty()&&journalMenu.quickMoveStack(h,10).isEmpty(),"journal icons cannot be taken");
  j.flush(server);server.saveEverything(false,true,true);System.out.println("RELAY_PROGRESSION_PASS: visits, special kill credits, success-only rewards, same-zone dedup, full mailbox, claim receipts, trash/cursor recovery, overflow, explicit close, journal icons");
 }
 public static void reload(MinecraftServer server){
  var j=RaidJournal.get(server);var h=home(server);check(RaidContracts.count(h)==2,"mail survived restart");check(j.completed.size()>=4,"paid task identities survived");var fixture=j.raids.get(FIXTURE);check(fixture!=null,"recovery fixture survived");
  h.getInventory().load(fixture.getList("inventory",10));h.getPersistentData().merge(fixture.getCompound("playerData").copy());TrashRecovery.login(h);check(count(h,Items.DIAMOND)==5&&count(h,Items.IRON_INGOT)==3,"saved trash restored after restart");
  var bag=h.getInventory().items.stream().filter(i->i.getItem().toString().contains("backpack")).findFirst().orElseThrow();check(BackpackWrapper.fromStack(bag).getInventoryHandler().getStackInSlot(0).getCount()==7,"backpack payload survived");TrashRecovery.login(h);check(count(h,Items.DIAMOND)==5,"no repeat restoration");j.raids.remove(FIXTURE);j.flush(server);
  System.out.println("RELAY_PROGRESSION_RELOAD_PASS: mailbox, paid tasks, player-data trash checkpoint, cursor, external backpack contents");
 }
 private ProgressionIntegrationTest(){}
}
