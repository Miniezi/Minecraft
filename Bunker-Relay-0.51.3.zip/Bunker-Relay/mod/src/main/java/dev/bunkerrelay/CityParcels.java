package dev.bunkerrelay;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public final class CityParcels {
    private static final int CHUNK=16;

    public static boolean reserved(ResourceKey<Level> dimension,int chunkX,int chunkZ){
        var id=dimension.location();
        if(!id.getNamespace().equals("bunkerrelay"))return false;
        switch(id.getPath()){
            case "city","infected_city","ashlands" -> {}
            default -> {return false;}
        }
        int x=withinParcel(chunkX),z=withinParcel(chunkZ);
        return edge(x)||edge(z)||(x>=-2&&x<=1&&z>=-2&&z<=1);
    }

    private static int withinParcel(int chunk){
        int coordinate=chunk*CHUNK;
        int regionOffset=Math.floorMod(coordinate+SectorPlan.STRIDE/2,SectorPlan.STRIDE)-SectorPlan.STRIDE/2;
        return Math.floorDiv(Math.floorMod(regionOffset+ExpeditionGrid.HALF,ExpeditionGrid.SIDE)-ExpeditionGrid.HALF,CHUNK);
    }

    private static boolean edge(int coordinate){
        return coordinate==-ExpeditionGrid.HALF/CHUNK||coordinate==ExpeditionGrid.HALF/CHUNK-1;
    }

    private CityParcels(){}
}
