package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.levelgen.Heightmap;

final class RaidDoubles {
    static boolean isolated(ServerPlayer player,List<ServerPlayer> team){
        return team.size()>1&&team.stream().noneMatch(other->other!=player&&other.distanceToSqr(player)<72*72);
    }

    static boolean spawn(ServerLevel level,RelayState state,ServerPlayer target,ServerPlayer original){
        for(int step=0;step<12;step++){
            double angle=step*Math.PI/6+target.getYRot()*Math.PI/180;
            int x=target.getBlockX()+(int)(Math.cos(angle)*36);
            int z=target.getBlockZ()+(int)(Math.sin(angle)*36);
            var column=new BlockPos(x,target.getBlockY(),z);
            if(!level.hasChunkAt(column)||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,x,z)
                ||Math.hypot(x-state.centerX,z-state.centerZ)<28
                ||level.players().stream().anyMatch(player->player.distanceToSqr(x,player.getY(),z)<26*26))continue;
            int y=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z);
            var position=column.atY(y);
            if(Math.abs(y-target.getY())>12||!level.getBlockState(position.below()).isSolidRender(level,position.below()))continue;
            var doubleMob=SporeEncounters.create(level,"inf_player");
            if(doubleMob==null)return false;
            doubleMob.moveTo(x+.5,y,z+.5,0,0);
            if(!level.noCollision(doubleMob))continue;
            var head=new ItemStack(Items.PLAYER_HEAD);
            head.set(DataComponents.PROFILE,new ResolvableProfile(original.getGameProfile()));
            doubleMob.setCustomName(Component.literal(original.getScoreboardName()));
            doubleMob.setCustomNameVisible(true);
            doubleMob.setItemSlot(EquipmentSlot.HEAD,head);
            doubleMob.setDropChance(EquipmentSlot.HEAD,0);
            doubleMob.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(.29);
            doubleMob.getAttribute(Attributes.MAX_HEALTH).setBaseValue(24+state.activeDifficulty*5);
            doubleMob.setHealth(doubleMob.getMaxHealth());
            doubleMob.addTag("relay_threat");
            doubleMob.addTag("relay_scaled");
            doubleMob.getPersistentData().putString("relay_role","double");
            doubleMob.getPersistentData().putInt("relay_structure_generation",state.generation);
            doubleMob.setTarget(target);
            if(level.addFreshEntity(doubleMob)){
                MeetingSignals.imitate(target,original,state,position);
                return true;
            }
        }
        return false;
    }

    private RaidDoubles(){}
}
