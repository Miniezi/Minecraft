package dev.bunkerrelay;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

final class ExpeditionReset {
    private static final Map<String,String> THEMES=Map.of("industrial","city","infected","infected_city",
        "ash","ashlands","forest","forest_expedition");

    static String dimension(String theme){return THEMES.get(theme);}

    // A pending request written by 0.11–0.16 is now processed as a live structure rebuild.
    static String pending(MinecraftServer server){
        try{
            var file=marker(server);
            if(!Files.exists(file))return null;
            var request=Files.readAllLines(file);
            return !request.isEmpty()&&THEMES.containsKey(request.getFirst())?request.getFirst():null;
        }catch(IOException failure){
            throw new IllegalStateException("Cannot read saved expedition reset request",failure);
        }
    }

    static void complete(MinecraftServer server)throws IOException{Files.deleteIfExists(marker(server));}

    private static Path marker(MinecraftServer server){return server.getWorldPath(LevelResource.ROOT).resolve("relay-expedition-reset");}
    private ExpeditionReset(){}
}
