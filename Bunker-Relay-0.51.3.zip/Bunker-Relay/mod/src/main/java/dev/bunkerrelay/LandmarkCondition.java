package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

enum LandmarkCondition {
    REGULAR("", "", Blocks.AIR),
    ABANDONED("Заброшено", "Пыль на пороге, свежих следов нет", Blocks.COBWEB),
    PATROL("Под охраной", "Свежие следы сапог и ящик с боеприпасами", Blocks.RED_CONCRETE),
    INFESTED("Заражено", "Наросты вокруг входа и слизь на ступенях", Blocks.NETHER_WART_BLOCK);

    final String title, clue;
    final Block marker;

    LandmarkCondition(String title, String clue, Block marker) {
        this.title = title;
        this.clue = clue;
        this.marker = marker;
    }

    static LandmarkCondition choose(long seed, BlockPos site) {
        int roll = Math.floorMod(RaidDirector.roll(seed ^ 0x69d13afbc2358ad1L, site.getX(), site.getZ()), 16);
        return roll < 3 ? values()[roll + 1] : REGULAR;
    }

    static LandmarkCondition read(String value) {
        return switch (value) {
            case "ABANDONED" -> ABANDONED;
            case "PATROL" -> PATROL;
            case "INFESTED" -> INFESTED;
            default -> REGULAR;
        };
    }

    int entrance(int regular) {
        return switch (this) {
            case REGULAR -> regular;
            case ABANDONED -> (regular + 1) % 3;
            case PATROL -> 1;
            case INFESTED -> 2;
        };
    }

    ItemStack bonus(int tier) {
        return switch (this) {
            case REGULAR -> ItemStack.EMPTY;
            case ABANDONED -> new ItemStack(Items.COPPER_INGOT, 2 + tier);
            case PATROL -> new ItemStack(Items.IRON_INGOT, 2 + tier);
            case INFESTED -> new ItemStack(Medicine.BANDAGE.get(), 1 + tier);
        };
    }
}
