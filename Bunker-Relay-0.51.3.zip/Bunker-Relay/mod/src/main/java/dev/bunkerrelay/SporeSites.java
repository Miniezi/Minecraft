package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;

final class SporeSites {
    static Mob boss(ServerLevel level,String theme){
        String id=switch(theme){
            case "infected" -> "hevoker";
            case "forest" -> "wendigo";
            case "ash" -> "hollen";
            default -> "grober";
        };
        return BuiltInRegistries.ENTITY_TYPE.getOptional(ResourceLocation.fromNamespaceAndPath("spore",id))
            .map(type->type.create(level)).filter(Mob.class::isInstance).map(Mob.class::cast).orElse(null);
    }

    static boolean place(ServerLevel level,BlockPos origin,int variant){
        String id=switch(variant%3){
            case 0 -> "biomass_tower_small";
            case 1 -> "biomass_tower";
            default -> "biomass_tower_tall";
        };
        var template=level.getStructureManager().get(ResourceLocation.fromNamespaceAndPath("spore",id)).orElse(null);
        if(template==null)return false;
        var size=template.getSize();
        if(size.getX()>8||size.getZ()>21||origin.getY()+size.getY()>=level.getMaxBuildHeight())return false;
        var corner=origin.offset(4,0,-size.getZ()/2);
        if(!template.placeInWorld(level,corner,corner,new StructurePlaceSettings().setIgnoreEntities(true),level.random,2))return false;
        for(int x=-2;x<=11;x++)for(int z=-11;z<=11;z++)
            level.setBlock(origin.offset(x,-1,z),Blocks.MOSSY_COBBLESTONE.defaultBlockState(),2);
        return true;
    }

    private SporeSites(){}
}
