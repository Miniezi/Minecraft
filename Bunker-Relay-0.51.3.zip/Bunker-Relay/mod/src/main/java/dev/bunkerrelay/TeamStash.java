package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;

final class TeamStash {
    private static final String MARKER="relay_team_stash";
    private static final int SLOTS=18;
    private static final String SAVED="relay_stash_saved";

    static String status(ServerPlayer player,RelayState state){
        var stash=RaidJournal.get(player.server).stash;
        return stash.contains("position")?"Тайник · "+BlockPos.of(stash.getLong("position")).toShortString()
            :"Поставить тайник перед собой";
    }

    static void use(ServerPlayer player,RelayState state){
        if(!allowed(player,state))return;
        var journal=RaidJournal.get(player.server);
        var stash=journal.stash;
        if(stash.contains("position")){
            var pos=BlockPos.of(stash.getLong("position"));
            if(player.blockPosition().distSqr(pos)>25){
                Navigation.waypoint(player,state.generation,pos,"Тайник команды");
                RaidRules.tell(player,"Метка тайника установлена.");
                return;
            }
            open(player,state,pos);
            return;
        }
        var level=player.serverLevel();
        var pos=player.blockPosition().relative(player.getDirection());
        if(!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,pos.getX(),pos.getZ())
            ||!level.isEmptyBlock(pos)||!level.isEmptyBlock(pos.above())
            ||!level.getBlockState(pos.below()).isSolidRender(level,pos.below())){
            RaidRules.tell(player,"Найдите свободное место на твёрдой поверхности.");
            return;
        }
        if(!level.setBlock(pos,Blocks.BARREL.defaultBlockState(),3))return;
        var block=level.getBlockEntity(pos);
        if(block==null)return;
        block.getPersistentData().putBoolean(MARKER,true);
        block.setChanged();
        stash.putLong("position",pos.asLong());
        stash.putString("dimension",level.dimension().location().toString());
        stash.putInt("generation",state.generation);
        journal.flush(player.server);
        open(player,state,pos);
    }

    static boolean marked(ServerLevel level,BlockPos pos){
        var block=level.getBlockEntity(pos);
        return block!=null&&block.getPersistentData().getBoolean(MARKER);
    }

    static void clear(ServerLevel level){
        var journal=RaidJournal.get(level.getServer());
        var stash=journal.stash;
        if(stash.contains("position")&&stash.getString("dimension").equals(level.dimension().location().toString())){
            var pos=BlockPos.of(stash.getLong("position"));
            if(marked(level,pos))level.removeBlock(pos,false);
        }
        journal.stash=new CompoundTag();
        journal.setDirty();
    }

    static void recover(ServerPlayer player){
        var journal=RaidJournal.get(player.server);
        var key=player.getUUID().toString();
        var pending=journal.stashPending.getCompound(key);
        if(!pending.hasUUID("id"))return;
        var data=player.getPersistentData();
        var id=pending.getUUID("id");
        if(!data.hasUUID(SAVED)||!id.equals(data.getUUID(SAVED))){
            player.getInventory().clearContent();
            player.getInventory().load(pending.getList("inventory",Tag.TAG_COMPOUND));
            data.putUUID(SAVED,id);
            RelayEconomy.save(player);
        }
        journal.stashPending.remove(key);
        journal.setDirty();
    }

    private static void checkpoint(ServerPlayer player,RaidJournal journal){
        var id=java.util.UUID.randomUUID();
        var key=player.getUUID().toString();
        var pending=new CompoundTag();
        pending.putUUID("id",id);
        pending.put("inventory",player.getInventory().save(new net.minecraft.nbt.ListTag()));
        journal.stashPending.put(key,pending);
        journal.flush(player.server);
        player.getPersistentData().putUUID(SAVED,id);
        RelayEconomy.save(player);
        journal.stashPending.remove(key);
        journal.setDirty();
    }

    private static boolean allowed(ServerPlayer player,RelayState state){
        return DownedPlayers.active(player,state)&&!DownedPlayers.down(player)&&player.isAlive();
    }

    static void open(ServerPlayer player,RelayState state,BlockPos pos){
        var stash=RaidJournal.get(player.server).stash;
        if(!allowed(player,state)||!stash.contains("position")||stash.getInt("generation")!=state.generation
            ||!BlockPos.of(stash.getLong("position")).equals(pos)||!marked(player.serverLevel(),pos)
            ||player.blockPosition().distSqr(pos)>25)return;
        player.openMenu(new SimpleMenuProvider((id,inv,ignored)->new Menu(id,inv,player,pos),
            Component.literal("Тайник команды · ЛКМ 1 / ПКМ стопка")));
    }

    static boolean accepted(ItemStack item){
        return !item.isEmpty()&&item.getMaxStackSize()>1&&!PdaProtection.isPda(item)&&!StarterKit.marked(item)
            &&!item.has(DataComponents.CONTAINER)&&!item.has(DataComponents.CUSTOM_DATA)
            &&!item.has(DataComponents.BUNDLE_CONTENTS)&&!item.has(DataComponents.BLOCK_ENTITY_DATA)
            &&!item.has(DataComponents.BUCKET_ENTITY_DATA)
            &&item.getCapability(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.ITEM)==null;
    }

    static void debitBaseline(ServerPlayer player,ItemStack item,int count){
        var inventory=RaidRules.record(player).getCompound("baseline").getList("inventory",Tag.TAG_COMPOUND);
        for(int i=inventory.size()-1;i>=0&&count>0;i--){
            var entry=inventory.getCompound(i);
            var stored=ItemStack.parseOptional(player.registryAccess(),entry);
            if(!Warehouse.matches(stored,item))continue;
            int used=Math.min(count,stored.getCount());
            stored.shrink(used);
            count-=used;
            if(stored.isEmpty())inventory.remove(i);
            else{
                var updated=(CompoundTag)stored.save(player.registryAccess());
                updated.putByte("Slot",entry.getByte("Slot"));
                inventory.set(i,updated);
            }
        }
    }

    private static final class Menu extends ChestMenu {
        private final ServerPlayer owner;
        private final SimpleContainer panel;
        private final BlockPos pos;
        private final int generation;
        Menu(int id,Inventory inv,ServerPlayer player,BlockPos pos){
            super(MenuType.GENERIC_9x2,id,inv,new SimpleContainer(SLOTS),2);
            panel=(SimpleContainer)getContainer();
            owner=player;this.pos=pos;generation=RelayState.get(player.server).generation;
            refresh();
        }

        private CompoundTag items(){return RaidJournal.get(owner.server).stash.getCompound("items");}
        private void refresh(){
            var contents=items();
            for(int i=0;i<SLOTS;i++)panel.setItem(i,ItemStack.parseOptional(owner.registryAccess(),contents.getCompound(Integer.toString(i))));
        }

        @Override public boolean stillValid(Player p){
            var state=RelayState.get(owner.server);
            return p==owner&&state.generation==generation&&allowed(owner,state)&&owner.blockPosition().distSqr(pos)<=25
                &&marked(owner.serverLevel(),pos);
        }

        @Override public void clicked(int slot,int button,ClickType type,Player player){
            if(!stillValid(player)||slot<0||slot>=slots.size()||type!=ClickType.PICKUP||button<0||button>1)return;
            var items=items();
            boolean changed=slot<SLOTS?take(items,slot,button):deposit(items,getSlot(slot).getItem(),button);
            if(changed){
                var journal=RaidJournal.get(owner.server);
                journal.stash.put("items",items);
                owner.getInventory().setChanged();
                checkpoint(owner,journal);
            }
            refresh();
            sendAllDataToRemote();
        }

        private boolean take(CompoundTag items,int slot,int button){
            String key=Integer.toString(slot);
            var item=ItemStack.parseOptional(owner.registryAccess(),items.getCompound(key));
            if(item.isEmpty()||!ItemStack.matches(item,panel.getItem(slot)))return false;
            int count=Math.min(button==0?1:item.getCount(),SafeInventory.capacity(owner.getInventory(),item));
            if(count==0)return false;
            SafeInventory.insert(owner.getInventory(),item.split(count));
            if(item.isEmpty())items.remove(key);else items.put(key,item.save(owner.registryAccess()));
            return true;
        }

        private boolean deposit(CompoundTag items,ItemStack from,int button){
            if(!accepted(from)){RaidRules.tell(owner,"Тайник принимает обычные припасы без вложений.");return false;}
            int left=button==0?1:from.getCount(), initial=left;
            for(int pass=0;pass<2&&left>0;pass++)for(int i=0;i<SLOTS&&left>0;i++){
                String key=Integer.toString(i);
                var item=ItemStack.parseOptional(owner.registryAccess(),items.getCompound(key));
                if(pass==0&&!Warehouse.matches(item,from)||pass==1&&!item.isEmpty())continue;
                int amount=Math.min(left,from.getMaxStackSize()-item.getCount());
                if(amount<=0)continue;
                items.put(key,from.copyWithCount(item.getCount()+amount).save(owner.registryAccess()));
                left-=amount;
            }
            int moved=initial-left;
            if(moved==0)return false;
            debitBaseline(owner,from,moved);
            from.shrink(moved);
            return true;
        }

        @Override public ItemStack quickMoveStack(Player player,int slot){return ItemStack.EMPTY;}
    }

    private TeamStash(){}
}
