package dev.bunkerrelay;
import java.util.BitSet;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.fml.ModList;
/** Read-only bridge pinned to Sable 2.0.6; occupancy includes unloaded plots. */
public final class VehicleGuard {
 public static String resetBlocker(ServerLevel level){
  if(!ModList.get().isLoaded("sable"))return null;
  String v=ModList.get().getModContainerById("sable").orElseThrow().getModInfo().getVersion().toString();
  if(!v.equals("2.0.6"))return "Для безопасного сброса требуется Sable 2.0.6.";
  try {
   Class<?> cls=Class.forName("dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer");
   Class<?> base=Class.forName("dev.ryanhcode.sable.api.sublevel.SubLevelContainer");
   // Exact method handles avoid enumerating Sable's client-only overloads on a server.
   Object container=MethodHandles.publicLookup().findStatic(base,"getContainer",MethodType.methodType(cls,ServerLevel.class)).invoke(level);
   if(container==null)return "Не удалось проверить технику Sable.";
   BitSet occupancy=(BitSet)MethodHandles.publicLookup().findVirtual(base,"getOccupancy",MethodType.methodType(BitSet.class)).invoke(container);
   return occupancy.isEmpty()?null:"В зоне есть техника Sable (возможно выгруженная). Автовозврат пока не реализован: сброс заблокирован.";
  }catch(Throwable e){if(e instanceof VirtualMachineError fatal)throw fatal;return "API Sable не подтверждён; сброс заблокирован.";}
 }
}
