package dev.bunkerrelay;

import net.minecraft.core.BlockPos;

/** Relative positions rotate together so objective footprints cannot overlap. */
final class ExpeditionLayout {
    private static final int[][] SPORE={{-160,162},{-245,-220},{-338,170},{180,-380}};
    private static final int[][] STORY={{-144,80},{-224,-144},{-320,224},{160,-320}};

    static BlockPos story(RelayState state,int index){
        if(state.layoutVersion==3)return ExpeditionGrid.point(state,index);
        int[] base=STORY[index];
        if(state.variableStories&&state.generating)return position(state,SPORE[index][0],SPORE[index][1]);
        int generation=state.generation+(state.generating?1:0);
        if(!state.variableStories)return position(state,base[0],base[1]);
        int shift=Math.floorMod(generation+index,4)*24;
        return position(state,base[0]+shift,base[1]-shift);
    }

    static boolean nearStoryPlots(RelayState state,BlockPos point){
        if(state.layoutVersion==3)return ExpeditionGrid.reserved(state,ExpeditionGrid.cell(state,point.getX()-state.centerX),ExpeditionGrid.cell(state,point.getZ()-state.centerZ));
        for(int[] base:SPORE){
            var plot=position(state,base[0],base[1]);
            if(Math.abs(plot.getX()-point.getX())<=44&&Math.abs(plot.getZ()-point.getZ())<=44)return true;
        }
        for(int[] base:STORY)for(int shift=0;shift<=72;shift+=24){
            var plot=position(state,base[0]+shift,base[1]-shift);
            if(Math.abs(plot.getX()-point.getX())<28&&Math.abs(plot.getZ()-point.getZ())<36)return true;
        }
        return false;
    }

    static BlockPos arena(RelayState state){
        return state.layoutVersion==3?ExpeditionGrid.point(state,4):position(state,256,-192);
    }

    static BlockPos radio(RelayState state){
        if(state.layoutVersion==3)return ExpeditionGrid.point(state,5);
        int distance=128+(state.layoutVersion==2?state.structureRadioDifficulty:state.activeDifficulty)*64;
        return position(state,distance,distance/2);
    }

    static BlockPos position(RelayState state,int x,int z){
        int rotation=state.layoutVersion==0?0:(int)Math.floorMod(seed(state) >>> 16,4);
        return switch(rotation){
            case 1 -> new BlockPos(state.centerX-z,0,state.centerZ+x);
            case 2 -> new BlockPos(state.centerX-x,0,state.centerZ-z);
            case 3 -> new BlockPos(state.centerX+z,0,state.centerZ-x);
            default -> new BlockPos(state.centerX+x,0,state.centerZ+z);
        };
    }

    static long seed(RelayState state){return state.layoutVersion==2?state.structureSeed:state.seed;}

    static void remember(RelayState state){
        String key=layoutKey(state);
        if(state.structureLayouts.contains(key))return;
        var layout=new net.minecraft.nbt.CompoundTag();
        layout.putLong("seed",state.layoutVersion==0?0:seed(state));
        layout.putInt("difficulty",state.layoutVersion==2?state.structureRadioDifficulty:state.activeDifficulty);
        state.structureLayouts.put(key,layout);
        state.setDirty();
    }

    static void use(RelayState state){
        state.layoutVersion=2;
        if(!state.structureLayouts.contains(layoutKey(state))){
            state.structureSeed=state.seed;
            state.structureRadioDifficulty=state.activeDifficulty;
            remember(state);
        }
        var layout=state.structureLayouts.getCompound(layoutKey(state));
        state.structureSeed=layout.getLong("seed");
        state.structureRadioDifficulty=Math.clamp(layout.getInt("difficulty"),1,5);
    }

    private static String layoutKey(RelayState state){return state.activeDimension+"/"+state.centerX+"/"+state.centerZ;}

    private ExpeditionLayout(){}
}
