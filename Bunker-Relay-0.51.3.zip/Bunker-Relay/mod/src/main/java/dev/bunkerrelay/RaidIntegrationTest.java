package dev.bunkerrelay;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.BackpackWrapper;
public final class RaidIntegrationTest {
 public static final UUID PLAYER=UUID.fromString("f067334b-8976-431a-8621-6393214585ea");
 private static ItemStack bag(){return new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse("sophisticatedbackpacks:backpack")));}
 private static void check(boolean b,String s){if(!b)throw new IllegalStateException("RAID TEST: "+s);}
 public static void run(MinecraftServer server){
  var s=RelayState.get(server);var p=new FakePlayer(server.getLevel(RelayState.get(server).hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER),new GameProfile(PLAYER,"RelayRaidTest"));
  RaidJournal.get(server).raids.remove(PLAYER);ItemStack outer=bag(),inner=bag(),third=bag();
  BackpackWrapper.fromStack(third).getInventoryHandler().setStackInSlot(0,new ItemStack(Items.GOLD_INGOT,7));
  BackpackWrapper.fromStack(inner).getInventoryHandler().setStackInSlot(0,third);
  BackpackWrapper.fromStack(outer).getInventoryHandler().setStackInSlot(0,inner);
  BackpackWrapper.fromStack(outer).getInventoryHandler().setStackInSlot(1,new ItemStack(Items.IRON_INGOT,13));
  p.getInventory().setItem(0,outer);var sword=new ItemStack(Items.IRON_SWORD);sword.setDamageValue(17);p.getInventory().setItem(1,sword);p.getInventory().setItem(40,new ItemStack(Items.SHIELD));p.experienceLevel=6;p.totalExperience=72;
  var originalId=BackpackWrapper.fromStack(outer).getContentsUuid().orElseThrow();
  check(RaidRules.begin(p,s)==null,"begin with nested bags");
  var baseline=RaidRules.record(p).getCompound("baseline");check(baseline.getCompound("packs").size()==3,"all three external backpack stores captured");
  var frozen=baseline.copy();
  BackpackWrapper.fromStack(third).getInventoryHandler().setStackInSlot(0,new ItemStack(Items.DIAMOND,64));
  BackpackWrapper.fromStack(outer).getInventoryHandler().setStackInSlot(1,ItemStack.EMPTY);
  p.getInventory().setItem(2,new ItemStack(Items.NETHERITE_INGOT,12));sword.setDamageValue(99);
  check(frozen.equals(baseline),"snapshot isolated from later mutations");
  RaidRules.fail(p);
  check(RaidRules.record(p).getString("status").equals("RESTORE"),"non-death abort retains rollback");
  RaidRules.settle(p,false);
  check(!RaidRules.active(p),"rollback completed");check(p.getInventory().getItem(2).isEmpty(),"raid loot removed");
  check(p.getInventory().getItem(1).getDamageValue()==17&&p.getInventory().getItem(40).is(Items.SHIELD),"durability and offhand restored");
  var restored=BackpackWrapper.fromStack(p.getInventory().getItem(0));check(!restored.getContentsUuid().orElseThrow().equals(originalId),"fresh isolated backpack identity");
  check(restored.getInventoryHandler().getStackInSlot(1).getCount()==13,"outer contents restored");
  var restoredInner=BackpackWrapper.fromStack(restored.getInventoryHandler().getStackInSlot(0));
  var restoredThird=BackpackWrapper.fromStack(restoredInner.getInventoryHandler().getStackInSlot(0));
  check(restoredThird.getInventoryHandler().getStackInSlot(0).is(Items.GOLD_INGOT)&&restoredThird.getInventoryHandler().getStackInSlot(0).getCount()==7,"deep nested contents restored; raid diamonds gone");
  check(p.experienceLevel==6,"XP restored");
  check(RaidRules.begin(p,s)==null,"second entry");
  var held=p.getInventory().removeItem(1,1);var toss=new ItemTossEvent(new ItemEntity(p.level(),0,73,31,held),p);NeoForge.EVENT_BUS.post(toss);
  check(!toss.isCanceled(),"drop allowed");check(p.getInventory().items.stream().noneMatch(item->item.is(Items.IRON_SWORD)),"tossed item stays out of inventory");
  p.getInventory().setItem(2,new ItemStack(Items.DIAMOND,9));
  BackpackWrapper.fromStack(p.getInventory().getItem(0)).getInventoryHandler().setStackInSlot(2,new ItemStack(Items.EMERALD,5));
  s.relayPowered=false;check(RaidRules.requestExtraction(p,s)!=null,"objective required");s.relayPowered=true;
  var exitInventory=p.getInventory().save(new ListTag()).copy();RaidRules.settle(p,true);check(exitInventory.equals(p.getInventory().save(new ListTag())),"success preserves exact inventory and backpack UUIDs; tossed gear not restored");check(p.getInventory().getItem(2).getCount()==9,"exfil keeps raid loot");
  check(BackpackWrapper.fromStack(p.getInventory().getItem(0)).getInventoryHandler().getStackInSlot(2).getCount()==5,"exfil keeps backpack loot");
  // Leave an active frozen transaction for the independent server restart test.
  check(RaidRules.begin(p,s)==null,"persistent entry");RaidRules.record(p).putString("status","RESTORE");RaidJournal.get(server).flush(server);
  System.out.println("RELAY_RAID_PASS: nested backpacks, snapshot isolation, non-death rollback, durability/offhand/XP, toss, objective gate, successful loot, persistent rollback");
 }
 public static void reload(MinecraftServer server){
  var p=new FakePlayer(server.getLevel(RelayState.get(server).hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER),new GameProfile(PLAYER,"RelayRaidTest"));check(RaidRules.active(p),"journal survived server restart");RaidRules.login(p,RelayState.get(server));
  check(!RaidRules.active(p)&&p.getInventory().getItem(2).getCount()==9,"idempotent rollback after restart");
  check(BackpackWrapper.fromStack(p.getInventory().getItem(0)).getInventoryHandler().getStackInSlot(2).getCount()==5,"external backpack payload survived restart");
  var tank=bag();var wrapper=BackpackWrapper.fromStack(tank);
  wrapper.getInventoryHandler().setStackInSlot(0,new ItemStack(Items.STONE));
  wrapper.getUpgradeHandler().setStackInSlot(0,new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse("sophisticatedbackpacks:tank_upgrade"))));
  var fluid=wrapper.getFluidHandler().orElseThrow();fluid.fill(new net.neoforged.neoforge.fluids.FluidStack(net.minecraft.world.level.material.Fluids.WATER,1000),net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
  p.getInventory().setItem(3,tank);var frozen=RaidSnapshot.capture(p);
  fluid.fill(new net.neoforged.neoforge.fluids.FluidStack(net.minecraft.world.level.material.Fluids.WATER,1000),net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
  RaidSnapshot.apply(p,frozen);
  check(BackpackWrapper.fromStack(p.getInventory().getItem(3)).getFluidHandler().orElseThrow().getFluidInTank(0).getAmount()==1000,"tank upgrade fluid restored");
  check(RaidSnapshot.reject(new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse("sophisticatedbackpacks:deposit_upgrade"))),p)==null,"world-transfer upgrade allowed");
  var before=p.getInventory().save(new ListTag());var menu=new TerminalMenu(10,p.getInventory(),p);
  menu.clicked(4,0,net.minecraft.world.inventory.ClickType.PICKUP,p);menu.clicked(10,0,net.minecraft.world.inventory.ClickType.QUICK_MOVE,p);
  check(before.equals(p.getInventory().save(new ListTag()))&&menu.quickMoveStack(p,0).isEmpty(),"terminal icons cannot be taken");
  System.out.println("RELAY_RAID_EXTRA_PASS: fluid tanks, allowed transfer upgrade, terminal buttons");
  System.out.println("RELAY_RAID_RELOAD_PASS: durable inventory and backpack recovery");
 }
 private RaidIntegrationTest(){}
}
