package dev.bunkerrelay;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
/** Optional contracts: progress belongs to one attempt; payment is once per player/sector/task. */
public final class RaidContracts {
 public static String cycle(RelayState s){return s.activeDimension+":"+s.centerX+":"+s.centerZ+":"+s.generation;}
 public static UUID rewardId(ServerPlayer p,CompoundTag raid,String kind){return UUID.nameUUIDFromBytes((p.getUUID()+":"+raid.getString("contractCycle")+":"+kind).getBytes(StandardCharsets.UTF_8));}
 public static void initialize(ServerPlayer p,RelayState s,CompoundTag r){if(!r.contains("contractCycle"))r.putString("contractCycle",cycle(s));}
 public static boolean completed(ServerPlayer p,CompoundTag r,String kind){return r.contains("contractCycle")&&RaidJournal.get(p.server).completed.contains(rewardId(p,r,kind).toString());}
 public static void tick(ServerPlayer p,RelayState s){
  if(!RaidRules.active(p)||!RaidRules.record(p).getString("status").equals("ACTIVE")||!p.level().dimension().equals(BunkerRelay.key(s.activeDimension)))return;
  var r=RaidRules.record(p);if(r.getInt("generation")!=s.generation)return;initialize(p,s,r);
  var d=RaidDirector.get(p.server);if(d.sectorX!=s.centerX||d.sectorZ!=s.centerZ)return;
  for(var room:d.rooms){String type=room.getString("type");if(!Set.of("echo","signal").contains(type)||r.getBoolean("visit_"+type))continue;
   if(Math.abs(p.getX()-room.getInt("x"))<=7&&Math.abs(p.getZ()-room.getInt("z"))<=5&&Math.abs(p.getY()-room.getInt("y"))<=4){r.putBoolean("visit_"+type,true);RaidJournal.get(p.server).setDirty();if(!completed(p,r,"scout"))RaidRules.tell(p,"Разведка: "+RaidDirector.roomName(type)+" отмечена. Награда — после эвакуации.");}
  }
 }
 public static void killed(LivingDeathEvent e){
  if(!(e.getSource().getEntity() instanceof ServerPlayer p)||!RaidRules.active(p)||!e.getEntity().getTags().contains("relay_threat")||e.getEntity().getPersistentData().getBoolean("relay_contract_counted"))return;
  var s=RelayState.get(p.server);var r=RaidRules.record(p);
  if(!r.getString("status").equals("ACTIVE")||r.getInt("generation")!=s.generation||!p.level().dimension().equals(BunkerRelay.key(s.activeDimension))||e.getEntity().level()!=p.level()||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,e.getEntity().getX(),e.getEntity().getZ()))return;
  initialize(p,s,r);e.getEntity().getPersistentData().putBoolean("relay_contract_counted",true);int before=r.getInt("hunts");r.putInt("hunts",Math.min(3,before+1));RaidJournal.get(p.server).setDirty();if(before==2&&!completed(p,r,"hunt"))RaidRules.tell(p,"Охота выполнена: 3 угрозы устранены. Эвакуируйтесь за наградой.");
 }
 public static void award(ServerPlayer p,CompoundTag raid){
  if(!raid.getString("status").equals("COMMIT")||!raid.contains("contractCycle"))return;
  if(raid.getBoolean("visit_echo")&&raid.getBoolean("visit_signal"))add(p,raid,"scout",new ItemStack(Items.IRON_BLOCK,2));
  if(raid.getInt("hunts")>=3)add(p,raid,"hunt",new ItemStack(Items.EMERALD,6));
 }
 private static void add(ServerPlayer p,CompoundTag raid,String kind,ItemStack stack){
  add(p,p.getUUID(),raid,kind,stack);
 }
 static void add(ServerPlayer p,UUID recipient,CompoundTag raid,String kind,ItemStack stack){
  var j=RaidJournal.get(p.server);UUID id=UUID.nameUUIDFromBytes((recipient+":"+raid.getString("contractCycle")+":"+kind).getBytes(StandardCharsets.UTF_8));if(j.completed.contains(id.toString()))return;
  var mail=j.mail.computeIfAbsent(recipient,key->new ListTag());var entry=new CompoundTag();entry.putUUID("id",id);entry.put("item",stack.save(p.registryAccess()));mail.add(entry);j.completed.add(id.toString());j.setDirty();
 }
 public static int count(ServerPlayer p){return RaidJournal.get(p.server).mail.getOrDefault(p.getUUID(),new ListTag()).size();}
 public static int claim(ServerPlayer p){
  if(RaidRules.active(p)||!Set.of(BunkerRelay.HUB,BunkerRelay.BUNKER,BunkerRelay.GARAGE).contains(p.level().dimension())){RaidRules.tell(p,"Награды забираются в бункере/гараже после завершения вылазки.");return 0;}
  var j=RaidJournal.get(p.server);var mail=j.mail.getOrDefault(p.getUUID(),new ListTag());var left=new ListTag();var receipts=p.getPersistentData().getCompound("relay_reward_receipts");int granted=0;
  for(var tag:mail){var entry=(CompoundTag)tag;String id=entry.getUUID("id").toString();if(receipts.contains(id))continue;
   var item=ItemStack.parseOptional(p.registryAccess(),entry.getCompound("item"));if(item.isEmpty()||SafeInventory.capacity(p.getInventory(),item)<item.getCount()){left.add(entry.copy());continue;}
   SafeInventory.insert(p.getInventory(),item);receipts.putBoolean(id,true);granted++;
  }
  p.getPersistentData().put("relay_reward_receipts",receipts);p.inventoryMenu.broadcastChanges();p.server.getPlayerList().saveAll();
  j.mail.put(p.getUUID(),left);j.flush(p.server);RaidRules.tell(p,"Получено наград: "+granted+". В почте: "+left.size()+". Непоместившиеся награды сохраняются.");return granted;
 }
 public static int open(ServerPlayer p){p.openMenu(new SimpleMenuProvider((id,inv,player)->new JournalMenu(id,inv,p),Component.literal("Журнал вылазки")));return 1;}
 public static final class JournalMenu extends ChestMenu {
  private final ServerPlayer owner;private final SimpleContainer panel;
  public JournalMenu(int id,Inventory inv){super(RelayMenus.JOURNAL.get(),id,inv,new SimpleContainer(27),3);owner=null;panel=(SimpleContainer)getContainer();}
 public JournalMenu(int id,Inventory inv,ServerPlayer p){this(id,inv,p,new SimpleContainer(27));}
  private JournalMenu(int id,Inventory inv,ServerPlayer p,SimpleContainer c){super(RelayMenus.JOURNAL.get(),id,inv,c,3);owner=p;panel=c;refresh();}
  private void icon(int slot,Item item,String title,String description){var stack=new ItemStack(item);stack.set(DataComponents.CUSTOM_NAME,Component.literal(title));stack.set(DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(List.of(Component.literal(description))));panel.setItem(slot,stack);}
  private void refresh(){var s=RelayState.get(owner.server);var r=RaidRules.active(owner)?RaidRules.record(owner):new CompoundTag();if(!r.contains("contractCycle"))r.putString("contractCycle",cycle(s));int visits=(r.getBoolean("visit_echo")?1:0)+(r.getBoolean("visit_signal")?1:0);
   icon(4,Items.COMPASS,s.relayPowered?"Радиостанция включена":"Основная цель: включить радиостанцию",new BlockPos(s.relayX,s.relayY,s.relayZ).toShortString());
   icon(10,Items.MAP,completed(owner,r,"scout")?"Разведка: награда за зону начислена":"Разведка: "+visits+" / 2","Зайти внутрь лаборатории и блокпоста. Награда: 2 железных блока.");
   icon(12,Items.IRON_SWORD,completed(owner,r,"hunt")?"Охота: награда за зону начислена":"Охота: "+Math.min(3,r.getInt("hunts"))+" / 3","Лично устранить особых мобов. Награда: 6 изумрудов.");
   icon(16,Items.CHEST,"Почта: "+count(owner),"Задачи необязательны. Награда — после эвакуации, один раз за зону.");
   icon(14,Items.BARREL,CargoContract.status(s),"Показать точку груза");
   if(BunkerRelay.nearTerminal(owner))icon(24,Items.WRITABLE_BOOK,"Заказы снабжения","Список нужных материалов");
   icon(20,Items.PAPER,"Координаты объектов","Показать разведданные в чате");icon(22,Items.EMERALD,"Забрать награды","Только в бункере/гараже. При нехватке места награды остаются в почте.");
  }
  @Override public void clicked(int slot,int button,ClickType type,Player p){if(p!=owner||type!=ClickType.PICKUP)return;if(slot==14)CargoContract.report(owner);if(slot==24&&BunkerRelay.nearTerminal(owner)){SupplyOrders.open(owner);return;}if(slot==20)RaidDirector.report(owner);if(slot==22)claim(owner);refresh();sendAllDataToRemote();}
  @Override public ItemStack quickMoveStack(Player p,int slot){return ItemStack.EMPTY;}
  @Override public boolean stillValid(Player p){return p==owner;}
  @Override public void broadcastChanges(){if(owner!=null)refresh();super.broadcastChanges();}
 }
 private RaidContracts(){}
}
