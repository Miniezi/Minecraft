package dev.bunkerrelay;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class RelayTerminalBlock {
    static final DeferredRegister.Blocks BLOCKS=DeferredRegister.createBlocks("bunkerrelay");
    static final java.util.function.Supplier<Block> TERMINAL=BLOCKS.register("terminal",()->
        new Block(BlockBehaviour.Properties.of().strength(4).lightLevel(state->5)));
    public static boolean isTarget(net.minecraft.world.level.Level level,net.minecraft.core.BlockPos pos){
        var dimension=level.dimension();
        boolean console=dimension.equals(BunkerRelay.HUB)&&pos.equals(HubBuilder.TERMINAL)
            ||dimension.equals(BunkerRelay.BUNKER)&&pos.equals(new net.minecraft.core.BlockPos(0,30,0));
        var block=level.getBlockState(pos);
        return console&&(block.is(TERMINAL.get())||block.is(net.minecraft.world.level.block.Blocks.LODESTONE));
    }
    private RelayTerminalBlock(){}
}
