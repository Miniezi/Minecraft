package dev.bunkerrelay;
import java.util.*;
public final class ZonePlan {
 public record Site(int x,int z,int kind){}
 public static List<Site> sites(long seed,int difficulty){
  if(difficulty<1||difficulty>5)throw new IllegalArgumentException("difficulty 1..5");
  Random rng=new Random(seed);List<int[]> cells=new ArrayList<>();List<Site> sites=new ArrayList<>();
  for(int x=-64;x<=64;x+=32)for(int z=-64;z<=64;z+=32)if(Math.abs(x)>16||Math.abs(z)>16)cells.add(new int[]{x,z});
  Collections.shuffle(cells,rng);
  for(int i=0;i<5+difficulty*2;i++){int[] c=cells.get(i);sites.add(new Site(c[0]+rng.nextInt(7)-3,c[1]+rng.nextInt(7)-3,rng.nextInt(3)));}
  return List.copyOf(sites);
 }
 public static int lootCount(int tier){if(tier<1||tier>5)throw new IllegalArgumentException();return 2+tier*2;}
}
