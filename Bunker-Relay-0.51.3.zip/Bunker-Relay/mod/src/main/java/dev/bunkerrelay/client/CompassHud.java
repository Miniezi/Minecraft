package dev.bunkerrelay.client;
import dev.bunkerrelay.ExitSignal;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

final class CompassHud {
 private static long lastFrame;
 private static double heading,bearing;
 static void reset(){lastFrame=0;}
 static double approach(double current,double target,double seconds){
  double delta=((target-current+180)%360+360)%360-180;
  return current+delta*(1-Math.exp(-14*seconds));
 }
 static void render(GuiGraphics gui){
  var mc=Minecraft.getInstance();var signal=ExitSignal.current;
  if(mc.player==null||mc.level==null||mc.options.hideGui||signal==null||signal.compass().isEmpty()
    ||!mc.level.dimension().location().equals(signal.dimension())){reset();return;}
  float partial=mc.getTimer().getGameTimeDeltaPartialTick(false);
  double x=Mth.lerp(partial,mc.player.xo,mc.player.getX()),z=Mth.lerp(partial,mc.player.zo,mc.player.getZ());
  double dx=signal.target().getX()+.5-x,dz=signal.target().getZ()+.5-z;
  double yaw=mc.player.getViewYRot(partial);
  double goal=dx*dx+dz*dz<.01?bearing:Math.toDegrees(Math.atan2(-dx,dz));
  long now=System.nanoTime();
  if(lastFrame==0){heading=yaw;bearing=goal;}
  else{double dt=Math.min(.1,(now-lastFrame)*1e-9);heading=approach(heading,yaw,dt);bearing=approach(bearing,goal,dt);}
  lastFrame=now;
  int cx=39,cy=39;
  String label=mc.font.plainSubstrByWidth(signal.compass(),Math.max(20,Math.min(220,gui.guiWidth()-86)));
  String info=(int)Math.ceil(Math.sqrt(dx*dx+dz*dz+Math.pow(signal.target().getY()-mc.player.getY(),2)))+" м";
  if(dx*dx+dz*dz<9)info+=" · "+(Math.abs(signal.target().getY()-mc.player.getY())>5?(signal.target().getY()>mc.player.getY()?"выше":"ниже"):"на месте");
  gui.fill(6,6,Math.max(76,77+Math.max(mc.font.width(label),mc.font.width(info))),73,0xcc101c23);
  for(int i=0;i<360;i+=3){double a=Math.toRadians(i);pixel(gui,cx+Math.sin(a)*29,cy-Math.cos(a)*29,0xff46777e);}
  for(int i=0;i<360;i+=15){double a=Math.toRadians(i-heading);for(int r=i%90==0?21:25;r<=28;r++)pixel(gui,cx+Math.sin(a)*r,cy-Math.cos(a)*r,0xff79a6aa);}
  String[] names={"Ю","З","С","В"};
  for(int i=0;i<4;i++){double a=Math.toRadians(i*90-heading);String name=names[i];gui.drawString(mc.font,name,(int)Math.round(cx+Math.sin(a)*17)-mc.font.width(name)/2,(int)Math.round(cy-Math.cos(a)*17)-4,i==2?0xffffb777:0xffade9dc,false);}
  gui.fill(cx-1,7,cx+2,12,0xffe4f9ef);
  double a=Math.toRadians(bearing-heading);
  int tx=(int)Math.round(cx+Math.sin(a)*25),ty=(int)Math.round(cy-Math.cos(a)*25);
  gui.fill(tx-2,ty-1,tx+3,ty+2,0xffffc66d);gui.fill(tx-1,ty-2,tx+2,ty+3,0xffffc66d);
  gui.fill(cx-1,cy-1,cx+2,cy+2,0xffade9dc);
  gui.drawString(mc.font,label,76,26,0xffade9dc);gui.drawString(mc.font,info,76,41,0xffffc66d);
 }
 private static void pixel(GuiGraphics gui,double x,double y,int color){int px=(int)Math.round(x),py=(int)Math.round(y);gui.fill(px,py,px+1,py+1,color);}
 private CompassHud(){}
}
