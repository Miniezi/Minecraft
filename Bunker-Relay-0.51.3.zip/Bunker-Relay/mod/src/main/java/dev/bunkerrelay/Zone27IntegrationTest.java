package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;

final class Zone27IntegrationTest {
    static void start(MinecraftServer server,RelayState state){
        var legacy=server.getLevel(BunkerRelay.key(state.activeDimension));
        var site=new BlockPos(240,75,240);
        for(int dx=-6;dx<=6;dx++)for(int dz=-6;dz<=6;dz++)
            legacy.setBlock(site.offset(dx,-1,dz),Blocks.STONE.defaultBlockState(),2);
        int oldFloor=StructureLevels.floor(legacy,state,"test",240,240,4,4,8);
        legacy.setBlock(site.east(5).above(7),Blocks.STONE.defaultBlockState(),3);
        legacy.setBlock(site.atY(oldFloor+7),Blocks.STONE.defaultBlockState(),3);
        legacy.setBlock(site.atY(oldFloor-1),Blocks.AIR.defaultBlockState(),3);
        if(StructureLevels.floor(legacy,state,"test",240,240,4,4,8)!=oldFloor
            ||!legacy.isEmptyBlock(site.atY(oldFloor+7))||legacy.isEmptyBlock(site.atY(oldFloor-1)))
            throw new IllegalStateException("Footprint grading failed");
        for(int variant=0;variant<3;variant++){
            var tower=site.south(variant*30);
            if(!SporeSites.place(legacy,tower,variant)||!legacy.getBlockState(tower.below()).is(Blocks.MOSSY_COBBLESTONE))
                throw new IllegalStateException("Spore template did not place: "+variant);
        }
        state.activeSize=state.size=2048;
        RegionalIntegrationTest.verify(server,state);
        FieldSecurityIntegrationTest.verify(server,state);
        Update22IntegrationTest.verify(server,state);
        BossIntegrationTest.verify(server,state);

        for(String dimension:java.util.List.of("city","infected_city","ashlands"))
            CityIntegration.smoke(server.getLevel(BunkerRelay.key(dimension)),state);
        var city=BunkerRelay.key("city");
        for(int center:new int[]{-1024,0,1024}){
            for(int offset:new int[]{-6,-2,0,1,5,6})
                if(!CityParcels.reserved(city,center+offset,center))
                    throw new IllegalStateException("City parcel alignment at "+center);
            if(CityParcels.reserved(city,center+3,center+3))
                throw new IllegalStateException("City block should be available");
        }
        if(CityParcels.reserved(net.minecraft.world.level.Level.OVERWORLD,0,0))
            throw new IllegalStateException("Outside worlds must retain their generation");
        System.out.println("RELAY_CITY_GRID_PASS");
        state.initialized=true;
        state.hubV2=true;
        state.activeTheme="forest";
        state.theme="forest";
        state.activeDimension="forest_expedition";
        state.activeSize=state.size=2048;
        state.seed=27027;
        state.raidRulesVersion=3;
        state.variableStories=true;
        HubBuilder.build(server.getLevel(BunkerRelay.HUB));
        WarehouseIntegrationTest.verify(server);
        DismantleIntegrationTest.verify(server);
        BunkerRequestsIntegrationTest.verify(server,state);
        var forest=server.getLevel(BunkerRelay.key(state.activeDimension));
        for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++){
            if(forest.getChunk(x,z).getAllStarts().values().stream().anyMatch(start->start.isValid()))
                throw new IllegalStateException("Unapproved structure in the expedition");
        }
        var builder=new ExpeditionBuilder(forest,state);
        for(int step=0;step<=33;step++)builder.tick();
        state.generation++;
        state.ready=true;
        state.setDirty();
        System.out.println("RELAY_027_PASS raised_floor=true spore_template=true structure_filter=true");
        SporeIntegrationTest.verify(server,state);
        CombatIntegrationTest.verify(server,state);
        LootEconomyIntegrationTest.verify(server,state);
        ExpeditionLightIntegrationTest.verify(server,state);
        RelayTestCommandsIntegrationTest.verify(server,state);
        CoopIntegrationTest.verify(server,state);
        LiveRefreshTest.start(server,state);
    }

    private Zone27IntegrationTest(){}
}
