package dev.bunkerrelay;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.items.ItemStackHandler;
public final class LootMenuIntegrationTest {
 private static void check(boolean b,String m){if(!b)throw new IllegalStateException("LOOT MENU TEST: "+m);}
 private static void fill(Inventory inv){inv.clearContent();for(int i=0;i<36;i++)inv.setItem(i,new ItemStack(Items.COBBLESTONE,64));}
 public static void run(MinecraftServer server){
  var journal=RaidJournal.get(server);journal.raids.remove(UUID.fromString("9847c63c-ce6e-4f13-b650-5f937646d6e7"));journal.raids.remove(UUID.fromString("ad48df28-e473-47d3-99d7-45dce68c0fd1"));journal.flush(server);
  var s=RelayState.get(server);var level=server.getLevel(BunkerRelay.key(s.activeDimension));
  var p=new FakePlayer(level,new GameProfile(UUID.fromString("9847c63c-ce6e-4f13-b650-5f937646d6e7"),"LootMenuTest"));p.moveTo(s.centerX+20,s.spawnY,s.centerZ+20);
  check(RaidRules.begin(p,s)==null,"raid entry");
  var c=new SimpleContainer(90);c.setItem(0,new ItemStack(Items.DIAMOND,64));c.setItem(1,new ItemStack(Items.IRON_INGOT,20));c.setItem(50,new ItemStack(Items.GOLD_INGOT,7));
  var menu=new RaidLootMenu(10,p.getInventory(),p,RaidLootMenu.container(c,()->true));
  for(GameType mode:new GameType[]{GameType.SURVIVAL,GameType.CREATIVE}){
   p.setGameMode(mode);fill(p.getInventory());int before=c.getItem(0).getCount();
   menu.clicked(0,0,ClickType.PICKUP,p);menu.clicked(0,0,ClickType.QUICK_MOVE,p);check(c.getItem(0).getCount()==before&&menu.getCarried().isEmpty(),"full inventory preserved in "+mode);
  }
  p.setGameMode(GameType.SURVIVAL);fill(p.getInventory());p.getInventory().setItem(0,new ItemStack(Items.DIAMOND,62));
  menu.clicked(0,0,ClickType.PICKUP,p);check(p.getInventory().getItem(0).getCount()==64&&c.getItem(0).getCount()==62,"partial stack only takes available capacity");
  p.getInventory().setItem(1,ItemStack.EMPTY);menu.clicked(1,1,ClickType.PICKUP,p);check(p.getInventory().getItem(1).getCount()==1&&c.getItem(1).getCount()==19,"right click takes exactly one selected item");
  menu.clicked(53,0,ClickType.PICKUP,p);p.getInventory().setItem(2,ItemStack.EMPTY);menu.clicked(5,0,ClickType.PICKUP,p);check(p.getInventory().getItem(2).is(Items.GOLD_INGOT)&&p.getInventory().getItem(2).getCount()==7&&c.getItem(50).isEmpty(),"second page exact source slot");
  menu.clicked(45,0,ClickType.PICKUP,p);int left=c.getItem(0).getCount();
  for(var type:new ClickType[]{ClickType.CLONE,ClickType.SWAP,ClickType.THROW,ClickType.PICKUP_ALL})menu.clicked(0,0,type,p);
  check(c.getItem(0).getCount()==left&&menu.getCarried().isEmpty(),"preview cannot be cloned, swapped, thrown or collected");
  menu.setCarried(new ItemStack(Items.EMERALD,3));menu.clicked(0,0,ClickType.PICKUP,p);check(c.getItem(0).getCount()==left&&menu.getCarried().getCount()==3,"deposit does not consume carried item");menu.setCarried(ItemStack.EMPTY);
  var p2=new FakePlayer(level,new GameProfile(UUID.fromString("ad48df28-e473-47d3-99d7-45dce68c0fd1"),"LootMenuTest2"));check(RaidRules.begin(p2,s)==null,"second participant");
  var menu2=new RaidLootMenu(11,p2.getInventory(),p2,RaidLootMenu.container(c,()->true));p.getInventory().clearContent();menu.clicked(0,0,ClickType.PICKUP,p);menu2.clicked(0,0,ClickType.PICKUP,p);check(p.getInventory().getItem(0).getCount()==left&&p2.getInventory().isEmpty(),"two players share one real stack");
  var handler=new ItemStackHandler(80);handler.setStackInSlot(0,new ItemStack(Items.REDSTONE,9));var modMenu=new RaidLootMenu(12,p2.getInventory(),p2,RaidLootMenu.handler(handler,()->true));modMenu.clicked(0,0,ClickType.PICKUP,p2);check(handler.getStackInSlot(0).isEmpty()&&p2.getInventory().getItem(0).getCount()==9,"mod item handler extraction");
  var broken=new RaidLootMenu(13,p.getInventory(),p,RaidLootMenu.container(c,()->false));int old=c.getItem(1).getCount();broken.clicked(1,0,ClickType.PICKUP,p);check(c.getItem(1).getCount()==old,"removed/out-of-range source cannot be accessed");
  p.getInventory().clearContent();p.getInventory().setItem(0,new ItemStack(Items.IRON_INGOT,12));
  var trash=new TrashMenu(14,p.getInventory(),p);trash.clicked(54,0,ClickType.QUICK_MOVE,p);check(trash.getSlot(0).getItem().getCount()==12&&p.getInventory().getItem(0).isEmpty(),"trash keeps deposited stack before close");
  trash.clicked(0,0,ClickType.QUICK_MOVE,p);check(trash.getSlot(0).getItem().isEmpty()&&p.getInventory().items.stream().anyMatch(i->i.is(Items.IRON_INGOT)&&i.getCount()==12),"trash item can be recovered before close");
  trash.getSlot(0).set(new ItemStack(Items.DIRT,8));trash.setCarried(new ItemStack(Items.EMERALD,2));trash.removed(p);check(trash.getSlot(0).getItem().isEmpty()&&p.getInventory().items.stream().anyMatch(i->i.is(Items.EMERALD)&&i.getCount()==2),"close deletes only trash slots, returns cursor");
  fill(p.getInventory());var fullTrash=new TrashMenu(15,p.getInventory(),p);fullTrash.setCarried(new ItemStack(Items.DIAMOND,5));fullTrash.removed(p);check(!RaidRules.record(p).getList("overflow",10).isEmpty(),"cursor overflow journaled, never destroyed");
  var normal=new BlockEvent.BreakEvent(level,new BlockPos(s.centerX+20,s.spawnY,s.centerZ+20),Blocks.STONE.defaultBlockState(),p);NeoForge.EVENT_BUS.post(normal);check(!normal.isCanceled(),"ordinary block mining allowed");
  var objective=new BlockEvent.BreakEvent(level,new BlockPos(s.relayX,s.relayY,s.relayZ),Blocks.LODESTONE.defaultBlockState(),p);NeoForge.EVENT_BUS.post(objective);check(objective.isCanceled(),"mission radio protected");
  journal.raids.remove(p.getUUID());journal.raids.remove(p2.getUUID());journal.flush(server);
  System.out.println("RELAY_LOOT_MENU_PASS: survival/creative full inventories, partial stacks, one-item choice, pages, shared loot, mod handlers, forbidden preview clicks, trash undo/close/cursor, block mining");
 }
 private LootMenuIntegrationTest(){}
}
