package dev.bunkerrelay;
import net.minecraft.core.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.*;
public final class HubBuilder {
 public static final BlockPos TERMINAL=new BlockPos(0,73,28);
 private static void set(ServerLevel l,int x,int y,int z,Block b){l.setBlock(new BlockPos(x,y,z),b.defaultBlockState(),2);}
 public static void build(ServerLevel l){
  for(int x=-30;x<=30;x++)for(int z=-30;z<=8;z++){
   if((Math.abs(x)==30||z==-30||z==8)&&!(z==-30&&Math.abs(x)<3)){set(l,x,96,z,Blocks.DEEPSLATE_BRICKS);set(l,x,97,z,Blocks.IRON_BARS);set(l,x,98,z,Blocks.IRON_BARS);}
   if(Math.abs(x)<=3)set(l,x,95,z,Blocks.GRAVEL);
   if((x==-28||x==28)&&(z+28)%12==0){set(l,x,96,z,Blocks.STONE_BRICK_WALL);set(l,x,97,z,Blocks.LANTERN);}
  }
  room(l,-10,10,18,38);room(l,11,31,18,38);
  for(int z=25;z<=29;z++)for(int y=73;y<=76;y++){set(l,10,y,z,Blocks.AIR);set(l,11,y,z,Blocks.AIR);}
  for(int step=0;step<=23;step++){
   int z=step-6,y=95-step;
   for(int x=-2;x<=2;x++)for(int dy=0;dy<=5;dy++){
    if(Math.abs(x)==2||dy==5)set(l,x,y+dy,z,Blocks.GRAY_CONCRETE);
    else if(dy==0)l.setBlock(new BlockPos(x,y,z),Blocks.STONE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.NORTH),2);
    else set(l,x,y+dy,z,Blocks.AIR);
   }
  }
  for(int x=-1;x<=1;x++)for(int y=73;y<=76;y++)set(l,x,y,18,Blocks.AIR);
  for(int z=-6;z<=-3;z++)for(int x=-3;x<=3;x++)set(l,x,101,z,Blocks.GRAY_CONCRETE);
  set(l,0,73,28,RelayTerminalBlock.TERMINAL.get());
  for(int x=-2;x<=2;x++)for(int z=26;z<=30;z++)
   set(l,x,72,z,Math.abs(x)==2?Blocks.YELLOW_CONCRETE:Blocks.POLISHED_DEEPSLATE);
  for(int x:new int[]{-2,2}){
   for(int y=73;y<=75;y++)set(l,x,y,28,Blocks.POLISHED_DEEPSLATE_WALL);
   set(l,x,76,28,Blocks.SEA_LANTERN);
  }
  for(int x=-2;x<=2;x++)set(l,x,77,28,Blocks.DEEPSLATE_TILES);
  set(l,-8,73,35,Blocks.CRAFTING_TABLE);set(l,-6,73,35,Blocks.FURNACE);set(l,-4,73,35,Blocks.CHEST);
  set(l,14,73,35,Blocks.CRAFTING_TABLE);set(l,16,73,35,Blocks.BLAST_FURNACE);set(l,18,73,35,Blocks.BARREL);
  for(int x=14;x<=28;x++)set(l,x,74,38,x%2==0?Blocks.YELLOW_CONCRETE:Blocks.BLACK_CONCRETE);
  for(int x=-2;x<=2;x++)set(l,x,96,-30,Blocks.OAK_FENCE_GATE);
  // The starter courtyard has a covered loading bay and a raised pedestrian route.
  for(int x=8;x<=23;x++)for(int z=-22;z<=-10;z++){
   set(l,x,95,z,(x==8||x==23)?Blocks.YELLOW_CONCRETE:Blocks.SMOOTH_STONE);
   if(x>=10&&x<=21&&z>=-20&&z<=-12)set(l,x,101,z,(x+z)%9==0?Blocks.SEA_LANTERN:Blocks.DEEPSLATE_TILES);
  }
  for(int x:new int[]{10,21})for(int z:new int[]{-20,-12})
   for(int y=96;y<101;y++)set(l,x,y,z,Blocks.POLISHED_DEEPSLATE_WALL);
  for(int x=-7;x<=7;x++)for(int z=-14;z<=-12;z++)set(l,x,95,z,Blocks.STONE_BRICKS);
  for(int x:new int[]{-7,7}){set(l,x,96,-13,Blocks.STONE_BRICK_WALL);set(l,x,97,-13,Blocks.LANTERN);}
  for(int z=20;z<=36;z++)if(z<26||z>30)set(l,0,72,z,Blocks.SMOOTH_STONE);
  for(int x:new int[]{-3,3})for(int y=96;y<=101;y++)
   set(l,x,y,-7,y==100?Blocks.YELLOW_CONCRETE:Blocks.POLISHED_DEEPSLATE);
  for(int x=-3;x<=3;x++)set(l,x,101,-7,x==0?Blocks.SEA_LANTERN:Blocks.DEEPSLATE_TILES);
  for(int x=-2;x<=2;x++)for(int z=-11;z<=-7;z++)set(l,x,95,z,Blocks.SMOOTH_STONE);
  for(int x:new int[]{-2,2})set(l,x,96,-10,Blocks.LANTERN);

 }
 private static void room(ServerLevel l,int x1,int x2,int z1,int z2){
  for(int x=x1;x<=x2;x++)for(int z=z1;z<=z2;z++)for(int y=72;y<=79;y++){
   boolean shell=x==x1||x==x2||z==z1||z==z2||y==72||y==79;
   set(l,x,y,z,shell?(y==72?Blocks.POLISHED_ANDESITE:Blocks.GRAY_CONCRETE):Blocks.AIR);
   if(y==79&&(x-x1)%5==2&&(z-z1)%5==2)set(l,x,y,z,Blocks.SEA_LANTERN);
  }
 }
 static void upgradeTerminal(ServerLevel level){if(level!=null&&level.getBlockState(TERMINAL).is(Blocks.LODESTONE))level.setBlock(TERMINAL,RelayTerminalBlock.TERMINAL.get().defaultBlockState(),3);}
 private HubBuilder(){}
}
