package dev.bunkerrelay;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
/** Inventory.add discards leftovers for creative players. These transfers never do. */
public final class SafeInventory {
 public static int capacity(Inventory inv,ItemStack stack){
  if(stack.isEmpty())return 0;long room=0;
  for(var slot:inv.items){int limit=Math.min(inv.getMaxStackSize(stack),stack.getMaxStackSize());if(slot.isEmpty())room+=limit;else if(ItemStack.isSameItemSameComponents(slot,stack))room+=Math.max(0,limit-slot.getCount());}
  return (int)Math.min(Integer.MAX_VALUE,room);
 }
 public static void insert(Inventory inv,ItemStack stack){
  if(stack.isEmpty())return;
  for(int pass=0;pass<2&&!stack.isEmpty();pass++)for(int i=0;i<inv.items.size()&&!stack.isEmpty();i++){
   ItemStack slot=inv.items.get(i);int limit=Math.min(inv.getMaxStackSize(stack),stack.getMaxStackSize());
   if(pass==0&&!slot.isEmpty()&&ItemStack.isSameItemSameComponents(slot,stack)){int n=Math.min(stack.getCount(),Math.max(0,limit-slot.getCount()));slot.grow(n);stack.shrink(n);}
   else if(pass==1&&slot.isEmpty()){int n=Math.min(stack.getCount(),limit);inv.items.set(i,stack.split(n));}
  }inv.setChanged();
 }
 public static void returnCarried(ServerPlayer p,ItemStack stack){insert(p.getInventory(),stack);if(stack.isEmpty())return;if(RaidRules.active(p))RaidRules.storeOverflow(p,stack);else p.drop(stack.copy(),false);stack.setCount(0);}
 private SafeInventory(){}
}
