package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
public final class RaidBosses {
 static ServerBossEvent bar;
 public static void reset(){if(bar!=null)bar.removeAllPlayers();bar=null;}
 public static String name(RelayState s){return switch(s.activeTheme){case "infected"->"Носитель Эхо";case "forest"->"Лесной егерь";case "ash"->"Пепельный кузнец";default->"Страж карантина";};}
 private static Component appearance(RelayState state,Mob boss){
  if(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(boss.getType()).getNamespace().equals("spore"))return Component.literal(name(state));
  String theme=switch(state.activeTheme){case "infected","forest","ash"->state.activeTheme;default->"industrial";};
  return Component.literal(name(state)).withStyle(style->style.withInsertion("bunkerrelay:boss/"+theme));
 }
 public static BlockPos arena(RelayState s){return ExpeditionLayout.arena(s).atY(s.bossY);}
 public static void prepare(ServerLevel level,RelayState s){var point=ExpeditionLayout.arena(s);int x=point.getX(),z=point.getZ();int y=StructureLevels.floor(level,s,"arena",x,z,18,18,10);s.bossY=y;s.bossGeneration=s.generation+1;s.bossId=null;s.bossDefeated=false;s.bossAbility=0;reset();
  BossArena.build(level,s,new BlockPos(x,y,z));s.setDirty();
 }
 public static void second(MinecraftServer server,RelayState s){if(!s.ready||s.bossGeneration!=s.generation||s.bossDefeated){reset();return;}var level=server.getLevel(BunkerRelay.key(s.activeDimension));if(level==null)return;var pos=arena(s);var players=server.getPlayerList().getPlayers().stream().filter(p->p.isAlive()&&!p.isSpectator()&&RaidRules.active(p)&&p.serverLevel()==level&&p.blockPosition().distSqr(pos)<80*80).toList();encounter(server,s,level,players);}
 static void encounter(MinecraftServer server,RelayState s,ServerLevel level,java.util.List<ServerPlayer> players){var pos=arena(s);if(players.isEmpty()){reset();if(s.bossAbility!=0){s.bossAbility=0;s.setDirty();}return;}Mob boss;
  if(s.bossId==null){boss=SporeSites.boss(level,s.activeTheme);if(boss==null)return;boss.moveTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5,0,0);boss.setCustomName(appearance(s,boss));boss.setCustomNameVisible(true);boss.setPersistenceRequired();boss.getAttribute(Attributes.MAX_HEALTH).setBaseValue(120+60*s.activeDifficulty);var attack=boss.getAttribute(Attributes.ATTACK_DAMAGE);if(attack!=null)attack.setBaseValue(5+2*s.activeDifficulty);boss.setHealth(boss.getMaxHealth());boss.getPersistentData().putBoolean("relay_boss",true);boss.addTag("relay_scaled");if(appearance(s,boss).getStyle().getInsertion()!=null&&(s.activeTheme.equals("forest")||s.activeTheme.equals("ash"))){boss.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(s.activeTheme.equals("forest")?Items.IRON_AXE:Items.IRON_SWORD));boss.setDropChance(EquipmentSlot.MAINHAND,0);}if(!level.addFreshEntity(boss))return;s.bossId=boss.getUUID();s.setDirty();}
  else{var entity=level.getEntity(s.bossId);if(!(entity instanceof Mob found)||!found.isAlive()){reset();return;}boss=found;if(!appearance(s,boss).equals(boss.getCustomName()))boss.setCustomName(appearance(s,boss));}
  if(bar==null)bar=new ServerBossEvent(Component.literal(name(s)),BossEvent.BossBarColor.RED,BossEvent.BossBarOverlay.NOTCHED_10);
  bar.setProgress(Math.clamp(boss.getHealth()/boss.getMaxHealth(),0,1));
  for(var p:new ArrayList<>(bar.getPlayers()))if(!players.contains(p))bar.removePlayer(p);
  players.forEach(bar::addPlayer);
  var currentBoss=boss;
  var target=players.stream().filter(p->p.blockPosition().distSqr(pos)<=48*48).min(Comparator.comparingDouble(p->p.distanceToSqr(currentBoss))).orElse(null);
  if(target==null){boss.getPersistentData().remove("relay_impact");boss.setTarget(null);s.bossAbility=0;s.setDirty();return;}
  boss.setTarget(target);
  if(boss.blockPosition().distSqr(pos)>64*64)boss.teleportTo(pos.getX()+.5,pos.getY(),pos.getZ()+.5);
  var data=boss.getPersistentData();
  boolean secondPhase=data.getBoolean("relay_phase_two");
  if(!secondPhase&&boss.getHealth()<=boss.getMaxHealth()/2){
   secondPhase=true;data.putBoolean("relay_phase_two",true);s.bossAbility=0;data.remove("relay_impact");
   BossEffects.phase(level,boss.blockPosition(),s.activeTheme);
   for(var player:players)RaidHud.alert(player,name(s)+": вторая фаза — приближается подкрепление!");
   RaidDirector.spawnNear(target,s,s.activeTheme.equals("infected")?"stalker":"warden",16);
   RaidDirector.spawnNear(target,s,s.activeTheme.equals("ash")?"screamer":"stalker",20);
  }
  bar.setName(Component.literal(name(s)+" · "+(secondPhase?"Фаза II":"Фаза I")));
  bar.setColor(secondPhase?BossEvent.BossBarColor.PURPLE:BossEvent.BossBarColor.RED);
  int period=secondPhase?8:12;
  int radius=secondPhase?7:5;
  int stage=++s.bossAbility%period;
  s.setDirty();
  if(stage==period-3){
   var point=(s.activeTheme.equals("industrial")?boss:target).blockPosition();
   data.putLong("relay_impact",point.asLong());
   String attack=switch(s.activeTheme){case "forest"->"Засада егеря";case "ash"->"Выброс жара";case "infected"->"Облако спор";default->"Удар Стража";};
   bar.setName(Component.literal(name(s)+" · "+attack));
   for(var player:players)RaidHud.alert(player,attack+" · покиньте отмеченный круг");
  }
  if(stage>=period-3||stage==0){
   if(!data.contains("relay_impact"))return;
   var point=BlockPos.of(data.getLong("relay_impact"));
   if(stage!=0)BossEffects.warning(level,point,s.activeTheme,radius,stage==period-3);
   if(stage==0){
    BossEffects.strike(level,point,s.activeTheme,radius);
    data.remove("relay_impact");
    for(var p:players)if(p.blockPosition().distSqr(point)<=radius*radius&&boss.hasLineOfSight(p)){
     p.hurt(level.damageSources().mobAttack(boss),4+s.activeDifficulty+(secondPhase?2:0));
     switch(s.activeTheme){
      case "infected" -> p.addEffect(new MobEffectInstance(MobEffects.POISON,80,0));
      case "ash" -> p.igniteForSeconds(3);
      case "forest" -> p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,100,1));
      default -> {p.push((p.getX()-point.getX())*.18,.5,(p.getZ()-point.getZ())*.18);p.hurtMarked=true;}
     }
    }
   }
  }
 }
 public static void died(LivingDeathEvent e){
  var entity=e.getEntity();
  if(!(entity.level() instanceof ServerLevel level)||!entity.getPersistentData().getBoolean("relay_boss"))return;
  var s=RelayState.get(level.getServer());
  if(!s.ready||!level.dimension().equals(BunkerRelay.key(s.activeDimension))||s.bossDefeated||s.bossGeneration!=s.generation||!entity.getUUID().equals(s.bossId))return;
  s.bossDefeated=true;s.setDirty();reset();
  entity.spawnAtLocation(new ItemStack(BossTrophies.trophy(s.activeTheme),s.activeDifficulty>=5?2:1));
  entity.spawnAtLocation(new ItemStack(Items.DIAMOND,1+s.activeLoot));
  entity.spawnAtLocation(new ItemStack(Items.EXPERIENCE_BOTTLE,3+s.activeLoot));
  String module=switch(s.activeTheme){case "forest"->"scope_mk5hd";case "ash"->"extended_mag_3";case "infected"->"muzzle_silencer_sg";default->"laser_ngal";};
  entity.spawnAtLocation(com.tacz.guns.api.item.builder.AttachmentItemBuilder.create().setId(net.minecraft.resources.ResourceLocation.parse("tacz:"+module)).build());
  String gun=switch(s.activeTheme){case "forest"->"svd";case "ash"->"rpk";case "infected"->"spas_12";default->"hk416d";};
  var weapon=com.tacz.guns.api.item.builder.GunItemBuilder.create().setId(net.minecraft.resources.ResourceLocation.parse("tacz:"+gun)).setAmmoCount(0).build(level.registryAccess());
  if(!weapon.isEmpty()){
   weapon.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,Component.literal("Трофейное оружие · "+name(s)));
   entity.spawnAtLocation(weapon);
  }
  for(var p:level.getServer().getPlayerList().getPlayers())if(p.serverLevel()==level&&RaidRules.active(p))
   RaidRules.chat(p,name(s)+" повержен. Добыча · "+entity.blockPosition().toShortString());
 }
 private RaidBosses(){}
}
