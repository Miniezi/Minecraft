package dev.bunkerrelay;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.*;
import net.minecraft.world.level.storage.loot.parameters.*;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.loot.*;
import net.neoforged.neoforge.registries.*;
public final class StructureLoot extends LootModifier {
 public static final DeferredRegister<MapCodec<? extends IGlobalLootModifier>> TYPES=DeferredRegister.create(NeoForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS,"bunkerrelay");
 public static final MapCodec<StructureLoot> CODEC=RecordCodecBuilder.mapCodec(i->codecStart(i).apply(i,StructureLoot::new));
 static{TYPES.register("structure_supply",()->CODEC);}
 public StructureLoot(LootItemCondition[] conditions){super(conditions);}
 public MapCodec<? extends IGlobalLootModifier> codec(){return CODEC;}
 @Override protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> original,LootContext ctx){
  var level=ctx.getLevel();if(!BunkerRelay.expedition(level))return original;
  var s=RelayState.get(level.getServer());if(!s.ready||!level.dimension().equals(BunkerRelay.key(s.activeDimension)))return original;
  var origin=ctx.getParamOrNull(LootContextParams.ORIGIN);if(origin==null||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,(int)Math.floor(origin.x),(int)Math.floor(origin.z)))return original;
  var id=ctx.getQueriedLootTableId();var table=level.getServer().reloadableRegistries().getLootTable(ResourceKey.create(Registries.LOOT_TABLE,id));
  if(table.getParamSet()!=LootContextParamSets.CHEST)return original;
  return new ObjectArrayList<>(RaidLoot.generate(level,s,ctx.getRandom()));
 }
}
