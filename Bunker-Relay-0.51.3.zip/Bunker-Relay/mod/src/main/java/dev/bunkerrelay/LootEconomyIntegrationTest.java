package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import com.tacz.guns.api.item.IAmmo;
import com.tacz.guns.api.item.IGun;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.common.util.FakePlayer;

final class LootEconomyIntegrationTest {
    static void verify(MinecraftServer server,RelayState state) {
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var probe=new RelayState();
        probe.seed=3811;
        probe.activeTheme="forest";
        probe.activeLoot=1;
        var low=RaidLoot.generate(level,probe,RandomSource.create(31));
        require(low.size()>=2&&low.stream().noneMatch(stack->stack.getItem() instanceof IGun),"no premium starter cache");
        probe.activeTheme="ash";
        probe.activeLoot=5;
        var high=RaidLoot.generate(level,probe,RandomSource.create(31));
        require(high.size()>low.size(),"high danger has broader cache");
        var at=new BlockPos(51,78,-19);
        var armory=new SimpleContainer(27);
        var repeat=new SimpleContainer(27);
        RaidLoot.specialist(armory,level,probe,at,SupplySites.Kind.ARMORY);
        RaidLoot.specialist(repeat,level,probe,at,SupplySites.Kind.ARMORY);
        for(int i=0;i<27;i++)require(ItemStack.matches(armory.getItem(i),repeat.getItem(i)),"deterministic cache");
        require(armory.getItem(4).getItem() instanceof IAmmo&&armory.getItem(5).getItem() instanceof IAmmo,"armory ammo");
        RaidLoot.specialist(repeat,level,probe,at,SupplySites.Kind.FACTORY);
        require(!(repeat.getItem(4).getItem() instanceof IAmmo)&&!repeat.getItem(7).isEmpty(),"factory components");
        var normal=new SimpleContainer(27);
        var secured=new SimpleContainer(27);
        RaidLoot.airdrop(normal,level,probe,at,false);
        RaidLoot.airdrop(secured,level,probe,at,true);
        require(!(normal.getItem(3).getItem() instanceof IGun)&&secured.getItem(3).getItem() instanceof IGun,"secured firearms");
        require(secured.getItem(4).getCount()>normal.getItem(4).getCount(),"secured ammo reserve");

        var player=new FakePlayer(server.getLevel(BunkerRelay.HUB),new GameProfile(UUID.randomUUID(),"RelayLootMarket")){
            @Override public java.util.OptionalInt openMenu(MenuProvider menu){
                containerMenu=menu.createMenu(77,getInventory(),this);
                return java.util.OptionalInt.of(77);
            }
        };
        var account=RelayEconomy.account(player);
        var pistol=find("glock");
        var ammo=find("9mm");
        require(RelayEconomy.offers(player).contains(pistol)&&RelayEconomy.unitBuy(player,pistol)<650,"available cheaper starter pistol");
        require(RelayEconomy.unitBuy(player,pistol)>SalvageValue.price(pistol.stack(player)),"no buy and sell loop");
        require(RelayEconomy.merchant(find("mek_basic"))==RelayEconomy.Merchant.MECHANISMS,"mechanic sells circuits");
        var old=RelayEconomy.offers(player);
        account.putLong("balance",1000);
        var spent=new CompoundTag();
        spent.putInt(ammo.id(),8);
        account.put("boughtUnits",spent);
        require(RelayEconomy.remainingUnits(player,ammo)==ammo.stock()*ammo.quantity()-8,"existing stock retained");
        RelayEconomy.open(player,false,RelayEconomy.Merchant.WEAPONS);
        long before=RelayEconomy.balance(player);
        player.containerMenu.clicked(9,0,ClickType.PICKUP,player);
        require(RelayEconomy.owned(player,ammo)==1&&RelayEconomy.balance(player)==before-RelayEconomy.unitBuy(player,ammo),"normal shop purchase");
        account.putInt("budget",1000);
        RelayEconomy.open(player,true,RelayEconomy.Merchant.WEAPONS);
        int slot=java.util.stream.IntStream.range(9,45).filter(i->!player.containerMenu.getSlot(i).getItem().isEmpty()).findFirst().orElseThrow();
        player.containerMenu.clicked(slot,0,ClickType.PICKUP,player);
        require(RelayEconomy.owned(player,ammo)==0&&RelayEconomy.balance(player)<before,"normal shop resale");
        var raid=new CompoundTag();
        raid.putString("status","COMMIT");
        raid.putString("contractCycle","loot-economy-test");
        raid.putInt("economyDifficulty",5);
        long saved=RelayEconomy.balance(player);
        RelayEconomy.extracted(player,raid);
        RelayEconomy.extracted(player,raid);
        require(RelayEconomy.balance(player)==saved+RelayEconomy.extractionReward(5),"single danger-scaled payout");
        require(account.getInt("budget")>=1600&&!old.equals(RelayEconomy.offers(player)),"new stock and buyer budget");
        System.out.println("RELAY_LOOT_ECONOMY_PASS");
    }

    private static RelayEconomy.Offer find(String id) {
        return RelayEconomy.CATALOG.stream().filter(offer->offer.id().equals(id)).findFirst().orElseThrow();
    }

    private static void require(boolean condition,String reason) {
        if(!condition)throw new IllegalStateException("Loot economy: "+reason);
    }
}
