package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

final class SectorBuildings {
    static final int SIDE=ExpeditionGrid.SIDE;

    static BlockPos candidate(RelayState state,int sectorX,int sectorZ,int attempt){
        long roll=RaidDirector.roll(ExpeditionLayout.seed(state),sectorX*5+attempt,sectorZ);
        if(state.layoutVersion==3)return new BlockPos(state.centerX+sectorX*SIDE-48+Math.floorMod(roll,97),0,
            state.centerZ+sectorZ*SIDE-48+Math.floorMod(roll>>>16,97));
        return new BlockPos(state.centerX+sectorX*SIDE+32+Math.floorMod(roll,128),0,
            state.centerZ+sectorZ*SIDE+32+Math.floorMod(roll>>>16,128));
    }

    static void discover(ServerPlayer player,RelayState state){
        int sx=ExpeditionGrid.cell(state,player.getBlockX()-state.centerX);
        int sz=ExpeditionGrid.cell(state,player.getBlockZ()-state.centerZ);
        var level=player.serverLevel();
        var director=RaidDirector.get(level.getServer());
        long cell=ChunkPos.asLong(sx,sz);
        if(state.caches.contains(cell)){
            var marked=ReconChart.site(state,sx,sz);
            if(marked!=null)SupplySites.alert(player,state,marked);
            return;
        }
        if(ExpeditionGrid.reserved(state,sx,sz))return;
        if(Math.floorMod(RaidDirector.roll(state.seed,sx,sz),5)==0){state.caches.add(cell);state.setDirty();return;}
        for(int attempt=0;attempt<4;attempt++){
            var point=candidate(state,sx,sz,attempt);
            int x=point.getX(),z=point.getZ();
            if(player.distanceToSqr(x,player.getY(),z)>72*72||!inBounds(state,point))continue;
            if(Math.hypot(x-state.centerX,z-state.centerZ)<36||Math.hypot(x-state.relayX,z-state.relayZ)<36
                ||RaidBosses.arena(state).distSqr(point.atY(state.bossY))<55*55
                ||director.rooms.stream().anyMatch(room->Math.hypot(x-room.getInt("x"),z-room.getInt("z"))<40))continue;
            if(ExpeditionLayout.nearStoryPlots(state,point)||StructureLevels.overlapsHistorical(level,state,point))continue;
            var known=StructureLevels.known(level,state,"sector",x,z);
            int y=site(level,state,point,known);
            if(y==Integer.MIN_VALUE)continue;
            var origin=point.atY(y);
            SurfacePlacement.grade(level,x,z,12,12,y);
            StructureLevels.rememberSector(level,state,origin);
            int variant=variant(state,sx,sz);
            var supply=SupplySites.select(state,sx,sz);
            String name;
            if(supply!=null){
                SupplySites.build(level,state,origin,supply);
                name=supply.title;
                SupplySites.alert(player,state,origin);
            }else{
                boolean spore=state.activeTheme.equals("infected")&&!known&&variant%2==0&&SporeSites.place(level,origin,variant);
                if(!spore)build(level,state,origin,variant);
                name=spore?"Споровая вышка":SiteDetails.name(state.activeTheme,variant);
                ExpeditionContent.stock(level,state,origin);
                if(level.getBlockEntity(origin) instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity chest){
                    var sign=new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.PAPER);
                    sign.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,
                        net.minecraft.network.chat.Component.literal(name));
                    chest.getInfoReferenceInventory().set(2,sign);
                    chest.setChanged();
                }
            }
            seal(level,state,origin);
            ReconChart.discovered(state,sx,sz,origin,name);
            RaidRules.chat(player,"Найдено · "+name+" · "+origin.toShortString());
            state.caches.add(cell);
            state.setDirty();
            return;
        }
    }

    static int variant(RelayState state, int sx, int sz) {
        return Math.floorMod(RaidDirector.roll(state.seed, sx, sz), SiteDetails.VARIANT_COUNT);
    }

    static boolean inBounds(RelayState state,BlockPos pos){
        return SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,pos.getX()-13,pos.getZ()-13)
            &&SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,pos.getX()+13,pos.getZ()+13);
    }

    static int site(ServerLevel level,RelayState state,BlockPos pos,boolean known){
        int x=pos.getX(),z=pos.getZ(),r=12;
        for(int cx=(x-r)>>4;cx<=(x+r)>>4;cx++)for(int cz=(z-r)>>4;cz<=(z+r)>>4;cz++){
            if(!level.hasChunk(cx,cz))return Integer.MIN_VALUE;
            var chunk=level.getChunk(cx,cz);
            if(!known&&!chunk.getAllReferences().isEmpty())return Integer.MIN_VALUE;
            if(chunk.getBlockEntitiesPos().stream().anyMatch(p->Math.abs(p.getX()-x)<=r&&Math.abs(p.getZ()-z)<=r
                &&!(known&&p.getX()==x&&p.getZ()==z&&level.getBlockEntity(p) instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity)))
                return Integer.MIN_VALUE;
        }
        if(known){
            int y=StructureLevels.sectorY(level,state,pos);
            var origin=pos.atY(y);
            String seal=sealKey(level,origin);
            return state.structureLevels.contains(seal)&&state.structureLevels.getInt(seal)==fingerprint(level,origin)
                ?y:Integer.MIN_VALUE;
        }
        int min=Integer.MAX_VALUE,max=Integer.MIN_VALUE;
        for(int dx=-r;dx<=r;dx++)for(int dz=-r;dz<=r;dz++){
            int y=level.getHeight(Heightmap.Types.WORLD_SURFACE,x+dx,z+dz);
            var under=new BlockPos(x+dx,y-1,z+dz);
            var top=level.getBlockState(under);
            if(!top.is(Blocks.GRASS_BLOCK)&&!top.is(Blocks.STONE)&&!top.is(Blocks.DIRT)&&!top.is(Blocks.COARSE_DIRT)
                &&!top.is(Blocks.SAND)&&!top.is(Blocks.GRAVEL)&&!top.is(Blocks.TERRACOTTA)
                &&!top.is(Blocks.PODZOL)&&!top.is(Blocks.MOSS_BLOCK)&&!top.is(Blocks.SNOW_BLOCK)&&!top.is(Blocks.TUFF))return Integer.MIN_VALUE;
            if(!level.getFluidState(under).isEmpty())return Integer.MIN_VALUE;
            min=Math.min(min,y);max=Math.max(max,y);
            if(max-min>2)return Integer.MIN_VALUE;
        }
        return max+7<level.getMaxBuildHeight()?max:Integer.MIN_VALUE;
    }

    static void build(ServerLevel level,RelayState state,BlockPos origin,int variant){
        Block floor,wall,roof,accent;
        switch(state.activeTheme){
            case "forest"->{floor=Blocks.SPRUCE_PLANKS;wall=Blocks.STRIPPED_SPRUCE_LOG;roof=Blocks.GREEN_WOOL;accent=Blocks.SPRUCE_FENCE;}
            case "infected"->{floor=Blocks.SMOOTH_QUARTZ;wall=Blocks.WHITE_CONCRETE;roof=Blocks.LIGHT_GRAY_CONCRETE;accent=Blocks.TINTED_GLASS;}
            case "ash"->{floor=Blocks.POLISHED_BLACKSTONE;wall=Blocks.CRACKED_DEEPSLATE_BRICKS;roof=Blocks.BLACKSTONE;accent=Blocks.IRON_BARS;}
            default->{floor=Blocks.POLISHED_ANDESITE;wall=Blocks.GRAY_CONCRETE;roof=Blocks.DEEPSLATE_TILES;accent=Blocks.YELLOW_CONCRETE;}
        }
        for(int x=-9;x<=9;x++)for(int z=-9;z<=9;z++){
            boolean inside=switch(variant){case 0,3,6->Math.abs(z)<=5;case 1,4,7->Math.abs(x)<=5;case 8->Math.abs(x)<=5||Math.abs(z)<=3;default->x<=3||Math.abs(z)<=3;};
            for(int y=0;y<=6;y++)level.setBlock(origin.offset(x,y,z),Blocks.AIR.defaultBlockState(),2);
            if(!inside)continue;
            for(int y=-3;y<0;y++){
                var at=origin.offset(x,y,z);
                if(y==-1||level.isEmptyBlock(at))level.setBlock(at,floor.defaultBlockState(),2);
            }
            boolean edge=variant%3==0?Math.abs(z)==5:variant%3==1?Math.abs(x)==5:x==3&&Math.abs(z)>3;
            if(edge&&Math.abs(x)>1&&Math.abs(z)>1)
                for(int y=0;y<=2;y++)level.setBlock(origin.offset(x,y,z),(y==1?accent:wall).defaultBlockState(),2);
            if(Math.abs(x)<=4&&z>=-4&&z<=-2)
                level.setBlock(origin.offset(x,4,z),roof.defaultBlockState(),2);
        }
        level.setBlock(origin.offset(-3,3,-3),Blocks.SEA_LANTERN.defaultBlockState(),2);
        level.setBlock(origin.offset(3,3,-3),Blocks.SEA_LANTERN.defaultBlockState(),2);
        SiteDetails.build(level,origin,state.activeTheme,variant,wall,roof,accent);
    }

    static void seal(ServerLevel level,RelayState state,BlockPos origin){
        state.structureLevels.putInt(sealKey(level,origin),fingerprint(level,origin));
        state.setDirty();
    }

    private static String sealKey(ServerLevel level,BlockPos origin){
        return "seal/"+level.dimension().location()+"/"+origin.getX()+"/"+origin.getZ();
    }

    private static int fingerprint(ServerLevel level,BlockPos origin){
        int hash=1;
        for(int x=-9;x<=9;x++)for(int z=-9;z<=9;z++)for(int y=-3;y<=6;y++){
            var block=level.getBlockState(origin.offset(x,y,z)).getBlock();
            hash=31*hash+net.minecraft.core.registries.BuiltInRegistries.BLOCK.getId(block);
        }
        return hash;
    }

    private SectorBuildings(){}
}
