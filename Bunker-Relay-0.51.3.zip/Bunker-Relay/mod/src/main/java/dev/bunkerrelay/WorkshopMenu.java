package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

public final class WorkshopMenu extends ChestMenu {
    private final ServerPlayer owner;
    private final SimpleContainer panel;

    WorkshopMenu(int id,Inventory inventory){this(id,inventory,null);}
    WorkshopMenu(int id,Inventory inventory,ServerPlayer owner){this(id,inventory,owner,new SimpleContainer(27));}
    private WorkshopMenu(int id,Inventory inventory,ServerPlayer owner,SimpleContainer panel){
        super(RelayMenus.WORKSHOP.get(),id,inventory,panel,3);
        this.owner=owner;
        this.panel=panel;
        if(owner!=null)refresh();
    }

    private void refresh(){
        panel.clearContent();
        icon(0,Items.COMPASS,"КПК · База","Вернуться в карманное меню");
        icon(18,Items.SHEARS,"Разборка оружия","Выбрать оружие из инвентаря");
        icon(4,Items.REDSTONE_TORCH,BasePower.label(RelayState.get(owner.server)),"Для ремонта и разбора нужно питание");
        if(!BaseUpgrades.has(owner,BaseUpgrades.Upgrade.WORKSHOP)){
            icon(10,Items.EMERALD,"Открыть мастерскую",BaseUpgrades.Upgrade.WORKSHOP.price+" кр. · для всей команды"); 
        }else{
            icon(10,Items.ANVIL,"Ремонт","Повреждённый предмет в основной руке");
            icon(12,Items.SHEARS,"Разобрать трофей","Трофей в основной руке");
            icon(14,Items.REDSTONE,"Установить деталь","Деталь в основной руке");
            icon(16,Items.BOOK,"Что дают детали","Список командных улучшений");
        }
    }

    private void icon(int slot,Item item,String title,String hint){
        var stack=new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME,Component.literal(title));
        stack.set(DataComponents.LORE,new ItemLore(List.of(Component.literal(hint))));
        panel.setItem(slot,stack);
    }

    @Override public void clicked(int slot,int button,ClickType type,Player player){
        if(player!=owner||button!=0||type!=ClickType.PICKUP||!stillValid(player))return;
        switch(slot){
            case 0 -> PocketDevice.open(owner,PocketDevice.Page.BASE);
            case 10 -> {if(BaseUpgrades.has(owner,BaseUpgrades.Upgrade.WORKSHOP))BaseUpgrades.repair(owner);else BaseUpgrades.buy(owner,BaseUpgrades.Upgrade.WORKSHOP);}
            case 12 -> {if(!panel.getItem(12).isEmpty())TrophyResearch.dismantle(owner);}
            case 14 -> {if(!panel.getItem(14).isEmpty())TrophyResearch.install(owner);}
            case 18 -> DismantleMenu.open(owner,true);
            case 16 -> {if(!panel.getItem(16).isEmpty())TrophyResearch.report(owner);}
            default -> {}
        }
        if(owner.containerMenu==this){refresh();broadcastChanges();}
    }

    @Override public ItemStack quickMoveStack(Player player,int slot){return ItemStack.EMPTY;}
    @Override public boolean stillValid(Player player){return owner!=null&&player==owner&&CourtyardWorkshop.nearby(owner,RelayState.get(owner.server));}
}
