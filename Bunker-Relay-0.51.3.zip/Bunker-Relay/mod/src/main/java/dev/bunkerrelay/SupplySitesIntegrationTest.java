package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class SupplySitesIntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        state.activeSize=8192;
        state.activeLoot=4;
        state.activeDifficulty=3;
        state.seed=31031;
        state.ready=true;
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"RelaySupplySites"));
        check(RaidRules.begin(player,state)==null,"active raid");
        verifyStarterKit(server,state,player);
        verifyNaturalSpawns(level,state);
        var tested=EnumSet.noneOf(SupplySites.Kind.class);
        for(int sx=2;sx<=18&&tested.size()<4;sx++)for(int sz=2;sz<=18&&tested.size()<4;sz++){
            var kind=SupplySites.select(state,sx,sz);
            if(kind==null||tested.contains(kind)||Math.floorMod(RaidDirector.roll(state.seed,sx,sz),5)==0)continue;
            var point=SectorBuildings.candidate(state,sx,sz,0).atY(80);
            for(int x=-12;x<=12;x++)for(int z=-12;z<=12;z++)
                level.setBlock(point.offset(x,-1,z),Blocks.GRASS_BLOCK.defaultBlockState(),2);
            player.moveTo(point.getX()+.5,point.getY(),point.getZ()+24.5);
            SectorBuildings.discover(player,state);
            check(state.caches.contains(ChunkPos.asLong(sx,sz))&&point.equals(ReconChart.site(state,sx,sz)),kind+" discovered");
            check(level.getBlockEntity(point) instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity,kind+" personal chest");
            check(PersonalLoot.templateItem(level,point,2).get(DataComponents.CUSTOM_NAME).getString().equals(kind.title),kind+" title");
            var first=PersonalLoot.templateItem(level,point,4);
            boolean loot=switch(kind){
                case ARMORY -> BuiltInRegistries.ITEM.getKey(first.getItem()).getNamespace().equals("tacz");
                case CANTEEN -> first.is(Items.BREAD)&&PersonalLoot.templateItem(level,point,6).is(Items.MILK_BUCKET);
                case WAREHOUSE -> first.is(Items.IRON_INGOT);
                case FACTORY -> BuiltInRegistries.ITEM.getKey(first.getItem()).toString().equals("create:shaft")
                    &&BuiltInRegistries.ITEM.getKey(PersonalLoot.templateItem(level,point,5).getItem()).getNamespace().equals("mekanism");
            };
            check(loot,kind+" corresponding loot");
            for(int z=1;z<=9;z++)for(int y=0;y<=1;y++)check(level.isEmptyBlock(point.offset(0,y,z)),kind+" open approach");
            player.moveTo(point.getX()+.5,point.getY(),point.getZ()+10.5);
            check(SupplySites.alert(player,state,point)==kind.guards,kind+" guard count");
            check(SupplySites.alert(player,state,point)==0,kind+" no repeat guard wave");
            var data=level.getBlockEntity(point).saveWithFullMetadata(server.registryAccess());
            check(data.getCompound("NeoForgeData").getBoolean("relay_supply_alarm"),kind+" persistent one-shot alarm");
            var champions=level.getEntitiesOfClass(net.minecraft.world.entity.Mob.class,
                new net.minecraft.world.phys.AABB(point).inflate(18),
                mob->mob.getPersistentData().contains("relay_miniboss"));
            check(champions.size()==1&&champions.getFirst().isAlive(),kind+" one living mini-boss");
            var champion=champions.getFirst();
            var source=level.damageSources().genericKill();
            champion.hurt(source,Float.MAX_VALUE);
            check(champion.getPersistentData().getBoolean("relay_miniboss_paid"),kind+" reward delivered by death");
            var drops=level.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                champion.getBoundingBox().inflate(2),item->item.getItem().is(MiniBosses.Kind.valueOf(kind.name()).reward));
            check(drops.size()==1,kind+" reward once");
            MiniBosses.died(new net.neoforged.neoforge.event.entity.living.LivingDeathEvent(champion,source));
            check(level.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                champion.getBoundingBox().inflate(2),item->item.getItem().is(MiniBosses.Kind.valueOf(kind.name()).reward)).size()==1,
                kind+" duplicate death reward blocked");
            tested.add(kind);
            System.out.println("RELAY_SUPPLY_SITE_PASS "+kind+" guards="+kind.guards);
        }
        check(tested.size()==4,"all supply types");
        server.halt(false);
    }

    private static void verifyStarterKit(MinecraftServer server,RelayState state,FakePlayer player){
        var menu=new PocketDevice.Menu(11,player.getInventory(),player,PocketDevice.Page.RAID);
        player.containerMenu=menu;
        for(int slot=0;slot<player.getInventory().items.size();slot++)
            player.getInventory().setItem(slot,new net.minecraft.world.item.ItemStack(Items.COBBLESTONE,64));
        check(!StarterKit.claim(player,state),"full inventory rejects without consuming claim");
        player.getInventory().clearContent();
        menu.clicked(16,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        var supplied=player.getInventory().items.stream().filter(item->!item.isEmpty()).toList();
        check(supplied.size()==7&&supplied.stream().allMatch(item->StarterKit.marked(item)&&SalvageValue.price(item)==1),"PDA kit and sale price");
        check(!StarterKit.claim(player,state),"repeat claim rejected");
        RaidJournal.get(server).raids.remove(player.getUUID());
        check(RaidRules.begin(player,state)==null&&!StarterKit.claim(player,state),"new entry in same cycle cannot farm kits");
        System.out.println("RELAY_STARTER_KIT_PASS");
    }

    private static void verifyNaturalSpawns(net.minecraft.server.level.ServerLevel level,RelayState state){
        var mob=SporeEncounters.create(level,"inf_human");
        mob.moveTo(state.centerX+.5,80,state.centerZ+.5);
        var natural=new net.neoforged.neoforge.event.entity.living.MobSpawnEvent.PositionCheck(
            mob,level,net.minecraft.world.entity.MobSpawnType.NATURAL,null);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(natural);
        check(natural.getResult()==net.neoforged.neoforge.event.entity.living.MobSpawnEvent.PositionCheck.Result.FAIL,"quiet extraction radius");
        var authored=new net.neoforged.neoforge.event.entity.living.MobSpawnEvent.PositionCheck(
            mob,level,net.minecraft.world.entity.MobSpawnType.SPAWN_EGG,null);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(authored);
        check(authored.getResult()!=net.neoforged.neoforge.event.entity.living.MobSpawnEvent.PositionCheck.Result.FAIL,"direct placement unaffected by natural spawn rules");
        System.out.println("RELAY_NATURAL_SPAWN_PASS");
    }

    private static void check(boolean condition,String message){
        if(!condition)throw new IllegalStateException("Supply site test: "+message);
    }

    private SupplySitesIntegrationTest(){}
}
