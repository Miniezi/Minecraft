package dev.bunkerrelay;

import java.util.HashSet;
import java.util.UUID;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update10IntegrationTest {
    private static final GameProfile PLAYER_A = new GameProfile(UUID.fromString("e3b153a1-e6fe-4e46-822d-c0b797d57620"), "Relay10Mission");
    private static final GameProfile PLAYER_B = new GameProfile(UUID.fromString("cd330a87-6205-4e54-98a8-f4adcacd351c"), "Relay10Loot");
    static void run(MinecraftServer server) {
        var state = RelayState.get(server);
        var level = server.getLevel(BunkerRelay.key(state.activeDimension));
        var mobs = new HashSet<>();
        var probe = new RelayState();
        probe.activeTheme = "infected";
        for (int tier=1; tier<=5; tier++) {
            probe.activeDifficulty = tier;
            for (int sample=0; sample<24; sample++) {
                var mob = SporeEncounters.create(level, probe, sample);
                check(mob != null && mob.getTags().contains("relay_spore"), "Spore tier " + tier);
                mobs.add(mob.getType());
            }
        }
        check(mobs.size() >= 8, "distinct Spore types");
        probe.activeTheme = "industrial";
        probe.activeLoot = 5;
        int salvage = 0;
        var random = RandomSource.create(310);
        for (int i=0; i<300; i++) {
            var loot = RaidLoot.generate(level, probe, random);
            check(loot.size() <= 11, "cache stack limit");
            if (loot.stream().anyMatch(item -> BuiltInRegistries.ITEM.getKey(item.getItem()).getNamespace().equals("mekanism")))
                salvage++;
        }
        check(salvage > 30 && salvage < 85, "Mekanism salvage frequency: " + salvage);

        var player = new FakePlayer(level,PLAYER_A);
        for (long seed=0; seed<4; seed++) {
            state.seed = seed;
            state.relayPowered = false;
            RaidMission.prepare(level,state);
            check(state.mission == seed+1, "mission selection");
            for (long packed : state.missionNodes) {
                var node = net.minecraft.core.BlockPos.of(packed);
                check(level.getBlockState(node).is(Blocks.LODESTONE), "mission node placed");
                RaidMission.use(player,state,node);
            }
            check(RaidMission.target(state).equals(RaidMission.radio(state)), "route advances");
            RaidMission.use(player,state,RaidMission.radio(state));
            if (seed==3) {
                RaidMission.second(server,state);
                check(state.missionStarted && !state.relayPowered && state.missionSeconds==0, "hold pauses when unattended");
            } else check(state.relayPowered, "mission unlocks extraction");
        }

        var cachePos = ExpeditionContent.cache(level,state,state.centerX+20,state.centerZ+20);
        var personal = (noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity)level.getBlockEntity(cachePos);
        var lootPlayer = lootPlayer(level, PLAYER_A);
        var second = lootPlayer(level, PLAYER_B);
        var lootA = noobanidus.mods.lootr.common.api.LootrAPI.getInventory(personal,lootPlayer);
        var lootB = noobanidus.mods.lootr.common.api.LootrAPI.getInventory(personal,second);
        check(!lootA.getItem(4).isEmpty() && !lootB.getItem(4).isEmpty(), "both players have loot");
        lootA.removeItemNoUpdate(4);
        lootA.setChanged();
        check(noobanidus.mods.lootr.common.api.LootrAPI.getInventory(personal,lootPlayer).getItem(4).isEmpty()
            && !lootB.getItem(4).isEmpty(), "independent inventories, no refill");
        var hub = server.getLevel(BunkerRelay.HUB);
        var buyer = new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay10Buyer"));
        var teammate = new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay10Team"));
        RelayEconomy.account(buyer).putLong("balance",2000);
        check(BaseUpgrades.buy(buyer,BaseUpgrades.Upgrade.STORAGE)==1, "purchase succeeds");
        check(BaseUpgrades.has(teammate,BaseUpgrades.Upgrade.STORAGE), "purchase shared");
        check(BaseUpgrades.buy(buyer,BaseUpgrades.Upgrade.STORAGE)==0 && RelayEconomy.balance(buyer)==1350,
              "repeat purchase does not debit");
        System.out.println("RELAY_010_PASS distinct_spore=" + mobs.size() + " mekanism_salvage=" + salvage
            + "/300 four_missions=true shared_upgrade=true personal_loot=true");
    }

    static void reload(MinecraftServer server) {
        var state = RelayState.get(server);
        check(state.mission==4 && state.missionStarted && !state.relayPowered, "mission survives restart");
        var level = server.getLevel(BunkerRelay.key(state.activeDimension));
        int x = state.centerX+20;
        int z = state.centerZ+20;
        level.getChunk(x >> 4, z >> 4);
        var cache = level.getChunk(x >> 4, z >> 4).getBlockEntities().entrySet().stream()
            .filter(entry -> entry.getKey().getX()==x && entry.getKey().getZ()==z)
            .map(java.util.Map.Entry::getValue)
            .filter(noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity.class::isInstance)
            .map(noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity.class::cast)
            .findFirst().orElseThrow();
        var a = lootPlayer(level,PLAYER_A);
        var b = lootPlayer(level,PLAYER_B);
        check(noobanidus.mods.lootr.common.api.LootrAPI.getInventory(cache,a).getItem(4).isEmpty(), "taken loot persists");
        check(!noobanidus.mods.lootr.common.api.LootrAPI.getInventory(cache,b).getItem(4).isEmpty(), "other loot persists");
        check(BaseUpgrades.has(b,BaseUpgrades.Upgrade.STORAGE), "shared upgrade survives restart");
        System.out.println("RELAY_010_RELOAD_PASS mission=true personal_loot=true shared_upgrade=true");
    }

    private static net.minecraft.server.level.ServerPlayer lootPlayer(net.minecraft.server.level.ServerLevel level, GameProfile profile) {
        var options = net.minecraft.server.level.ClientInformation.createDefault();
        var player = new net.minecraft.server.level.ServerPlayer(level.getServer(), level, profile, options);
        var connection = new net.minecraft.network.Connection(net.minecraft.network.protocol.PacketFlow.SERVERBOUND);
        var cookie = new net.minecraft.server.network.CommonListenerCookie(profile, 0, options, false);
        player.connection = new net.minecraft.server.network.ServerGamePacketListenerImpl(level.getServer(), connection, player, cookie);
        return player;
    }

    private static void check(boolean condition, String description) {
        if (!condition) throw new IllegalStateException("RELAY_010 " + description);
    }

    private Update10IntegrationTest() {}
}
