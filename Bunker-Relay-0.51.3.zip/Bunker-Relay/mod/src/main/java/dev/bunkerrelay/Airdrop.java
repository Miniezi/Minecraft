package dev.bunkerrelay;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;

final class Airdrop {
    static void tick(ServerLevel level,RelayState state,RaidDirector director,List<ServerPlayer> players){
        if(director.dropLanded){
            securityTick(level,state,director,players);
            return;
        }
        boolean scanner=TrophyResearch.has(state,TrophyResearch.Part.SCANNER);
        if(director.elapsed<director.dropDue-(scanner?40:20))return;
        if(!director.dropPending){
            var site=find(level,state,players);
            if(site==null){director.dropDue=director.elapsed+65;return;}
            director.dropPosition=site.asLong();
            director.dropPending=true;
            if(scanner&&director.elapsed<director.dropDue-20)
                for(var p:players)RaidRules.chat(p,"Модуль анализа · пеленг груза "+RaidHud.direction(p.blockPosition(),site)+" · точность через несколько секунд");
        }
        if(director.elapsed>=director.dropDue-20&&!director.dropSecurity.getBoolean("announced")){
            director.dropSecurity.putBoolean("announced",true);
            director.setDirty();
            for(var p:players)RaidRules.chat(p,"Радио · воздушный сброс · "+BlockPos.of(director.dropPosition).toShortString()+" · КПК → Вылазка → Воздушный сброс");
        }
        var site=BlockPos.of(director.dropPosition);
        if(!level.hasChunkAt(site))return;
        if(director.elapsed<director.dropDue)return;
        if(!land(level,state,site)){
            director.dropPending=false;director.dropSecurity.remove("announced");director.dropDue=director.elapsed+65;
            for(var p:players)RaidRules.tell(p,"Точка сброса занята. Пилот ищет другую площадку.");
            return;
        }
        director.dropLanded=true;
        director.dropPending=false;
        director.dropSecurity.putInt("beaconUntil",director.elapsed+90);
        director.setDirty();
        RaidVisuals.landing(level,site);
        for(var p:players)RaidRules.chat(p,"Воздушный груз · "+site.toShortString()+" · Приседание + ПКМ по ящику отключает маяк и запускает взлом.");
    }

    static void animate(net.minecraft.server.MinecraftServer server,RelayState state,int elapsedTicks){
        if(!state.ready||state.generating||server.getPlayerList().getPlayerCount()==0)return;
        var director=RaidDirector.get(server);
        if(!director.dropPending&&!director.dropLanded)return;
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var site=BlockPos.of(director.dropPosition);
        if(level==null||!level.hasChunkAt(site)||level.players().stream().noneMatch(p->p.distanceToSqr(site.getX()+.5,site.getY(),site.getZ()+.5)<64*64))return;
        double seconds=director.elapsed+elapsedTicks/20.0;
        if(director.dropPending)RaidVisuals.dropFrame(level,site,director.dropDue-seconds);
        else if(director.dropSecurity.hasUUID("breacher"))
            RaidVisuals.breachFrame(level,site,1-(director.dropSecurity.getInt("finish")-seconds)/12.0);
        else if(beaconActive(director))RaidVisuals.beacon(level,site,level.getGameTime());
    }

    private static BlockPos find(ServerLevel level,RelayState state,List<ServerPlayer> players){
        var site=find(level,state,players,0);
        if(site!=null||!TrophyResearch.has(state,TrophyResearch.Part.SCANNER))return site;
        return find(level,state,players,0.5);
    }

    private static BlockPos find(ServerLevel level,RelayState state,List<ServerPlayer> players,double bearingOffset){
        for(var player:players)for(int step=0;step<16;step++){
            double angle=(step+bearingOffset)*Math.PI/8+player.getYRot()*Math.PI/180;
            int distance=40+(step%3)*8;
            int x=player.getBlockX()+(int)(Math.cos(angle)*distance),z=player.getBlockZ()+(int)(Math.sin(angle)*distance);
            var column=new BlockPos(x,player.getBlockY(),z);
            if(!level.hasChunkAt(column)||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,x,z)
                ||Math.hypot(x-state.centerX,z-state.centerZ)<36
                ||players.stream().anyMatch(other->other.distanceToSqr(x,other.getY(),z)<26*26))continue;
            var pos=column.atY(level.getHeight(Heightmap.Types.WORLD_SURFACE,x,z));
            if(Math.abs(pos.getY()-player.getY())<=22&&clear(level,pos))return pos;
        }
        return null;
    }

    private static boolean clear(ServerLevel level,BlockPos pos){
        return pos.getY()<level.getMaxBuildHeight()-2&&level.isEmptyBlock(pos)&&level.isEmptyBlock(pos.above())
            &&level.getFluidState(pos.below()).isEmpty()
            &&level.getBlockState(pos.below()).isFaceSturdy(level,pos.below(),net.minecraft.core.Direction.UP);
    }

    static boolean land(ServerLevel level,RelayState state,BlockPos pos){
        if(!clear(level,pos)||!level.setBlock(pos,Blocks.CHEST.defaultBlockState(),3)
            ||!(level.getBlockEntity(pos) instanceof ChestBlockEntity chest))return false;
        RaidLoot.airdrop(chest,level,state,pos,false);
        var instructions=new ItemStack(Items.PAPER);
        instructions.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,
            net.minecraft.network.chat.Component.literal("Отсек опечатан · приседание + ПКМ по ящику"));
        chest.setItem(1,instructions);
        chest.setChanged();
        PersonalLoot.convert(level,pos,chest);
        return true;
    }

    static boolean controls(RaidDirector director,BlockPos pos){
        return director.dropLanded&&pos.asLong()==director.dropPosition;
    }

    static boolean startBreach(ServerPlayer player,RaidDirector director,BlockPos site){
        if(!controls(director,site)||!player.isShiftKeyDown())return false;
        var data=director.dropSecurity;
        if(data.contains("secured")){
            RaidRules.tell(player,"Защищённый отсек уже открыт · "+BlockPos.of(data.getLong("secured")).toShortString());
            return true;
        }
        if(data.hasUUID("breacher")){
            RaidRules.tell(player,"Отсек уже вскрывают.");
            return true;
        }
        data.putBoolean("muted",true);
        data.putUUID("breacher",player.getUUID());
        data.putInt("finish",director.elapsed+12);
        RaidRules.tell(player,"Маяк отключён. Взлом займёт 12 секунд. Держитесь в радиусе 8 блоков.");
        director.setDirty();
        return true;
    }

    static void securityTick(ServerLevel level,RelayState state,RaidDirector director,List<ServerPlayer> players){
        var data=director.dropSecurity;
        var site=BlockPos.of(director.dropPosition);
        int remaining=data.getInt("beaconUntil")-director.elapsed;
        if(beaconActive(director)&&remaining%15==0&&level.hasChunkAt(site)){
            level.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,site.getX()+.5,site.getY()+1,site.getZ()+.5,15,.3,.6,.3,.02);
            players.stream().filter(player->player.blockPosition().distSqr(site)<=48*48)
                .min(java.util.Comparator.comparingDouble(player->player.blockPosition().distSqr(site)))
                .ifPresent(player->RaidDirector.spawnNear(player,state,"stalker",44,players));
        }
        if(!data.hasUUID("breacher"))return;
        var id=data.getUUID("breacher");
        var operator=players.stream().filter(player->player.getUUID().equals(id)).findFirst().orElse(null);
        if(operator==null||!operator.isAlive()||operator.blockPosition().distSqr(site)>64){
            if(operator!=null)RaidRules.tell(operator,"Взлом прерван: вы отошли от груза.");
        }else if(director.elapsed<data.getInt("finish"))return;
        else{
            var secured=unlock(level,state,site);
            if(secured!=null){
                data.putLong("secured",secured.asLong());
                RaidVisuals.unlocked(level,secured);
                MiniBosses.arm(level,state,secured,MiniBosses.Kind.AIRDROP);
                MiniBosses.encounter(operator,state,secured);
            }
            RaidRules.tell(operator,secured==null?"Освободите место рядом с ящиком и повторите взлом."
                :"Защищённый отсек открыт · "+secured.toShortString());
        }
        data.remove("breacher");
        director.setDirty();
    }

    private static BlockPos unlock(ServerLevel level,RelayState state,BlockPos site){
        for(var direction:net.minecraft.core.Direction.Plane.HORIZONTAL){
            var column=site.relative(direction,2);
            for(int dy:new int[]{0,1,-1,2,-2}){
                var pos=column.above(dy);
                if(!level.hasChunkAt(pos)||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,pos.getX(),pos.getZ())
                    ||!clear(level,pos))continue;
                level.setBlock(pos,Blocks.CHEST.defaultBlockState(),3);
                if(!(level.getBlockEntity(pos) instanceof ChestBlockEntity chest))continue;
                RaidLoot.airdrop(chest,level,state,pos,true);
                PersonalLoot.convert(level,pos,chest);
                return pos;
            }
        }
        return null;
    }

    private static boolean beaconActive(RaidDirector director){
        return !director.dropSecurity.getBoolean("muted")&&director.elapsed<director.dropSecurity.getInt("beaconUntil");
    }

    static String status(RaidDirector director){
        if(director.dropLanded){
            var data=director.dropSecurity;
            if(data.contains("secured"))return "Защищённый отсек открыт";
            if(data.hasUUID("breacher"))return "Взлом · "+Math.max(0,data.getInt("finish")-director.elapsed)+" с";
            return beaconActive(director)?"Груз на земле · маяк активен":"Груз на земле";
        }
        return director.dropPending?"До сброса "+Math.max(0,director.dropDue-director.elapsed)+" с":"Сигнала пока нет";
    }

    static void track(ServerPlayer player){
        var director=RaidDirector.get(player.server);
        var state=RelayState.get(player.server);
        if(state.ready&&director.dropPending&&director.elapsed<director.dropDue-20){
            RaidRules.chat(player,"Пеленг груза · "+RaidHud.direction(player.blockPosition(),BlockPos.of(director.dropPosition)));
            return;
        }
        if(state.ready&&(director.dropPending||director.dropLanded)){
            var pos=BlockPos.of(director.dropSecurity.getBoolean("muted")&&director.dropSecurity.contains("secured")?director.dropSecurity.getLong("secured"):director.dropPosition);
            Navigation.waypoint(player,state.generation,pos,"Воздушный сброс");
            RaidRules.chat(player,status(director)+" · "+pos.toShortString());
        }else RaidRules.tell(player,"Воздушного сброса пока нет.");
    }

    private Airdrop(){}
}
