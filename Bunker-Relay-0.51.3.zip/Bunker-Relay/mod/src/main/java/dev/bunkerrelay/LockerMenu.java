package dev.bunkerrelay;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

public final class LockerMenu extends ChestMenu {
    private enum Mode { TAKE, DEPOSIT, SELL }
    private static final int PAGE_SIZE = 36;

    private final ServerPlayer owner;
    private final SimpleContainer panel;
    private final boolean pocket;
    private final boolean market;
    private final RelayEconomy.Merchant merchant;
    private final List<ItemStack> depositSnapshot = new ArrayList<>();
    private List<Warehouse.Entry> entries = List.of();
    private Mode mode;
    private int page;

    LockerMenu(int id, Inventory inventory) {
        this(id, inventory, null, false, false, RelayEconomy.Merchant.RESOURCES);
    }

    LockerMenu(int id, Inventory inventory, ServerPlayer owner, boolean pocket, boolean market,
               RelayEconomy.Merchant merchant) {
        super(RelayMenus.LOCKER.get(), id, inventory, new SimpleContainer(54), 6);
        this.owner = owner;
        this.panel = (SimpleContainer) getContainer();
        this.pocket = pocket;
        this.market = market;
        this.merchant = merchant;
        mode = market ? Mode.SELL : Mode.TAKE;
        if (owner != null) refresh(new Warehouse(owner));
    }

    private void refresh(Warehouse warehouse) {
        panel.clearContent();
        icon(0, new ItemStack(Items.CHEST_MINECART), selected(Mode.TAKE, "Выдать"), "Из склада в рюкзак");
        icon(1, new ItemStack(Items.HOPPER), selected(Mode.DEPOSIT, "Сдать"), "Из рюкзака на склад");
        icon(2, new ItemStack(Items.EMERALD), selected(Mode.SELL, "Продать"), "Скупка прямо со склада");
        icon(7, new ItemStack(Items.GOLD_NUGGET), "Счёт " + RelayEconomy.balance(owner) + " кр.",
            "Бюджет скупщика " + RelayEconomy.account(owner).getInt("budget") + " кр.");
        icon(8, new ItemStack(Items.BARREL), "Склад " + warehouse.occupied() + " / " + Warehouse.CAPACITY,
            "Занято ячеек хранения");
        entries = warehouse.entries();
        depositSnapshot.clear();
        if (mode == Mode.DEPOSIT) {
            for (int i = 0; i < PAGE_SIZE; i++) {
                var stack = getSlot(54 + i).getItem();
                depositSnapshot.add(stack.copy());
                if (!stack.isEmpty()) icon(9 + i, stack, stack.getHoverName().getString(),
                    "В рюкзаке " + stack.getCount() + " · на складе " + warehouse.count(stack));
            }
        } else {
            page = Math.clamp(page, 0, Math.max(0, (entries.size() - 1) / PAGE_SIZE));
            for (int i = 0; i < PAGE_SIZE && page * PAGE_SIZE + i < entries.size(); i++) {
                var entry = entries.get(page * PAGE_SIZE + i);
                int quote = SalvageValue.price(entry.sample());
                String detail = "На складе " + entry.count();
                if (mode == Mode.SELL) detail += quote > 0 ? " · " + quote + " кр./шт." : " · не принимается";
                icon(9 + i, entry.sample(), entry.sample().getHoverName().getString(), detail);
            }
            if (page > 0) icon(45, new ItemStack(Items.ARROW), "Предыдущая страница", "");
            if ((page + 1) * PAGE_SIZE < entries.size()) icon(46, new ItemStack(Items.ARROW), "Следующая страница", "");
            icon(49, new ItemStack(Items.PAPER), "Страница " + (page + 1), "");
        }
        icon(52, new ItemStack(Items.LODESTONE), market ? "Торговцы" : pocket ? "КПК" : "Терминал", "Вернуться");
    }

    private String selected(Mode expected, String name) {
        return mode == expected ? "• " + name : name;
    }

    private void icon(int slot, ItemStack item, String name, String detail) {
        var copy = item.copyWithCount(1);
        copy.set(DataComponents.CUSTOM_NAME, Component.literal(name));
        copy.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(detail))));
        panel.setItem(slot, copy);
    }

    @Override public void clicked(int slot, int button, ClickType type, Player player) {
        if (player != owner || !stillValid(player) || type != ClickType.PICKUP || button < 0 || button > 1
            || slot < 0 || slot >= 54 || panel.getItem(slot).isEmpty()) return;
        if (slot == 52) {
            if (market && pocket) RelayEconomy.openPocket(owner, true, merchant);
            else if (market) RelayEconomy.open(owner, true, merchant);
            else if (pocket) PocketDevice.open(owner, PocketDevice.Page.BASE);
            else BunkerRelay.openTerminal(owner);
            return;
        }
        var warehouse = new Warehouse(owner);
        if (slot < Mode.values().length) {
            mode = Mode.values()[slot];
            page = 0;
        } else if (slot == 45) {
            page--;
        } else if (slot == 46) {
            page++;
        } else if (slot >= 9 && slot < 45) {
            int requested = button == 0 ? 1 : Integer.MAX_VALUE;
            if (mode == Mode.DEPOSIT) {
                var item = getSlot(54 + slot - 9).getItem();
                if (Warehouse.matches(item, depositSnapshot.get(slot - 9))) {
                    if (warehouse.deposit(item, requested) > 0) warehouse.save();
                    else RaidRules.tell(owner, "На складе нет места.");
                }
            } else {
                var item = entries.get(page * PAGE_SIZE + slot - 9).sample();
                int available = Math.min(requested, warehouse.count(item));
                if (mode == Mode.SELL) {
                    int price = SalvageValue.price(item);
                    int sold = SalvageValue.affordableSale(owner, price, available);
                    if (sold > 0) {
                        warehouse.remove(item, sold);
                        SalvageValue.creditSale(owner, sold * price);
                        warehouse.save();
                        RaidRules.tell(owner, "Продано " + sold + " шт. за " + sold * price + " кр.");
                    } else RaidRules.tell(owner, price == 0 ? "Скупщик не принимает этот предмет." : "Сделка недоступна.");
                } else {
                    int taken = Math.min(available, SafeInventory.capacity(owner.getInventory(), item));
                    if (taken > 0) {
                        warehouse.remove(item, taken);
                        SafeInventory.insert(owner.getInventory(), item.copyWithCount(taken));
                        warehouse.save();
                    } else RaidRules.tell(owner, "В рюкзаке нет места.");
                }
            }
        }
        refresh(warehouse);
        broadcastChanges();
    }

    @Override public ItemStack quickMoveStack(Player player, int slot) { return ItemStack.EMPTY; }

    @Override public boolean stillValid(Player player) {
        return player.level().isClientSide() || player == owner && RelayEconomy.safe(owner)
            && BaseUpgrades.has(owner, BaseUpgrades.Upgrade.STORAGE);
    }
}
