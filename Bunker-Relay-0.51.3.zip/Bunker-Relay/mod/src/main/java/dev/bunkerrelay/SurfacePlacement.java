package dev.bunkerrelay;

import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

final class SurfacePlacement {
    // Sample outside the construction rectangle so a rebuilt roof cannot raise its own floor.
    static int floor(ServerLevel level,int x,int z,int width,int depth,int headroom){
        int[] ring=new int[4*(width+depth+2)];
        int n=0;
        for(int dx=-width-1;dx<=width+1;dx++){
            ring[n++]=ground(level,x+dx,z-depth-1);
            ring[n++]=ground(level,x+dx,z+depth+1);
        }
        for(int dz=-depth;dz<=depth;dz++){
            ring[n++]=ground(level,x-width-1,z+dz);
            ring[n++]=ground(level,x+width+1,z+dz);
        }
        Arrays.sort(ring);
        int y=ring[n/2];
        if(y<=level.getMinBuildHeight()||y+headroom>=level.getMaxBuildHeight())
            throw new IllegalArgumentException("No buildable surface at "+x+", "+z);
        return y;
    }

    static int ground(ServerLevel level,int x,int z){
        var pos=new BlockPos.MutableBlockPos();
        int top=level.getChunk(x>>4,z>>4).getHeight(Heightmap.Types.WORLD_SURFACE,x&15,z&15)+1;
        for(int y=top-1;y>=level.getMinBuildHeight();y--){
            pos.set(x,y,z);
            var block=level.getBlockState(pos);
            if(!block.getFluidState().isEmpty()||(!block.is(BlockTags.LOGS)&&!block.is(BlockTags.LEAVES)
                &&block.isFaceSturdy(level,pos,net.minecraft.core.Direction.UP)))return y+1;
        }
        return level.getMinBuildHeight();
    }

    static void grade(ServerLevel level,int x,int z,int width,int depth,int floor){
        var pos=new BlockPos.MutableBlockPos();
        for(int dx=-width;dx<=width;dx++)for(int dz=-depth;dz<=depth;dz++){
            int cx=x+dx,cz=z+dz;
            int top=level.getChunk(cx>>4,cz>>4).getHeight(Heightmap.Types.WORLD_SURFACE,cx&15,cz&15)+1;
            for(int y=top-1;y>=floor;y--){
                pos.set(cx,y,cz);
                if(!level.isEmptyBlock(pos))level.setBlock(pos,Blocks.AIR.defaultBlockState(),2);
            }
            for(int y=floor-1;y>=level.getMinBuildHeight();y--){
                pos.set(cx,y,cz);
                var block=level.getBlockState(pos);
                if(block.getFluidState().isEmpty()&&!block.is(BlockTags.LOGS)&&!block.is(BlockTags.LEAVES)
                    &&block.isFaceSturdy(level,pos,net.minecraft.core.Direction.UP))break;
                level.setBlock(pos,Blocks.STONE.defaultBlockState(),2);
            }
        }
    }

    static void approach(ServerLevel level,BlockPos start,net.minecraft.core.Direction outward){
        int walkY=start.getY();
        var sideways=outward.getClockWise();
        for(int step=0;step<24;step++){
            var center=start.relative(outward,step);
            int target=ground(level,center.getX(),center.getZ());
            if(step>0)walkY+=Integer.compare(target,walkY);
            for(int offset=-1;offset<=1;offset++){
                var at=center.relative(sideways,offset);
                grade(level,at.getX(),at.getZ(),0,0,walkY);
                level.setBlock(at.atY(walkY-1),Blocks.ANDESITE.defaultBlockState(),2);
            }
            if(step>=2&&walkY==target)break;
        }
    }

    private SurfacePlacement(){}
}
