package dev.bunkerrelay;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.*;
/** Distinct, open boss districts with a broad approach and cover. */
public final class BossArena {
 public static void build(ServerLevel level,RelayState s,BlockPos origin){
  boolean forest=s.activeTheme.equals("forest"),ash=s.activeTheme.equals("ash"),lab=s.activeTheme.equals("infected");
  Block floor=forest?Blocks.MOSSY_STONE_BRICKS:ash?Blocks.POLISHED_BLACKSTONE:lab?Blocks.SMOOTH_QUARTZ:Blocks.SMOOTH_STONE;
  Block wall=forest?Blocks.DARK_OAK_LOG:ash?Blocks.DEEPSLATE_BRICKS:lab?Blocks.WHITE_CONCRETE:Blocks.GRAY_CONCRETE;
  for(int x=-18;x<=18;x++)for(int z=-18;z<=18;z++){
   level.setBlock(origin.offset(x,-1,z),floor.defaultBlockState(),2);
   for(int y=0;y<9;y++)level.setBlock(origin.offset(x,y,z),Blocks.AIR.defaultBlockState(),2);
   boolean edge=Math.abs(x)==18||Math.abs(z)==18;
   if(edge&&!(z==-18&&Math.abs(x)<=3))for(int y=0;y<4;y++)level.setBlock(origin.offset(x,y,z),(y==2&&lab?Blocks.LIGHT_BLUE_STAINED_GLASS:wall).defaultBlockState(),2);
   if(Math.abs(x)==18&&Math.abs(z)==18)for(int y=4;y<9;y++)level.setBlock(origin.offset(x,y,z),wall.defaultBlockState(),2);
  }
  for(int x:new int[]{-12,12})for(int z:new int[]{-10,10}){
   for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++)for(int y=0;y<4;y++){
    Block b=forest?(y==3?Blocks.DARK_OAK_SLAB:Blocks.DARK_OAK_PLANKS):ash?(y==3?Blocks.IRON_BARS:Blocks.BLACKSTONE):lab?(y==0?Blocks.IRON_BLOCK:Blocks.CYAN_STAINED_GLASS):Blocks.ORANGE_TERRACOTTA;
    level.setBlock(origin.offset(x+dx,y,z+dz),b.defaultBlockState(),2);
   }
   level.setBlock(origin.offset(x,4,z),(ash?Blocks.SHROOMLIGHT:Blocks.SEA_LANTERN).defaultBlockState(),2);
  }
  for(int x=-4;x<=4;x++)level.setBlock(origin.offset(x,5,-18),wall.defaultBlockState(),2);
  for(int step=0;step<18;step++)for(int dx=-3;dx<=3;dx++){
   var p=origin.offset(dx,-1-step,-19-step);if(p.getY()<level.getSeaLevel())continue;level.setBlock(p,floor.defaultBlockState(),2);for(int h=1;h<5;h++)level.setBlock(p.above(h),Blocks.AIR.defaultBlockState(),2);
  }
  for(int h=level.getSeaLevel();h<origin.getY();h++){
   level.setBlock(new BlockPos(origin.getX()+18,h,origin.getZ()),wall.defaultBlockState(),2);
   level.setBlock(new BlockPos(origin.getX()+19,h,origin.getZ()),Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.EAST),2);
  }
 }
 private BossArena(){}
}
