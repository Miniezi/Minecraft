package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class Update21IntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var names=new HashSet<String>();
        var origin=new BlockPos(state.centerX+80,235,state.centerZ+80);
        String previousTheme=state.activeTheme;
        var fingerprints=new HashSet<String>();
        for(String theme:List.of("industrial","infected","forest","ash")){
            state.activeTheme=theme;
            for(int variant=0;variant<SiteDetails.VARIANT_COUNT;variant++){
                check(names.add(SiteDetails.name(theme,variant)),"distinct location name");
                SectorBuildings.build(level,state,origin,variant);
                check(!level.isEmptyBlock(origin.below())&&level.isEmptyBlock(origin),"entrance and floor");
                var signature=new StringBuilder();
                for(int x=-7;x<=7;x++)for(int z=-7;z<=7;z++)for(int y=0;y<=6;y++)
                    signature.append(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getId(level.getBlockState(origin.offset(x,y,z)).getBlock())).append(',');
                check(fingerprints.add(signature.toString()),"distinct physical layout");
            }
        }
        state.activeTheme=previousTheme;
        for (int index = 0; index < 4; index++) RaidDirector.prepare(level, state, index);
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"Relay21Horror"));
        for(int mission:new int[]{5,6,7,8}){
            state.seed=mission-1;
            state.relayPowered=false;
            RaidMission.prepare(level,state);
            int expectedNodes = switch (mission) {
                case 7 -> 3;
                case 8 -> 1;
                default -> 2;
            };
            check(state.mission == mission && state.missionNodes.length == expectedNodes, "mission nodes " + mission);
            if (expectedNodes > 1) {
                var second = BlockPos.of(state.missionNodes[1]);
                RaidMission.use(player, state, second);
                check((state.missionProgress == 0) == (mission == 5 || mission == 7), "sequence requirement");
            }
            for (long node : state.missionNodes) RaidMission.use(player, state, BlockPos.of(node));
            RaidMission.use(player, state, RaidMission.radio(state));
            boolean defense = mission == 6 || mission == 8;
            check(defense ? state.missionStarted && !state.relayPowered : state.relayPowered, "mission finale " + mission);
        }
        check(RaidDirector.chooseEvent(5, false).equals("footsteps"), "footsteps event");
        check(RaidDirector.chooseEvent(6, false).equals("siren"), "siren event");
        check(RaidDirector.chooseEvent(6, true).equals("double"), "isolated group event");
        var variants = new HashSet<Integer>();
        for (int seed = 0; seed < 100; seed++) {
            state.seed = seed;
            variants.add(SectorBuildings.variant(state, 1, 1));
        }
        check(variants.size() == SiteDetails.VARIANT_COUNT, "reroll in the same sector");
        var spawn=origin.east(20);
        level.setBlock(spawn.below(),Blocks.STONE.defaultBlockState(),3);
        var mob=RaidDirector.spawn(level,state,spawn,"faceless",player);
        check(mob!=null&&mob.getCustomName()!=null&&mob.getCustomName().getString().equals("Безликий"),"faceless mob");
        player.getPersistentData().putBoolean("relay_quiet",true);
        check(!RaidHorror.enabled(player)&&RaidHorror.DRONE.get()!=null,"quiet mode and sound event");
        System.out.println("RELAY_021_PASS layouts="+names.size()+" missions=4 events=3 horror=true");
        server.halt(false);
    }
    private static void check(boolean value,String message){if(!value)throw new IllegalStateException("RELAY_021 "+message);}
    private Update21IntegrationTest(){}
}
