package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

final class CoopIntegrationTest {
    static void verify(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var journal=RaidJournal.get(server);
        var p=player(level,"RelayPatient");
        var helper=player(level,"RelayHelper");
        var anchor=new BlockPos(state.centerX+64,state.spawnY+28,state.centerZ+64);
        p.moveTo(anchor.getX()+.5,anchor.getY(),anchor.getZ()+.5);
        helper.moveTo(anchor.getX()+2.5,anchor.getY(),anchor.getZ()+.5);
        p.getInventory().setItem(9,new ItemStack(Items.BREAD,4));
        require(RaidRules.begin(p,state)==null&&RaidRules.begin(helper,state)==null,"raid entry");
        try{
            helper.getInventory().setItem(0,new ItemStack(Medicine.MEDKIT.get()));
            DownedPlayers.start(p,state);
            require(DownedPlayers.down(p)&&p.getHealth()==1,"downed");
            helper.getInventory().setItem(0,new ItemStack(Medicine.BANDAGE.get(),2));
            require(DownedPlayers.prepare(helper,p,state),"bandage begins");
            require(DownedPlayers.finish(helper,p,state,level.getGameTime()+40),"bandage completes");
            require(RaidRules.record(p).getLong("downedUntil")==level.getGameTime()+800
                &&helper.getMainHandItem().getCount()==1&&!DownedPlayers.prepare(helper,p,state),"one stabilization per wound");
            helper.getInventory().setItem(0,new ItemStack(Medicine.MEDKIT.get()));
            require(DownedPlayers.prepare(helper,p,state),"rescue begins");
            helper.setPos(helper.getX()+1,helper.getY(),helper.getZ());
            require(!DownedPlayers.finish(helper,p,state,level.getGameTime()+80)&&helper.getMainHandItem().getCount()==1,"movement interrupts treatment");
            require(DownedPlayers.prepare(helper,p,state),"rescue retry");
            require(!DownedPlayers.finish(helper,p,state,level.getGameTime()+30),"treatment timer");
            require(DownedPlayers.finish(helper,p,state,level.getGameTime()+100)&&!DownedPlayers.down(p)
                &&helper.getMainHandItem().isEmpty()&&p.getHealth()==8,"rescue consumes one kit");

            DownedPlayers.start(p,state);
            require(RaidRules.record(p).getLong("downedUntil")==level.getGameTime()+400
                &&!RaidRules.record(p).getBoolean("stabilized"),"second wound timing");
            DownedPlayers.clear(p);
            var box=p.blockPosition().relative(p.getDirection());
            level.setBlock(box.below(),Blocks.STONE.defaultBlockState(),2);
            level.setBlock(box,Blocks.AIR.defaultBlockState(),2);
            level.setBlock(box.above(),Blocks.AIR.defaultBlockState(),2);
            TeamStash.use(p,state);
            require(journal.stash.contains("position")&&TeamStash.marked(level,box),"team barrel");
            p.containerMenu.clicked(18,1,ClickType.PICKUP,p);
            require(p.getInventory().getItem(9).isEmpty()&&RaidRules.record(p).getCompound("baseline")
                .getList("inventory",Tag.TAG_COMPOUND).isEmpty(),"deposit debits rollback snapshot");
            TeamStash.open(helper,state,box);
            helper.containerMenu.clicked(0,1,ClickType.PICKUP,helper);
            require(helper.getInventory().items.stream().anyMatch(item->item.is(Items.BREAD)&&item.getCount()==4),
                "teammate withdraws supplies");

            var raid=RaidRules.record(helper);
            raid.put("final",RaidSnapshot.captureLive(helper));
            ExpeditionReport.prepare(helper,state,raid);
            raid.putString("status","COMMIT");
            int reports=journal.reports.size();
            ExpeditionReport.save(helper,raid);
            ExpeditionReport.save(helper,raid);
            require(journal.reports.size()==reports+1&&raid.getCompound("report").getCompound("loot")
                .getInt("minecraft:bread")==4,"single report with extracted items");
            require(journal.reports.getCompound(reports).getInt("rescues")==1
                &&journal.reports.getCompound(reports).getInt("bandages")==1,"medical report");
            journal.reports.removeLast();

            require(StarterKit.claim(p,state)&&!StarterKit.claim(p,state),"kit once per raid");
            require(p.getInventory().items.stream().anyMatch(stack->stack.getItem() instanceof com.tacz.guns.api.item.IGun gun
                &&gun.getGunId(stack).toString().equals("tacz:glock_17")&&SalvageValue.price(stack)==1),"functional starter pistol");
            require(p.getInventory().items.stream().anyMatch(stack->stack.getItem() instanceof com.tacz.guns.api.item.IAmmo ammo
                &&ammo.getAmmoId(stack).toString().equals("tacz:9mm")&&stack.getCount()==12),"matching ammunition");
            new PocketDevice.Menu(11,p.getInventory(),p,PocketDevice.Page.RAID).clicked(10,0,ClickType.PICKUP,p);
            require(p.containerMenu instanceof ReconChart,"PDA target list");
            p.containerMenu.clicked(0,0,ClickType.PICKUP,p);
            require(p.getPersistentData().getString("relay_route").equals("waypoint")&&!Navigation.text(p,state).contains("угроза"),"selected compass target");
            var device=new ItemStack(PocketDevice.ITEM.get());
            require(SalvageValue.price(device)==0&&!TeamStash.accepted(device),"PDA excluded from sale and stash");
            var thrown=new ItemEntity(level,helper.getX(),helper.getY(),helper.getZ(),device);
            var toss=NeoForge.EVENT_BUS.post(new ItemTossEvent(thrown,helper));
            require(toss.isCanceled()&&helper.getInventory().contains(new ItemStack(PocketDevice.ITEM.get())),"toss returns PDA");
            helper.getInventory().items.replaceAll(item->PdaProtection.isPda(item)?ItemStack.EMPTY:item);
            var drops=new ArrayList<ItemEntity>();
            drops.add(new ItemEntity(level,0,64,0,new ItemStack(PocketDevice.ITEM.get())));
            drops.add(new ItemEntity(level,0,64,0,new ItemStack(Items.DIAMOND)));
            NeoForge.EVENT_BUS.post(new LivingDropsEvent(helper,helper.damageSources().genericKill(),drops,false));
            require(drops.size()==1&&drops.getFirst().getItem().is(Items.DIAMOND),"ordinary death drops untouched");
            var replacement=player(level,"RelayReplacement");
            PdaProtection.clonePlayer(helper,replacement);
            PdaProtection.restore(replacement);
            require(replacement.getInventory().contains(new ItemStack(PocketDevice.ITEM.get())),"PDA restored on respawn");
        }finally{
            TeamStash.clear(level);
            journal.raids.remove(p.getUUID());
            journal.raids.remove(helper.getUUID());
            journal.setDirty();
        }
        System.out.println("RELAY_COOP048_PASS");
    }

    private static FakePlayer player(ServerLevel level,String name){
        return new FakePlayer(level,new GameProfile(UUID.randomUUID(),name)){
            @Override public java.util.OptionalInt openMenu(MenuProvider provider){
                containerMenu=provider.createMenu(82,getInventory(),this);
                return java.util.OptionalInt.of(82);
            }
        };
    }

    private static void require(boolean result,String check){
        if(!result)throw new IllegalStateException("Coop 048: "+check);
    }
}
