package dev.bunkerrelay;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;

final class Warehouse {
    static final String KEY = "relay_locker";
    static final int CAPACITY = 54;

    record Entry(ItemStack sample, int count) {}

    private final NonNullList<ItemStack> stock = NonNullList.withSize(CAPACITY, ItemStack.EMPTY);
    private final ServerPlayer owner;

    Warehouse(ServerPlayer owner) {
        this.owner = owner;
        ContainerHelper.loadAllItems(owner.getPersistentData().getCompound(KEY), stock, owner.registryAccess());
    }

    List<Entry> entries() {
        List<Entry> result = new ArrayList<>();
        for (var stack : stock) {
            if (stack.isEmpty() || countIn(result, stack) > 0) continue;
            result.add(new Entry(stack.copyWithCount(1), count(stack)));
        }
        return result;
    }

    private int countIn(List<Entry> entries, ItemStack sample) {
        return entries.stream().filter(entry -> matches(entry.sample(), sample)).mapToInt(Entry::count).sum();
    }

    int count(ItemStack sample) {
        return stock.stream().filter(stack -> matches(stack, sample)).mapToInt(ItemStack::getCount).sum();
    }

    int occupied() {
        return (int) stock.stream().filter(stack -> !stack.isEmpty()).count();
    }

    int deposit(ItemStack from, int requested) {
        if(PdaProtection.isPda(from))return 0;
        int amount = Math.min(requested, from.getCount());
        int left = amount;
        for (var stack : stock) if (left > 0 && matches(stack, from)) {
            int added = Math.min(left, Math.max(0, stack.getMaxStackSize() - stack.getCount()));
            stack.grow(added);
            left -= added;
        }
        for (int slot = 0; slot < stock.size() && left > 0; slot++) if (stock.get(slot).isEmpty()) {
            int added = Math.min(left, from.getMaxStackSize());
            stock.set(slot, from.copyWithCount(added));
            left -= added;
        }
        from.shrink(amount - left);
        return amount - left;
    }

    void remove(ItemStack sample, int amount) {
        for (var stack : stock) if (amount > 0 && matches(stack, sample)) {
            int removed = Math.min(amount, stack.getCount());
            stack.shrink(removed);
            amount -= removed;
        }
    }

    void save() {
        owner.getPersistentData().put(KEY, ContainerHelper.saveAllItems(new CompoundTag(), stock, owner.registryAccess()));
        RelayEconomy.save(owner);
    }

    static boolean matches(ItemStack stack, ItemStack sample) {
        return !stack.isEmpty() && !sample.isEmpty() && ItemStack.isSameItemSameComponents(stack, sample);
    }
}
