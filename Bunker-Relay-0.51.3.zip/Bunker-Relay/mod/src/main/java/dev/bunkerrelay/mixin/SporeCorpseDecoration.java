package dev.bunkerrelay.mixin;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "com.Harbinger.Spore.Sentities.Utility.CorpseEntity", remap = false)
abstract class SporeCorpseDecoration {
    @Inject(method = "tickTimer", at = @At("HEAD"), cancellable = true)
    private void bunkerrelay$noDecay(CallbackInfo result) {
        if (bunkerrelay$isDecoration()) result.cancel();
    }

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void bunkerrelay$noHarvest(DamageSource source, float damage, CallbackInfoReturnable<Boolean> result) {
        if (bunkerrelay$isDecoration()) result.setReturnValue(false);
    }

    @Inject(method = "interactAt", at = @At("HEAD"), cancellable = true)
    private void bunkerrelay$noLoot(Player player, Vec3 hit, InteractionHand hand,
                                    CallbackInfoReturnable<InteractionResult> result) {
        if (bunkerrelay$isDecoration()) result.setReturnValue(InteractionResult.PASS);
    }

    @org.spongepowered.asm.mixin.Unique
    private boolean bunkerrelay$isDecoration() {
        return ((Entity) (Object) this).getPersistentData().getBoolean("relay_spore_corpse");
    }
}
