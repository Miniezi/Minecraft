package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.energy.EnergyStorage;

final class Update13IntegrationTest {
    private static final UUID PARTNER=UUID.fromString("b2754f12-8d04-49f4-ab84-ca5652f077e2");

    static void run(MinecraftServer server){
        var state=RelayState.get(server);
        var hub=server.getLevel(BunkerRelay.HUB);
        var user=new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay13Research"));
        state.baseUpgrades|=1<<BaseUpgrades.Upgrade.WORKSHOP.ordinal();
        state.reserveSeconds=120;
        state.research=0;
        user.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(BossTrophies.QUARANTINE.get()));
        check(TrophyResearch.dismantle(user)==1&&user.getMainHandItem().is(TrophyResearch.Part.REGULATOR.module.get()),"trophy converted");
        check(TrophyResearch.install(user)==1&&user.getMainHandItem().isEmpty(),"module installed");
        user.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(TrophyResearch.Part.REGULATOR.module.get()));
        check(TrophyResearch.install(user)==0&&user.getMainHandItem().getCount()==1,"duplicate kept");
        var storage=new EnergyStorage(1000);
        storage.receiveEnergy(300,false);
        BasePower.updateSource(state,storage);
        check(storage.getEnergyStored()==180,"installed regulator reduces FE load");

        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        check(state.ready,"ready fixture");
        CargoContract.prepare(level,state);
        var first=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"Relay13Carrier"));
        var second=new FakePlayer(level,new GameProfile(PARTNER,"Relay13Partner"));
        check(RaidRules.begin(first,state)==null&&RaidRules.begin(second,state)==null,"two raid records");
        var at=BlockPos.of(state.cargoAt);
        first.moveTo(at.getX(),at.getY(),at.getZ());
        second.moveTo(at.getX(),at.getY(),at.getZ());
        first.setItemInHand(InteractionHand.OFF_HAND,new ItemStack(Items.SHIELD));
        check(CargoContract.take(first)==0,"offhand must be free");
        first.setItemInHand(InteractionHand.OFF_HAND,ItemStack.EMPTY);
        double normalSpeed=first.getAttribute(Attributes.MOVEMENT_SPEED).getValue();
        check(CargoContract.take(first)==1&&first.getAttribute(Attributes.MOVEMENT_SPEED).getValue()<normalSpeed,"burden applied");
        check(CargoContract.take(second)==0,"one carrier");
        RaidRules.fail(first);
        check(state.cargoCarrier==null&&first.getAttribute(Attributes.MOVEMENT_SPEED).getValue()==normalSpeed,"drop on failed raid");
        check(CargoContract.take(second)==1,"cargo transferred");
        second.moveTo(state.centerX,state.spawnY,state.centerZ);
        state.relayPowered=true;
        var record=RaidRules.record(second);
        CargoContract.capture(second,state,record);
        check(record.contains("cargoTeam"),"cargo recorded for evacuation");
        record.put("final",RaidSnapshot.captureLive(second));
        record.putString("status","COMMIT");
        RaidJournal.get(server).flush(server);
        var returned=new FakePlayer(hub,new GameProfile(PARTNER,"Relay13Partner"));
        RaidRules.settle(returned,false);
        CargoContract.settle(returned,record);
        check(state.cargoDelivered&&state.cargoCarrier==null&&RaidContracts.count(second)==2,"unique cargo payout");
        var tag=state.save(new net.minecraft.nbt.CompoundTag(),server.registryAccess());
        check(tag.getBoolean("cargoDelivered")&&tag.getInt("research")!=0,"contract and research serialized");
        RaidJournal.get(server).raids.remove(first.getUUID());
        RaidJournal.get(server).raids.remove(second.getUUID());
        RaidJournal.get(server).flush(server);
        server.saveEverything(false,true,true);
        System.out.println("RELAY_013_PASS trophies=true research=true cargo_transfer=true cargo_failure=true cargo_payout=true");
        server.halt(false);
    }

    static void reload(MinecraftServer server){
        var state=RelayState.get(server);
        check(state.cargoAvailable&&state.cargoDelivered&&state.cargoCarrier==null,"delivery survives restart");
        check(TrophyResearch.has(state,TrophyResearch.Part.REGULATOR),"installed module survives restart");
        var mail=RaidJournal.get(server).mail.get(PARTNER);
        check(mail!=null&&mail.size()==2,"cargo reward survives restart");
        System.out.println("RELAY_013_RELOAD_PASS");
        server.halt(false);
    }

    private static void check(boolean condition,String message){
        if(!condition)throw new IllegalStateException("RELAY_013 "+message);
    }

    private Update13IntegrationTest(){}
}
