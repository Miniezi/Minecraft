package dev.bunkerrelay;

enum ZoneProfile {
    FOREST("forest","Лес",1,2),
    INDUSTRIAL("industrial","Промзона",2,3),
    INFECTED("infected","Заражённый город",3,4),
    ASH("ash","Пустошь",5,5);

    final String id,title;
    final int min,max;

    ZoneProfile(String id,String title,int min,int max){
        this.id=id;this.title=title;this.min=min;this.max=max;
    }

    static ZoneProfile of(String id){
        for(var profile:values())if(profile.id.equals(id))return profile;
        return INDUSTRIAL;
    }

    int difficulty(long seed){return min+Math.floorMod(seed,max-min+1);}
    String range(){return min==max?Integer.toString(max):min+"–"+max;}
}
