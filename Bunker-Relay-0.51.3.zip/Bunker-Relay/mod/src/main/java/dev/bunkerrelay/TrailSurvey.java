package dev.bunkerrelay;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

final class TrailSurvey {
    static boolean markDetour(ServerLevel level,RelayState state,BlockPos from,BlockPos to,BlockPos owner,Block material){
        int minX=Math.min(from.getX(),to.getX())-14,maxX=Math.max(from.getX(),to.getX())+14;
        int minZ=Math.min(from.getZ(),to.getZ())-14,maxZ=Math.max(from.getZ(),to.getZ())+14;
        var start=surface(level,from.getX(),from.getZ());
        var end=surface(level,to.getX(),to.getZ());
        if(start==null||end==null)return false;
        var heights=new HashMap<BlockPos,Optional<BlockPos>>();
        var parent=new HashMap<BlockPos,BlockPos>();
        var open=new ArrayDeque<BlockPos>();
        open.add(start);
        parent.put(start,start);
        while(!open.isEmpty()&&parent.size()<3600){
            var node=open.removeFirst();
            if(node.equals(end)){
                for(var point=end;!point.equals(start);point=parent.get(point)){
                    var at=point.below();
                    var ground=level.getBlockState(at);
                    if(ground.is(Blocks.GRASS_BLOCK)||ground.is(Blocks.DIRT)||ground.is(Blocks.COARSE_DIRT)
                        ||ground.is(Blocks.PODZOL)||ground.is(Blocks.SAND)||ground.is(Blocks.GRAVEL)||ground.is(Blocks.STONE))
                        level.setBlock(at,material.defaultBlockState(),2);
                }
                return true;
            }
            for(var direction:Direction.Plane.HORIZONTAL){
                var column=node.relative(direction).atY(0);
                if(column.getX()<minX||column.getX()>maxX||column.getZ()<minZ||column.getZ()>maxZ
                    ||!SectorPlan.contains(state.centerX,state.centerZ,state.activeSize,column.getX(),column.getZ()))continue;
                var next=heights.computeIfAbsent(column,p->Optional.ofNullable(surface(level,p.getX(),p.getZ()))).orElse(null);
                if(next==null||parent.containsKey(next)||Math.abs(next.getY()-node.getY())>1
                    ||StructureLevels.overlapsHistorical(level,state,next,0,owner))continue;
                parent.put(next,node);
                open.addLast(next);
            }
        }
        return false;
    }

    private static BlockPos surface(ServerLevel level,int x,int z){
        var column=new BlockPos(x,0,z);
        if(!level.hasChunkAt(column))return null;
        var at=column.atY(level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z));
        return level.isEmptyBlock(at)&&level.isEmptyBlock(at.above())&&level.getFluidState(at.below()).isEmpty()
            &&level.getBlockState(at.below()).isSolidRender(level,at.below())?at:null;
    }

    private TrailSurvey(){}
}
