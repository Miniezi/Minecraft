package dev.bunkerrelay;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IAmmo;

final class SalvageValue {
    private static final java.util.Map<String,Integer> CATALOG_VALUES=RelayEconomy.CATALOG.stream().collect(
        java.util.stream.Collectors.toUnmodifiableMap(RelayEconomy.Offer::item,RelayEconomy::unitSell,Math::min));

    private static final java.util.Map<String,Integer> FIELD_MATERIALS=java.util.Map.of(
        "spore:mutated_fiber",3,"spore:armor_fragment",12,"spore:tendons",16,
        "spore:claw_fragment",8,"spore:mutated_heart",30,"spore:cerebrum",28,
        "spore:sickle_fragment",45,"spore:corrosive_sack",40);

    static int price(ItemStack stack) {
        if (stack.isEmpty()||PdaProtection.isPda(stack)) return 0;
        var id=BuiltInRegistries.ITEM.getKey(stack.getItem());
        var path=id.getPath();
        if (path.contains("backpack") || path.contains("shulker_box") || path.contains("bundle")
            || stack.has(DataComponents.CONTAINER) || stack.has(DataComponents.BUNDLE_CONTENTS)
            || stack.has(DataComponents.BLOCK_ENTITY_DATA) || stack.has(DataComponents.BUCKET_ENTITY_DATA)
            || suspiciousNamespace(id) || containsItems(stack)) return 0;
        if (StarterKit.marked(stack)) return 1;
        int requested=BunkerRequests.salvagePrice(stack);
        if(requested>0)return requested;
        if (BossTrophies.isTrophy(stack)) return 420;
        String key=id.toString();
        if(stack.getItem() instanceof IGun gun)key=taczKey("gun",gun.getGunId(stack),key);
        else if(stack.getItem() instanceof IAttachment attachment)key=taczKey("attachment",attachment.getAttachmentId(stack),key);
        else if(stack.getItem() instanceof IAmmo ammo)key=taczKey("ammo",ammo.getAmmoId(stack),key);
        int estimate=switch(stack.getRarity()){
            case EPIC -> 80;
            case RARE -> 32;
            case UNCOMMON -> 9;
            default -> stack.getMaxStackSize()==1?8:1;
        };
        if(id.getNamespace().equals("minecraft")) {
            if(path.startsWith("netherite_"))estimate=Math.max(estimate,100);
            else if(stack.isDamageableItem()&&path.startsWith("diamond_"))estimate=Math.max(estimate,38);
            else if(stack.isDamageableItem()&&path.startsWith("iron_"))estimate=Math.max(estimate,12);
        }
        int value=CATALOG_VALUES.getOrDefault(key,FIELD_MATERIALS.getOrDefault(key,estimate));
        if (stack.isDamageableItem()) value=Math.max(1,(int)(value*(1.0-(double)stack.getDamageValue()/stack.getMaxDamage())));
        return value;
    }

    private static boolean containsItems(ItemStack stack) {
        var handler=stack.getCapability(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.ITEM);
        if(handler==null)return false;
        for(int slot=0;slot<handler.getSlots();slot++)if(!handler.getStackInSlot(slot).isEmpty())return true;
        return false;
    }

    private static String taczKey(String type,ResourceLocation id,String fallback){
        return id!=null&&id.getNamespace().equals("tacz")?type+"/"+id.getPath():fallback;
    }

    private static boolean suspiciousNamespace(ResourceLocation id) {
        return id.getNamespace().startsWith("sophisticated")&&id.getPath().matches(".*(chest|barrel|storage|backpack).*")
            || id.getPath().endsWith("spawn_egg") || id.getPath().contains("command_block");
    }

    static int affordableSale(ServerPlayer player, int price, int available) {
        if (price <= 0) return 0;
        return (int) Math.min(available, Math.min(RelayEconomy.account(player).getInt("budget") / price,
            (RelayEconomy.MAX_BALANCE - RelayEconomy.balance(player)) / price));
    }

    static void creditSale(ServerPlayer player, int payout) {
        var account = RelayEconomy.account(player);
        account.putLong("balance", RelayEconomy.balance(player) + payout);
        account.putInt("budget", account.getInt("budget") - payout);
    }

    static String sellSlot(ServerPlayer player, ItemStack stack, int requested) {
        if (!RelayEconomy.safe(player)||requested<=0) return "Сделка недоступна.";
        int price=price(stack);
        if (price==0) return "Скупщик не принимает этот предмет.";
        int owned=player.getInventory().items.stream().filter(item->ItemStack.isSameItemSameComponents(item,stack))
            .mapToInt(ItemStack::getCount).sum();
        int count=affordableSale(player,price,Math.min(owned,requested));
        if(count<=0) return "Недостаточно бюджета скупщика.";
        int payout=count*price;
        var sample=stack.copyWithCount(1);
        int left=count;
        int first=Math.min(left,stack.getCount());
        stack.shrink(first);
        left-=first;
        for(var item:player.getInventory().items){
            if(left==0)break;
            if(!ItemStack.isSameItemSameComponents(item,sample))continue;
            int take=Math.min(left,item.getCount());
            item.shrink(take);
            left-=take;
        }
        creditSale(player,payout);
        RelayEconomy.save(player);
        return "Продано "+count+" шт. за "+payout+" кр.";
    }

    private SalvageValue() {}
}
