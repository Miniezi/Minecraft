package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.neoforge.common.util.FakePlayer;

final class CombatIntegrationTest {
    static void verify(MinecraftServer server,RelayState state) {
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var at=new BlockPos(state.centerX+12,state.spawnY+32,state.centerZ);
        var pressure=EncounterPressure.of(state);
        require(pressure==EncounterPressure.FOREST&&pressure.waveSize==1,"small forest waves");
        require(EncounterPressure.ASH.fieldSpecies(true).equals("protector"),"heavy wasteland guard");
        var spawned=new ArrayList<Mob>();
        try {
            for(int i=0;i<pressure.limit;i++){
                var mob=SporeEncounters.create(level,"inf_husk");
                mob.moveTo(at.getX()+.5+i,at.getY(),at.getZ()+.5);
                require(level.addFreshEntity(mob),"spawn under shared cap");
                spawned.add(mob);
                if(i+1==pressure.naturalLimit)require(!pressure.room(level,at,true),"natural spawns reserve room for waves");
            }
            require(RaidDirector.spawn(level,state,at,"screamer",null)==null,"wave observes cap from ordinary mobs");
        } finally {
            spawned.forEach(Mob::discard);
        }
        require(pressure.room(level,at,false),"clearing enemies frees capacity");

        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"RelayCombatTest"));
        player.moveTo(at.getX()+5.5,at.getY(),at.getZ()+.5);
        var factory=MiniBosses.Kind.FACTORY;
        var brute=SporeEncounters.create(level,factory.type);
        brute.moveTo(at.getX()+.5,at.getY(),at.getZ()+.5);
        brute.getPersistentData().putLong("relay_guard_site",at.asLong());
        double speed=brute.getAttributeValue(Attributes.MOVEMENT_SPEED);
        factory.combat.configure(brute);
        require(brute.getAttributeValue(Attributes.MOVEMENT_SPEED)<speed,"heavy combat speed");
        factory.combat.fight(level,brute,player,factory,state);
        long impact=brute.getPersistentData().getLong("relay_miniboss_impact");
        require(impact==level.getGameTime()+40&&brute.hasEffect(MobEffects.MOVEMENT_SLOWDOWN),"heavy telegraph");
        factory.combat.fight(level,brute,player,factory,state);
        require(brute.getPersistentData().getLong("relay_miniboss_impact")==impact,"wind-up lasts two seconds");
        var clinic=MiniBosses.Kind.CLINIC;
        var ambusher=SporeEncounters.create(level,clinic.type);
        ambusher.moveTo(at.getX()+.5,at.getY(),at.getZ()+.5);
        ambusher.getPersistentData().putLong("relay_guard_site",at.asLong());
        clinic.combat.fight(level,ambusher,player,clinic,state);
        require(ambusher.hasEffect(MobEffects.MOVEMENT_SPEED),"clinic ambush rush");
        require(MiniBosses.Kind.ARMORY.combat==MiniBossCombat.RANGED,"armory ranged");
        System.out.println("RELAY_REGION_COMBAT_PASS");
    }

    private static void require(boolean condition,String message) {
        if(!condition)throw new IllegalStateException("Regional combat: "+message);
    }
}
