package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

final class SporeIntegrationTest {
    static void verify(MinecraftServer server, RelayState state) {
        var level = server.getLevel(BunkerRelay.key(state.activeDimension));
        var spawn = new BlockPos(state.centerX, state.spawnY + 10, state.centerZ);
        var zombie = EntityType.ZOMBIE.create(level);
        zombie.moveTo(spawn.getX(), spawn.getY(), spawn.getZ());
        require(!level.addFreshEntity(zombie), "vanilla zombie blocked");
        var chicken = EntityType.CHICKEN.create(level);
        chicken.moveTo(spawn.getX(), spawn.getY(), spawn.getZ());
        require(level.addFreshEntity(chicken), "passive mob allowed");
        chicken.discard();
        var fungalCategory=SporeEncounters.create(level,"inf_human").getType().getCategory();
        require(level.getBiome(spawn).value().getMobSettings().getMobs(fungalCategory).unwrap().stream()
            .anyMatch(entry -> BuiltInRegistries.ENTITY_TYPE.getKey(entry.type).getNamespace().equals("spore")), "natural spore pool");
        for (var kind : MiniBosses.Kind.values()) require(SporeEncounters.create(level,kind.type)!=null,"mini-boss "+kind);
        for (var role : new String[]{"stalker","screamer","warden","patrol_site","faceless"}) {
            var mob=RaidDirector.spawn(level,state,spawn,role,null);
            require(mob!=null&&SporeEncounters.isSpore(mob)&&!mob.getPersistentData().contains("relay_expiry"),"authored role "+role);
            mob.discard();
        }

        var mob = SporeEncounters.create(level,"stalker");
        mob.moveTo(spawn.getX(),spawn.getY(),spawn.getZ());
        require(level.addFreshEntity(mob),"fungal mob accepted");
        try {
            var type = mob.getClass();
            require(Boolean.FALSE.equals(type.getMethod("canStarve").invoke(mob)), "starvation disabled");
            type.getMethod("setEvoPoints",Integer.class).invoke(mob,100);
            require(Integer.valueOf(0).equals(type.getMethod("getEvoPoints").invoke(mob)),"evolution points blocked");
        } catch (ReflectiveOperationException error) {
            throw new IllegalStateException("Spore compatibility", error);
        }
        for(int i=0;i<32;i++)
            net.neoforged.neoforge.common.NeoForge.EVENT_BUS.post(
                new net.neoforged.neoforge.event.entity.living.LivingDeathEvent(mob,mob.damageSources().generic()));
        require(level.getEntitiesOfClass(AreaEffectCloud.class,new AABB(spawn).inflate(6)).isEmpty(),"no death clouds");
        mob.discard();

        for (var at : BlockPos.betweenClosed(spawn.offset(-5,-1,-5),spawn.offset(5,-1,5)))
            level.setBlock(at,Blocks.STONE.defaultBlockState(),2);
        SporeCorpses.scatter(level,state,spawn,spawn);
        var bodies=level.getEntitiesOfClass(net.minecraft.world.entity.Entity.class,new AABB(spawn).inflate(8),
            entity->entity.getPersistentData().getBoolean(SporeCorpses.DECORATION));
        require(bodies.size()>=4,"scattered fungal corpses");
        for(var entity:bodies){
            require(BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).equals(ResourceLocation.parse("spore:corpse_piece")),
                "real Spore corpse");
            require(!entity.hurt(entity.damageSources().generic(),10)&&entity.isAlive(),"decorative corpse stays");
            entity.discard();
        }
        for (var at : BlockPos.betweenClosed(spawn.offset(-5,-1,-5),spawn.offset(5,-1,5)))
            level.setBlock(at,Blocks.AIR.defaultBlockState(),2);
        System.out.println("RELAY_SPORE_ONLY_PASS");
    }

    private static void require(boolean condition,String message) {
        if (!condition) throw new IllegalStateException("Spore integration: "+message);
    }
}
