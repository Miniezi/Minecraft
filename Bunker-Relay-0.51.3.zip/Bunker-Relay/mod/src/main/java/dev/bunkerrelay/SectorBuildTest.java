package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;

final class SectorBuildTest {
    static void run(MinecraftServer server,RelayState state){
        var hub=server.getLevel(BunkerRelay.HUB);
        var level=hub;
        check(hub.getBlockState(HubBuilder.TERMINAL).is(RelayTerminalBlock.TERMINAL.get()),"old terminal migrated");
        var pos=new BlockPos(state.centerX+64,227,state.centerZ+64);
        check(SectorBuildings.inBounds(state,pos),"center sector bounds");
        for(int x=-12;x<=12;x++)for(int z=-12;z<=12;z++)
            level.setBlock(pos.offset(x,-1,z),Blocks.GRASS_BLOCK.defaultBlockState(),2);
        check(SectorBuildings.site(level,state,pos,false)==pos.getY(),"flat natural ground");
        level.setBlock(pos.offset(3,0,0),Blocks.OAK_PLANKS.defaultBlockState(),2);
        check(SectorBuildings.site(level,state,pos,false)==Integer.MIN_VALUE,"structure collision");
        level.setBlock(pos.offset(3,0,0),Blocks.AIR.defaultBlockState(),2);
        SectorBuildings.build(level,state,pos,0);
        ExpeditionContent.stock(level,state,pos);
        StructureLevels.rememberSector(level,state,pos);
        SectorBuildings.seal(level,state,pos);
        check(!PersonalLoot.templateItem(level,pos,4).isEmpty(),"sector loot");
        check(StructureLevels.overlapsHistorical(level,state,pos.east(14)),"overlap rejected");
        check(SectorBuildings.site(level,state,pos,true)==pos.getY(),"registered footprint reused");
        level.setBlock(pos.offset(2,1,2),Blocks.DIAMOND_BLOCK.defaultBlockState(),2);
        check(SectorBuildings.site(level,state,pos,true)==Integer.MIN_VALUE,"modified footprint preserved");
        System.out.println("RELAY_019_PASS terminal=true flat=true obstacle=true overlap=true loot=true");
        server.halt(false);
    }
    private static void check(boolean ok,String message){if(!ok)throw new IllegalStateException("SECTOR_BUILD "+message);}
    private SectorBuildTest(){}
}
