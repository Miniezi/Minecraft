package dev.bunkerrelay.client;
import dev.bunkerrelay.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BeaconRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.*;
public final class RelayClient {
 @EventBusSubscriber(modid="bunkerrelay",bus=EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
 public static final class Menus {
  @SubscribeEvent public static void screens(RegisterMenuScreensEvent e){e.<DismantleMenu,RelayScreen<DismantleMenu>>register(RelayMenus.DISMANTLE.get(),RelayScreen::new);e.<LockerMenu,RelayScreen<LockerMenu>>register(RelayMenus.LOCKER.get(),RelayScreen::new);e.<SkillMenu,RelayScreen<SkillMenu>>register(RelayMenus.SKILLS.get(),RelayScreen::new);e.<WorkshopMenu,RelayScreen<WorkshopMenu>>register(RelayMenus.WORKSHOP.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));e.<ReconChart,RelayScreen<ReconChart>>register(RelayMenus.RECON.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));e.<PocketDevice.Menu,RelayScreen<PocketDevice.Menu>>register(RelayMenus.POCKET.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));e.<TerminalMenu,RelayScreen<TerminalMenu>>register(RelayMenus.TERMINAL.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));e.<RelayEconomy.MarketMenu,RelayScreen<RelayEconomy.MarketMenu>>register(RelayMenus.MARKET.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));e.<SupplyOrders.OrdersMenu,RelayScreen<SupplyOrders.OrdersMenu>>register(RelayMenus.ORDERS.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));e.<RaidContracts.JournalMenu,RelayScreen<RaidContracts.JournalMenu>>register(RelayMenus.JOURNAL.get(),(menu,inv,title)->new RelayScreen<>(menu,inv,title));}
 }
 @EventBusSubscriber(modid="bunkerrelay",value=Dist.CLIENT)
 public static final class World {
  @SubscribeEvent(priority=net.neoforged.bus.api.EventPriority.HIGHEST)
  public static void useTerminalWithGun(InputEvent.MouseButton.Pre event){
   var mc=Minecraft.getInstance();
   if(event.getAction()!=org.lwjgl.glfw.GLFW.GLFW_PRESS||mc.screen!=null||mc.player==null||mc.level==null
       ||mc.gameMode==null||!mc.options.keyUse.matchesMouse(event.getButton())
       ||!(mc.player.getMainHandItem().getItem() instanceof com.tacz.guns.api.item.IGun)
       ||!(mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit)
       ||hit.getType()!=net.minecraft.world.phys.HitResult.Type.BLOCK
       ||!RelayTerminalBlock.isTarget(mc.level,hit.getBlockPos()))return;
   event.setCanceled(true);
   mc.gameMode.useItemOn(mc.player,net.minecraft.world.InteractionHand.MAIN_HAND,hit);
  }

  @SubscribeEvent public static void compass(RenderGuiEvent.Post event){CompassHud.render(event.getGuiGraphics());}
  @SubscribeEvent public static void beam(RenderLevelStageEvent e){
   var mc=Minecraft.getInstance();var p=ExitSignal.current;
   if(e.getStage()!=RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES||mc.level==null||p==null||!p.enabled()||!mc.level.dimension().location().equals(p.dimension()))return;
   var pose=e.getPoseStack();var cam=e.getCamera().getPosition();pose.pushPose();pose.translate(p.position().getX()-cam.x,p.position().getY()-cam.y,p.position().getZ()-cam.z);
   var buffers=mc.renderBuffers().bufferSource();BeaconRenderer.renderBeaconBeam(pose,buffers,BeaconRenderer.BEAM_LOCATION,e.getPartialTick().getGameTimeDeltaPartialTick(false),1,mc.level.getGameTime(),0,1024,0xff39cddd,.13f,.18f);
   pose.popPose();buffers.endBatch(RenderType.beaconBeam(BeaconRenderer.BEAM_LOCATION,false));buffers.endBatch(RenderType.beaconBeam(BeaconRenderer.BEAM_LOCATION,true));
  }
  @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut e){ExitSignal.current=null;CompassHud.reset();}
 }
}
