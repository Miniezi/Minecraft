package dev.bunkerrelay;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.*;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import com.tacz.guns.api.item.builder.*;
public final class ExpeditionContent {
 public static void joined(EntityJoinLevelEvent e){
  if(!(e.getLevel() instanceof ServerLevel level)||!BunkerRelay.expedition(level))return;
  var entity=e.getEntity();
  var s=RelayState.get(level.getServer());
  var data=entity.getPersistentData();
  if(entity.getUUID().equals(s.previousBoss)
      ||data.getBoolean("relay_boss")&&!entity.getUUID().equals(s.bossId)&&e.loadedFromDisk()
      ||data.contains("relay_structure_generation")&&data.getInt("relay_structure_generation")!=(s.generating?s.generation+1:s.generation)){
   e.setCanceled(true);return;
  }
  if(!(entity instanceof Mob mob)||!SporeEncounters.isSpore(mob)||mob.getTags().contains("relay_scaled"))return;if((!s.ready&&!s.generating)||!level.dimension().equals(BunkerRelay.key(s.activeDimension))||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,mob.getX(),mob.getZ()))return;
  int tier=s.activeDifficulty;var health=mob.getAttribute(Attributes.MAX_HEALTH);if(health!=null){health.setBaseValue(health.getBaseValue()*(1+(tier-1)*0.35));mob.setHealth(mob.getMaxHealth());}
  var attack=mob.getAttribute(Attributes.ATTACK_DAMAGE);if(attack!=null)attack.setBaseValue(attack.getBaseValue()*(1+(tier-1)*0.2));mob.addTag("relay_scaled");
 }
 public static void nearby(ServerPlayer player,RelayState s){
  var level=player.serverLevel();int cellX=Math.floorDiv(player.getBlockX()-s.centerX,192),cellZ=Math.floorDiv(player.getBlockZ()-s.centerZ,192);
  for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
   int gx=cellX+dx,gz=cellZ+dz;long key=ChunkPos.asLong(gx,gz);if(s.caches.contains(key))continue;
   long roll=RaidDirector.roll(ExpeditionLayout.seed(s),gx,gz);
   int x=s.centerX+gx*192+60+Math.floorMod(roll,73);
   int z=s.centerZ+gz*192+60+Math.floorMod(roll>>>16,73);
   int margin=FieldSites.RADIUS+2;
   if(!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,x-margin,z-margin)||!SectorPlan.contains(s.centerX,s.centerZ,s.activeSize,x+margin,z+margin)||player.distanceToSqr(x,player.getY(),z)>96*96)continue;
   var director=RaidDirector.get(level.getServer());
   if(Math.hypot(x-s.centerX,z-s.centerZ)<30||Math.hypot(x-s.relayX,z-s.relayZ)<24
       ||Math.hypot(x-RaidBosses.arena(s).getX(),z-RaidBosses.arena(s).getZ())<40
       ||director.rooms.stream().anyMatch(room->Math.hypot(x-room.getInt("x"),z-room.getInt("z"))<30)){
    s.caches.add(key);s.setDirty();continue;
   }
   if(!loadedAndUnoccupied(level,s,x,z,margin))continue;
   cache(level,s,x,z);s.caches.add(key);s.setDirty();
  }
 }
 private static boolean loadedAndUnoccupied(ServerLevel level,RelayState state,int x,int z,int margin){
  boolean known=StructureLevels.known(level,state,"cache",x,z);
  for(int cx=(x-margin)>>4;cx<=(x+margin)>>4;cx++)for(int cz=(z-margin)>>4;cz<=(z+margin)>>4;cz++){
   if(!level.hasChunk(cx,cz))return false;
   var chunk=level.getChunk(cx,cz);
   if(chunk.getBlockEntitiesPos().stream().anyMatch(pos->Math.abs(pos.getX()-x)<=margin&&Math.abs(pos.getZ()-z)<=margin
       &&!(known&&pos.getX()==x&&pos.getZ()==z&&chunk.getBlockEntity(pos) instanceof noobanidus.mods.lootr.common.block.entity.LootrChestBlockEntity)))return false;
  }
  return true;
 }
 public static BlockPos cache(ServerLevel level,RelayState s,int x,int z){
  int y=StructureLevels.floor(level,s,"cache",x,z,FieldSites.RADIUS,FieldSites.RADIUS,8);
  FieldSites.build(level,s,new BlockPos(x,y,z));
  BlockPos cp=new BlockPos(x,y,z);stock(level,s,cp);
  for(int i=0;i<s.activeDifficulty;i++){
   var mob=SporeEncounters.create(level,s,i);if(mob!=null){mob.moveTo(x+1+i%3,y,z+1+i/3,0,0);mob.getPersistentData().putInt("relay_structure_generation",s.generating?s.generation+1:s.generation);level.addFreshEntity(mob);}
  }
  return cp;
 }
 static void stock(ServerLevel level,RelayState s,BlockPos origin){
  BlockPos cp=origin;int x=cp.getX(),z=cp.getZ();level.setBlock(cp,Blocks.CHEST.defaultBlockState(),3);
  if(level.getBlockEntity(cp) instanceof ChestBlockEntity chest){
   RaidLoot.fill(chest,level,s,cp);
   if(Math.floorMod(RaidDirector.roll(s.seed,x,z),5)==0){
    chest.setItem(0,new ItemStack(Items.BREAD,2));
    chest.setItem(1,new ItemStack(Items.MILK_BUCKET));
    level.setBlock(cp.above(2),Blocks.SEA_LANTERN.defaultBlockState(),2);
   }
   PersonalLoot.convert(level,cp,chest);
  }
 }
 public static void smoke(ServerLevel level,RelayState s){
  BlockPos p=cache(level,s,s.centerX+12,s.centerZ+12);
  if(PersonalLoot.templateItem(level,p,4).isEmpty())throw new IllegalStateException("Supply cache missing");
  if(ModList.get().isLoaded("tacz")){
   var recipe=level.getRecipeManager().byKey(ResourceLocation.parse("bunkerrelay:ammo_9mm")).orElseThrow(()->new IllegalStateException("Create recipe missing"));
   var output=recipe.value().getResultItem(level.registryAccess());
   if(!(output.getItem() instanceof com.tacz.guns.api.item.IAmmo ammo)||!ammo.getAmmoId(output).equals(ResourceLocation.parse("tacz:9mm")))throw new IllegalStateException("Create ammo data lost");
   var gun=GunItemBuilder.create().setId(ResourceLocation.parse("tacz:glock_17")).build(level.registryAccess());if(gun.isEmpty()||java.util.stream.IntStream.range(4,13).noneMatch(slot->PersonalLoot.templateItem(level,p,slot).getItem() instanceof com.tacz.guns.api.item.IAmmo))throw new IllegalStateException("TaCZ creation failed");
  }else throw new IllegalStateException("TaCZ missing from test server");
 }
 private ExpeditionContent(){}
}
