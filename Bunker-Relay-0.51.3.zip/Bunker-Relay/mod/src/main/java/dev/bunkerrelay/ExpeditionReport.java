package dev.bunkerrelay;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

final class ExpeditionReport {
    static void baseline(ServerPlayer player,CompoundTag raid){
        var counts=new LinkedHashMap<String,Integer>();
        count(player,raid.getCompound("baseline"),counts,1);
        var snapshot=new CompoundTag();
        counts.forEach(snapshot::putInt);
        raid.put("reportBaseline",snapshot);
    }

    static void prepare(ServerPlayer player,RelayState state,CompoundTag raid){
        var report=new CompoundTag();
        report.putString("zone",ZoneProfile.of(state.activeTheme).title);
        report.putBoolean("mission",state.relayPowered);
        report.putBoolean("cargo",raid.contains("cargoTeam"));
        report.putString("contract",ExpeditionContracts.selected(state).title);
        report.putInt("credits",RelayEconomy.extractionCredit(player,raid));
        var counts=new LinkedHashMap<String,Integer>();
        if(raid.contains("reportBaseline")){
            var baseline=raid.getCompound("reportBaseline");
            for(var key:baseline.getAllKeys())counts.put(key,-baseline.getInt(key));
        }else count(player,raid.getCompound("baseline"),counts,-1);
        count(player,raid.getCompound("final"),counts,1);
        var loot=new CompoundTag();
        for(var entry:counts.entrySet())if(entry.getValue()>0)loot.putInt(entry.getKey(),entry.getValue());
        report.put("loot",loot);
        raid.put("report",report);
    }

    private static void count(ServerPlayer p,CompoundTag snapshot,Map<String,Integer> counts,int sign){
        for(var entry:snapshot.getList("inventory",Tag.TAG_COMPOUND)){
            var stack=ItemStack.parseOptional(p.registryAccess(),(CompoundTag)entry);
            if(stack.isEmpty()||PdaProtection.isPda(stack))continue;
            counts.merge(BuiltInRegistries.ITEM.getKey(stack.getItem()).toString(),sign*stack.getCount(),Integer::sum);
        }
    }

    static void save(ServerPlayer player,CompoundTag raid){
        if(!raid.hasUUID("transaction"))return;
        var journal=RaidJournal.get(player.server);
        var transaction=raid.getUUID("transaction");
        for(var entry:journal.reports)if(transaction.equals(((CompoundTag)entry).getUUID("transaction")))return;
        var report=raid.getCompound("report").copy();
        for(String stat:List.of("wounds","bandages","rescues"))report.putInt(stat,raid.getInt(stat));
        report.putUUID("transaction",transaction);
        report.putString("player",player.getScoreboardName());
        report.putInt("generation",raid.getInt("generation"));
        report.putString("status",raid.getString("status"));
        journal.reports.add(report);
        while(journal.reports.size()>96)journal.reports.removeFirst();
        journal.setDirty();
    }

    static List<CompoundTag> latest(ServerPlayer player){
        var journal=RaidJournal.get(player.server);
        int newest=journal.reports.stream().mapToInt(entry->((CompoundTag)entry).getInt("generation")).max().orElse(-1);
        if(newest<0)return List.of();
        var result=new ArrayList<CompoundTag>();
        for(var entry:journal.reports)if(((CompoundTag)entry).getInt("generation")==newest)result.add((CompoundTag)entry);
        for(var raid:journal.raids.values())if(raid.getInt("generation")==newest&&raid.getString("status").equals("ACTIVE")&&raid.contains("player")){
            var pending=new CompoundTag();
            pending.putString("player",raid.getString("player"));pending.putString("status","ACTIVE");
            result.add(pending);
        }
        return result;
    }

    static String outcome(CompoundTag entry){
        return switch(entry.getString("status")){
            case "COMMIT" -> "Эвакуация · "+entry.getInt("credits")+" кр.";
            case "DEAD" -> "Погиб";
            case "ACTIVE" -> "Ещё в зоне";
            default -> "Вылазка прервана";
        };
    }

    static void details(ServerPlayer player,CompoundTag report){
        RaidRules.chat(player,report.getString("player")+" · "+outcome(report));
        if(report.contains("wounds"))RaidRules.chat(player,"Ранения · "+report.getInt("wounds")
            +"   Перевязки напарникам · "+report.getInt("bandages")+"   Спасения · "+report.getInt("rescues"));
        if(!report.getString("status").equals("COMMIT"))return;
        if(report.contains("contract"))RaidRules.chat(player,report.getString("zone")+" · "+report.getString("contract")
            +" · задача "+(report.getBoolean("mission")?"выполнена":"не завершена")
            +(report.getBoolean("cargo")?" · груз эвакуирован":""));
        var loot=report.getCompound("loot");
        var keys=loot.getAllKeys().stream().sorted(Comparator.comparingInt((String key)->loot.getInt(key)).reversed()).limit(15).toList();
        if(keys.isEmpty()){RaidRules.chat(player,"Прироста в основном инвентаре нет.");return;}
        var line=Component.literal("Прирост в инвентаре · ");
        for(String key:keys){
            var item=BuiltInRegistries.ITEM.get(net.minecraft.resources.ResourceLocation.parse(key));
            line.append(item.getDescription()).append(" ×"+loot.getInt(key)+"  ");
        }
        player.sendSystemMessage(line);
    }

    private ExpeditionReport(){}
}
