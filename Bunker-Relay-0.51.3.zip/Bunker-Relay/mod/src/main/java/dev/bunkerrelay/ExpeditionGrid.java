package dev.bunkerrelay;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;

final class ExpeditionGrid {
    static final int SIDE=192;
    static final int HALF=SIDE/2;
    static final int PLOTS=9+ZoneLandmarks.COUNT;

    static void plan(ServerLevel level,RelayState state){
        int limit=(state.activeSize/2-HALF)/SIDE;
        var cells=new ArrayList<BlockPos>();
        for(int x=-limit;x<=limit;x++)for(int z=-limit;z<=limit;z++)
            if(x!=0||z!=0)cells.add(new BlockPos(x,0,z));
        Collections.shuffle(cells,new Random(state.seed));
        var plan=new CompoundTag();
        for(int index=0;index<PLOTS;index++){
            int best=-1,bestCost=Integer.MAX_VALUE,examined=0;
            for(int candidate=cells.size()-1;candidate>=0&&examined<4;candidate--){
                var cell=cells.get(candidate);
                var point=new BlockPos(state.centerX+cell.getX()*SIDE,0,state.centerZ+cell.getZ()*SIDE);
                if(StructureLevels.overlapsHistorical(level,state,point,42)||!clearPlot(level,point))continue;
                examined++;
                int cost=terrainCost(level,point);
                if(cost<bestCost){best=candidate;bestCost=cost;}
                if(cost==0)break;
            }
            if(best>=0){
                var chosen=cells.remove(best);
                plan.putLong("plot"+index,new BlockPos(state.centerX+chosen.getX()*SIDE,0,state.centerZ+chosen.getZ()*SIDE).asLong());
            }
            if(!plan.contains("plot"+index))throw new IllegalStateException("Недостаточно свободных участков для новой вылазки");
        }
        state.expeditionPlots=plan;
        state.layoutVersion=3;
        state.setDirty();
    }

    private static int terrainCost(ServerLevel level,BlockPos point){
        int low=Integer.MAX_VALUE,high=Integer.MIN_VALUE,wet=0;
        for(int dx=-16;dx<=16;dx+=8)for(int dz=-16;dz<=16;dz+=8){
            int x=point.getX()+dx,z=point.getZ()+dz;
            int ground=SurfacePlacement.ground(level,x,z);
            low=Math.min(low,ground);
            high=Math.max(high,ground);
            if(!level.getFluidState(new BlockPos(x,ground-1,z)).isEmpty())wet++;
        }
        return high-low+wet*4;
    }

    private static boolean clearPlot(ServerLevel level,BlockPos point){
        for(int x=(point.getX()-26)>>4;x<=(point.getX()+26)>>4;x++)
            for(int z=(point.getZ()-29)>>4;z<=(point.getZ()+26)>>4;z++){
                var chunk=level.getChunk(x,z);
                if(!chunk.getAllReferences().isEmpty())return false;
                for(int dx=0;dx<16;dx++)for(int dz=0;dz<16;dz++)
                    if(chunk.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE,dx,dz)+52
                        >=level.getMaxBuildHeight())return false;
                if(chunk.getBlockEntitiesPos().stream().anyMatch(pos->Math.abs(pos.getX()-point.getX())<=26
                    &&pos.getZ()>=point.getZ()-29&&pos.getZ()<=point.getZ()+26))return false;
            }
        return true;
    }

    static BlockPos point(RelayState state,int index){return BlockPos.of(state.expeditionPlots.getLong("plot"+index));}

    static int cell(RelayState state,int offset){
        return Math.floorDiv(offset+(state.layoutVersion==3?HALF:0),SIDE);
    }

    static boolean reserved(RelayState state,int x,int z){
        if(state.layoutVersion!=3)return false;
        if(x==0&&z==0)return true;
        for(int i=0;i<PLOTS;i++){
            var point=point(state,i);
            if(cell(state,point.getX()-state.centerX)==x&&cell(state,point.getZ()-state.centerZ)==z)return true;
        }
        return false;
    }

    private ExpeditionGrid(){}
}
