package dev.bunkerrelay;

import com.tacz.guns.api.item.builder.AmmoItemBuilder;
import com.tacz.guns.api.item.builder.AttachmentItemBuilder;
import com.tacz.guns.api.item.builder.GunItemBuilder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class RaidLoot {
    private static final String[] FOREST = {"bread","cooked_rabbit","coal","string","leather","copper_ingot","arrow"};
    private static final String[] INDUSTRIAL = {"iron_ingot","copper_ingot","coal","redstone","string","create:zinc_ingot","create:andesite_alloy","immersiveengineering:wirecoil_copper"};
    private static final String[] INFECTED = {"bread","cooked_beef","coal","redstone","bunkerrelay:bandage","spore:mutated_fiber","spore:armor_fragment"};
    private static final String[] ASH = {"iron_ingot","quartz","redstone","gold_ingot","mekanism:ingot_osmium","spore:armor_fragment","spore:tendons"};
    private static final String[] FOOD = {"bread","cooked_beef","cooked_chicken","baked_potato","carrot","cookie"};
    private static final String[] FREIGHT = {"iron_ingot","copper_ingot","redstone","string","coal","leather","create:zinc_ingot","andesite"};
    private static final String[] PARTS = {"create:cogwheel","create:belt_connector","create:andesite_casing","immersiveengineering:wirecoil_copper","immersiveengineering:connector_lv","create:zinc_ingot"};
    private static final String[] SIDEARMS = {"glock_17","m1911"};
    private static final String[] FIELD_GUNS = {"m870","hk_mp5a5","ak47","ak74m"};
    private static final String[] PREMIUM_GUNS = {"m4a1","hk416d","scar_h","m700"};
    private static final String[] SIMPLE_MODULES = {"extended_mag_1","grip_vertical_military","sight_t2","laser_peq15"};
    private static final String[] PREMIUM_MODULES = {"extended_mag_2","scope_acog_ta31","sight_rmr_dot","laser_ngal"};
    private static final String[] COMMON_AMMO = {"9mm","45acp","12g"};
    private static final String[] FIELD_AMMO = {"556x45","545x39","762x39","12g"};
    private static final String[] PREMIUM_AMMO = {"556x45","545x39","308","762x39"};

    public static List<ItemStack> generate(ServerLevel level,RelayState state,RandomSource random) {
        int tier=tier(state);
        var profile=ZoneProfile.of(state.activeTheme);
        var result=new ArrayList<ItemStack>();
        supplies(result,switch(profile){
            case FOREST -> FOREST;
            case INDUSTRIAL -> INDUSTRIAL;
            case INFECTED -> INFECTED;
            case ASH -> ASH;
        },2+(tier-1)/2,1,1+tier,random);
        if(random.nextInt(100)<25+8*tier)result.add(ammo(tier,4+2*tier,random));
        if(tier>=2&&random.nextInt(100)<(profile==ZoneProfile.INDUSTRIAL?24:12))result.add(circuit(tier,1));
        if(tier>=3&&random.nextInt(100)<tier*2)result.add(module(tier,random));
        if(tier>=4&&random.nextInt(100)<tier)result.add(gun(level,tier-1,random));
        return result;
    }

    static void specialist(Container chest,ServerLevel level,RelayState state,BlockPos at,SupplySites.Kind kind) {
        var random=random(state,at,0x4a83df4aL);
        int tier=tier(state);
        var result=new ArrayList<ItemStack>();
        switch(kind){
            case ARMORY -> {
                result.add(ammo(tier,8+3*tier,random));
                result.add(ammo(Math.max(1,tier-1),4+2*tier,random));
                if(tier>=2&&random.nextInt(100)<30+9*tier)result.add(module(tier,random));
                if(random.nextInt(100)<8+7*tier)result.add(gun(level,tier,random));
            }
            case CANTEEN -> {
                supplies(result,FOOD,3,2,3+tier,random);
                if(tier>=3)result.add(new ItemStack(Medicine.BANDAGE.get(),1+random.nextInt(2)));
            }
            case WAREHOUSE -> {
                supplies(result,FREIGHT,3,2,3+2*tier,random);
                if(tier>=3)result.add(new ItemStack(tier>=5?Items.QUARTZ:Items.GOLD_INGOT,1+random.nextInt(2)));
            }
            case FACTORY -> {
                supplies(result,PARTS,3,1,2+tier,random);
                result.add(circuit(tier,1+(tier>=4?random.nextInt(2):0)));
                if(tier>=4&&random.nextInt(3)==0)result.add(new ItemStack(Items.REDSTONE,4+tier));
            }
        }
        put(chest,4,result);
    }

    static void medical(List<ItemStack> result,RelayState state,RandomSource random) {
        int tier=tier(state);
        result.add(new ItemStack(Medicine.BANDAGE.get(),1+tier+random.nextInt(2)));
        if(tier>=3)result.add(new ItemStack(Medicine.MEDKIT.get()));
        else result.add(new ItemStack(Items.MILK_BUCKET));
    }

    static void airdrop(Container chest,ServerLevel level,RelayState state,BlockPos at,boolean secured) {
        int tier=tier(state);
        var random=random(state,at,secured?0x6d82443dL:0x3621ebc5L);
        if(secured){
            chest.setItem(0,new ItemStack(Items.GOLDEN_APPLE));
            chest.setItem(1,new ItemStack(tier>=3?Items.DIAMOND:Items.GOLD_INGOT,tier>=3?1+(tier==5?1:0):2));
            chest.setItem(2,module(Math.min(5,tier+1),random));
            if(tier>=3||random.nextInt(100)<45)chest.setItem(3,gun(level,tier,random));
        }else{
            chest.setItem(0,new ItemStack(Items.EMERALD,1+tier/2));
            chest.setItem(2,new ItemStack(tier>=3?Items.DIAMOND:Items.GOLD_INGOT,tier>=5?2:1));
            if(tier>=3&&random.nextBoolean())chest.setItem(3,module(tier,random));
        }
        var extras=new ArrayList<ItemStack>();
        extras.add(ammo(tier,(secured?14:8)+2*tier,random));
        medical(extras,state,random);
        put(chest,4,extras);
    }

    public static void fill(Container chest,ServerLevel level,RelayState state,BlockPos at) {
        put(chest,4,generate(level,state,random(state,at,0)));
    }

    private static void put(Container chest,int first,List<ItemStack> result) {
        for(var stack:result)if(!stack.isEmpty()&&first<chest.getContainerSize())chest.setItem(first++,stack);
        chest.setChanged();
    }

    private static int tier(RelayState state) {return Math.clamp(state.activeLoot,1,5);}

    private static RandomSource random(RelayState state,BlockPos at,long salt) {
        return RandomSource.create(state.seed^at.asLong()^salt);
    }

    private static void supplies(List<ItemStack> result,String[] choices,int rolls,int min,int max,RandomSource random) {
        var pool=new ArrayList<>(List.of(choices));
        for(int i=0;i<rolls&&!pool.isEmpty();){
            String key=pool.remove(random.nextInt(pool.size()));
            var item=BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(key)).orElse(null);
            if(item==null||item==Items.AIR)continue;
            int count=Math.min(item.getDefaultMaxStackSize(),min+random.nextInt(max-min+1));
            result.add(new ItemStack(item,count));i++;
        }
    }

    private static ItemStack ammo(int tier,int count,RandomSource random) {
        return AmmoItemBuilder.create().setId(tacz(pick(tier<=2?COMMON_AMMO:tier<=4?FIELD_AMMO:PREMIUM_AMMO,random)))
            .setCount(count).build();
    }

    private static ItemStack gun(ServerLevel level,int tier,RandomSource random) {
        return GunItemBuilder.create().setId(tacz(pick(tier<=2?SIDEARMS:tier<=4?FIELD_GUNS:PREMIUM_GUNS,random)))
            .setAmmoCount(0).build(level.registryAccess());
    }

    private static ItemStack module(int tier,RandomSource random) {
        return AttachmentItemBuilder.create().setId(tacz(pick(tier>=4?PREMIUM_MODULES:SIMPLE_MODULES,random))).build();
    }

    private static ItemStack circuit(int tier,int count) {
        var id=switch(tier){
            case 1 -> "alloy_infused";
            case 2,3 -> "basic_control_circuit";
            case 4 -> "advanced_control_circuit";
            default -> "elite_control_circuit";
        };
        return new ItemStack(BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse("mekanism:"+id)).orElse(Items.REDSTONE),count);
    }

    private static String pick(String[] options,RandomSource random) {return options[random.nextInt(options.length)];}
    private static ResourceLocation tacz(String path) {return ResourceLocation.fromNamespaceAndPath("tacz",path);}
    private RaidLoot(){}
}
