package dev.bunkerrelay;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.flag.FeatureFlags;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;
public final class RelayMenus {
 public static final DeferredRegister<MenuType<?>> TYPES=DeferredRegister.create(Registries.MENU,"bunkerrelay");
 public static final Supplier<MenuType<TerminalMenu>> TERMINAL=TYPES.register("terminal",()->new MenuType<>(TerminalMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<RelayEconomy.MarketMenu>> MARKET=TYPES.register("market",()->new MenuType<>(RelayEconomy.MarketMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<SupplyOrders.OrdersMenu>> ORDERS=TYPES.register("orders",()->new MenuType<>(SupplyOrders.OrdersMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<RaidContracts.JournalMenu>> JOURNAL=TYPES.register("journal",()->new MenuType<>(RaidContracts.JournalMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<PocketDevice.Menu>> POCKET=TYPES.register("pocket",()->new MenuType<>(PocketDevice.Menu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<ReconChart>> RECON=TYPES.register("recon",()->new MenuType<>(ReconChart::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<WorkshopMenu>> WORKSHOP=TYPES.register("workshop",()->new MenuType<>(WorkshopMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<SkillMenu>> SKILLS=TYPES.register("skills",()->new MenuType<>(SkillMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<LockerMenu>> LOCKER=TYPES.register("locker",()->new MenuType<>(LockerMenu::new,FeatureFlags.DEFAULT_FLAGS));
 public static final Supplier<MenuType<DismantleMenu>> DISMANTLE=TYPES.register("dismantle",()->new MenuType<>(DismantleMenu::new,FeatureFlags.DEFAULT_FLAGS));
 private RelayMenus(){}
}
