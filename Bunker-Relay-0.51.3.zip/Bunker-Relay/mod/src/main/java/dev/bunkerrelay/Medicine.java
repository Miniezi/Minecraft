package dev.bunkerrelay;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

final class Medicine extends Item {
    static final java.util.function.Supplier<Item> BANDAGE=BossTrophies.ITEMS.register("bandage",
        ()->new Medicine(5,40));
    static final java.util.function.Supplier<Item> MEDKIT=BossTrophies.ITEMS.register("medkit",
        ()->new Medicine(10,100));

    private final float healing;
    private final int cooldown;

    private Medicine(float healing,int cooldown){
        super(new Properties().stacksTo(16));
        this.healing=healing;this.cooldown=cooldown;
    }

    static void register(){}

    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        var stack=player.getItemInHand(hand);
        if(!player.isHurt()){
            if(player instanceof ServerPlayer p)RaidRules.tell(p,"Здоровье полное.");
            return InteractionResultHolder.fail(stack);
        }
        if(player.getCooldowns().isOnCooldown(BANDAGE.get())||player.getCooldowns().isOnCooldown(MEDKIT.get()))
            return InteractionResultHolder.fail(stack);
        if(!level.isClientSide){
            player.heal(healing);
            player.getCooldowns().addCooldown(BANDAGE.get(),cooldown);
            player.getCooldowns().addCooldown(MEDKIT.get(),cooldown);
            if(!player.getAbilities().instabuild)stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
    }

    @Override public void appendHoverText(ItemStack stack,TooltipContext context,java.util.List<Component> lines,
        net.minecraft.world.item.TooltipFlag flag){
        lines.add(Component.literal("ПКМ · восстанавливает до "+(int)healing+" ед. здоровья"));
    }
}
