package dev.bunkerrelay.mixin;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "com.Harbinger.Spore.Sevents.Infection", remap = false)
abstract class SporeDeaths {
    @Redirect(method = "onEntityDeath", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"))
    private static boolean bunkerrelay$skipDeathSpores(Level level, Entity spawned) {
        var id = BuiltInRegistries.ENTITY_TYPE.getKey(spawned.getType());
        if (spawned instanceof AreaEffectCloud || id.getNamespace().equals("spore") && id.getPath().equals("scent")) return false;
        return level.addFreshEntity(spawned);
    }
}
