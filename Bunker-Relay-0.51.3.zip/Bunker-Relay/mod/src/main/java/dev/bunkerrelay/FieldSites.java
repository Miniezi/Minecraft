package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.levelgen.Heightmap;

final class FieldSites {
    static final int RADIUS=5;

    static void build(ServerLevel level,RelayState state,BlockPos origin){
        Block floor=switch(state.activeTheme){
            case "forest" -> Blocks.SPRUCE_PLANKS;
            case "infected" -> Blocks.SMOOTH_QUARTZ;
            case "ash" -> Blocks.POLISHED_BLACKSTONE;
            default -> Blocks.POLISHED_ANDESITE;
        };
        for(int x=-RADIUS;x<=RADIUS;x++)for(int z=-RADIUS;z<=RADIUS;z++)
            put(level,origin.offset(x,-1,z),floor);
        for(int x:new int[]{-5,5})for(int z:new int[]{-5,5}){
            int ground=level.getHeight(Heightmap.Types.WORLD_SURFACE,origin.getX()+x,origin.getZ()+z);
            for(int y=Math.max(ground,origin.getY()-24);y<origin.getY()-1;y++)
                put(level,new BlockPos(origin.getX()+x,y,origin.getZ()+z),floor);
            put(level,origin.offset(x,0,z),Blocks.STONE_BRICK_WALL);
            put(level,origin.offset(x,1,z),Blocks.LANTERN);
        }
        // A ladder on the exterior reaches the platform even on steep hillsides.
        var ladder=origin.west(6);
        int ground=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,ladder.getX(),ladder.getZ());
        for(int y=Math.min(ground,origin.getY()-1);y<=origin.getY();y++){
            var pos=ladder.atY(y);
            if(y<origin.getY())put(level,pos.east(),floor);
            if(y<origin.getY())level.setBlock(pos,Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.WEST),2);
        }
        switch(state.activeTheme){
            case "forest" -> {
                for(int z=-4;z<=-2;z++)for(int x=-4;x<=4;x++)put(level,origin.offset(x,3,z),Blocks.GREEN_WOOL);
                for(int x:new int[]{-4,4})for(int y=0;y<3;y++)put(level,origin.offset(x,y,-3),Blocks.SPRUCE_FENCE);
                put(level,origin.offset(-3,0,-3),Blocks.CRAFTING_TABLE);
            }
            case "infected" -> {
                for(int z=-4;z<=-2;z++)for(int y=0;y<3;y++){
                    put(level,origin.offset(-4,y,z),Blocks.WHITE_CONCRETE);
                    put(level,origin.offset(4,y,z),Blocks.TINTED_GLASS);
                }
                for(int x=-4;x<=4;x++)put(level,origin.offset(x,0,-4),Blocks.YELLOW_CONCRETE);
                put(level,origin.offset(-3,0,-3),Blocks.CAULDRON);
            }
            case "ash" -> {
                for(int x=-4;x<=4;x++)if(x!=0)for(int y=0;y<2;y++)put(level,origin.offset(x,y,-4),Blocks.BLACKSTONE_WALL);
                put(level,origin.offset(-3,0,-3),Blocks.BLAST_FURNACE);
                put(level,origin.offset(3,0,-3),Blocks.SOUL_LANTERN);
            }
            default -> {
                for(int x:new int[]{-4,4})for(int z=-4;z<=-1;z++)for(int y=0;y<3;y++)
                    put(level,origin.offset(x,y,z),y==1?Blocks.YELLOW_CONCRETE:Blocks.GRAY_CONCRETE);
                put(level,origin.offset(-3,0,-3),Blocks.ANVIL);
            }
        }
    }

    private static void put(ServerLevel level,BlockPos pos,Block block){level.setBlock(pos,block.defaultBlockState(),2);}
    private FieldSites(){}
}
