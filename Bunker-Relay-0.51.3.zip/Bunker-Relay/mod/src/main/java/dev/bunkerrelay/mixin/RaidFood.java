package dev.bunkerrelay.mixin;

import dev.bunkerrelay.BunkerRelay;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(FoodData.class)
abstract class RaidFood {
    @Redirect(method="tick",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/player/Player;heal(F)V"))
    private void bunkerrelay$slowNutritionRecovery(Player player,float amount){
        player.heal(BunkerRelay.expedition(player.level())?amount*.25f:amount);
    }
}
