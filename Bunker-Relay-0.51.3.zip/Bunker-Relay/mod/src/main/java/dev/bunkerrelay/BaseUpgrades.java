package dev.bunkerrelay;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;

final class BaseUpgrades {
    enum Upgrade {
        STORAGE("Склад", 650), SUPPLY("Снабжение", 900),
        WORKSHOP("Мастерская", 800), INTEL("Разведцентр", 450);
        final String title;
        final int price;
        Upgrade(String title, int price) { this.title = title; this.price = price; }
    }

    static boolean has(ServerPlayer player, Upgrade upgrade) {
        return (RelayState.get(player.server).baseUpgrades & (1 << upgrade.ordinal())) != 0;
    }

    static int buy(ServerPlayer player, Upgrade upgrade) {
        if (!RelayEconomy.safe(player)) return unavailable(player);
        if (has(player, upgrade)) { RaidRules.tell(player, "Улучшение уже куплено."); return 0; }
        if (!charge(player, upgrade.price)) return 0;
        var state = RelayState.get(player.server);
        state.baseUpgrades |= 1 << upgrade.ordinal();
        state.setDirty();
        player.server.saveEverything(false, true, true);
        RaidRules.tell(player, "Для команды открыто улучшение «" + upgrade.title + "».");
        return 1;
    }

    static int status(ServerPlayer player) {
        if (!RelayEconomy.safe(player)) return unavailable(player);
        for (var upgrade : Upgrade.values())
            RaidRules.chat(player, upgrade.title + " · " + (has(player, upgrade) ? "открыто" : upgrade.price + " кр."));
        return 1;
    }

    private static boolean charge(ServerPlayer player, int amount) {
        long balance = RelayEconomy.balance(player);
        if (balance < amount) { RaidRules.tell(player, "Нужно " + amount + " кр."); return false; }
        RelayEconomy.account(player).putLong("balance", balance - amount);
        return true;
    }

    static int locker(ServerPlayer player) {
        return locker(player, false, false, RelayEconomy.Merchant.RESOURCES);
    }

    static int locker(ServerPlayer player, boolean pocket, boolean market, RelayEconomy.Merchant merchant) {
        if (!RelayEconomy.safe(player) || !has(player, Upgrade.STORAGE)) return unavailable(player);
        player.openMenu(new SimpleMenuProvider(
            (id, inv, ignored) -> new LockerMenu(id, inv, player, pocket, market, merchant),
            Component.literal(market ? "Скупщик · склад" : "Личный склад")));
        return 1;
    }

    static int repair(ServerPlayer player) {
        if (!RelayEconomy.safe(player) || !has(player, Upgrade.WORKSHOP)) return unavailable(player);
        if(!BasePower.available(player))return 0;
        var item = player.getMainHandItem();
        if (!item.isDamaged()) { RaidRules.tell(player, "Возьмите повреждённый предмет в основную руку."); return 0; }
        int cost = 15 + (int)Math.ceil(45.0 * item.getDamageValue() / item.getMaxDamage());
        if(TrophyResearch.has(RelayState.get(player.server),TrophyResearch.Part.TOOLING))cost=(cost+1)/2;
        if(BunkerRequests.Request.ENGINEER.complete(RelayState.get(player.server)))cost=(cost*75+99)/100;
        if (!charge(player, cost)) return 0;
        item.setDamageValue(0);
        RelayEconomy.save(player);
        RaidRules.tell(player, "Ремонт выполнен · " + cost + " кр.");
        return 1;
    }

    static int intel(ServerPlayer player) {
        if (!RelayEconomy.safe(player) || !has(player, Upgrade.INTEL)) return unavailable(player);
        if(!BasePower.available(player))return 0;
        var state = RelayState.get(player.server);
        if (!state.ready) { RaidRules.tell(player, "Зона ещё не готова."); return 0; }
        var director = RaidDirector.get(player.server);
        RaidRules.chat(player, "Добыча " + state.activeLoot
            + " · " + (director.event.isEmpty() ? "сейчас спокойно" : "активное событие " + director.event));
        RaidDirector.report(player);
        return RaidMission.report(player);
    }

    private static int unavailable(ServerPlayer player) {
        RaidRules.tell(player, "Улучшение доступно на базе после покупки.");
        return 0;
    }

    private BaseUpgrades() {}
}
