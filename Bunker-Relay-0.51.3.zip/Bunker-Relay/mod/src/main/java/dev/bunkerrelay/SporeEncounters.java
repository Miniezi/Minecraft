package dev.bunkerrelay;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

final class SporeEncounters {
    private static final String[][] POOLS = {
        {"inf_human", "inf_husk"},
        {"inf_pillager", "inf_hazmat"},
        {"stalker", "leaper"},
        {"slasher", "spitter"},
        {"brute", "protector"}
    };

    static Mob create(ServerLevel level, RelayState state, int index) {
        var pool = POOLS[Math.clamp(state.activeDifficulty, 1, 5) - 1];
        return create(level, pool[Math.floorMod(index + level.random.nextInt(pool.length), pool.length)]);
    }

    static Mob create(ServerLevel level, String id) {
        var type = BuiltInRegistries.ENTITY_TYPE.getOptional(ResourceLocation.fromNamespaceAndPath("spore", id));
        if (type.isPresent() && type.get().create(level) instanceof Mob mob) {
            mob.addTag("relay_spore");
            return mob;
        }
        return null;
    }

    static boolean isSpore(net.minecraft.world.entity.Entity entity) {
        return BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).getNamespace().equals("spore");
    }

    static void drops(LivingDropsEvent event) {
        var mob = event.getEntity();
        if (!mob.getTags().contains("relay_spore") || !(mob.level() instanceof ServerLevel level)
                || !(event.getSource().getEntity() instanceof Player)) return;
        var state = RelayState.get(level.getServer());
        if (!state.ready || !BunkerRelay.expedition(level)
                || !level.dimension().equals(BunkerRelay.key(state.activeDimension))
                || !SectorPlan.contains(state.centerX, state.centerZ, state.activeSize, mob.getX(), mob.getZ())) return;
        if (level.random.nextInt(10) >= 1 + state.activeLoot) return;
        BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse("spore:biomass")).ifPresent(item ->
            event.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(
                level, mob.getX(), mob.getY(), mob.getZ(), new ItemStack(item))));
    }

    private SporeEncounters() {}
}
