package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;

final class SporeCorpses {
    public static final String DECORATION = "relay_spore_corpse";
    // Spore corpse variants for the jaw and legs fit the cleared rooms.
    private static final int[] PARTS = {1, 2, 3, 4};
    private static final int[][] SPOTS = {{-3,-3},{3,-3},{-4,1},{4,1},{-2,4},{2,4}};

    static void scatter(ServerLevel level, RelayState state, BlockPos origin, BlockPos cache) {
        var type = BuiltInRegistries.ENTITY_TYPE.getOptional(ResourceLocation.parse("spore:corpse_piece")).orElse(null);
        if (type == null) return;
        var random = net.minecraft.util.RandomSource.create(state.seed ^ origin.asLong());
        for (var offset : SPOTS) {
            var at = origin.offset(offset[0], 0, offset[1]);
            if (at.distSqr(cache) < 4 || !level.isEmptyBlock(at)
                || !level.getFluidState(at).isEmpty() || !level.getBlockState(at.below()).isSolidRender(level, at.below())) continue;
            var body = type.create(level);
            if (body == null) continue;
            var appearance = body.saveWithoutId(new CompoundTag());
            appearance.putInt("corpse_type", PARTS[random.nextInt(PARTS.length)]);
            appearance.putFloat("inflation", .8f);
            body.load(appearance);
            body.getPersistentData().putBoolean(DECORATION, true);
            body.getPersistentData().putInt("relay_structure_generation", state.generation + (state.generating ? 1 : 0));
            body.moveTo(at.getX() + .5, at.getY(), at.getZ() + .5, random.nextFloat() * 360, 0);
            if (level.noCollision(body)) level.addFreshEntity(body);
        }
    }

    private SporeCorpses() {}
}
