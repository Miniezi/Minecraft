package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

final class BossIntegrationTest {
    static void run(MinecraftServer server,RelayState state){
        verify(server,state);
        server.halt(false);
    }

    static void verify(MinecraftServer server,RelayState state){
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        state.ready=true;
        state.bossGeneration=state.generation;
        state.activeDifficulty=3;
        state.activeLoot=3;
        state.bossY=level.getMaxBuildHeight()-24;
        var player=new FakePlayer(level,new GameProfile(UUID.randomUUID(),"RelayBossTest"));
        for(String theme:List.of("industrial","infected","forest","ash")){
            state.activeTheme=theme;
            state.bossId=null;
            state.bossDefeated=false;
            state.bossAbility=0;
            RaidBosses.reset();
            var arena=RaidBosses.arena(state);
            level.setBlock(arena.below(),Blocks.STONE.defaultBlockState(),3);
            level.setBlock(arena.offset(4,-1,0),Blocks.STONE.defaultBlockState(),3);
            player.moveTo(arena.getX()+4.5,arena.getY(),arena.getZ()+.5);
            RaidBosses.encounter(server,state,level,List.of(player));
            check(level.getEntity(state.bossId) instanceof Mob,theme+" spawn");
            var boss=(Mob)level.getEntity(state.bossId);
            check(RaidBosses.bar.getPlayers().contains(player),theme+" bar");
            boss.setCustomName(Component.literal(RaidBosses.name(state)));
            state.bossAbility=8;
            RaidBosses.encounter(server,state,level,List.of(player));
            check(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(boss.getType()).getNamespace().equals("spore"),theme+" native Spore boss");
            check(boss.getPersistentData().contains("relay_impact"),theme+" warning");
            for(int second=0;second<3;second++)RaidBosses.encounter(server,state,level,List.of(player));
            check(!boss.getPersistentData().contains("relay_impact"),theme+" strike");
            boss.setHealth(boss.getMaxHealth()/3);
            RaidBosses.encounter(server,state,level,List.of(player));
            check(RaidBosses.bar.getName().getString().contains("Фаза II"),theme+" phase");
            var source=level.damageSources().genericKill();
            boss.hurt(source,Float.MAX_VALUE);
            check(state.bossDefeated&&RaidBosses.bar==null,theme+" victory");
            var drops=level.getEntitiesOfClass(ItemEntity.class,new AABB(arena).inflate(8),
                item->item.getItem().is(BossTrophies.trophy(theme)));
            check(drops.size()==1,theme+" trophy");
            RaidBosses.died(new LivingDeathEvent(boss,source));
            check(level.getEntitiesOfClass(ItemEntity.class,new AABB(arena).inflate(8),item->item.getItem().is(BossTrophies.trophy(theme))).size()==1,
                theme+" one reward");
            System.out.println("RELAY_BOSS_PASS theme="+theme);
        }
    }

    private static void check(boolean result,String label){
        if(!result)throw new IllegalStateException("Boss test: "+label);
    }

    private BossIntegrationTest(){}
}
