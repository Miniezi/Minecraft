package dev.bunkerrelay;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredRegister;

final class BossTrophies {
    static final DeferredRegister.Items ITEMS=DeferredRegister.createItems("bunkerrelay");
    static final java.util.function.Supplier<Item> QUARANTINE=ITEMS.register("quarantine_core", ()->new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(16)));
    static final java.util.function.Supplier<Item> ECHO=ITEMS.register("echo_sample", ()->new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(16)));
    static final java.util.function.Supplier<Item> RANGER=ITEMS.register("ranger_insignia", ()->new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(16)));
    static final java.util.function.Supplier<Item> FORGE=ITEMS.register("forge_core", ()->new Item(new Item.Properties().rarity(Rarity.EPIC).stacksTo(16)));

    static Item trophy(String theme) {
        return switch(theme){case "infected"->ECHO.get();case "forest"->RANGER.get();case "ash"->FORGE.get();default->QUARANTINE.get();};
    }
    static boolean isTrophy(ItemStack stack) {
        return stack.is(QUARANTINE.get())||stack.is(ECHO.get())||stack.is(RANGER.get())||stack.is(FORGE.get());
    }
    private BossTrophies() {}
}
