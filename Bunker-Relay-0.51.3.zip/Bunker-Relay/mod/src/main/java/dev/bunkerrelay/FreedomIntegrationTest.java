package dev.bunkerrelay;
import java.util.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.*;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.level.BlockEvent;
public final class FreedomIntegrationTest {
 private static final UUID ID=UUID.fromString("bad84291-9b9f-4112-b75f-2bddbb5afc18"),FIXTURE=UUID.fromString("6cd97e94-801d-4bb1-91fd-cc3ea9567ea0");
 private static void check(boolean b,String m){if(!b)throw new IllegalStateException("FREEDOM: "+m);}
 public static void run(MinecraftServer server){
  var s=RelayState.get(server);var level=server.getLevel(BunkerRelay.key(s.activeDimension));var p=new FakePlayer(level,new GameProfile(ID,"FreedomTest"));var j=RaidJournal.get(server);j.raids.remove(ID);check(RaidRules.begin(p,s)==null,"entry");var pos=new BlockPos(s.centerX+50,s.spawnY,s.centerZ+50);p.moveTo(pos.getX(),pos.getY(),pos.getZ());
  for(var block:new net.minecraft.world.level.block.Block[]{Blocks.CHEST,Blocks.OAK_DOOR,Blocks.LEVER,Blocks.CRAFTING_TABLE,Blocks.FURNACE}){level.setBlock(pos,block.defaultBlockState(),2);var e=new PlayerInteractEvent.RightClickBlock(p,InteractionHand.MAIN_HAND,pos,new BlockHitResult(Vec3.atCenterOf(pos),Direction.UP,pos,false));NeoForge.EVENT_BUS.post(e);check(!e.isCanceled(),"ordinary interaction allowed "+block);}
  var place=new BlockEvent.EntityPlaceEvent(BlockSnapshot.create(level.dimension(),level,pos),Blocks.STONE.defaultBlockState(),p);NeoForge.EVENT_BUS.post(place);check(!place.isCanceled(),"block placement allowed");
  var chest=ChestMenu.threeRows(20,p.getInventory());p.containerMenu=chest;NeoForge.EVENT_BUS.post(new PlayerContainerEvent.Open(p,chest));check(p.containerMenu==chest,"normal container not closed");p.containerMenu=p.inventoryMenu;
  var villager=EntityType.VILLAGER.create(level);var interact=new PlayerInteractEvent.EntityInteract(p,InteractionHand.MAIN_HAND,villager);NeoForge.EVENT_BUS.post(interact);check(!interact.isCanceled(),"entity interaction allowed");
  for(var item:new Item[]{Items.WATER_BUCKET,Items.OAK_BOAT,Items.PIG_SPAWN_EGG}){p.getInventory().setItem(0,new ItemStack(item));p.getInventory().selected=0;var use=new PlayerInteractEvent.RightClickItem(p,InteractionHand.MAIN_HAND);NeoForge.EVENT_BUS.post(use);check(!use.isCanceled(),"world item use allowed "+item);}
  var drop=new ItemTossEvent(new ItemEntity(level,0,64,0,new ItemStack(Items.DIAMOND,3)),p);NeoForge.EVENT_BUS.post(drop);check(!drop.isCanceled(),"drop allowed");
  for(String id:List.of("sophisticatedbackpacks:deposit_upgrade","sophisticatedbackpacks:restock_upgrade","sophisticatedbackpacks:pump_upgrade","sophisticatedbackpacks:mob_catcher_upgrade")){var item=new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse(id)));check(!item.isEmpty()&&RaidSnapshot.reject(item,p)==null,"upgrade allowed "+id);}
  RaidHud.clear(p);RaidRules.tell(p,"Обычное уведомление");check(RaidHud.hasNotice(p),"ordinary messages routed into actionbar queue");RaidHud.alert(p,"Опасность");check(RaidHud.hasNotice(p),"priority alert available");RaidRules.logout(p);check(!RaidHud.hasNotice(p),"notice queue cleared on logout");j.raids.remove(ID);
  // Pending successful COMMIT: replay must apply the final inventory, never the entry baseline.
  var home=server.getLevel(s.hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER);var q=new FakePlayer(home,new GameProfile(FIXTURE,"CommitReplay"));j.raids.remove(FIXTURE);q.getInventory().setItem(0,new ItemStack(Items.IRON_INGOT,20));check(RaidRules.begin(q,s)==null,"commit fixture entry");q.getInventory().setItem(0,new ItemStack(Items.IRON_INGOT,3));q.getInventory().setItem(1,new ItemStack(Items.DIAMOND,2));var r=RaidRules.record(q);r.put("final",RaidSnapshot.captureLive(q));r.putString("status","COMMIT");j.flush(server);
  System.out.println("RELAY_FREEDOM_PASS: doors, chests, levers, workstations, placement, entity/container use, buckets/boats, drops, transfer upgrades, actionbar routing, pending final-state fixture");
 }
 public static void reload(MinecraftServer server){var s=RelayState.get(server);var q=new FakePlayer(server.getLevel(s.hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER),new GameProfile(FIXTURE,"CommitReplay"));check(RaidRules.active(q),"pending commit persisted");RaidRules.login(q,s);check(!RaidRules.active(q)&&q.getInventory().getItem(0).getCount()==3&&q.getInventory().getItem(1).is(Items.DIAMOND)&&q.getInventory().getItem(1).getCount()==2,"commit recovery uses final items, not initial twenty iron");System.out.println("RELAY_FREEDOM_RELOAD_PASS: successful commit recovery keeps spent loadout spent and retains loot");}
 private FreedomIntegrationTest(){}
}
