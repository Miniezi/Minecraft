package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

final class ExpeditionContracts {
    enum Type {
        STANDARD("Обычная вылазка","Исследование зоны и добыча"),
        MEDICAL("Медицинский резерв","Санитарный шлюз → больница → эвакуация"),
        CARGO("Тяжёлый груз","Заберите груз с блокпоста и эвакуируйте его"),
        BEACONS("Калибровка маяков","Настройте два маяка, включите радио и эвакуируйтесь");
        final String title,hint;
        Type(String title,String hint){this.title=title;this.hint=hint;}
        boolean available(ZoneProfile zone){return this!=MEDICAL||zone==ZoneProfile.INFECTED;}
    }

    static Type selected(RelayState state){
        try{return Type.valueOf(state.fieldRoutes.getString("expeditionContract"));}
        catch(IllegalArgumentException ex){return Type.STANDARD;}
    }

    static String status(ServerPlayer player,RelayState state){
        var type=selected(state);
        return switch(type){
            case MEDICAL -> !state.fieldRoutes.getBoolean("medicalClue")?"Осмотрите сундук санитарного шлюза"
                :!state.fieldRoutes.getBoolean("medicalFound")?"Заберите резерв в карантинной больнице":"Резерв найден · эвакуируйтесь за наградой";
            case CARGO -> CargoContract.status(state);
            case BEACONS -> state.relayPowered?"Маяки настроены · эвакуируйтесь за наградой":RaidMission.label(state);
            default -> RaidMission.label(state);
        };
    }

    static void discover(ServerPlayer player,RelayState state,BlockPos pos){
        if(selected(state)!=Type.MEDICAL)return;
        var block=player.serverLevel().getBlockEntity(pos);
        if(block==null)return;
        var data=block.getPersistentData();
        if(data.getInt("relay_supply_cycle")!=state.generation)return;
        if(data.getString("relay_landmark").equals("Санитарный шлюз")&&!state.fieldRoutes.getBoolean("medicalClue")){
            state.fieldRoutes.putBoolean("medicalClue",true);
            state.setDirty();
            for(var room:RaidDirector.get(player.server).rooms)if(room.getString("title").equals("Карантинная больница")){
                var target=new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z"));
                Navigation.waypoint(player,state.generation,target,"Медицинский резерв");
                RaidRules.chat(player,"В журнале шлюза указана больница · "+target.toShortString());
                break;
            }
        }
        if(data.getString("relay_landmark").equals("Карантинная больница")&&state.fieldRoutes.getBoolean("medicalClue")){
            var raid=RaidRules.record(player);
            if(raid!=null&&!raid.getBoolean("medicalFound")){
                raid.putBoolean("medicalFound",true);
                state.fieldRoutes.putBoolean("medicalFound",true);
                state.setDirty();
                RaidJournal.get(player.server).setDirty();
                RaidRules.tell(player,"Возьмите подписанный медицинский резерв в основной инвентарь и эвакуируйтесь.");
            }
        }
    }

    static void capture(ServerPlayer p,RelayState state,CompoundTag raid){
        switch(selected(state)){
            case MEDICAL -> {if(raid.getBoolean("medicalFound")&&p.getInventory().items.stream().anyMatch(item->isReserve(item,state)))raid.putString("expeditionReward","medical");}
            case BEACONS -> {if(state.relayPowered)raid.putString("expeditionReward","beacons");}
            default -> {}
        }
    }

    static ItemStack reserve(RelayState state){
        var stack=new ItemStack(Medicine.MEDKIT.get());
        var tag=new CompoundTag();
        tag.putInt("relay_medical_cycle",state.generation+(state.generating?1:0));
        stack.set(net.minecraft.core.component.DataComponents.CUSTOM_DATA,net.minecraft.world.item.component.CustomData.of(tag));
        stack.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,
            net.minecraft.network.chat.Component.literal("Медицинский резерв · для эвакуации"));
        return stack;
    }

    private static boolean isReserve(ItemStack item,RelayState state){
        var data=item.get(net.minecraft.core.component.DataComponents.CUSTOM_DATA);
        if(data==null)return false;
        var tag=data.copyTag();
        return tag.contains("relay_medical_cycle")&&tag.getInt("relay_medical_cycle")==state.generation;
    }

    static void award(ServerPlayer player,CompoundTag raid){
        switch(raid.getString("expeditionReward")){
            case "medical" -> RaidContracts.add(player,player.getUUID(),raid,"medical_reserve",new ItemStack(Medicine.MEDKIT.get(),2));
            case "beacons" -> RaidContracts.add(player,player.getUUID(),raid,"expedition_beacons",new ItemStack(Items.EMERALD,8));
            default -> {}
        }
    }

    private ExpeditionContracts(){}
}
