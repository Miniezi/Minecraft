package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.capabilities.Capabilities;

final class BasePower {
    private static final int LOAD=160;
    private static final int MAX_SECONDS=1800;

    private static ServerLevel home(MinecraftServer server, RelayState state) {
        return server.getLevel(state.hubV2?BunkerRelay.HUB:BunkerRelay.BUNKER);
    }

    private static BlockPos terminal(RelayState state) {
        return state.hubV2?HubBuilder.TERMINAL:new BlockPos(0,30,0);
    }

    static BlockPos socket(RelayState state) { return terminal(state).east(3); }

    static void second(MinecraftServer server, RelayState state) {
        if(!state.initialized)return;
        var level=home(server,state);
        if(level==null||server.getPlayerList().getPlayers().stream().noneMatch(RelayEconomy::safe))return;
        if(!level.hasChunkAt(socket(state))){updateSource(state,null);return;}
        var storage=level.getCapability(Capabilities.EnergyStorage.BLOCK,socket(state),Direction.WEST);
        updateSource(state,storage);
        var lamp=terminal(state).above(2);
        var current=level.getBlockState(lamp);
        if(state.powerSource.equals("off")){
            if(current.is(Blocks.LIGHT))level.removeBlock(lamp,false);
        }else if(current.isAir())level.setBlock(lamp,Blocks.LIGHT.defaultBlockState(),3);
    }

    static void updateSource(RelayState state,net.neoforged.neoforge.energy.IEnergyStorage storage) {
        String source="off";
        int draw=TrophyResearch.has(state,TrophyResearch.Part.REGULATOR)?120:LOAD;
        if(storage!=null&&storage.extractEnergy(draw,true)==draw&&storage.extractEnergy(draw,false)==draw)source="grid";
        else if(state.reserveSeconds>0){
            state.reserveSeconds--;
            source="reserve";
            state.setDirty();
        }
        state.powerSource=source;
    }

    static boolean available(ServerPlayer player) {
        var state=RelayState.get(player.server);
        if(!state.powerSource.equals("off")||state.reserveSeconds>0)return true;
        RaidRules.tell(player,"Сервис без питания · проверьте терминал");
        return false;
    }

    static String label(RelayState state) {
        return switch(state.powerSource){
            case "grid" -> "Питание от сети";
            case "reserve" -> "Резерв · "+state.reserveSeconds+" с";
            default -> "Питание отключено · резерв "+state.reserveSeconds+" с";
        };
    }

    static int report(ServerPlayer player) {
        var state=RelayState.get(player.server);
        RaidRules.chat(player,label(state)+" · аккумулятор на "+socket(state).toShortString()+" · "+(TrophyResearch.has(state,TrophyResearch.Part.REGULATOR)?120:LOAD)+" FE/с");
        RaidRules.tell(player,"Уголь в руке · «Заправить резерв» на терминале");
        return 1;
    }

    static int fuel(ServerPlayer player) {
        var state=RelayState.get(player.server);
        if(!RelayEconomy.safe(player)||player.serverLevel()!=home(player.server,state)
            ||player.blockPosition().distSqr(terminal(state))>64){
            RaidRules.tell(player,"Заправьте резерв у терминала бункера.");
            return 0;
        }
        var held=player.getMainHandItem();
        if(!held.is(Items.COAL)&&!held.is(Items.CHARCOAL)){
            RaidRules.tell(player,"Возьмите уголь или древесный уголь в основную руку.");
            return 0;
        }
        if(state.reserveSeconds>MAX_SECONDS-120){
            RaidRules.tell(player,"В резерве недостаточно места для ещё одной порции.");
            return 0;
        }
        held.shrink(1);
        state.reserveSeconds+=120;
        state.setDirty();
        player.server.saveEverything(false,true,true);
        return report(player);
    }

    private BasePower() {}
}
