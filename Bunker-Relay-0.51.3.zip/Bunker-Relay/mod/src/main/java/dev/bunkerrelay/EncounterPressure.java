package dev.bunkerrelay;

import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

enum EncounterPressure {
    FOREST(6, 2, 1, 25, 32, Set.of("inf_human","inf_husk","inf_hazmat")),
    INDUSTRIAL(9, 4, 2, 42, 46, Set.of("inf_husk","inf_pillager","inf_hazmat","stalker")),
    INFECTED(12, 6, 3, 29, 70, Set.of("inf_human","inf_hazmat","slasher","spitter","leaper","stalker")),
    ASH(10, 4, 2, 38, 38, Set.of("brute","protector","spitter","inf_husk"));

    private static final double RADIUS = 48;
    final int limit, naturalLimit, waveSize, exposedChance, coveredChance;
    private final Set<String> naturalSpecies;

    EncounterPressure(int limit,int naturalLimit,int waveSize,int exposedChance,int coveredChance,Set<String> naturalSpecies) {
        this.limit=limit;
        this.naturalLimit=naturalLimit;
        this.waveSize=waveSize;
        this.exposedChance=exposedChance;
        this.coveredChance=coveredChance;
        this.naturalSpecies=naturalSpecies;
    }

    static EncounterPressure of(RelayState state) {
        return valueOf(ZoneProfile.of(state.activeTheme).name());
    }

    boolean room(ServerLevel level,BlockPos center,boolean natural) {
        int budget=natural?naturalLimit:limit;
        double squared=RADIUS*RADIUS;
        return level.getEntitiesOfClass(Mob.class,new AABB(center).inflate(RADIUS),mob ->
            mob instanceof Enemy && mob.isAlive() && SporeEncounters.isSpore(mob)
                && mob.distanceToSqr(center.getX()+.5,center.getY()+.5,center.getZ()+.5)<=squared).size()<budget;
    }

    boolean natural(ServerLevel level,Mob mob,boolean night) {
        if(!naturalSpecies.contains(BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).getPath()))return false;
        var at=mob.blockPosition();
        boolean covered=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,at.getX(),at.getZ())>at.getY()+2;
        int chance=covered?coveredChance:exposedChance;
        if(night)chance=covered?Math.min(88,chance+13):Math.max(8,chance-14);
        return level.random.nextInt(100)<chance&&room(level,at,true);
    }

    int guards(int base,boolean valuable) {
        return switch(this){
            case FOREST -> Math.min(base,2);
            case INDUSTRIAL -> base;
            case INFECTED -> base+1;
            case ASH -> valuable?base+1:Math.min(base,2);
        };
    }

    String fieldSpecies(boolean valuable) {
        return switch(this){
            case FOREST -> "inf_husk";
            case INDUSTRIAL -> "inf_pillager";
            case INFECTED -> "slasher";
            case ASH -> valuable?"protector":"inf_husk";
        };
    }
}
