package dev.bunkerrelay;
/** Non-overlapping sectors; the old terrain is retained on disk. */
public final class SectorPlan {
 public static final int DEFAULT_SIZE=4096,STRIDE=16384,GRID=3500,MAX_SECTORS=GRID*GRID;
 public record Center(int x,int z){}
 public static boolean validSize(int n){return n==2048||n==4096||n==8192;}
 private static int signed(int n){return n%2==0?n/2:-(n+1)/2;}
 public static Center center(int index){if(index<0||index>=MAX_SECTORS)throw new IllegalArgumentException("Sector limit reached");return new Center(signed(index%GRID)*STRIDE,signed(index/GRID)*STRIDE);}
 public static boolean contains(int x,int z,int size,double px,double pz){return px>=x-size/2.0+1&&px<x+size/2.0-1&&pz>=z-size/2.0+1&&pz<z+size/2.0-1;}
 private SectorPlan(){}
}
