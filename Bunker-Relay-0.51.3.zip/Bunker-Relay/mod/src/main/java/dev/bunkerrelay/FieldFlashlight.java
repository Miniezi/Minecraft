package dev.bunkerrelay;

import net.minecraft.world.item.Item;

/** Keeps the handheld item from earlier world saves loadable. Relay Lights recognizes its registry ID. */
final class FieldFlashlight {
    static final java.util.function.Supplier<Item> ITEM=BossTrophies.ITEMS.register("field_flashlight",
        ()->new Item(new Item.Properties().stacksTo(1)));

    static void register(){}

    private FieldFlashlight(){}
}
