package dev.bunkerrelay;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.level.BlockEvent;
public final class RaidRules {
 public static boolean active(ServerPlayer p){return RaidJournal.get(p.server).raids.containsKey(p.getUUID());}
 public static CompoundTag record(ServerPlayer p){return RaidJournal.get(p.server).raids.get(p.getUUID());}
 public static void register(){
  NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST,RaidRules::death);
  NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST,RaidContracts::killed);
  NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,RaidRules::blockUse);
  NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST,RaidRules::breakBlock);
  NeoForge.EVENT_BUS.addListener(RaidRules::blast);
 }
 public static String begin(ServerPlayer p,RelayState s){
  if(active(p))return "Предыдущая вылазка ещё не завершена.";
  p.closeContainer();if(!p.getPersistentData().getString("relay_route").equals("waypoint"))Navigation.route(p,"auto");
  if(TrashRecovery.pending(p))return "Освободите место для вещей из восстановленной корзины перед выходом.";
  try{
   var r=new CompoundTag();r.put("baseline",RaidSnapshot.capture(p));r.putString("status","ACTIVE");r.putString("player",p.getScoreboardName());r.putInt("generation",s.generation);r.putUUID("transaction",UUID.randomUUID());
   ExpeditionReport.baseline(p,r);RaidContracts.initialize(p,s,r);r.putInt("economyDifficulty",s.activeDifficulty);
   var j=RaidJournal.get(p.server);j.raids.put(p.getUUID(),r);j.flush(p.server);p.server.getPlayerList().saveAll();return null;
  }catch(IllegalArgumentException error){return error.getMessage();}
 }
 public static void fail(ServerPlayer p){
  if(!active(p))return;var r=record(p);if(!r.getString("status").equals("ACTIVE"))return;
  CargoContract.drop(p,RelayState.get(p.server));
  MeetingSignals.clear(p);r.putString("status","RESTORE");RaidJournal.get(p.server).flush(p.server);
 }
 public static void settle(ServerPlayer p,boolean success){
  if(!active(p))return;DownedPlayers.clear(p);p.closeContainer();var r=record(p);var j=RaidJournal.get(p.server);boolean committingNow=false;
  if(success&&r.getString("status").equals("ACTIVE")){
   if(TrashRecovery.pending(p)||!r.getList("overflow",Tag.TAG_COMPOUND).isEmpty())throw new IllegalStateException("Освободите место для сохранённых при закрытии меню вещей.");
   r.put("final",RaidSnapshot.captureLive(p));CargoContract.capture(p,RelayState.get(p.server),r);ExpeditionContracts.capture(p,RelayState.get(p.server),r);ExpeditionReport.prepare(p,RelayState.get(p.server),r);r.putString("status","COMMIT");j.flush(p.server);committingNow=true;
  }else if(r.getString("status").equals("ACTIVE")){r.putString("status","RESTORE");j.flush(p.server);}
  boolean committed=r.getString("status").equals("COMMIT");
  if(!committed||!r.contains("cargoTeam"))CargoContract.drop(p,RelayState.get(p.server));
  boolean died=r.getString("status").equals("DEAD");
  if(!died)TrashRecovery.discardOnSettlement(p);
  BunkerRelay.returnToBunker(p);
  if(!died&&(!committed||!committingNow))RaidSnapshot.apply(p,r.getCompound(committed?"final":"baseline"));
  p.getPersistentData().putUUID("relay_settled",r.getUUID("transaction"));p.inventoryMenu.broadcastChanges();
  p.server.getPlayerList().saveAll();p.server.saveEverything(false,true,true);
  if(committed){CargoContract.settle(p,r);RaidContracts.award(p,r);ExpeditionContracts.award(p,r);RelayEconomy.extracted(p,r);}
  ExpeditionReport.save(p,r);
  j.raids.remove(p.getUUID());j.flush(p.server);MeetingSignals.clear(p);
  chat(p,committed?"Эвакуация завершена. Вся добыча сохранена.":died?"Вылазка завершилась гибелью. Действуют обычные правила выпадения вещей.":"Вылазка потеряна. Снаряжение и содержимое рюкзаков восстановлены до выхода.");
  if(committed&&RaidContracts.count(p)>0)tell(p,"В почте есть награды. Откройте журнал в КПК.");
 }
 public static void login(ServerPlayer p,RelayState s){
  TeamStash.recover(p);
  if(!active(p))return;var r=record(p);
  if(!r.getString("status").equals("ACTIVE")||r.getInt("generation")!=s.generation||!s.ready||!BunkerRelay.expedition(p.level()))settle(p,false);
 }
 public static String requestExtraction(ServerPlayer p,RelayState s){
  return requestExtraction(p,s,new BlockPos(s.centerX,s.spawnY,s.centerZ));
 }
 static String requestExtraction(ServerPlayer p,RelayState s,BlockPos point){
  if(DownedPlayers.down(p))return "Перед эвакуацией напарник должен поднять вас.";
  if(!active(p))return "Это старая вылазка без снимка: вернитесь и начните новую.";
  if(!s.ready||s.generating||!record(p).getString("status").equals("ACTIVE")||record(p).getInt("generation")!=s.generation
      ||!p.level().dimension().equals(BunkerRelay.key(s.activeDimension)))return "Вылазка уже завершена.";
  boolean backup=point.equals(FieldRoutes.point(s,FieldRoutes.EXIT));
  if(!backup&&!point.equals(new BlockPos(s.centerX,s.spawnY,s.centerZ)))return "Неизвестная площадка.";
  if(p.blockPosition().distSqr(point)>144)return "Подойдите к площадке эвакуации.";
  if(backup&&!FieldRoutes.known(s,FieldRoutes.EXIT))return "Запасной выход обесточен. Запустите полевую подстанцию.";
  if(!backup&&!s.relayPowered)return RaidMission.label(s)+" · "+RaidMission.target(s).toShortString();
  p.closeContainer();if(TrashRecovery.pending(p)||!record(p).getList("overflow",Tag.TAG_COMPOUND).isEmpty())return "Освободите место в инвентаре; отложенные вещи вернутся автоматически.";
  RaidVisuals.extraction(p.serverLevel(),point,1);
  settle(p,true);
  return null;
 }
 public static void tick(ServerPlayer p,RelayState s){
  if(!active(p))return;
  if(!record(p).getString("status").equals("ACTIVE")){if(p.isAlive())settle(p,false);return;}
  if(!BunkerRelay.expedition(p.level())||!s.ready||record(p).getInt("generation")!=s.generation){settle(p,false);return;}
  
  if(p.tickCount%20==0){
   RaidContracts.tick(p,s);
   var list=record(p).getList("overflow",Tag.TAG_COMPOUND);var remaining=new ListTag();
   for(Tag v:list){ItemStack item=ItemStack.parseOptional(p.registryAccess(),(CompoundTag)v);SafeInventory.insert(p.getInventory(),item);if(!item.isEmpty())remaining.add(item.save(p.registryAccess()));}
   record(p).put("overflow",remaining);RaidJournal.get(p.server).setDirty();
  }
 }
 public static void resetTimers(){RaidHud.reset();Navigation.reset();}
 public static void logout(ServerPlayer p){MeetingSignals.clear(p);if(!active(p)||!record(p).getString("status").equals("COMMIT"))CargoContract.drop(p,RelayState.get(p.server));RaidHud.clear(p);}
 public static void closeZone(MinecraftServer server){MeetingSignals.reset();var j=RaidJournal.get(server);for(var r:j.raids.values())if(r.getString("status").equals("ACTIVE"))r.putString("status","RESTORE");j.flush(server);}
 public static int discard(ServerPlayer p){return TrashMenu.open(p);}
 public static void storeOverflow(ServerPlayer p,ItemStack item){if(item.isEmpty())return;var r=record(p);var list=r.getList("overflow",Tag.TAG_COMPOUND);list.add(item.copy().save(p.registryAccess()));r.put("overflow",list);RaidJournal.get(p.server).setDirty();tell(p,"Нет места: предмет сохранён и вернётся после освобождения слота.");}
 private static void death(LivingDeathEvent event){
  if(!(event.getEntity() instanceof ServerPlayer player)||!active(player))return;
  var raid=record(player);
  if(!raid.getString("status").equals("ACTIVE"))return;
  CargoContract.drop(player,RelayState.get(player.server));
  
  // Vanilla and equipment mods handle inventory drops, enchantments and keepInventory.
  MeetingSignals.clear(player);raid.putString("status","DEAD");
  var overflow=raid.getList("overflow",Tag.TAG_COMPOUND);
  if(player.level().getGameRules().getBoolean(net.minecraft.world.level.GameRules.RULE_KEEPINVENTORY)){
   TrashRecovery.retain(player,overflow);
  }else for(var entry:overflow){
   var stack=ItemStack.parseOptional(player.registryAccess(),(CompoundTag)entry);
   if(!stack.isEmpty())player.drop(stack,true,false);
  }
  raid.remove("overflow");
  RaidJournal.get(player.server).flush(player.server);
 }
 private static void blockUse(PlayerInteractEvent.RightClickBlock e){
  if(!(e.getEntity() instanceof ServerPlayer p)||!active(p))return;
  var s=RelayState.get(p.server);var pos=e.getPos();
  if(!p.level().dimension().equals(BunkerRelay.key(s.activeDimension))||!s.ready||s.generating
      ||record(p).getInt("generation")!=s.generation||!record(p).getString("status").equals("ACTIVE"))return;
  if(TeamStash.marked(p.serverLevel(),pos)){
   e.setCanceled(true);
   if(e.getHand()==InteractionHand.MAIN_HAND)TeamStash.open(p,s,pos);
   return;
  }
  var director=RaidDirector.get(p.server);
  if(e.getHand()==InteractionHand.MAIN_HAND&&Airdrop.startBreach(p,director,pos)){
   e.setCanceled(true);return;
  }
  if(e.getHand()==InteractionHand.MAIN_HAND){
   SupplySites.alert(p,s,pos);
   MiniBosses.encounter(p,s,pos);
   FieldSecurity.read(p,s,pos);
   ExpeditionContracts.discover(p,s,pos);
  }
  if(TrophyResearch.medicalLocked(p.serverLevel(),s,pos)){
   e.setCanceled(true);
   if(e.getHand()==InteractionHand.MAIN_HAND)tell(p,"Медицинский отсек изолирован. Установите стабилизатор из трофея Стража в мастерской.");
   return;
  }
  if(FieldSecurity.locked(p.serverLevel(),s,pos)){
   e.setCanceled(true);
   if(e.getHand()==InteractionHand.MAIN_HAND)tell(p,s.activeTheme.equals("ash")?"Сейф заперт. Ключ у командира, код — в форте.":"Сейф заперт. Ключ у командира, код — в ремонтной мастерской.");
   return;
  }
  if(!p.level().getBlockState(pos).is(net.minecraft.world.level.block.Blocks.LODESTONE))return;
  boolean radio=pos.equals(new BlockPos(s.relayX,s.relayY,s.relayZ));
  boolean exit=pos.equals(new BlockPos(s.centerX,s.spawnY,s.centerZ));
  boolean node=RaidMission.node(s,pos);
  boolean cargo=CargoContract.station(s,pos);
  boolean field=FieldRoutes.controls(s,pos);
  if(!radio&&!exit&&!node&&!cargo&&!field)return;e.setCanceled(true);if(e.getHand()!=InteractionHand.MAIN_HAND)return;
  if(field){FieldRoutes.interact(p,s,pos);return;}
  if(cargo){CargoContract.take(p);return;}
  if(radio||node){RaidMission.use(p,s,pos);return;}
  String problem=requestExtraction(p,s);if(problem!=null)tell(p,problem);
 }
 private static boolean objective(MinecraftServer server,BlockPos pos){var s=RelayState.get(server);return FieldRoutes.controls(s,pos)||CargoContract.station(s,pos)||Navigation.protectedBlock(s,pos)||pos.equals(new BlockPos(s.relayX,s.relayY,s.relayZ))||pos.equals(new BlockPos(s.centerX,s.spawnY,s.centerZ));}
 private static void breakBlock(BlockEvent.BreakEvent e){if(e.getPlayer() instanceof ServerPlayer p&&BunkerRelay.expedition(p.level())&&(objective(p.server,e.getPos())||dropControl(p.serverLevel(),e.getPos())))e.setCanceled(true);}
 private static void blast(net.neoforged.neoforge.event.level.ExplosionEvent.Detonate e){if(e.getLevel() instanceof net.minecraft.server.level.ServerLevel l&&BunkerRelay.expedition(l))e.getAffectedBlocks().removeIf(pos->objective(l.getServer(),pos)||dropControl(l,pos));}
 private static boolean dropControl(net.minecraft.server.level.ServerLevel level,BlockPos pos){
  var s=RelayState.get(level.getServer());
  return s.ready&&level.dimension().equals(BunkerRelay.key(s.activeDimension))&&(TeamStash.marked(level,pos)||Airdrop.controls(RaidDirector.get(level.getServer()),pos)||FieldSecurity.locked(level,s,pos)||TrophyResearch.medicalLocked(level,s,pos));
 }
 public static void tell(ServerPlayer p,String message){RaidHud.notice(p,message);}
 public static void chat(ServerPlayer p,String message){p.sendSystemMessage(Component.literal("[Bunker Relay] "+message));}
 private RaidRules(){}
}
