package dev.bunkerrelay;

import java.util.HashSet;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;

final class Update15IntegrationTest {
    static void verify(MinecraftServer server, RelayState state){
        var hub=server.getLevel(BunkerRelay.HUB);
        check(state.annexBuilt,"service wing installed");
        var arrival=BunkerAnnex.arrival(state);
        check(hub.getBlockState(arrival).isAir()&&hub.getBlockState(arrival.below()).is(Blocks.SMOOTH_STONE),"safe arrival");
        check(hub.getBlockState(BunkerAnnex.exit(state)).is(Blocks.LODESTONE),"service wing exit");
        var marker=arrival.offset(1,0,0);
        hub.setBlock(marker,Blocks.GOLD_BLOCK.defaultBlockState(),3);
        check(BunkerAnnex.install(hub,state)&&hub.getBlockState(marker).is(Blocks.GOLD_BLOCK),"repeat install preserves construction");

        var layout=new RelayState();
        layout.centerX=state.centerX;
        layout.centerZ=state.centerZ;
        check(ExpeditionLayout.arena(layout).equals(new BlockPos(state.centerX+256,0,state.centerZ-192)),"legacy arena");
        layout.layoutVersion=1;
        var orientations=new HashSet<BlockPos>();
        for(long rotation=0;rotation<4;rotation++){
            layout.seed=rotation<<16;
            orientations.add(ExpeditionLayout.arena(layout));
            var sites=new HashSet<BlockPos>();
            sites.add(ExpeditionLayout.arena(layout));sites.add(ExpeditionLayout.radio(layout));
            for(int i=0;i<4;i++)sites.add(ExpeditionLayout.story(layout,i));
            check(sites.size()==6&&sites.stream().allMatch(pos->
                SectorPlan.contains(layout.centerX,layout.centerZ,2048,pos.getX(),pos.getZ())),"six distinct sites in bounds");
        }
        check(orientations.size()==4,"seed changes orientation");
        var director=RaidDirector.get(server);
        for(int i=0;i<4;i++){
            var expected=ExpeditionLayout.story(state,i);
            var room=director.rooms.get(i);
            check(expected.getX()==room.getInt("x")&&expected.getZ()==room.getInt("z"),"built story position");
        }
        check(ExpeditionLayout.radio(state).getX()==state.relayX&&ExpeditionLayout.radio(state).getZ()==state.relayZ,"built radio position");
        var level=server.getLevel(BunkerRelay.key(state.activeDimension));
        var post=ExpeditionContent.cache(level,state,state.centerX+48,state.centerZ+48);
        check(level.getBlockState(post.offset(5,1,5)).is(Blocks.LANTERN),"field site shelter");
        check(!PersonalLoot.templateItem(level,post,4).isEmpty(),"personal field cache");
        System.out.println("RELAY_015_PASS annex=true migration=true rotations=4 field_cache=true");
    }

    static void upgrade(MinecraftServer server,RelayState state){
        var hub=server.getLevel(BunkerRelay.HUB);
        check(state.hubV2&&state.ready,"existing save");
        check(state.layoutVersion==0,"old layout retained");
        var blocked=new BlockPos(52,96,24);
        check(hub.getBlockState(blocked).is(Blocks.DIAMOND_BLOCK),"occupied site preserved");
        check(state.annexBuilt&&!BunkerAnnex.arrival(state).below().equals(blocked),"alternate wing site");
        var player=new net.neoforged.neoforge.common.util.FakePlayer(hub,new com.mojang.authlib.GameProfile(
            java.util.UUID.randomUUID(),"Relay15Chart")){
            @Override public java.util.OptionalInt openMenu(net.minecraft.world.MenuProvider menu){
                containerMenu=menu.createMenu(50,getInventory(),this);
                return java.util.OptionalInt.of(50);
            }
        };
        check(ReconChart.open(player)==1&&player.containerMenu instanceof ReconChart,"chart opens");
        player.containerMenu.clicked(0,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        check(Navigation.text(player,state).contains("Площадка эвакуации"),"chart selects live destination");
        server.saveEverything(false,true,true);
        System.out.println("RELAY_015_UPGRADE_PASS old_layout=true occupied_site=true waypoint=true");
        server.halt(false);
    }

    private static void check(boolean condition,String message){
        if(!condition)throw new IllegalStateException("RELAY_015 "+message);
    }

    private Update15IntegrationTest(){}
}
