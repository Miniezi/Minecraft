package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

final class SiteDetails {
    static final int VARIANT_COUNT = 9;
    private static final String[] FACTORY={"Ремонтный цех","Погрузочный двор","Склад фильтров","Электроподстанция","Насосная","Диспетчерская","Кабельная эстакада","Шлюз обслуживания","Котельная"};
    private static final String[] INFECTED={"Карантинный пост","Пункт сортировки","Изолятор","Медпункт","Пост дезактивации","Полевой архив","Мобильная лаборатория","Санитарный шлюз","Хранилище проб"};
    private static final String[] FOREST={"Лесная стоянка","Застава егерей","Лесопилка","Пункт снабжения","Наблюдательный пост","Радиолагерь","Заслон лесничества","Укрытие спасателей","Пожарный пост"};
    private static final String[] ASH={"Пепельный редут","Брошенная плавильня","Контрольная точка","Мастерская на пустоши","Разрушенный укрепрайон","Пост связи","Стрелковый двор","Противопылевой шлюз","Станция фильтрации"};

    static String name(String theme,int variant){
        return switch(theme){case "forest"->FOREST[variant];case "infected"->INFECTED[variant];case "ash"->ASH[variant];default->FACTORY[variant];};
    }

    static void build(ServerLevel level,BlockPos origin,String theme,int variant,Block wall,Block roof,Block accent){
        Block equipment=switch(theme){case "forest"->Blocks.CRAFTING_TABLE;case "infected"->Blocks.CAULDRON;case "ash"->Blocks.BLACKSTONE_WALL;default->Blocks.ANVIL;};
        switch(variant){
            case 0 -> {
                for(int z=-2;z<=2;z++)put(level,origin.offset(-5,0,z),wall);
                put(level,origin.offset(-4,0,-1),equipment);
            }
            case 1 -> {
                for(int z=-5;z<=5;z++)for(int x=-3;x<=3;x++)
                    put(level,origin.offset(x,4,z),roof);
                for(int x:new int[]{-3,3})for(int z:new int[]{-5,5})for(int y=0;y<4;y++)put(level,origin.offset(x,y,z),wall);
            }
            case 2 -> {
                for(int z=-5;z<=5;z+=3)for(int x=-5;x<=-2;x++)
                    put(level,origin.offset(x,0,z),accent);
                put(level,origin.offset(-3,0,4),equipment);
            }
            case 3 -> {
                for(int x:new int[]{-5,5})for(int z:new int[]{-4,4})for(int y=0;y<=4;y++)put(level,origin.offset(x,y,z),wall);
                for(int x=-5;x<=5;x++)for(int z=-4;z<=4;z++)
                    if(Math.abs(x)==5||Math.abs(z)==4)put(level,origin.offset(x,4,z),accent);
                put(level,origin.offset(4,0,3),equipment);
            }
            case 4 -> {
                for(int x=-4;x<=4;x++)if(x!=0)for(int y=0;y<=2;y++)put(level,origin.offset(x,y,-5),wall);
                for(int z=-3;z<=3;z+=3)for(int x:new int[]{-4,4})put(level,origin.offset(x,1,z),accent);
                put(level,origin.offset(2,0,-4),equipment);
            }
            case 5 -> {
                for(int x=-4;x<=4;x++)for(int z=-4;z<=-2;z++)put(level,origin.offset(x,4,z),roof);
                for(int y=0;y<=4;y++)put(level,origin.offset(-4,y,-4),wall);
                for(int y=0;y<=5;y++)put(level,origin.offset(3,y,-4),Blocks.IRON_BARS);
                put(level,origin.offset(3,6,-4),Blocks.REDSTONE_LAMP);
                put(level,origin.offset(2,0,-4),equipment);
            }
            case 6 -> {
                for (int x : new int[]{-4, 4}) {
                    for (int z = -5; z <= 4; z++) {
                        put(level, origin.offset(x, 3, z), accent);
                        if (z == -5 || z == 4) {
                            for (int y = 0; y < 3; y++) put(level, origin.offset(x, y, z), wall);
                        }
                    }
                }
                for (int x = -4; x <= 4; x++) put(level, origin.offset(x, 3, -5), roof);
                put(level, origin.offset(-3, 0, -3), equipment);
            }
            case 7 -> {
                for (int z = 1; z <= 5; z++) {
                    for (int x : new int[]{-2, 2})
                        for (int y = 0; y < 3; y++) put(level, origin.offset(x, y, z), wall);
                    for (int x = -2; x <= 2; x++) put(level, origin.offset(x, 3, z), roof);
                }
                put(level, origin.offset(0, 2, 5), Blocks.SEA_LANTERN);
                put(level, origin.offset(-3, 0, 3), equipment);
            }
            case 8 -> {
                for (int x : new int[]{-4, 4}) {
                    for (int z = -5; z <= -2; z++) {
                        for (int dx = -1; dx <= 1; dx++) {
                            put(level, origin.offset(x + dx, 3, z), roof);
                            put(level, origin.offset(x + dx, 0, z), accent);
                            if (z == -5) put(level, origin.offset(x + dx, 1, z), wall);
                        }
                        put(level, origin.offset(x, 2, z), wall);
                    }
                }
                put(level, origin.offset(-4, 1, -3), equipment);
            }
            default -> throw new IllegalArgumentException("Unknown sector variant: " + variant);
        }
    }

    private static void put(ServerLevel level,BlockPos pos,Block block){level.setBlock(pos,block.defaultBlockState(),2);}
    private SiteDetails(){}
}
