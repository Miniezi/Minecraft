package dev.bunkerrelay;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
public record ExitSignal(ResourceLocation dimension,BlockPos position,boolean enabled,String compass,BlockPos target) implements CustomPacketPayload {
 public ExitSignal(ResourceLocation dimension,BlockPos position,boolean enabled){this(dimension,position,enabled,"",position);}
 public static final Type<ExitSignal> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("bunkerrelay","exit_signal"));
 public static final StreamCodec<RegistryFriendlyByteBuf,ExitSignal> CODEC=StreamCodec.of((b,p)->{b.writeResourceLocation(p.dimension);b.writeBlockPos(p.position);b.writeBoolean(p.enabled);b.writeUtf(p.compass);b.writeBlockPos(p.target);},b->new ExitSignal(b.readResourceLocation(),b.readBlockPos(),b.readBoolean(),b.readUtf(),b.readBlockPos()));
 public static volatile ExitSignal current;
 public Type<ExitSignal> type(){return TYPE;}
 public static void register(RegisterPayloadHandlersEvent e){e.registrar("2").playToClient(TYPE,CODEC,(p,c)->c.enqueueWork(()->current=p));}
}
