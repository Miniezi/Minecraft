package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

final class FieldRoutes {
    static final int SUBSTATION = 0, VAULT = 1, EXIT = 2;
    private static final int[][] PLOTS = {{-256,-360},{-448,-296},{-520,112}};
    private static final int[][] SEARCH = {
        {0,0},{32,0},{-32,0},{0,48},{0,-48},{64,48},{-64,48},{64,-48},{-64,-48},
        {96,0},{-96,0},{0,96},{0,-96},{96,96},{-96,96},{96,-96},{-96,-96}
    };

    static BlockPos point(RelayState state, int type) {
        return state.fieldRoutes.contains("point" + type) ? BlockPos.of(state.fieldRoutes.getLong("point" + type)) : null;
    }

    static String name(int type) {
        return switch (type) {
            case SUBSTATION -> "Полевая подстанция";
            case VAULT -> "Резервное хранилище";
            default -> "Запасная эвакуация";
        };
    }

    static void build(ServerLevel level, RelayState state, int type) {
        if(type==SUBSTATION){
            var contract=ExpeditionContracts.selected(state);
            state.fieldRoutes=new net.minecraft.nbt.CompoundTag();
            state.fieldRoutes.putString("expeditionContract",contract.name());
        }
        int[] plot = PLOTS[type];
        var column = state.layoutVersion==3?ExpeditionGrid.point(state,6+type):findPlot(level,state,type,plot);
        if (column==null) return;
        int y = StructureLevels.floor(level,state,"field"+type,column.getX(),column.getZ(),4,4,8);
        var at = column.atY(y);
        switch(type){
            case SUBSTATION -> FieldArchitecture.substation(level,at);
            case VAULT -> FieldArchitecture.vault(level,at);
            case EXIT -> FieldArchitecture.extraction(level,at,true);
            default -> throw new IllegalArgumentException("Unknown field structure: "+type);
        }
        state.fieldRoutes.putLong("point"+type,at.asLong());
        state.setDirty();
    }

    private static BlockPos findPlot(ServerLevel level,RelayState state,int type,int[] plot){
        for(int[] offset:SEARCH){
            var candidate=ExpeditionLayout.position(state,plot[0]+offset[0],plot[1]+offset[1]);
            int x=candidate.getX(),z=candidate.getZ();
            if(!SectorBuildings.inBounds(state,candidate)||ExpeditionLayout.nearStoryPlots(state,candidate))continue;
            if(StructureLevels.known(level,state,"field"+type,x,z))return candidate;
            if(StructureLevels.overlapsHistorical(level,state,candidate))continue;
            boolean nearRoute=false;
            for(int previous=SUBSTATION;previous<type;previous++){
                var existing=point(state,previous);
                if(existing!=null&&existing.atY(0).distSqr(candidate)<=64*64)nearRoute=true;
            }
            if(nearRoute)continue;
            boolean clear=true;
            for(int cx=(x-4)>>4;cx<=(x+4)>>4;cx++)for(int cz=(z-4)>>4;cz<=(z+5)>>4;cz++){
                var chunk=level.getChunk(cx,cz);
                if(!chunk.getAllReferences().isEmpty()||chunk.getBlockEntitiesPos().stream()
                    .anyMatch(pos->Math.abs(pos.getX()-x)<=4&&pos.getZ()>=z-4&&pos.getZ()<=z+5))clear=false;
            }
            if(clear)return candidate;
        }
        return null;
    }

    static boolean known(RelayState state, int type) {
        return point(state,type)!=null && (type==SUBSTATION || state.fieldRoutes.getBoolean("powered"));
    }

    static boolean controls(RelayState state,BlockPos pos) {
        for (int type=SUBSTATION;type<=EXIT;type++) if (pos.equals(point(state,type))) return true;
        return false;
    }

    static boolean interact(ServerPlayer player,RelayState state,BlockPos pos) {
        if (pos.equals(point(state,SUBSTATION))) {
            if (point(state,VAULT)==null && point(state,EXIT)==null) {
                RaidRules.tell(player,"Цепь подстанции повреждена.");
                return true;
            }
            if (!state.fieldRoutes.getBoolean("powered")) {
                state.fieldRoutes.putBoolean("powered",true);
                state.setDirty();
                String unlocked=point(state,VAULT)==null?"запасной выход":point(state,EXIT)==null?"резервное хранилище":"резервное хранилище и запасной выход";
                for (var teammate : player.server.getPlayerList().getPlayers())
                    if (RaidRules.active(teammate)) RaidRules.chat(teammate,"Подстанция запущена. КПК показывает "+unlocked+".");
                RaidDirector.spawnNear(player,state,"stalker",42);
            }
            FieldSecurity.cancel(player,state);
            int target=point(state,VAULT)==null?EXIT:VAULT;
            Navigation.waypoint(player,state.generation,point(state,target),name(target));
        } else if (pos.equals(point(state,VAULT))) {
            if (!known(state,VAULT)) RaidRules.tell(player,"Хранилище обесточено. Запустите полевую подстанцию.");
            else if (!state.fieldRoutes.getBoolean("opened")) {
                ExpeditionContent.stock(player.serverLevel(),state,pos.north(2));
                state.fieldRoutes.putBoolean("opened",true);
                MiniBosses.arm(player.serverLevel(),state,pos.north(2),MiniBosses.Kind.VAULT);
                MiniBosses.encounter(player,state,pos.north(2));
                state.setDirty();
                RaidRules.tell(player,"Хранилище открыто. Груз в личном сундуке.");
            } else RaidRules.tell(player,"Хранилище открыто. Проверьте личный сундук.");
        } else if (pos.equals(point(state,EXIT))) {
            String issue=RaidRules.requestExtraction(player,state,pos);
            if (issue!=null) RaidRules.tell(player,issue);
        } else return false;
        return true;
    }

    private FieldRoutes() {}
}
