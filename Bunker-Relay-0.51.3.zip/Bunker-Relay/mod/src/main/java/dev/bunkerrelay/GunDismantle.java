package dev.bunkerrelay;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.api.item.builder.AmmoItemBuilder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

final class GunDismantle {
    record Plan(List<ItemStack> outputs, Component error) {
        boolean allowed() { return error == null; }

        Component summary() {
            if (!allowed()) return error;
            var result=Component.literal("");
            for (var stack:outputs) {
                if (!result.getString().isEmpty()) result.append(" · ");
                result.append(stack.getHoverName()).append(" ×"+stack.getCount());
            }
            return result;
        }
    }

    static Plan plan(ServerPlayer player,ItemStack stack) {
        if (!(stack.getItem() instanceof IGun gun)) return blocked("Выберите оружие TaCZ.");
        if (StarterKit.marked(stack)) return blocked("Стартовое оружие разбирать нельзя.");
        var index=TimelessAPI.getCommonGunIndex(gun.getGunId(stack)).orElse(null);
        if (index==null) return blocked("Данные этого оружия отсутствуют.");
        var outputs=new ArrayList<ItemStack>();
        boolean light=index.getType().equals("pistol");
        outputs.add(new ItemStack(Items.IRON_INGOT,light?2:4));
        var shaft=BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse("create:shaft")).orElse(Items.IRON_NUGGET);
        outputs.add(new ItemStack(shaft,light?1:2));
        if (!light) outputs.add(new ItemStack(Items.COPPER_INGOT,2));

        for (var type:AttachmentType.values()) {
            if (type==AttachmentType.NONE) continue;
            var data=gun.getAttachmentTag(stack,type);
            if (data==null||data.isEmpty())continue;
            var attachment=gun.getAttachment(player.registryAccess(),stack,type);
            if (attachment.isEmpty()) return blocked("Не удалось прочитать установленный модуль.");
            outputs.add(attachment.copy());
        }
        int ammo=gun.getCurrentAmmoCount(stack);
        if (ammo<0||ammo>10000)return blocked("Сначала разрядите оружие.");
        if (gun.hasBulletInBarrel(stack)) ammo++;
        if (!gun.useDummyAmmo(stack)&&!gun.useInventoryAmmo(stack)&&ammo>0) {
            var ammoId=index.getGunData().getAmmoId();
            if (ammoId==null||TimelessAPI.getCommonAmmoIndex(ammoId).isEmpty()) return blocked("Сначала разрядите оружие.");
            var rounds=AmmoItemBuilder.create().setId(ammoId).setCount(ammo).build();
            if(rounds.isEmpty())return blocked("Не удалось извлечь патроны.");
            outputs.add(rounds);
        }
        return new Plan(List.copyOf(outputs),null);
    }

    private static Plan blocked(String reason) {
        return new Plan(List.of(),Component.literal(reason));
    }

    static boolean dismantle(ServerPlayer player,int slot,ItemStack snapshot) {
        var inventory=player.getInventory();
        var current=inventory.getItem(slot);
        if (!ItemStack.matches(current,snapshot)) {
            RaidRules.tell(player,"Предмет изменился. Выберите оружие заново.");
            return false;
        }
        var recipe=plan(player,current);
        if (!recipe.allowed()) {
            RaidRules.tell(player,recipe.error().getString());
            return false;
        }
        var simulated=new Inventory(player);
        for(int i=0;i<inventory.items.size();i++)simulated.items.set(i,inventory.items.get(i).copy());
        simulated.items.get(slot).shrink(1);
        for (var output:recipe.outputs()) {
            var remaining=output.copy();
            SafeInventory.insert(simulated,remaining);
            if (!remaining.isEmpty()) {
                RaidRules.tell(player,"Не хватает места для всех деталей, модулей и патронов.");
                return false;
            }
        }
        for(int i=0;i<inventory.items.size();i++){
            var result=simulated.items.get(i);
            if(!ItemStack.matches(inventory.items.get(i),result))inventory.items.set(i,result);
        }
        RelayEconomy.save(player);
        player.displayClientMessage(Component.literal("Получено · ").append(recipe.summary()),false);
        return true;
    }

    private GunDismantle() {}
}
