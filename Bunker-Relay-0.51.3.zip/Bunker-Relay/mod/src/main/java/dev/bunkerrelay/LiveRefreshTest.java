package dev.bunkerrelay;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.util.FakePlayer;

final class LiveRefreshTest {
    private static BlockPos entry,terrain;
    private static int generation;
    private static long seed;

    static void start(MinecraftServer server,RelayState state){
        check(state.ready,"existing expedition");
        generation=state.generation;
        seed=state.seed;
        var zone=server.getLevel(BunkerRelay.key(state.activeDimension));
        entry=new BlockPos(state.centerX,state.spawnY,state.centerZ);
        terrain=entry.offset(45,12,45);
        zone.setBlock(terrain,Blocks.DIAMOND_BLOCK.defaultBlockState(),3);
        zone.setBlock(entry,Blocks.AIR.defaultBlockState(),3);
        var hub=server.getLevel(BunkerRelay.HUB);
        var player=new FakePlayer(hub,new GameProfile(UUID.randomUUID(),"Relay16Refresh"));
        var terminal=HubBuilder.TERMINAL;
        player.moveTo(terminal.getX(),terminal.getY(),terminal.getZ());
        state.theme=state.activeTheme;
        var menu=new TerminalMenu(12,player.getInventory(),player);
        player.containerMenu=menu;
        menu.clicked(22,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        if(Boolean.getBoolean("bunkerrelay.zone27Test")){
            menu.clicked(26,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
            check(state.generation==generation&&state.ready&&!state.generating,"skipping does not replace current expedition");
            var profile=ZoneProfile.of(state.activeTheme);
            state.lightOffers.putBoolean(profile.id,true);
            menu.clicked(10+profile.ordinal(),0,net.minecraft.world.inventory.ClickType.PICKUP,player);
            check(menu.getSlot(23).getItem().is(net.minecraft.world.item.Items.CLOCK),"night shown before launch");
        }
        menu.clicked(20,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        menu.clicked(24,0,net.minecraft.world.inventory.ClickType.PICKUP,player);
        check(state.generating&&!state.ready&&server.isRunning(),"live builder started");
    }

    static void verify(MinecraftServer server,RelayState state){
        var zone=server.getLevel(BunkerRelay.key(state.activeDimension));
        check(state.ready&&state.generation==generation+1,"next generation ready");
        check(state.centerX==entry.getX()&&state.centerZ==entry.getZ()&&state.spawnY==entry.getY(),"same coordinates and height");
        check(zone.getBlockState(terrain).is(Blocks.DIAMOND_BLOCK),"terrain outside structures preserved");
        check(zone.getBlockState(entry).is(Blocks.LODESTONE),"entry rebuilt");
        for(int z=3;z<=10;z++){
            var walk=entry.south(z);
            check(zone.isEmptyBlock(walk)&&zone.isEmptyBlock(walk.above())&&!zone.isEmptyBlock(walk.below()),"walkable arrival route");
        }
        check(!state.relayPowered&&state.cargoAvailable&&!state.cargoDelivered,"missions reset");
        check(server.isRunning()&&ExpeditionReset.pending(server)==null,"same running server, no restart marker");
        if(Boolean.getBoolean("bunkerrelay.zone27Test")){
            check(state.seed!=seed&&state.layoutVersion==3,"fresh seed and grid plan");
            check(state.nightRaid&&zone.getDayTime()==18000,"accepted night stays fixed after regeneration");
            var cells=new java.util.HashSet<BlockPos>();
            for(int i=0;i<ExpeditionGrid.PLOTS;i++){
                var point=ExpeditionGrid.point(state,i);
                check(cells.add(point)&&ExpeditionGrid.reserved(state,
                    ExpeditionGrid.cell(state,point.getX()-state.centerX),ExpeditionGrid.cell(state,point.getZ()-state.centerZ)),
                    "one reserved parcel per object");
                check(!ExpeditionRoads.road(point.getX()-state.centerX)&&!ExpeditionRoads.road(point.getZ()-state.centerZ),"road corridor kept clear");
            }
            var report=state.save(new net.minecraft.nbt.CompoundTag(),server.registryAccess());
            check(report.getCompound("expeditionPlots").equals(state.expeditionPlots),"grid persisted");
            var testRoad=entry.offset(96,20,0);
            zone.setBlock(testRoad,Blocks.GRASS_BLOCK.defaultBlockState(),3);
            var walker=new FakePlayer(zone,new GameProfile(UUID.randomUUID(),"RelayRoadTest"));
            walker.moveTo(testRoad.getX()+.5,testRoad.getY()+1,testRoad.getZ()+.5);
            ExpeditionRoads.visit(walker,state);
            check(zone.getBlockState(testRoad).is(Blocks.DIRT_PATH),"forest trail generated on exploration");
            System.out.println("RELAY_GRID_PASS");
            var allRooms=RaidDirector.get(server).rooms;
            var rooms=allRooms.stream().filter(room->!room.getString("type").equals("landmark")).toList();
            check(rooms.size()==4,"four story sites");
            check(rooms.stream().map(room->room.getString("template")).collect(java.util.stream.Collectors.toSet())
                .equals(java.util.Set.of("lab","celltower","hospital","church")),"original Spore templates");
            for(var room:rooms){
                var origin=new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z"));
                check(zone.isEmptyBlock(origin.north(3))&&zone.isEmptyBlock(origin.north(3).above()),"open story approach");
                check(!PersonalLoot.templateItem(zone,origin.south(4),3).isEmpty(),"story loot and journal");
            }
            for(long node:state.missionNodes)
                check(zone.getBlockState(BlockPos.of(node)).is(Blocks.LODESTONE),"template mission node");
            check(zone.getBlockState(BlockPos.of(state.cargoStation)).is(Blocks.LODESTONE),"template cargo node");
            var landmarks=allRooms.stream().filter(room->room.getString("type").equals("landmark")).toList();
            check(landmarks.size()==ZoneLandmarks.COUNT,"five zone landmarks");
            check(landmarks.stream().filter(room->room.getString("template").startsWith("kaisyn:")).count()==2,"two imported forest landmarks");
            check(landmarks.stream().allMatch(room->!PersonalLoot.templateItem(zone,
                new BlockPos(room.getInt("x"),room.getInt("y"),room.getInt("z")),4).isEmpty()),"landmark caches stocked");
            System.out.println("RELAY_SPORE_STORY_PASS");
        }
        System.out.println("RELAY_016_LIVE_PASS retained_terrain=true rebuilt_structure=true running=true");
        server.halt(false);
    }

    private static void check(boolean value,String message){if(!value)throw new IllegalStateException("LIVE_REFRESH "+message);}
    private LiveRefreshTest(){}
}
