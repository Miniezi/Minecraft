package dev.bunkerrelay;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
public final class RelayState extends SavedData {
 public boolean initialized,generating,ready,hubV2,legacyAvailable;
 public int difficulty=1,loot=1,generation,size=4096,nextSector;
 public String theme="industrial",activeDimension="expedition",activeTheme="industrial";
 public int activeDifficulty=1,activeLoot=1,activeSize=188,centerX,centerZ,spawnY=31;
 public CompoundTag structureLevels=new CompoundTag(),structureLayouts=new CompoundTag();
 public boolean fixedRaidLight,nightRaid;
 public CompoundTag lightOffers=new CompoundTag(),routeEvent=new CompoundTag();
 public CompoundTag fieldRoutes=new CompoundTag(), scoutMap=new CompoundTag();
 public CompoundTag expeditionPlots=new CompoundTag(),roadChunks=new CompoundTag();
 public long structureSeed;
 public int structureRadioDifficulty;
 public long seed,annexOrigin,workshopOrigin;
 public int layoutVersion;
 public boolean annexBuilt,workshopBuilt,variableStories,sectorBuildings;
 public int bossY,bossGeneration=-1,bossAbility;public java.util.UUID bossId,previousBoss;public boolean bossDefeated;
 public int exitSignalY,exitSignalGeneration=-1;
 public int relayX,relayY,relayZ,raidRulesVersion;public boolean relayPowered;
 public boolean cargoAvailable,cargoDelivered;
 public long cargoStation,cargoAt;
 public java.util.UUID cargoCarrier;
 public int research;
 public CompoundTag bunkerRequests=new CompoundTag();
 public int baseUpgrades,reserveSeconds=120;
 public String powerSource="off";
 public int mission,missionProgress,missionSeconds;
 public boolean missionStarted;
 public long[] missionNodes=new long[0];
 public final java.util.Set<Long> caches=new java.util.HashSet<>();
 public static RelayState get(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(RelayState::new,RelayState::load),"bunkerrelay");}
 private static RelayState load(CompoundTag t,HolderLookup.Provider r){
  RelayState s=new RelayState();s.bossY=t.getInt("bossY");s.bossGeneration=t.contains("bossGeneration")?t.getInt("bossGeneration"):-1;s.bossAbility=t.getInt("bossAbility");s.bossDefeated=t.getBoolean("bossDefeated");s.bossId=t.hasUUID("bossId")?t.getUUID("bossId"):null;s.exitSignalY=t.getInt("exitSignalY");s.exitSignalGeneration=t.contains("exitSignalGeneration")?t.getInt("exitSignalGeneration"):-1;s.initialized=t.getBoolean("initialized");s.generating=t.getBoolean("generating");s.ready=t.getBoolean("ready");s.hubV2=t.getBoolean("hubV2");s.legacyAvailable=t.contains("legacyAvailable")?t.getBoolean("legacyAvailable"):s.initialized&&!s.hubV2;
  s.difficulty=Math.clamp(t.getInt("difficulty"),1,5);s.loot=Math.clamp(t.getInt("loot"),1,5);s.generation=t.getInt("generation");s.seed=t.getLong("seed");
  String theme=t.getString("theme");s.theme=java.util.Set.of("industrial","ash","infected","forest").contains(theme)?theme:"industrial";
  s.activeDifficulty=s.difficulty;s.activeLoot=s.loot;s.activeTheme=s.theme;
  if(t.contains("activeDimension")){
   s.activeDimension=t.getString("activeDimension");s.activeTheme=t.getString("activeTheme");s.activeDifficulty=Math.clamp(t.getInt("activeDifficulty"),1,5);s.activeLoot=Math.clamp(t.getInt("activeLoot"),1,5);
   s.activeSize=t.getInt("activeSize");s.centerX=t.getInt("centerX");s.centerZ=t.getInt("centerZ");s.spawnY=t.getInt("spawnY");s.nextSector=Math.max(0,t.getInt("nextSector"));
  }
  s.relayX=t.getInt("relayX");s.relayY=t.getInt("relayY");s.relayZ=t.getInt("relayZ");s.raidRulesVersion=t.getInt("raidRulesVersion");s.relayPowered=t.getBoolean("relayPowered");
  if(t.contains("reserveSeconds"))s.reserveSeconds=Math.clamp(t.getInt("reserveSeconds"),0,1800);
  s.research=t.getInt("research");s.cargoAvailable=t.getBoolean("cargoAvailable");s.cargoDelivered=t.getBoolean("cargoDelivered");
  s.cargoStation=t.getLong("cargoStation");s.cargoAt=t.getLong("cargoAt");s.cargoCarrier=t.hasUUID("cargoCarrier")?t.getUUID("cargoCarrier"):null;
  s.previousBoss=t.hasUUID("previousBoss")?t.getUUID("previousBoss"):null;
  s.fixedRaidLight=t.getBoolean("fixedRaidLight");s.nightRaid=t.getBoolean("nightRaid");
  s.lightOffers=t.getCompound("lightOffers").copy();s.routeEvent=t.getCompound("routeEvent").copy();
  s.fieldRoutes=t.getCompound("fieldRoutes").copy();s.scoutMap=t.getCompound("scoutMap").copy();
  s.structureLevels=t.getCompound("structureLevels").copy();s.structureLayouts=t.getCompound("structureLayouts").copy();
  s.expeditionPlots=t.getCompound("expeditionPlots");s.roadChunks=t.getCompound("roadChunks");
  s.structureSeed=t.getLong("structureSeed");s.structureRadioDifficulty=t.getInt("structureRadioDifficulty");
  s.layoutVersion=t.getInt("layoutVersion");s.annexBuilt=t.getBoolean("annexBuilt");s.annexOrigin=t.getLong("annexOrigin");
  s.sectorBuildings=t.getBoolean("sectorBuildings");
  s.variableStories=t.getBoolean("variableStories");
  s.workshopBuilt=t.getBoolean("workshopBuilt");s.workshopOrigin=t.getLong("workshopOrigin");
  s.bunkerRequests=t.getCompound("bunkerRequests");
  s.baseUpgrades=t.getInt("baseUpgrades");
  s.mission=t.getInt("mission");s.missionProgress=t.getInt("missionProgress");s.missionSeconds=t.getInt("missionSeconds");
  s.missionStarted=t.getBoolean("missionStarted");s.missionNodes=t.getLongArray("missionNodes");
  for(long cache:t.getLongArray("caches"))s.caches.add(cache);
  if(SectorPlan.validSize(t.getInt("size")))s.size=t.getInt("size");return s;
 }
 @Override public CompoundTag save(CompoundTag t,HolderLookup.Provider r){
  t.putInt("exitSignalY",exitSignalY);t.putInt("exitSignalGeneration",exitSignalGeneration);t.putInt("bossY",bossY);t.putInt("bossGeneration",bossGeneration);t.putInt("bossAbility",bossAbility);t.putBoolean("bossDefeated",bossDefeated);if(bossId!=null)t.putUUID("bossId",bossId);t.putInt("relayX",relayX);t.putInt("relayY",relayY);t.putInt("relayZ",relayZ);t.putInt("raidRulesVersion",raidRulesVersion);t.putBoolean("relayPowered",relayPowered);
  t.putInt("reserveSeconds",reserveSeconds);
  t.putInt("research",research);t.putBoolean("cargoAvailable",cargoAvailable);t.putBoolean("cargoDelivered",cargoDelivered);
  t.putLong("cargoStation",cargoStation);t.putLong("cargoAt",cargoAt);if(cargoCarrier!=null)t.putUUID("cargoCarrier",cargoCarrier);else t.remove("cargoCarrier");
  if(previousBoss!=null)t.putUUID("previousBoss",previousBoss);
  t.putBoolean("fixedRaidLight",fixedRaidLight);t.putBoolean("nightRaid",nightRaid);
  t.put("lightOffers",lightOffers.copy());t.put("routeEvent",routeEvent.copy());
  t.put("fieldRoutes",fieldRoutes.copy());t.put("scoutMap",scoutMap.copy());
  t.put("structureLevels",structureLevels.copy());t.put("structureLayouts",structureLayouts.copy());
  t.put("expeditionPlots",expeditionPlots);t.put("roadChunks",roadChunks);
  t.putLong("structureSeed",structureSeed);t.putInt("structureRadioDifficulty",structureRadioDifficulty);
  t.putInt("layoutVersion",layoutVersion);t.putBoolean("annexBuilt",annexBuilt);t.putLong("annexOrigin",annexOrigin);
  t.putBoolean("sectorBuildings",sectorBuildings);
  t.putBoolean("variableStories",variableStories);
  t.putBoolean("workshopBuilt",workshopBuilt);t.putLong("workshopOrigin",workshopOrigin);
  t.put("bunkerRequests",bunkerRequests.copy());
  t.putInt("baseUpgrades",baseUpgrades);
  t.putInt("mission",mission);t.putInt("missionProgress",missionProgress);t.putInt("missionSeconds",missionSeconds);
  t.putBoolean("missionStarted",missionStarted);t.putLongArray("missionNodes",missionNodes);
  t.putLongArray("caches",caches.stream().mapToLong(Long::longValue).toArray());
  t.putBoolean("initialized",initialized);t.putBoolean("generating",generating);t.putBoolean("ready",ready);t.putBoolean("hubV2",hubV2);t.putBoolean("legacyAvailable",legacyAvailable);
  t.putInt("difficulty",difficulty);t.putInt("loot",loot);t.putInt("generation",generation);t.putLong("seed",seed);t.putString("theme",theme);t.putInt("size",size);t.putInt("nextSector",nextSector);
  t.putString("activeDimension",activeDimension);t.putString("activeTheme",activeTheme);t.putInt("activeDifficulty",activeDifficulty);t.putInt("activeLoot",activeLoot);t.putInt("activeSize",activeSize);t.putInt("centerX",centerX);t.putInt("centerZ",centerZ);t.putInt("spawnY",spawnY);return t;
 }
}
