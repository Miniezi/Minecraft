package dev.bunkerrelay;
public final class RaidBalance {public static int lootTier(int difficulty,int offset){return Math.clamp(difficulty+Math.clamp(offset,-1,1),1,5);}private RaidBalance(){}}
