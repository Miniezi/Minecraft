package dev.bunkerrelay;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
/** A reversible staging container until removed(): only its 27 slots are then destroyed. */
public final class TrashMenu extends ChestMenu {
 private final ServerPlayer owner;private final SimpleContainer trash;private boolean closed;
 public static int open(ServerPlayer p){p.openMenu(new SimpleMenuProvider((id,inv,player)->new TrashMenu(id,inv,p),Component.literal("Корзина — удаление при закрытии")));RaidRules.tell(p,"Положите ненужное в верхние 27 слотов. До закрытия можно забрать обратно. Закрытие, отключение или смерть удаляют содержимое корзины.");return 1;}
 public TrashMenu(int id,Inventory inv,ServerPlayer p){this(id,inv,p,new SimpleContainer(27));}
 private TrashMenu(int id,Inventory inv,ServerPlayer p,SimpleContainer c){super(MenuType.GENERIC_9x3,id,inv,c,3);owner=p;trash=c;TrashRecovery.checkpoint(p,trash,getCarried());}
 @Override public void clicked(int slot,int button,ClickType type,Player p){if(closed||p!=owner)return;super.clicked(slot,button,type,p);TrashRecovery.checkpoint(owner,trash,getCarried());}
 @Override public void broadcastChanges(){if(owner!=null&&!closed)TrashRecovery.checkpoint(owner,trash,getCarried());super.broadcastChanges();}
 @Override public boolean stillValid(Player p){return !closed&&p==owner;}
 @Override public void removed(Player p){if(closed)return;closed=true;TrashRecovery.closed(owner);for(int i=0;i<trash.getContainerSize();i++)PdaProtection.retain(owner,trash.getItem(i));trash.clearContent();if(p instanceof ServerPlayer server){var cursor=getCarried();setCarried(ItemStack.EMPTY);SafeInventory.returnCarried(server,cursor);}super.removed(p);}
}
