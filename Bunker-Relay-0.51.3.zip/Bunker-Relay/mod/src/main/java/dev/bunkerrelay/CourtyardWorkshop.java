package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;

final class CourtyardWorkshop {
    static boolean install(ServerLevel level,RelayState state){
        if(state.workshopBuilt)return true;
        // Both plot and approach must be clear so migration never opens a hole in a player's build.
        for(int x:new int[]{-18,18})for(int z:new int[]{-19,-3,-24}){
            var origin=new BlockPos(x,95,z);
            if(!clear(level,origin)||!clearPath(level,origin))continue;
            build(level,origin);
            path(level,origin);
            state.workshopBuilt=true;
            state.workshopOrigin=origin.asLong();
            state.setDirty();
            return true;
        }
        return false;
    }

    private static boolean clear(ServerLevel level,BlockPos origin){
        for(int x=-8;x<=8;x++)for(int z=-5;z<=5;z++){
            if(!level.getBlockState(origin.offset(x,0,z)).is(Blocks.GRASS_BLOCK))return false;
            for(int y=1;y<=7;y++)if(!level.isEmptyBlock(origin.offset(x,y,z)))return false;
        }
        for(int x=-5;x<=5;x++)if(!level.isEmptyBlock(origin.offset(x,5,6)))return false;
        return level.isEmptyBlock(origin.offset(-3,1,6));
    }

    private static boolean clearPath(ServerLevel level,BlockPos origin){
        int end=origin.getX()<0?-3:3;
        for(int x=Math.min(origin.getX(),end);x<=Math.max(origin.getX(),end);x++)
            for(int z=7;z<=9;z++)for(int y=1;y<=2;y++)
                if(!level.isEmptyBlock(new BlockPos(x,origin.getY()+y,origin.getZ()+z)))return false;
        for(int x=-1;x<=1;x++)for(int z=6;z<=9;z++)for(int y=1;y<=2;y++)
            if(!level.isEmptyBlock(origin.offset(x,y,z)))return false;
        return true;
    }

    private static void build(ServerLevel level,BlockPos origin){
        for(int x=-8;x<=8;x++)for(int z=-5;z<=5;z++){
            put(level,origin.offset(x,0,z),Math.abs(x)<=1?Blocks.SMOOTH_STONE:Blocks.POLISHED_ANDESITE);
            put(level,origin.offset(x,5,z),Blocks.DEEPSLATE_TILES);
            if(Math.abs(x)==8||Math.abs(z)==5)for(int y=1;y<=4;y++){
                if(z==5&&Math.abs(x)<=1&&y<=3)continue;
                var block=y==1?Blocks.POLISHED_DEEPSLATE:y==3&&Math.abs(x)%3==1?Blocks.GLASS:Blocks.LIGHT_GRAY_CONCRETE;
                put(level,origin.offset(x,y,z),block);
            }
        }
        for(int x=-5;x<=5;x++)for(int z=2;z<=6;z++)
            put(level,origin.offset(x,5,z),x%4==0?Blocks.SEA_LANTERN:Blocks.COPPER_BLOCK);
        for(int x=-1;x<=1;x++){
            put(level,origin.offset(x,4,5),Blocks.YELLOW_CONCRETE);
            put(level,origin.offset(x,0,5),Blocks.YELLOW_CONCRETE);
        }
        for(int x:new int[]{-6,6}){
            put(level,origin.offset(x,1,-3),Blocks.BARREL);
            put(level,origin.offset(x,1,1),Blocks.CRAFTING_TABLE);
            put(level,origin.offset(x,4,1),Blocks.SEA_LANTERN);
        }
        put(level,origin.offset(0,1,-3),Blocks.SMITHING_TABLE);
        put(level,origin.offset(2,1,-3),Blocks.ANVIL);
        put(level,origin.offset(-2,1,-3),Blocks.BLAST_FURNACE);
        var signPos=origin.offset(-3,1,6);
        if(level.getBlockState(signPos.below()).isFaceSturdy(level,signPos.below(),net.minecraft.core.Direction.UP)){
            level.setBlock(signPos,Blocks.SPRUCE_SIGN.defaultBlockState().setValue(StandingSignBlock.ROTATION,0),3);
            if(level.getBlockEntity(signPos) instanceof SignBlockEntity sign)
                sign.setText(new SignText().setMessage(1,Component.literal("МАСТЕРСКАЯ")),true);
        }
    }

    private static void path(ServerLevel level,BlockPos origin){
        int end=origin.getX()<0?-3:3;
        for(int x=Math.min(origin.getX(),end);x<=Math.max(origin.getX(),end);x++)
            for(int z=7;z<=9;z++)pave(level,new BlockPos(x,origin.getY(),origin.getZ()+z));
        for(int x=-1;x<=1;x++)for(int z=6;z<=9;z++)pave(level,origin.offset(x,0,z));
    }

    private static void pave(ServerLevel level,BlockPos pos){
        if(level.getBlockState(pos).is(Blocks.GRASS_BLOCK))put(level,pos,Blocks.STONE_BRICKS);
    }

    static BlockPos entrance(RelayState state){return BlockPos.of(state.workshopOrigin).offset(0,1,5);}
    static BlockPos bench(RelayState state){return BlockPos.of(state.workshopOrigin).offset(0,1,-3);}

    static boolean nearby(ServerPlayer player,RelayState state){
        return state.workshopBuilt&&RelayEconomy.safe(player)&&player.level().dimension().equals(BunkerRelay.HUB)
            &&player.blockPosition().distSqr(bench(state))<=36;
    }

    static String hint(ServerPlayer player,RelayState state){
        if(!state.workshopBuilt)return "Площадка пока недоступна";
        var door=entrance(state);
        return nearby(player,state)?"Открыть верстак":"Двор, "+(door.getX()<0?"западная":"восточная")+" сторона · "+door.toShortString();
    }

    static int useOrLocate(ServerPlayer player){
        var state=RelayState.get(player.server);
        if(!nearby(player,state)){
            RaidRules.tell(player,hint(player,state));
            return 0;
        }
        player.openMenu(new SimpleMenuProvider((id,inv,ignored)->new WorkshopMenu(id,inv,player),
            Component.literal("Мастерская")));
        return 1;
    }

    private static void put(ServerLevel level,BlockPos pos,Block block){level.setBlock(pos,block.defaultBlockState(),2);}
    private CourtyardWorkshop(){}
}
