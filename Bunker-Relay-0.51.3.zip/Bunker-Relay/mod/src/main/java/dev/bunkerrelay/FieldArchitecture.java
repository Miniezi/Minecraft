package dev.bunkerrelay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.levelgen.Heightmap;

final class FieldArchitecture {
    static void extraction(ServerLevel level,BlockPos origin,boolean backup){
        int width=backup?4:5;
        Block marking=backup?Blocks.ORANGE_CONCRETE:Blocks.LIGHT_BLUE_CONCRETE;
        platform(level,origin,width,Blocks.POLISHED_ANDESITE,marking);
        for(int side:new int[]{-1,1}){
            for(int z:new int[]{-width,width}){
                int x=side*(width-1);
                for(int y=0;y<3;y++)put(level,origin,x,y,z,Blocks.DEEPSLATE_BRICKS);
                put(level,origin,x,3,z,Blocks.SEA_LANTERN);
            }
            for(int z=-width+1;z<width;z++)put(level,origin,side*width,0,z,Blocks.IRON_BARS);
            for(int y=0;y<4;y++)put(level,origin,side*2,y,2,marking);
        }
        for(int x=-2;x<=2;x++)put(level,origin,x,3,2,marking);
        put(level,origin,0,3,2,Blocks.SEA_LANTERN);
        // An illuminated landing cross can be read from the arrival path and from above.
        for(int i=-width+1;i<width;i++){
            put(level,origin,i,-1,0,Math.abs(i)==2?Blocks.SEA_LANTERN:marking);
            put(level,origin,0,-1,i,marking);
        }
        finish(level,origin,width,Blocks.POLISHED_ANDESITE);
        if(backup)SurfacePlacement.approach(level,origin.south(width+1),Direction.SOUTH);
    }

    static void substation(ServerLevel level,BlockPos origin){
        platform(level,origin,4,Blocks.SMOOTH_STONE,Blocks.YELLOW_CONCRETE);
        for(int side:new int[]{-1,1}){
            for(int z=-3;z<=-1;z++){
                put(level,origin,side*3,0,z,Blocks.CUT_COPPER);
                put(level,origin,side*3,1,z,Blocks.WAXED_EXPOSED_CUT_COPPER);
            }
            for(int y=2;y<=5;y++)put(level,origin,side*3,y,-2,Blocks.IRON_BARS);
            put(level,origin,side*3,6,-2,Blocks.COPPER_BLOCK);
        }
        for(int x=-3;x<=3;x++)put(level,origin,x,5,-2,Blocks.IRON_BARS);
        put(level,origin,0,5,-2,Blocks.SEA_LANTERN);
        finish(level,origin,4,Blocks.SMOOTH_STONE);
    }

    static void vault(ServerLevel level,BlockPos origin){
        platform(level,origin,4,Blocks.POLISHED_DEEPSLATE,Blocks.GREEN_CONCRETE);
        for(int x=-3;x<=3;x++){
            for(int y=0;y<3;y++)put(level,origin,x,y,-4,Blocks.DEEPSLATE_BRICKS);
            for(int z=-4;z<=1;z++)put(level,origin,x,3,z,Blocks.DEEPSLATE_TILES);
        }
        for(int side:new int[]{-1,1}){
            for(int z=-3;z<=1;z++)for(int y=0;y<3;y++)
                put(level,origin,side*3,y,z,y==1?Blocks.TINTED_GLASS:Blocks.DEEPSLATE_BRICKS);
            put(level,origin,side*2,2,1,Blocks.SEA_LANTERN);
        }
        for(int x=-2;x<=2;x++)put(level,origin,x,3,1,Blocks.GREEN_CONCRETE);
        finish(level,origin,4,Blocks.POLISHED_DEEPSLATE);
        put(level,origin,0,0,-2,Blocks.IRON_BLOCK);
    }

    static void radio(ServerLevel level,BlockPos origin){
        platform(level,origin,3,Blocks.POLISHED_ANDESITE,Blocks.CYAN_CONCRETE);
        for(int x=-3;x<=3;x++)for(int y=0;y<3;y++)
            put(level,origin,x,y,-3,y==1&&Math.abs(x)<3?Blocks.CYAN_STAINED_GLASS:Blocks.GRAY_CONCRETE);
        for(int side:new int[]{-1,1}){
            put(level,origin,side*3,0,-2,Blocks.GRAY_CONCRETE);
            put(level,origin,side*3,1,-2,Blocks.GRAY_CONCRETE);
            put(level,origin,side*3,2,-2,Blocks.SEA_LANTERN);
        }
        for(int y=0;y<5;y++)put(level,origin,2,y,2,Blocks.IRON_BARS);
        for(int x=0;x<=3;x++)put(level,origin,x,4,2,Blocks.IRON_BARS);
        put(level,origin,2,5,2,Blocks.SEA_LANTERN);
        finish(level,origin,3,Blocks.POLISHED_ANDESITE);
    }

    private static void platform(ServerLevel level,BlockPos origin,int width,Block floor,Block marking){
        for(int x=-width;x<=width;x++)for(int z=-width;z<=width;z++){
            boolean painted=Math.abs(x)==width||Math.abs(z)==width||(x==0&&z>=1);
            put(level,origin,x,-1,z,painted?marking:floor);
            for(int y=0;y<4;y++)put(level,origin,x,y,z,Blocks.AIR);
        }
    }

    private static void finish(ServerLevel level,BlockPos origin,int width,Block support){
        put(level,origin,0,0,0,Blocks.LODESTONE);
        var approach=origin.south(width+1);
        var chunk=level.getChunkAt(approach);
        int ground=chunk.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,approach.getX()&15,approach.getZ()&15)+1;
        for(int y=ground;y<origin.getY();y++){
            var rung=approach.atY(y);
            level.setBlock(rung.north(),support.defaultBlockState(),2);
            level.setBlock(rung,Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING,Direction.SOUTH),2);
        }
    }

    private static void put(ServerLevel level,BlockPos origin,int x,int y,int z,Block block){
        level.setBlock(origin.offset(x,y,z),block.defaultBlockState(),2);
    }

    private FieldArchitecture(){}
}
