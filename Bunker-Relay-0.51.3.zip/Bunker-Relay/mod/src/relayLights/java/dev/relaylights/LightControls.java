package dev.relaylights;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid=RelayLights.ID,value=Dist.CLIENT)
final class LightControls {
    private static final KeyMapping LIGHT=new KeyMapping("key.relaylights.light",InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_K,"key.categories.relaylights");
    private static final KeyMapping MODE=new KeyMapping("key.relaylights.mode",InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_O,"key.categories.relaylights");
    private static final java.util.prefs.Preferences OPTIONS=java.util.prefs.Preferences.userRoot().node("dev/relaylights");
    private static boolean shared=OPTIONS.getBoolean("shared",false);
    private static boolean on,sent;

    @EventBusSubscriber(modid=RelayLights.ID,value=Dist.CLIENT,bus=EventBusSubscriber.Bus.MOD)
    public static final class Registration {
        @SubscribeEvent public static void keys(RegisterKeyMappingsEvent event){event.register(LIGHT);event.register(MODE);}
    }

    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        var mc=Minecraft.getInstance();
        if(mc.player==null)return;
        int tick=++LightNetwork.clientTick;
        LightNetwork.CLIENT.values().removeIf(expires->expires<tick);
        while(MODE.consumeClick()){
            if(mc.screen!=null)continue;
            shared=!shared;
            OPTIONS.putBoolean("shared",shared);
            mc.player.displayClientMessage(Component.translatable(shared?"relaylights.shared":"relaylights.local"),true);
        }
        while(LIGHT.consumeClick()){
            if(mc.screen!=null)continue;
            if(RelayLights.strength(mc.player)>0)on=!on;
            else mc.player.displayClientMessage(Component.translatable("relaylights.no_light"),true);
        }
        if(mc.player.isSpectator()||!mc.player.isAlive()||RelayLights.strength(mc.player)==0)on=false;
        boolean send=on&&shared;
        if(send!=sent||send&&tick%12==0){
            PacketDistributor.sendToServer(new LightNetwork.Toggle(send));
            sent=send;
        }
    }

    static boolean on(){return on;}

    @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut event){
        on=false;sent=false;
        LightNetwork.CLIENT.clear();
        BeamRenderer.close();
    }

    private LightControls(){}
}
