package dev.relaylights;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import java.io.IOException;
import java.util.Comparator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL30;

@EventBusSubscriber(modid=RelayLights.ID,value=Dist.CLIENT)
public final class BeamRenderer {
    private static final int MAX_LIGHTS=4;
    private static final float RANGE=22;
    private static final ResourceLocation EMPTY=ResourceLocation.parse("relaylights:shaders/post/beam.json");
    private static PostChain chain;
    private static PostPass beam;
    private static RenderTarget source;
    private static Object resources;
    private static int width,height;
    private static boolean failed;

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void draw(RenderLevelStageEvent event){
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_LEVEL)return;
        var mc=Minecraft.getInstance();
        if(mc.level==null||mc.player==null||!LightControls.on()&&LightNetwork.CLIENT.isEmpty())return;
        var camera=event.getCamera().getPosition();
        var peers=mc.level.players().stream()
            .filter(p->p!=mc.player&&LightNetwork.CLIENT.containsKey(p.getId())&&p.distanceToSqr(camera)<40*40)
            .sorted(Comparator.comparingDouble(p->p.distanceToSqr(camera))).limit(MAX_LIGHTS).toList();
        if(!LightControls.on()&&peers.isEmpty())return;
        try{
            setup(mc);
            if(failed)return;
            var shader=beam.getEffect();
            shader.safeGetUniform("InverseProjection").set(new Matrix4f(event.getProjectionMatrix()).invert());
            shader.safeGetUniform("SceneProjection").set(event.getProjectionMatrix());
            int count=0;
            if(LightControls.on())setLight(event,mc.player,count++);
            for(var player:peers){
                if(count>=MAX_LIGHTS)break;
                if(RelayLights.strength(player)>0)setLight(event,player,count++);
            }
            if(count==0)return;
            shader.safeGetUniform("LightCount").set(count);
            chain.process(0);
            var lit=chain.getTempTarget("lit");
            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,lit.frameBufferId);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,source.frameBufferId);
            GlStateManager._glBlitFrameBuffer(0,0,width,height,0,0,width,height,GL30.GL_COLOR_BUFFER_BIT,GL30.GL_NEAREST);
        }catch(IOException|RuntimeException error){
            close();
            resources=mc.getResourceManager();
            failed=true;
            com.mojang.logging.LogUtils.getLogger().warn("Relay Lights could not render the beam",error);
        }finally{
            mc.getMainRenderTarget().bindWrite(true);
        }
    }

    private static void setup(Minecraft mc)throws IOException{
        var target=mc.getMainRenderTarget();
        if(resources!=mc.getResourceManager()||source!=null&&source!=target){
            close();
            resources=mc.getResourceManager();
        }
        if(failed)return;
        if(chain==null){
            source=target;
            chain=new PostChain(mc.getTextureManager(),mc.getResourceManager(),target,EMPTY);
            chain.addTempTarget("lit",target.width,target.height);
            beam=chain.addPass("relaylights:beam",target,chain.getTempTarget("lit"),false);
            beam.addAuxAsset("DepthSampler",target::getDepthTextureId,target.width,target.height);
            width=0;
        }
        if(width!=target.width||height!=target.height){
            width=target.width;height=target.height;
            chain.resize(width,height);
        }
    }

    private static void setLight(RenderLevelStageEvent event,Player player,int index){
        float partial=event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Vec3 direction=player.getViewVector(partial);
        Vec3 origin=player.getEyePosition(partial);
        if (player == Minecraft.getInstance().player && Minecraft.getInstance().options.getCameraType().isFirstPerson()) {
            origin = event.getCamera().getPosition();
        }
        Vec3 offset=origin.subtract(event.getCamera().getPosition());
        var position=event.getModelViewMatrix().transformDirection(new Vector3f((float)offset.x,(float)offset.y,(float)offset.z));
        var angle=event.getModelViewMatrix().transformDirection(new Vector3f((float)direction.x,(float)direction.y,(float)direction.z));
        beam.getEffect().safeGetUniform("Origin"+index).set(position.x,position.y,position.z,RANGE);
        beam.getEffect().safeGetUniform("Direction"+index).set(angle.x,angle.y,angle.z,RelayLights.strength(player));
    }

    static void close(){
        if(chain!=null)chain.close();
        chain=null;beam=null;source=null;failed=false;
    }

    private BeamRenderer(){}
}
