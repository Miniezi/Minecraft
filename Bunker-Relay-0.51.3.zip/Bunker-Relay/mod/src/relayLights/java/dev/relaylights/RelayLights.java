package dev.relaylights;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(RelayLights.ID)
public final class RelayLights {
    public static final String ID="relaylights";
    private static final ResourceLocation LEGACY=ResourceLocation.parse("bunkerrelay:field_flashlight");
    private static final DeferredRegister.Items ITEMS=DeferredRegister.createItems(ID);
    public static final java.util.function.Supplier<Item> FLASHLIGHT=ITEMS.register("flashlight",
        ()->new Item(new Item.Properties().stacksTo(1)));

    public RelayLights(IEventBus bus){
        ITEMS.register(bus);
        bus.addListener(RelayLights::addCreativeItems);
        bus.addListener(LightNetwork::register);
        NeoForge.EVENT_BUS.addListener(LightNetwork::tick);
    }

    private static void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (CreativeModeTabs.TOOLS_AND_UTILITIES.equals(event.getTabKey())) {
            event.accept(FLASHLIGHT.get());
        }
    }

    public static float strength(Player player){
        for(var stack:new net.minecraft.world.item.ItemStack[]{player.getMainHandItem(),player.getOffhandItem()}){
            if(stack.is(FLASHLIGHT.get())||BuiltInRegistries.ITEM.getKey(stack.getItem()).equals(LEGACY))return 1;
        }
        return ModList.get().isLoaded("tacz")&&TaCZLight.hasModule(player.getMainHandItem())?.85f:0;
    }
}
