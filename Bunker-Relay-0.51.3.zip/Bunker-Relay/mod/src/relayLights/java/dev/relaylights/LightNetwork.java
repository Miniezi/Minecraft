package dev.relaylights;

import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

final class LightNetwork {
    record Toggle(boolean enabled) implements CustomPacketPayload {
        static final Type<Toggle> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(RelayLights.ID,"toggle"));
        static final StreamCodec<RegistryFriendlyByteBuf,Toggle> CODEC=StreamCodec.of(
            (buffer,value)->buffer.writeBoolean(value.enabled),buffer->new Toggle(buffer.readBoolean()));
        @Override public Type<Toggle> type(){return TYPE;}
    }

    record Signal(int entity,boolean enabled) implements CustomPacketPayload {
        static final Type<Signal> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(RelayLights.ID,"signal"));
        static final StreamCodec<RegistryFriendlyByteBuf,Signal> CODEC=StreamCodec.of(
            (buffer,value)->{buffer.writeVarInt(value.entity);buffer.writeBoolean(value.enabled);},
            buffer->new Signal(buffer.readVarInt(),buffer.readBoolean()));
        @Override public Type<Signal> type(){return TYPE;}
    }

    private static final Map<ServerPlayer,Long> ACTIVE=new WeakHashMap<>();
    static final Map<Integer,Integer> CLIENT=new HashMap<>();
    static int clientTick;

    static void register(RegisterPayloadHandlersEvent event){
        var registrar=event.registrar("1");
        registrar.playToServer(Toggle.TYPE,Toggle.CODEC,(value,context)->context.enqueueWork(()->{
            if(context.player() instanceof ServerPlayer player)toggle(player,value.enabled());
        }));
        registrar.playToClient(Signal.TYPE,Signal.CODEC,(value,context)->context.enqueueWork(()->{
            if(value.enabled())CLIENT.put(value.entity(),clientTick+24);
            else CLIENT.remove(value.entity());
        }));
    }

    static boolean eligible(ServerPlayer player){
        return player.isAlive()&&!player.isSpectator()&&RelayLights.strength(player)>0;
    }

    private static void toggle(ServerPlayer player,boolean enabled){
        if(enabled&&eligible(player))ACTIVE.put(player,player.server.getTickCount()+30L);
        else if(ACTIVE.remove(player)!=null)publish(player,false);
    }

    static void tick(ServerTickEvent.Post event){
        int tick=event.getServer().getTickCount();
        if(tick%8!=0)return;
        var iterator=ACTIVE.entrySet().iterator();
        while(iterator.hasNext()){
            var entry=iterator.next();
            var player=entry.getKey();
            if(player.hasDisconnected()){iterator.remove();continue;}
            if(tick>entry.getValue()||!eligible(player)){
                iterator.remove();
                publish(player,false);
            }else publish(player,true);
        }
    }

    private static void publish(ServerPlayer player,boolean enabled){
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,new Signal(player.getId(),enabled));
    }

    private LightNetwork(){}
}
