package dev.relaylights;

import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import net.minecraft.world.item.ItemStack;

final class TaCZLight {
    static boolean hasModule(ItemStack stack){
        if(!(stack.getItem() instanceof IGun gun))return false;
        var laser=gun.getAttachmentId(stack,AttachmentType.LASER);
        return laser!=null&&laser.getNamespace().equals("tacz")
            &&(laser.getPath().equals("laser_peq15")||laser.getPath().equals("laser_ngal"));
    }

    private TaCZLight(){}
}
