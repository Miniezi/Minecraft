#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform mat4 InverseProjection;
uniform mat4 SceneProjection;
uniform int LightCount;
uniform vec4 Origin0, Origin1, Origin2, Origin3;
uniform vec4 Direction0, Direction1, Direction2, Direction3;

in vec2 texCoord;
out vec4 fragColor;

// First-person visibility already comes from the scene depth buffer. For a
// displaced lamp, sample the visible geometry between it and this fragment.
float visibility(vec3 lamp, vec3 surface) {
    if (dot(lamp, lamp) < 0.0001) return 1.0;
    float visibilityFactor = 1.0;
    for (int i = 1; i <= 16; ++i) {
        vec3 probe = mix(lamp, surface, float(i) / 17.0);
        vec4 clip = SceneProjection * vec4(probe, 1.0);
        if (clip.w <= 0.0) continue;
        vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (any(lessThan(uv, vec2(0))) || any(greaterThanEqual(uv, vec2(1)))) continue;
        float depth = texture(DepthSampler, uv).r;
        vec4 hit = InverseProjection * vec4(clip.xy / clip.w, depth * 2.0 - 1.0, 1.0);
        float gap = hit.z / hit.w - probe.z;
        // Only nearby depth crossings cast a shadow. Unrelated foreground
        // objects must not blank an entire teammate's beam.
        float block = smoothstep(0.04, 0.12, gap) * (1.0 - smoothstep(0.35, 0.75, gap));
        visibilityFactor = min(visibilityFactor, 1.0 - block);
    }
    return visibilityFactor;
}

float spot(vec3 surface,vec4 origin,vec4 direction) {
    vec3 toSurface=surface-origin.xyz;
    float distanceSquared=dot(toSurface,toSurface);
    if(distanceSquared<0.03 || distanceSquared>origin.w*origin.w)return 0.0;
    float distanceToLamp=sqrt(distanceSquared);
    float alignment=dot(toSurface/distanceToLamp,direction.xyz);
    float cone=smoothstep(0.91,0.987,alignment);
    if (cone <= 0.0) return 0.0;
    float edge=1.0-smoothstep(max(0.0,origin.w-0.65),origin.w,distanceToLamp);
    return visibility(origin.xyz,surface)*cone*edge*direction.w/(1.0+distanceSquared*0.015);
}

void main() {
    vec4 scene=texture(DiffuseSampler,texCoord);
    float depth=texture(DepthSampler,texCoord).r;
    if(depth>=0.999999){
        fragColor=scene;
        return;
    }
    vec4 projected=InverseProjection*vec4(texCoord*2.0-1.0,depth*2.0-1.0,1.0);
    vec3 surface=projected.xyz/projected.w;
    float light=spot(surface,Origin0,Direction0);
    if(LightCount>1)light+=spot(surface,Origin1,Direction1);
    if(LightCount>2)light+=spot(surface,Origin2,Direction2);
    if(LightCount>3)light+=spot(surface,Origin3,Direction3);
    vec3 lit=scene.rgb+vec3(1.0,0.96,0.84)*min(light,1.2)*sqrt(scene.rgb+vec3(0.055))*0.75;
    fragColor=vec4(min(lit,vec3(1.0)),scene.a);
}
